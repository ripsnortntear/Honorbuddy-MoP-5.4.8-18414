﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class106
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class106 : Class91
{
  private static DateTime dateTime_0;
  private static WoWAura woWAura_0;
  private static WoWUnit woWUnit_0;

  private static double Double_9 => (DateTime.UtcNow - Class106.dateTime_0).TotalSeconds;

  private static int Int32_4 => (int) (DateTime.UtcNow - Class43.dateTime_0).TotalSeconds;

  private static bool Boolean_21
  {
    get
    {
      HashSet<WoWUnit> woWunitSet = new HashSet<WoWUnit>()
      {
        Class91.WoWUnit_0,
        Class91.WoWUnit_1
      };
      if (Class91.Boolean_1)
        woWunitSet.UnionWith(Class91.IEnumerable_1.Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_1 => WoWObject.op_Inequality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_0) && WoWObject.op_Inequality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_1))));
      foreach (WoWUnit woWunit in woWunitSet)
      {
        Class106.Class131 class131 = new Class106.Class131();
        class131.woWUnit_0 = woWunit;
        if (!WoWObject.op_Equality((WoWObject) class131.woWUnit_0, (WoWObject) null) && ((WoWObject) class131.woWUnit_0).IsValid)
        {
          Class106.woWAura_0 = class131.woWUnit_0.smethod_0().FirstOrDefault<WoWAura>(new Func<WoWAura, bool>(class131.method_0));
          if (WoWAura.op_Inequality(Class106.woWAura_0, (WoWAura) null) && class131.woWUnit_0.IsTargetingMeOrPet && !class131.woWUnit_0.smethod_17() && !class131.woWUnit_0.smethod_0(Class68.Enum15.const_6) && !class131.woWUnit_0.smethod_0(Class68.Enum15.const_9) && (Class106.woWAura_0.SpellId != 126700 && Class106.woWAura_0.SpellId != 126707 || Class91.Double_3 <= 80.0 && class131.woWUnit_0.smethod_18() && Class106.Int32_4 <= 3))
          {
            Class106.woWUnit_0 = class131.woWUnit_0;
            return true;
          }
        }
      }
      return false;
    }
  }

  private static Composite Composite_0
  {
    get
    {
      if (Class106.canRunDecoratorDelegate_0 == null)
        Class106.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
      return Class77.smethod_2(113613, Class106.canRunDecoratorDelegate_0, "Symbiosis: Growl", (Action) (() =>
      {
        Class140.smethod_7("Symbiosis: Growl: " + Class106.woWAura_0.Name, Class140.struct24_2);
        Class106.dateTime_0 = DateTime.UtcNow;
      }));
    }
  }

  private static Composite Composite_1
  {
    get
    {
      if (Class106.canRunDecoratorDelegate_1 == null)
        Class106.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
      return Class77.smethod_2(74001, Class106.canRunDecoratorDelegate_1, "Combat Readiness", (Action) (() =>
      {
        Class140.smethod_7("Combat Readiness: " + Class106.woWAura_0.Name, Class140.struct24_2);
        Class106.dateTime_0 = DateTime.UtcNow;
      }));
    }
  }

  private static Composite Composite_2
  {
    get
    {
      if (Class106.canRunDecoratorDelegate_2 == null)
        Class106.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_10));
      return Class77.smethod_2(5277, Class106.canRunDecoratorDelegate_2, "Evasion", (Action) (() =>
      {
        Class140.smethod_7("Evasion: " + Class106.woWAura_0.Name, Class140.struct24_2);
        Class106.dateTime_0 = DateTime.UtcNow;
      }));
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class106.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class106.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_12));
    }
    // ISSUE: reference to a compiler-generated field
    return (Composite) new Decorator(Class106.canRunDecoratorDelegate_3, (Composite) new PrioritySelector(new Composite[3]
    {
      Class106.Composite_0,
      Class106.Composite_1,
      Class106.Composite_2
    }));
  }
}
