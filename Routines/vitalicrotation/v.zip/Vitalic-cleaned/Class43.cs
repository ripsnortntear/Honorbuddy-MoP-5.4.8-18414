﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class43
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class43
{
  private static bool bool_0;
  private static Class43.Delegate16 delegate16_0 = new Class43.Delegate16(Class62.smethod_0);
  public static DateTime dateTime_0;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static void Initialise() => Class43.Attach();

  public static void Attach()
  {
    if (Class43.bool_0)
      return;
    Class37.smethod_8(Class37.Types.SWING_DAMAGE, new Class37.Delegate11(Class43.smethod_1));
    Class37.smethod_8(Class37.Types.RANGE_DAMAGE, new Class37.Delegate11(Class43.smethod_1));
    Class37.smethod_8(Class37.Types.SPELL_DAMAGE, new Class37.Delegate11(Class43.smethod_1));
    Class37.smethod_8(Class37.Types.SPELL_PERIODIC_DAMAGE, new Class37.Delegate11(Class43.smethod_1));
    Class43.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class43.bool_0)
      return;
    Class37.smethod_9(Class37.Types.SWING_DAMAGE, new Class37.Delegate11(Class43.smethod_1));
    Class37.smethod_9(Class37.Types.RANGE_DAMAGE, new Class37.Delegate11(Class43.smethod_1));
    Class37.smethod_9(Class37.Types.SPELL_DAMAGE, new Class37.Delegate11(Class43.smethod_1));
    Class37.smethod_9(Class37.Types.SPELL_PERIODIC_DAMAGE, new Class37.Delegate11(Class43.smethod_1));
    Class43.bool_0 = false;
  }

  public static void Shutdown() => Class43.smethod_0();

  private static void smethod_1(EventArgs0 eventArgs0_0)
  {
    if ((eventArgs0_0.lazy_6.Value & Enum13.flag_13) == (Enum13) 0)
      return;
    int num;
    try
    {
      num = (int) (double) eventArgs0_0.Args[14];
    }
    catch (Exception ex)
    {
      return;
    }
    if (num <= 3000)
      return;
    Class43.dateTime_0 = DateTime.UtcNow;
  }

  private delegate void Delegate16(params object[] args);
}
