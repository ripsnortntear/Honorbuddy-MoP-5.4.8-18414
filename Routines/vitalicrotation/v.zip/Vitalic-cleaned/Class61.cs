﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class61
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class61
{
  private static DateTime dateTime_0 = DateTime.MinValue;
  private static DateTime dateTime_1;
  private static WoWObject woWObject_0;
  public static List<WoWClass> list_0 = new List<WoWClass>();
  private static Dictionary<WoWClass, HashSet<int>> dictionary_0 = new Dictionary<WoWClass, HashSet<int>>()
  {
    {
      (WoWClass) 4,
      new HashSet<int>() { 259, 260, 261 }
    },
    {
      (WoWClass) 3,
      new HashSet<int>() { 253, 254, (int) byte.MaxValue }
    }
  };
  public static WoWUnit woWUnit_0;
  private static DateTime dateTime_2;
  private static WoWUnit woWUnit_1;
  private static WoWUnit woWUnit_2;
  private static WoWPlayer woWPlayer_0;
  private static WoWUnit woWUnit_3;
  private static WoWUnit woWUnit_4;
  private static WoWUnit woWUnit_5;

  static Class61()
  {
    Class41.Event_0 += (EventHandler) ((sender, e) =>
    {
      Class61.list_0 = new List<WoWClass>();
      Class61.dateTime_0 = DateTime.MinValue;
    });
    Class144.Event_0 += (Class144.Delegate42) ((sender, e) =>
    {
      if (!Class61.Boolean_0)
        return;
      if (Class61.Boolean_3)
        Class61.dateTime_0 = DateTime.MinValue;
      else if (Class61.dateTime_0 == DateTime.MinValue)
        Class61.dateTime_0 = DateTime.UtcNow;
      if (!Class61.Boolean_3 || !(DateTime.UtcNow - Class61.dateTime_1 > TimeSpan.FromSeconds(2.0)) || (long) Class61.list_0.Count >= (long) Class61.LocalPlayer_0.GroupInfo.PartySize)
        return;
      using (StyxWoW.Memory.AcquireFrame())
      {
        for (int index = Class61.list_0.Count + 1; index <= 5; ++index)
        {
          int returnVal = Lua.GetReturnVal<int>($"return GetArenaOpponentSpec({index})", 0U);
          if (Class61.dictionary_0[(WoWClass) 4].Contains(returnVal))
            Class61.list_0.Add((WoWClass) 4);
          if (Class61.dictionary_0[(WoWClass) 3].Contains(returnVal))
            Class61.list_0.Add((WoWClass) 3);
        }
        Class61.dateTime_1 = DateTime.UtcNow;
      }
    });
  }

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static WoWUnit WoWUnit_1 => Class50.woWUnit_1;

  private static ulong UInt64_0 => Class50.ulong_0;

  private static bool Boolean_0 => Class41.bool_1;

  private static bool Boolean_1 => Class41.bool_2;

  private static bool Boolean_2
  {
    get
    {
      Class61.woWObject_0 = (WoWObject) ObjectManager.GetObjectsOfType<WoWGameObject>().FirstOrDefault<WoWGameObject>((Func<WoWGameObject, bool>) (woWGameObject_0 => (((WoWObject) woWGameObject_0).Entry == 179830U || ((WoWObject) woWGameObject_0).Entry == 179831U || ((WoWObject) woWGameObject_0).Entry == 179786U || ((WoWObject) woWGameObject_0).Entry == 179785U || ((WoWObject) woWGameObject_0).Entry == 220174U || ((WoWObject) woWGameObject_0).Entry == 220165U) && ((WoWObject) woWGameObject_0).WithinInteractRange));
      return WoWObject.op_Inequality(Class61.woWObject_0, (WoWObject) null);
    }
  }

  public static bool Boolean_3
  {
    get
    {
      return Class53.smethod_3((WoWUnit) Class61.LocalPlayer_0, 44521) || Class53.smethod_3((WoWUnit) Class61.LocalPlayer_0, 32727);
    }
  }

  public static IEnumerable<WoWUnit> IEnumerable_0
  {
    get
    {
      return Class63.IEnumerable_0.Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_6 => ((WoWObject) woWUnit_6).IsValid && woWUnit_6.IsPlayer && !woWUnit_6.IsDead));
    }
  }

  public static IEnumerable<WoWUnit> IEnumerable_1
  {
    get
    {
      return Class63.IEnumerable_0.Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_6 => ((WoWObject) woWUnit_6).IsValid && woWUnit_6.IsPlayer && !woWUnit_6.IsDead && woWUnit_6.smethod_18()));
    }
  }

  public static IEnumerable<WoWUnit> IEnumerable_2 => Class134.Class134_0.lazy_21.Value;

  public static IEnumerable<WoWUnit> IEnumerable_3 => Class134.Class134_0.lazy_22.Value;

  public static int Int32_0 => Class61.IEnumerable_2.Count<WoWUnit>();

  public static double Double_0
  {
    get
    {
      return Class61.dateTime_0 == DateTime.MinValue ? 0.0 : (DateTime.UtcNow - Class61.dateTime_0).TotalSeconds;
    }
  }

  private static WoWUnit WoWUnit_2
  {
    get
    {
      return Class61.IEnumerable_2.OrderBy<WoWUnit, double>((Func<WoWUnit, double>) (woWUnit_6 => ((WoWObject) woWUnit_6).Distance)).FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_6 => WoWObject.op_Inequality((WoWObject) woWUnit_6, (WoWObject) Class61.WoWUnit_0) && woWUnit_6.smethod_17()));
    }
  }

  private static WoWUnit WoWUnit_3
  {
    get
    {
      return Class61.IEnumerable_2.OrderBy<WoWUnit, double>((Func<WoWUnit, double>) (woWUnit_6 => ((WoWObject) woWUnit_6).Distance)).FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_6 => WoWObject.op_Inequality((WoWObject) woWUnit_6, (WoWObject) Class61.WoWUnit_0) && !woWUnit_6.smethod_17()));
    }
  }

  private static WoWUnit WoWUnit_4
  {
    get
    {
      return Class61.IEnumerable_2.FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_6 => WoWObject.op_Inequality((WoWObject) woWUnit_6, (WoWObject) Class61.WoWUnit_0)));
    }
  }

  private static bool Boolean_4
  {
    get
    {
      Class61.woWUnit_4 = Class63.IEnumerable_2.FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_6 => ((WoWObject) woWUnit_6).IsValid && WoWObject.op_Inequality((WoWObject) woWUnit_6, (WoWObject) Class61.WoWUnit_1) && WoWObject.op_Inequality((WoWObject) woWUnit_6, (WoWObject) Class61.WoWUnit_0) && !woWUnit_6.IsDead));
      return WoWObject.op_Inequality((WoWObject) Class61.woWUnit_4, (WoWObject) null);
    }
  }

  private static bool Boolean_5
  {
    get
    {
      Class61.woWUnit_5 = Class63.IEnumerable_0.Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_6 => ((WoWObject) woWUnit_6).IsValid && woWUnit_6.IsPlayer && WoWObject.op_Inequality((WoWObject) woWUnit_6, (WoWObject) Class61.WoWUnit_1) && WoWObject.op_Inequality((WoWObject) woWUnit_6, (WoWObject) Class61.WoWUnit_0) && !woWUnit_6.IsDead && Class70.smethod_2(woWUnit_6) < 25.0)).OrderBy<WoWUnit, bool>((Func<WoWUnit, bool>) (woWUnit_6 => Class63.smethod_6(woWUnit_6) || WoWObject.op_Equality((WoWObject) woWUnit_6.CurrentTarget, (WoWObject) Class61.LocalPlayer_0))).ThenBy<WoWUnit, bool>((Func<WoWUnit, bool>) (woWUnit_6 => woWUnit_6.IsCasting || woWUnit_6.IsChanneling)).FirstOrDefault<WoWUnit>();
      return WoWObject.op_Inequality((WoWObject) Class61.woWUnit_5, (WoWObject) null);
    }
  }

  private static bool Boolean_6
  {
    get
    {
      if (WoWObject.op_Equality((WoWObject) Class61.woWUnit_3, (WoWObject) Class61.WoWUnit_1))
        return false;
      Class61.woWUnit_2 = (WoWUnit) null;
      if (VitalicSettings.Instance.AutoFocusTargets == 1)
        return false;
      WoWPlayer woWplayer = Class134.Class134_0.lazy_5.Value;
      if (!WoWObject.op_Inequality((WoWObject) woWplayer, (WoWObject) null) || Class134.Class134_0.lazy_18.Value <= 40.0 || Class77.Int32_0 == 1856 || !WoWObject.op_Equality((WoWObject) Class61.WoWUnit_1, (WoWObject) null) && (!Class61.WoWUnit_1.IsPlayer || Class63.smethod_6(Class61.WoWUnit_1)))
        return false;
      Class61.woWUnit_2 = Class61.WoWUnit_3;
      Class61.woWUnit_3 = Class61.woWUnit_2;
      Class61.woWPlayer_0 = woWplayer;
      return WoWObject.op_Inequality((WoWObject) Class61.woWUnit_2, (WoWObject) null);
    }
  }

  private static bool Boolean_7
  {
    get
    {
      Class61.woWUnit_1 = (WoWUnit) null;
      if (!WoWObject.op_Inequality((WoWObject) Class61.WoWUnit_1, (WoWObject) null) || !Class61.WoWUnit_1.IsPlayer || Class63.smethod_2((WoWUnit) Class61.woWPlayer_0) && ((WoWUnit) Class61.woWPlayer_0).HealthPercent <= 70.0 && Class134.Class134_0.lazy_18.Value >= 40.0 && Class70.smethod_2(Class61.WoWUnit_1) <= 35.0 || Class61.WoWUnit_1.smethod_17() || Class61.WoWUnit_0.smethod_17() && Class61.LocalPlayer_0.GroupInfo.PartySize <= 3U)
        return false;
      Class61.woWPlayer_0 = (WoWPlayer) null;
      Class61.woWUnit_2 = (WoWUnit) null;
      Class61.woWUnit_1 = Class61.WoWUnit_2;
      return WoWObject.op_Inequality((WoWObject) Class61.woWUnit_1, (WoWObject) null) && Class70.smethod_2(Class61.woWUnit_1) <= 35.0;
    }
  }

  private static bool Boolean_8
  {
    get
    {
      Class61.woWUnit_1 = (WoWUnit) null;
      Class61.woWUnit_2 = (WoWUnit) null;
      if (!WoWObject.op_Equality((WoWObject) Class61.WoWUnit_1, (WoWObject) null) && !Class61.WoWUnit_1.IsDead && !WoWObject.op_Equality((WoWObject) Class61.WoWUnit_0, (WoWObject) Class61.WoWUnit_1))
      {
        if (Class61.WoWUnit_1.smethod_17() && Class70.smethod_2(Class61.WoWUnit_1) > 35.0)
        {
          Class61.woWUnit_2 = Class61.WoWUnit_3;
          if (WoWObject.op_Inequality((WoWObject) Class61.woWUnit_2, (WoWObject) null) && Class70.smethod_2(Class61.woWUnit_2) <= 35.0)
            return true;
        }
        return false;
      }
      Class61.woWUnit_1 = Class61.WoWUnit_2;
      if (WoWObject.op_Inequality((WoWObject) Class61.woWUnit_1, (WoWObject) null))
        return true;
      Class61.woWUnit_2 = Class61.WoWUnit_3;
      return !WoWObject.op_Inequality((WoWObject) Class61.woWUnit_2, (WoWObject) null) || true;
    }
  }

  private static WoWUnit WoWUnit_5
  {
    get
    {
      return Class61.IEnumerable_2.OrderBy<WoWUnit, double>((Func<WoWUnit, double>) (woWUnit_6 => ((WoWObject) woWUnit_6).Distance)).FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_6 => WoWObject.op_Inequality((WoWObject) woWUnit_6, (WoWObject) Class61.WoWUnit_0)));
    }
  }

  private static Composite Composite_0
  {
    get
    {
      if (Class61.canRunDecoratorDelegate_0 == null)
        Class61.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_16));
      CanRunDecoratorDelegate decoratorDelegate0 = Class61.canRunDecoratorDelegate_0;
      if (Class61.retrieveSwitchParameterDelegate_0 == null)
        Class61.retrieveSwitchParameterDelegate_0 = new RetrieveSwitchParameterDelegate<bool>((object) null, __methodptr(smethod_17));
      RetrieveSwitchParameterDelegate<bool> parameterDelegate0 = Class61.retrieveSwitchParameterDelegate_0;
      SwitchArgument<bool>[] switchArgumentArray1 = new SwitchArgument<bool>[2];
      SwitchArgument<bool>[] switchArgumentArray2 = switchArgumentArray1;
      if (Class61.canRunDecoratorDelegate_1 == null)
        Class61.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_18));
      CanRunDecoratorDelegate decoratorDelegate1 = Class61.canRunDecoratorDelegate_1;
      Composite[] compositeArray1 = new Composite[3];
      Composite[] compositeArray2 = compositeArray1;
      if (Class61.canRunDecoratorDelegate_2 == null)
        Class61.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_19));
      CanRunDecoratorDelegate decoratorDelegate2 = Class61.canRunDecoratorDelegate_2;
      if (Class61.actionSucceedDelegate_0 == null)
        Class61.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_20));
      Action action1 = new Action(Class61.actionSucceedDelegate_0);
      Decorator decorator1 = new Decorator(decoratorDelegate2, (Composite) action1);
      compositeArray2[0] = (Composite) decorator1;
      Composite[] compositeArray3 = compositeArray1;
      if (Class61.canRunDecoratorDelegate_3 == null)
        Class61.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_21));
      CanRunDecoratorDelegate decoratorDelegate3 = Class61.canRunDecoratorDelegate_3;
      if (Class61.actionSucceedDelegate_1 == null)
        Class61.actionSucceedDelegate_1 = new ActionSucceedDelegate((object) null, __methodptr(smethod_22));
      Action action2 = new Action(Class61.actionSucceedDelegate_1);
      Decorator decorator2 = new Decorator(decoratorDelegate3, (Composite) action2);
      compositeArray3[1] = (Composite) decorator2;
      Composite[] compositeArray4 = compositeArray1;
      if (Class61.canRunDecoratorDelegate_4 == null)
        Class61.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_23));
      CanRunDecoratorDelegate decoratorDelegate4 = Class61.canRunDecoratorDelegate_4;
      if (Class61.actionSucceedDelegate_2 == null)
        Class61.actionSucceedDelegate_2 = new ActionSucceedDelegate((object) null, __methodptr(smethod_24));
      Action action3 = new Action(Class61.actionSucceedDelegate_2);
      Decorator decorator3 = new Decorator(decoratorDelegate4, (Composite) action3);
      compositeArray4[2] = (Composite) decorator3;
      PrioritySelector prioritySelector1 = new PrioritySelector(compositeArray1);
      SwitchArgument<bool> switchArgument1 = new SwitchArgument<bool>(true, (Composite) new Decorator(decoratorDelegate1, (Composite) prioritySelector1));
      switchArgumentArray2[0] = switchArgument1;
      SwitchArgument<bool>[] switchArgumentArray3 = switchArgumentArray1;
      if (Class61.canRunDecoratorDelegate_5 == null)
        Class61.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_25));
      CanRunDecoratorDelegate decoratorDelegate5 = Class61.canRunDecoratorDelegate_5;
      Composite[] compositeArray5 = new Composite[2];
      Composite[] compositeArray6 = compositeArray5;
      if (Class61.canRunDecoratorDelegate_6 == null)
        Class61.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_26));
      CanRunDecoratorDelegate decoratorDelegate6 = Class61.canRunDecoratorDelegate_6;
      if (Class61.actionSucceedDelegate_3 == null)
        Class61.actionSucceedDelegate_3 = new ActionSucceedDelegate((object) null, __methodptr(smethod_27));
      Action action4 = new Action(Class61.actionSucceedDelegate_3);
      Decorator decorator4 = new Decorator(decoratorDelegate6, (Composite) action4);
      compositeArray6[0] = (Composite) decorator4;
      Composite[] compositeArray7 = compositeArray5;
      if (Class61.canRunDecoratorDelegate_7 == null)
        Class61.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_28));
      CanRunDecoratorDelegate decoratorDelegate7 = Class61.canRunDecoratorDelegate_7;
      if (Class61.actionSucceedDelegate_4 == null)
        Class61.actionSucceedDelegate_4 = new ActionSucceedDelegate((object) null, __methodptr(smethod_29));
      Action action5 = new Action(Class61.actionSucceedDelegate_4);
      Decorator decorator5 = new Decorator(decoratorDelegate7, (Composite) action5);
      compositeArray7[1] = (Composite) decorator5;
      PrioritySelector prioritySelector2 = new PrioritySelector(compositeArray5);
      SwitchArgument<bool> switchArgument2 = new SwitchArgument<bool>(false, (Composite) new Decorator(decoratorDelegate5, (Composite) prioritySelector2));
      switchArgumentArray3[1] = switchArgument2;
      SwitchArgument<bool>[] switchArgumentArray4 = switchArgumentArray1;
      Switch<bool> @switch = new Switch<bool>(parameterDelegate0, switchArgumentArray4);
      return (Composite) new Decorator(decoratorDelegate0, (Composite) @switch);
    }
  }

  private static Composite Composite_1
  {
    get
    {
      if (Class61.canRunDecoratorDelegate_8 == null)
        Class61.canRunDecoratorDelegate_8 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_30));
      CanRunDecoratorDelegate decoratorDelegate8 = Class61.canRunDecoratorDelegate_8;
      Composite[] compositeArray1 = new Composite[5];
      Composite[] compositeArray2 = compositeArray1;
      if (Class61.actionSucceedDelegate_5 == null)
        Class61.actionSucceedDelegate_5 = new ActionSucceedDelegate((object) null, __methodptr(smethod_31));
      Action action1 = new Action(Class61.actionSucceedDelegate_5);
      compositeArray2[0] = (Composite) action1;
      Composite[] compositeArray3 = compositeArray1;
      if (Class61.canRunDecoratorDelegate_9 == null)
        Class61.canRunDecoratorDelegate_9 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_32));
      CanRunDecoratorDelegate decoratorDelegate9 = Class61.canRunDecoratorDelegate_9;
      if (Class61.actionSucceedDelegate_6 == null)
        Class61.actionSucceedDelegate_6 = new ActionSucceedDelegate((object) null, __methodptr(smethod_33));
      Action action2 = new Action(Class61.actionSucceedDelegate_6);
      DecoratorContinue decoratorContinue1 = new DecoratorContinue(decoratorDelegate9, (Composite) action2);
      compositeArray3[1] = (Composite) decoratorContinue1;
      Composite[] compositeArray4 = compositeArray1;
      if (Class61.canRunDecoratorDelegate_10 == null)
        Class61.canRunDecoratorDelegate_10 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_34));
      CanRunDecoratorDelegate decoratorDelegate10 = Class61.canRunDecoratorDelegate_10;
      if (Class61.actionSucceedDelegate_7 == null)
        Class61.actionSucceedDelegate_7 = new ActionSucceedDelegate((object) null, __methodptr(smethod_35));
      Action action3 = new Action(Class61.actionSucceedDelegate_7);
      DecoratorContinue decoratorContinue2 = new DecoratorContinue(decoratorDelegate10, (Composite) action3);
      compositeArray4[2] = (Composite) decoratorContinue2;
      Composite[] compositeArray5 = compositeArray1;
      if (Class61.canRunDecoratorDelegate_11 == null)
        Class61.canRunDecoratorDelegate_11 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_36));
      CanRunDecoratorDelegate decoratorDelegate11 = Class61.canRunDecoratorDelegate_11;
      if (Class61.actionSucceedDelegate_8 == null)
        Class61.actionSucceedDelegate_8 = new ActionSucceedDelegate((object) null, __methodptr(smethod_37));
      Action action4 = new Action(Class61.actionSucceedDelegate_8);
      DecoratorContinue decoratorContinue3 = new DecoratorContinue(decoratorDelegate11, (Composite) action4);
      compositeArray5[3] = (Composite) decoratorContinue3;
      Composite[] compositeArray6 = compositeArray1;
      if (Class61.canRunDecoratorDelegate_12 == null)
        Class61.canRunDecoratorDelegate_12 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_38));
      CanRunDecoratorDelegate decoratorDelegate12 = Class61.canRunDecoratorDelegate_12;
      if (Class61.actionSucceedDelegate_9 == null)
        Class61.actionSucceedDelegate_9 = new ActionSucceedDelegate((object) null, __methodptr(smethod_39));
      Action action5 = new Action(Class61.actionSucceedDelegate_9);
      DecoratorContinue decoratorContinue4 = new DecoratorContinue(decoratorDelegate12, (Composite) action5);
      compositeArray6[4] = (Composite) decoratorContinue4;
      Sequence sequence = new Sequence(compositeArray1);
      return (Composite) new Decorator(decoratorDelegate8, (Composite) sequence);
    }
  }

  public static Composite Composite_2
  {
    get
    {
      Composite[] compositeArray1 = new Composite[3];
      Composite[] compositeArray2 = compositeArray1;
      if (Class61.canRunDecoratorDelegate_13 == null)
        Class61.canRunDecoratorDelegate_13 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_40));
      DecoratorContinue decoratorContinue1 = new DecoratorContinue(Class61.canRunDecoratorDelegate_13, Class61.Composite_0);
      compositeArray2[0] = (Composite) decoratorContinue1;
      Composite[] compositeArray3 = compositeArray1;
      if (Class61.canRunDecoratorDelegate_14 == null)
        Class61.canRunDecoratorDelegate_14 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_41));
      DecoratorContinue decoratorContinue2 = new DecoratorContinue(Class61.canRunDecoratorDelegate_14, Class61.Composite_1);
      compositeArray3[1] = (Composite) decoratorContinue2;
      compositeArray1[2] = (Composite) new ActionAlwaysFail();
      return (Composite) new Sequence(compositeArray1);
    }
  }

  public static Composite Composite_3
  {
    get
    {
      if (Class61.canRunDecoratorDelegate_15 == null)
        Class61.canRunDecoratorDelegate_15 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_42));
      CanRunDecoratorDelegate decoratorDelegate15 = Class61.canRunDecoratorDelegate_15;
      if (Class61.canRunDecoratorDelegate_16 == null)
        Class61.canRunDecoratorDelegate_16 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_43));
      CanRunDecoratorDelegate decoratorDelegate16 = Class61.canRunDecoratorDelegate_16;
      if (Class61.actionSucceedDelegate_10 == null)
        Class61.actionSucceedDelegate_10 = new ActionSucceedDelegate((object) null, __methodptr(smethod_44));
      Action action = new Action(Class61.actionSucceedDelegate_10);
      Decorator decorator = new Decorator(decoratorDelegate16, (Composite) action);
      return (Composite) new Decorator(decoratorDelegate15, (Composite) decorator);
    }
  }
}
