﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class118
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class118 : Class91
{
  public static bool bool_0;
  public static DateTime dateTime_0;
  private static readonly TimeSpan timeSpan_0 = TimeSpan.FromMilliseconds(75.0);
  private static WoWUnit woWUnit_0;
  public static HashSet<int> hashSet_0 = new HashSet<int>()
  {
    77767,
    56641,
    19434,
    109259
  };
  public static Dictionary<int, bool> dictionary_0 = new Dictionary<int, bool>()
  {
    {
      116,
      false
    },
    {
      50464,
      false
    },
    {
      331,
      false
    },
    {
      5782,
      true
    },
    {
      1120,
      false
    },
    {
      689,
      false
    },
    {
      30108,
      false
    },
    {
      1454,
      false
    },
    {
      33786,
      true
    },
    {
      28272,
      true
    },
    {
      118,
      true
    },
    {
      61305,
      true
    },
    {
      61721,
      true
    },
    {
      61780,
      true
    },
    {
      28271,
      true
    },
    {
      51514,
      true
    },
    {
      339,
      false
    },
    {
      30451,
      false
    },
    {
      20066,
      true
    },
    {
      116858,
      true
    },
    {
      113092,
      false
    },
    {
      8092,
      false
    },
    {
      11366,
      false
    },
    {
      48181,
      false
    },
    {
      102051,
      false
    },
    {
      1064,
      false
    },
    {
      77472,
      true
    },
    {
      8004,
      true
    },
    {
      73920,
      false
    },
    {
      51505,
      false
    },
    {
      8936,
      true
    },
    {
      2061,
      true
    },
    {
      2060,
      true
    },
    {
      2006,
      false
    },
    {
      5185,
      true
    },
    {
      19750,
      true
    },
    {
      635,
      false
    },
    {
      7328,
      false
    },
    {
      2008,
      false
    },
    {
      50769,
      false
    },
    {
      2812,
      false
    },
    {
      82327,
      false
    },
    {
      10326,
      true
    },
    {
      82326,
      true
    },
    {
      116694,
      true
    },
    {
      124682,
      false
    },
    {
      115151,
      false
    },
    {
      115310,
      false
    },
    {
      126201,
      false
    },
    {
      44614,
      false
    },
    {
      133,
      false
    },
    {
      1513,
      false
    },
    {
      982,
      true
    },
    {
      111771,
      true
    },
    {
      118297,
      false
    },
    {
      29722,
      false
    },
    {
      124465,
      false
    },
    {
      32375,
      true
    },
    {
      2948,
      false
    },
    {
      12051,
      true
    },
    {
      90337,
      true
    },
    {
      47757,
      true
    },
    {
      115268,
      true
    },
    {
      6358,
      true
    },
    {
      51963,
      true
    },
    {
      78674,
      false
    },
    {
      113792,
      false
    },
    {
      115175,
      true
    },
    {
      115750,
      true
    },
    {
      103103,
      false
    },
    {
      113724,
      true
    },
    {
      117014,
      false
    },
    {
      605,
      false
    },
    {
      740,
      true
    },
    {
      32546,
      true
    },
    {
      119996,
      false
    },
    {
      113506,
      true
    },
    {
      129197,
      false
    },
    {
      724,
      false
    },
    {
      31687,
      true
    },
    {
      145067,
      true
    },
    {
      34914,
      false
    },
    {
      117952,
      false
    },
    {
      5143,
      false
    }
  };

  static Class118()
  {
    Class144.Event_0 += (Class144.Delegate42) ((sender, e) =>
    {
      if (VitalicSettings.Instance.MacrosEnabled || !Class144.class80_11.method_2())
        return;
      Class118.bool_0 = !Class118.bool_0;
      if (Class118.bool_0)
        Class140.smethod_9("Fast Kick: |cFF00FF00Enabled");
      else
        Class140.smethod_9("Fast Kick: |cffb73737Disabled");
    });
  }

  private static double Double_9
  {
    get => VitalicSettings.Instance.InterruptDelay + Class144.double_0 / 1000.0;
  }

  private static double Double_10 => VitalicSettings.Instance.InterruptShadowstepBuffer;

  private static bool Boolean_21
  {
    get
    {
      if (!Class91.Boolean_1)
        return false;
      Class118.woWUnit_0 = Class91.IEnumerable_1.OrderBy<WoWUnit, double>((Func<WoWUnit, double>) (woWUnit_1 => woWUnit_1.CurrentCastTimeLeft.TotalSeconds)).FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_1 => woWUnit_1.IsCasting && WoWObject.op_Inequality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_0) && WoWObject.op_Inequality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_1) && !Class118.hashSet_0.Contains(woWUnit_1.CastingSpellId) && Class118.dictionary_0.ContainsKey(woWUnit_1.CastingSpellId) && woWUnit_1.CurrentCastTimeLeft.TotalSeconds >= 0.2 && !woWUnit_1.smethod_8() && !woWUnit_1.smethod_12() && DateTime.Now - woWUnit_1.CurrentCastStartTime > TimeSpan.FromSeconds(VitalicSettings.Instance.InterruptMinimum)));
      return WoWObject.op_Inequality((WoWObject) Class118.woWUnit_0, (WoWObject) null);
    }
  }

  private static Composite smethod_4(Class144.Delegate43 delegate43_10)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: method pointer
    return (Composite) new Action(new ActionSucceedDelegate((object) new Class118.Class133()
    {
      delegate43_0 = delegate43_10
    }, __methodptr(method_0)));
  }

  private static bool smethod_5(WoWUnit woWUnit_1)
  {
    switch (WoWObject.op_Equality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_0) ? Class91.Int32_0 : Class91.Int32_1)
    {
      case 408:
      case 703:
      case 1776:
      case 1833:
        return true;
      default:
        return false;
    }
  }

  public static Composite smethod_6()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_10));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class118.canRunDecoratorDelegate_0;
    Composite[] compositeArray1 = new Composite[5];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_11));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class118.canRunDecoratorDelegate_1;
    // ISSUE: reference to a compiler-generated field
    if (Class118.retrieveSwitchParameterDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.retrieveSwitchParameterDelegate_0 = new RetrieveSwitchParameterDelegate<bool>((object) null, __methodptr(smethod_12));
    }
    // ISSUE: reference to a compiler-generated field
    RetrieveSwitchParameterDelegate<bool> parameterDelegate0 = Class118.retrieveSwitchParameterDelegate_0;
    SwitchArgument<bool>[] switchArgumentArray1 = new SwitchArgument<bool>[2];
    SwitchArgument<bool>[] switchArgumentArray2 = switchArgumentArray1;
    Composite[] compositeArray3 = new Composite[3];
    Composite[] compositeArray4 = compositeArray3;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_13));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate2 = Class118.canRunDecoratorDelegate_2;
    // ISSUE: reference to a compiler-generated field
    if (Class118.actionSucceedDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_14));
    }
    // ISSUE: reference to a compiler-generated field
    Action action1 = new Action(Class118.actionSucceedDelegate_0);
    Decorator decorator1 = new Decorator(decoratorDelegate2, (Composite) action1);
    compositeArray4[0] = (Composite) decorator1;
    Composite[] compositeArray5 = compositeArray3;
    TimeSpan timeSpan0_1 = Class118.timeSpan_0;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_15));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate3 = Class118.canRunDecoratorDelegate_3;
    ActionAlwaysSucceed actionAlwaysSucceed1 = new ActionAlwaysSucceed();
    WaitContinue waitContinue1 = new WaitContinue(timeSpan0_1, decoratorDelegate3, (Composite) actionAlwaysSucceed1);
    compositeArray5[1] = (Composite) waitContinue1;
    compositeArray3[2] = Class118.smethod_4((Class144.Delegate43) (object_0 => Class91.WoWUnit_0));
    SwitchArgument<bool> switchArgument1 = new SwitchArgument<bool>(false, (Composite) new Sequence(compositeArray3));
    switchArgumentArray2[0] = switchArgument1;
    SwitchArgument<bool>[] switchArgumentArray3 = switchArgumentArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_17));
    }
    // ISSUE: reference to a compiler-generated field
    SwitchArgument<bool> switchArgument2 = new SwitchArgument<bool>(true, (Composite) new Decorator(Class118.canRunDecoratorDelegate_4, Class118.smethod_4((Class144.Delegate43) (object_0 => Class91.WoWUnit_0))));
    switchArgumentArray3[1] = switchArgument2;
    SwitchArgument<bool>[] switchArgumentArray4 = switchArgumentArray1;
    Switch<bool> switch1 = new Switch<bool>(parameterDelegate0, switchArgumentArray4);
    Decorator decorator2 = new Decorator(decoratorDelegate1, (Composite) switch1);
    compositeArray2[0] = (Composite) decorator2;
    Composite[] compositeArray6 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_5 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_19));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate5 = Class118.canRunDecoratorDelegate_5;
    // ISSUE: reference to a compiler-generated field
    if (Class118.retrieveSwitchParameterDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.retrieveSwitchParameterDelegate_1 = new RetrieveSwitchParameterDelegate<bool>((object) null, __methodptr(smethod_20));
    }
    // ISSUE: reference to a compiler-generated field
    RetrieveSwitchParameterDelegate<bool> parameterDelegate1 = Class118.retrieveSwitchParameterDelegate_1;
    SwitchArgument<bool>[] switchArgumentArray5 = new SwitchArgument<bool>[2];
    SwitchArgument<bool>[] switchArgumentArray6 = switchArgumentArray5;
    Composite[] compositeArray7 = new Composite[3];
    Composite[] compositeArray8 = compositeArray7;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_6 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_21));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate6 = Class118.canRunDecoratorDelegate_6;
    // ISSUE: reference to a compiler-generated field
    if (Class118.actionSucceedDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.actionSucceedDelegate_1 = new ActionSucceedDelegate((object) null, __methodptr(smethod_22));
    }
    // ISSUE: reference to a compiler-generated field
    Action action2 = new Action(Class118.actionSucceedDelegate_1);
    Decorator decorator3 = new Decorator(decoratorDelegate6, (Composite) action2);
    compositeArray8[0] = (Composite) decorator3;
    Composite[] compositeArray9 = compositeArray7;
    TimeSpan timeSpan0_2 = Class118.timeSpan_0;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_7 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_23));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate7 = Class118.canRunDecoratorDelegate_7;
    ActionAlwaysSucceed actionAlwaysSucceed2 = new ActionAlwaysSucceed();
    WaitContinue waitContinue2 = new WaitContinue(timeSpan0_2, decoratorDelegate7, (Composite) actionAlwaysSucceed2);
    compositeArray9[1] = (Composite) waitContinue2;
    compositeArray7[2] = Class118.smethod_4((Class144.Delegate43) (object_0 => Class91.WoWUnit_0));
    SwitchArgument<bool> switchArgument3 = new SwitchArgument<bool>(false, (Composite) new Sequence(compositeArray7));
    switchArgumentArray6[0] = switchArgument3;
    switchArgumentArray5[1] = new SwitchArgument<bool>(true, Class118.smethod_4((Class144.Delegate43) (object_0 => Class91.WoWUnit_0)));
    SwitchArgument<bool>[] switchArgumentArray7 = switchArgumentArray5;
    Switch<bool> switch2 = new Switch<bool>(parameterDelegate1, switchArgumentArray7);
    Decorator decorator4 = new Decorator(decoratorDelegate5, (Composite) switch2);
    compositeArray6[1] = (Composite) decorator4;
    Composite[] compositeArray10 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_8 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_8 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_26));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate8 = Class118.canRunDecoratorDelegate_8;
    // ISSUE: reference to a compiler-generated field
    if (Class118.retrieveSwitchParameterDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.retrieveSwitchParameterDelegate_2 = new RetrieveSwitchParameterDelegate<bool>((object) null, __methodptr(smethod_27));
    }
    // ISSUE: reference to a compiler-generated field
    RetrieveSwitchParameterDelegate<bool> parameterDelegate2 = Class118.retrieveSwitchParameterDelegate_2;
    SwitchArgument<bool>[] switchArgumentArray8 = new SwitchArgument<bool>[2];
    SwitchArgument<bool>[] switchArgumentArray9 = switchArgumentArray8;
    Composite[] compositeArray11 = new Composite[3];
    Composite[] compositeArray12 = compositeArray11;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_9 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_9 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_28));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate9 = Class118.canRunDecoratorDelegate_9;
    // ISSUE: reference to a compiler-generated field
    if (Class118.actionSucceedDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.actionSucceedDelegate_2 = new ActionSucceedDelegate((object) null, __methodptr(smethod_29));
    }
    // ISSUE: reference to a compiler-generated field
    Action action3 = new Action(Class118.actionSucceedDelegate_2);
    Decorator decorator5 = new Decorator(decoratorDelegate9, (Composite) action3);
    compositeArray12[0] = (Composite) decorator5;
    Composite[] compositeArray13 = compositeArray11;
    TimeSpan timeSpan0_3 = Class118.timeSpan_0;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_10 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_10 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_30));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate10 = Class118.canRunDecoratorDelegate_10;
    ActionAlwaysSucceed actionAlwaysSucceed3 = new ActionAlwaysSucceed();
    WaitContinue waitContinue3 = new WaitContinue(timeSpan0_3, decoratorDelegate10, (Composite) actionAlwaysSucceed3);
    compositeArray13[1] = (Composite) waitContinue3;
    compositeArray11[2] = Class118.smethod_4((Class144.Delegate43) (object_0 => Class91.WoWUnit_1));
    SwitchArgument<bool> switchArgument4 = new SwitchArgument<bool>(false, (Composite) new Sequence(compositeArray11));
    switchArgumentArray9[0] = switchArgument4;
    switchArgumentArray8[1] = new SwitchArgument<bool>(true, Class118.smethod_4((Class144.Delegate43) (object_0 => Class91.WoWUnit_1)));
    SwitchArgument<bool>[] switchArgumentArray10 = switchArgumentArray8;
    Switch<bool> switch3 = new Switch<bool>(parameterDelegate2, switchArgumentArray10);
    Decorator decorator6 = new Decorator(decoratorDelegate8, (Composite) switch3);
    compositeArray10[2] = (Composite) decorator6;
    Composite[] compositeArray14 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_11 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_11 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_33));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate11 = Class118.canRunDecoratorDelegate_11;
    // ISSUE: reference to a compiler-generated field
    if (Class118.retrieveSwitchParameterDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.retrieveSwitchParameterDelegate_3 = new RetrieveSwitchParameterDelegate<bool>((object) null, __methodptr(smethod_34));
    }
    // ISSUE: reference to a compiler-generated field
    RetrieveSwitchParameterDelegate<bool> parameterDelegate3 = Class118.retrieveSwitchParameterDelegate_3;
    SwitchArgument<bool>[] switchArgumentArray11 = new SwitchArgument<bool>[2];
    SwitchArgument<bool>[] switchArgumentArray12 = switchArgumentArray11;
    Composite[] compositeArray15 = new Composite[3];
    Composite[] compositeArray16 = compositeArray15;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_12 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_12 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_35));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate12 = Class118.canRunDecoratorDelegate_12;
    // ISSUE: reference to a compiler-generated field
    if (Class118.actionSucceedDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.actionSucceedDelegate_3 = new ActionSucceedDelegate((object) null, __methodptr(smethod_36));
    }
    // ISSUE: reference to a compiler-generated field
    Action action4 = new Action(Class118.actionSucceedDelegate_3);
    Decorator decorator7 = new Decorator(decoratorDelegate12, (Composite) action4);
    compositeArray16[0] = (Composite) decorator7;
    Composite[] compositeArray17 = compositeArray15;
    TimeSpan timeSpan0_4 = Class118.timeSpan_0;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_13 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_13 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_37));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate13 = Class118.canRunDecoratorDelegate_13;
    ActionAlwaysSucceed actionAlwaysSucceed4 = new ActionAlwaysSucceed();
    WaitContinue waitContinue4 = new WaitContinue(timeSpan0_4, decoratorDelegate13, (Composite) actionAlwaysSucceed4);
    compositeArray17[1] = (Composite) waitContinue4;
    compositeArray15[2] = Class118.smethod_4((Class144.Delegate43) (object_0 => Class91.WoWUnit_1));
    SwitchArgument<bool> switchArgument5 = new SwitchArgument<bool>(false, (Composite) new Sequence(compositeArray15));
    switchArgumentArray12[0] = switchArgument5;
    switchArgumentArray11[1] = new SwitchArgument<bool>(true, Class118.smethod_4((Class144.Delegate43) (object_0 => Class91.WoWUnit_1)));
    SwitchArgument<bool>[] switchArgumentArray13 = switchArgumentArray11;
    Switch<bool> switch4 = new Switch<bool>(parameterDelegate3, switchArgumentArray13);
    Decorator decorator8 = new Decorator(decoratorDelegate11, (Composite) switch4);
    compositeArray14[3] = (Composite) decorator8;
    Composite[] compositeArray18 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_14 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_14 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_40));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate14 = Class118.canRunDecoratorDelegate_14;
    // ISSUE: reference to a compiler-generated field
    if (Class118.retrieveSwitchParameterDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.retrieveSwitchParameterDelegate_4 = new RetrieveSwitchParameterDelegate<bool>((object) null, __methodptr(smethod_41));
    }
    // ISSUE: reference to a compiler-generated field
    RetrieveSwitchParameterDelegate<bool> parameterDelegate4 = Class118.retrieveSwitchParameterDelegate_4;
    SwitchArgument<bool>[] switchArgumentArray14 = new SwitchArgument<bool>[2];
    SwitchArgument<bool>[] switchArgumentArray15 = switchArgumentArray14;
    Composite[] compositeArray19 = new Composite[3];
    Composite[] compositeArray20 = compositeArray19;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_15 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_15 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_42));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate15 = Class118.canRunDecoratorDelegate_15;
    // ISSUE: reference to a compiler-generated field
    if (Class118.actionSucceedDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.actionSucceedDelegate_4 = new ActionSucceedDelegate((object) null, __methodptr(smethod_43));
    }
    // ISSUE: reference to a compiler-generated field
    Action action5 = new Action(Class118.actionSucceedDelegate_4);
    Decorator decorator9 = new Decorator(decoratorDelegate15, (Composite) action5);
    compositeArray20[0] = (Composite) decorator9;
    Composite[] compositeArray21 = compositeArray19;
    TimeSpan timeSpan0_5 = Class118.timeSpan_0;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_16 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_16 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_44));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate16 = Class118.canRunDecoratorDelegate_16;
    ActionAlwaysSucceed actionAlwaysSucceed5 = new ActionAlwaysSucceed();
    WaitContinue waitContinue5 = new WaitContinue(timeSpan0_5, decoratorDelegate16, (Composite) actionAlwaysSucceed5);
    compositeArray21[1] = (Composite) waitContinue5;
    compositeArray19[2] = Class118.smethod_4((Class144.Delegate43) (object_0 => Class118.woWUnit_0));
    SwitchArgument<bool> switchArgument6 = new SwitchArgument<bool>(false, (Composite) new Sequence(compositeArray19));
    switchArgumentArray15[0] = switchArgument6;
    SwitchArgument<bool>[] switchArgumentArray16 = switchArgumentArray14;
    // ISSUE: reference to a compiler-generated field
    if (Class118.canRunDecoratorDelegate_17 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class118.canRunDecoratorDelegate_17 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_46));
    }
    // ISSUE: reference to a compiler-generated field
    SwitchArgument<bool> switchArgument7 = new SwitchArgument<bool>(true, (Composite) new Decorator(Class118.canRunDecoratorDelegate_17, Class118.smethod_4((Class144.Delegate43) (object_0 => Class118.woWUnit_0))));
    switchArgumentArray16[1] = switchArgument7;
    SwitchArgument<bool>[] switchArgumentArray17 = switchArgumentArray14;
    Switch<bool> switch5 = new Switch<bool>(parameterDelegate4, switchArgumentArray17);
    Decorator decorator10 = new Decorator(decoratorDelegate14, (Composite) switch5);
    compositeArray18[4] = (Composite) decorator10;
    PrioritySelector prioritySelector = new PrioritySelector(compositeArray1);
    return (Composite) new Decorator(decoratorDelegate0, (Composite) prioritySelector);
  }
}
