﻿// Decompiled with JetBrains decompiler
// Type: ns1.GClass71
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

public class GClass71(params Composite[] composite_0) : PrioritySelector(composite_0)
{
  protected virtual IEnumerable<RunStatus> Execute(object context)
  {
    IEnumerable<RunStatus> source = base.Execute(context);
    if (source.First<RunStatus>() == 2)
    {
      foreach (Composite child in ((GroupComposite) this).Children)
      {
        RunStatus? lastStatus = child.LastStatus;
        if ((lastStatus.GetValueOrDefault() != 2 ? 1 : (!lastStatus.HasValue ? 1 : 0)) == 0)
        {
          if (child is GClass69)
            Class62.smethod_1((object) "Decorator returned true:", (object) ((GClass69) child).string_0);
          if (child is GClass70)
            Class62.smethod_1((object) "PrioritySelector returned true:", (object) ((GClass70) child).string_0);
        }
      }
    }
    return source;
  }
}
