﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class77
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.CommonBot;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

internal static class Class77
{
  internal const int int_0 = 26679;
  internal const int int_1 = 115189;
  internal const int int_2 = 74001;
  internal const int int_3 = 14185;
  internal const int int_4 = 36554;
  internal const int int_5 = 108212;
  internal const int int_6 = 137573;
  internal const int int_7 = 114014;
  internal const int int_8 = 121733;
  internal const int int_9 = 8676;
  internal const int int_10 = 53;
  internal const int int_11 = 2094;
  internal const int int_12 = 121153;
  internal const int int_13 = 1833;
  internal const int int_14 = 31224;
  internal const int int_15 = 121411;
  internal const int int_16 = 1842;
  internal const int int_17 = 51722;
  internal const int int_18 = 1725;
  internal const int int_19 = 5277;
  internal const int int_20 = 2098;
  internal const int int_21 = 8647;
  internal const int int_22 = 51723;
  internal const int int_23 = 1966;
  internal const int int_24 = 703;
  internal const int int_25 = 1330;
  internal const int int_26 = 1776;
  internal const int int_27 = 1752;
  internal const int int_28 = 1766;
  internal const int int_29 = 408;
  internal const int int_30 = 1804;
  internal const int int_31 = 921;
  internal const int int_32 = 14183;
  internal const int int_33 = 73651;
  internal const int int_34 = 73981;
  internal const int int_35 = 1943;
  internal const int int_36 = 6770;
  internal const int int_37 = 51713;
  internal const int int_38 = 114842;
  internal const int int_39 = 5938;
  internal const int int_40 = 114018;
  internal const int int_41 = 5171;
  internal const int int_42 = 76577;
  internal const int int_43 = 2983;
  internal const int int_44 = 1784;
  internal const int int_45 = 115192;
  internal const int int_46 = 115191;
  internal const int int_47 = 112942;
  internal const int int_48 = 121733;
  internal const int int_49 = 57934;
  internal const int int_50 = 1856;
  internal const int int_51 = 115193;
  internal const int int_52 = 110503;
  internal const int int_53 = 111240;
  internal const int int_54 = 32645;
  internal const int int_55 = 1329;
  internal const int int_56 = 121471;
  internal const int int_57 = 79140;
  internal const int int_58 = 13750;
  internal const int int_59 = 13877;
  internal const int int_60 = 51690;
  internal const int int_61 = 16511;
  internal const int int_62 = 113953;
  internal const int int_63 = 113952;
  internal const int int_64 = 137619;
  internal const int int_65 = 23978;
  internal const int int_66 = 97388;
  internal const int int_67 = 102695;
  internal const int int_68 = 26297;
  internal const int int_69 = 20572;
  internal const int int_70 = 84617;
  internal const int int_71 = 91021;
  internal const int int_72 = 112947;
  internal const int int_73 = 58984;
  internal const int int_74 = 146631;
  internal const int int_75 = 56801;
  internal const int int_76 = 56809;
  internal const int int_77 = 146629;
  internal const int int_78 = 8679;
  internal const int int_79 = 2823;
  internal const int int_80 = 5761;
  internal const int int_81 = 108215;
  internal const int int_82 = 108211;
  private static Class77.Delegate32 delegate32_0 = new Class77.Delegate32(Class62.smethod_0);
  private static Class77.Delegate32 delegate32_1 = new Class77.Delegate32(Class62.smethod_1);
  private static DateTime dateTime_0;
  public static WoWSpell woWSpell_0 = WoWSpell.FromId(6770);
  private static readonly Dictionary<int, DateTime> dictionary_0 = new Dictionary<int, DateTime>();
  internal static HashSet<int> hashSet_0 = new HashSet<int>()
  {
    5277,
    2983,
    51722,
    1856
  };

  static Class77()
  {
    Class144.Event_0 += (Class144.Delegate42) ((sender, e) => Class77.smethod_5());
  }

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static WoWUnit WoWUnit_1 => Class50.woWUnit_1;

  private static ulong UInt64_0 => Class50.ulong_0;

  public static int LastSpellCast { get; private set; }

  public static double Double_0 => (DateTime.UtcNow - Class77.dateTime_0).TotalSeconds;

  public static int Int32_0
  {
    get => !WoWSpell.op_Inequality(Class49.woWSpell_0, (WoWSpell) null) ? 0 : Class49.woWSpell_0.Id;
  }

  public static int Int32_1
  {
    get => !WoWSpell.op_Inequality(Class49.woWSpell_1, (WoWSpell) null) ? 0 : Class49.woWSpell_1.Id;
  }

  public static int Int32_2
  {
    get => !WoWSpell.op_Inequality(Class49.woWSpell_2, (WoWSpell) null) ? 0 : Class49.woWSpell_2.Id;
  }

  public static Composite smethod_0(
    int int_84,
    Class144.Delegate43 delegate43_4,
    CanRunDecoratorDelegate canRunDecoratorDelegate_0,
    string string_0,
    Action action_0 = null,
    bool bool_0 = false)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class77.Class78 class78 = new Class77.Class78();
    // ISSUE: reference to a compiler-generated field
    class78.int_0 = int_84;
    // ISSUE: reference to a compiler-generated field
    class78.delegate43_0 = delegate43_4;
    // ISSUE: reference to a compiler-generated field
    class78.canRunDecoratorDelegate_0 = canRunDecoratorDelegate_0;
    // ISSUE: reference to a compiler-generated field
    class78.string_0 = string_0;
    // ISSUE: reference to a compiler-generated field
    class78.action_0 = action_0;
    // ISSUE: reference to a compiler-generated field
    class78.bool_0 = bool_0;
    // ISSUE: method pointer
    // ISSUE: method pointer
    // ISSUE: method pointer
    // ISSUE: method pointer
    // ISSUE: method pointer
    // ISSUE: method pointer
    return (Composite) new Decorator(new CanRunDecoratorDelegate((object) class78, __methodptr(method_0)), (Composite) new Sequence(new Composite[4]
    {
      (Composite) new Action(new ActionSucceedDelegate((object) class78, __methodptr(method_1))),
      (Composite) new Action(new ActionSucceedDelegate((object) class78, __methodptr(method_2))),
      (Composite) new Action(new ActionSucceedDelegate((object) class78, __methodptr(method_3))),
      (Composite) new DecoratorContinue(new CanRunDecoratorDelegate((object) class78, __methodptr(method_4)), (Composite) new Action(new ActionSucceedDelegate((object) class78, __methodptr(method_5))))
    }));
  }

  public static Composite smethod_1(
    int int_84,
    CanRunDecoratorDelegate canRunDecoratorDelegate_0,
    string string_0,
    Action action_0 = null)
  {
    return Class77.smethod_0(int_84, (Class144.Delegate43) (object_0 => Class77.WoWUnit_0), canRunDecoratorDelegate_0, string_0, action_0);
  }

  public static Composite smethod_2(
    int int_84,
    CanRunDecoratorDelegate canRunDecoratorDelegate_0,
    string string_0,
    Action action_0 = null)
  {
    return Class77.smethod_0(int_84, (Class144.Delegate43) (object_0 => (WoWUnit) Class77.LocalPlayer_0), canRunDecoratorDelegate_0, string_0, action_0);
  }

  private static void smethod_3(int int_84)
  {
    if (Class77.dictionary_0.ContainsKey(int_84))
      Class77.dictionary_0[int_84] = DateTime.UtcNow + TimeSpan.FromSeconds(0.2);
    else
      Class77.dictionary_0.Add(int_84, DateTime.UtcNow + TimeSpan.FromSeconds(0.2));
  }

  public static Composite smethod_4(
    int int_84,
    CanRunDecoratorDelegate canRunDecoratorDelegate_0,
    string string_0,
    Action action_0 = null)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class77.Class79 class79 = new Class77.Class79();
    // ISSUE: reference to a compiler-generated field
    class79.int_0 = int_84;
    // ISSUE: reference to a compiler-generated field
    class79.action_0 = action_0;
    // ISSUE: method pointer
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    return (Composite) new Decorator(new CanRunDecoratorDelegate((object) class79, __methodptr(method_0)), Class77.smethod_0(class79.int_0, (Class144.Delegate43) (object_0 => (WoWUnit) Class77.LocalPlayer_0), canRunDecoratorDelegate_0, string_0, new Action(class79.method_1)));
  }

  public static void smethod_5()
  {
    foreach (int key in Class77.dictionary_0.Where<KeyValuePair<int, DateTime>>((Func<KeyValuePair<int, DateTime>, bool>) (keyValuePair_0 => keyValuePair_0.Value < DateTime.UtcNow)).Select<KeyValuePair<int, DateTime>, int>((Func<KeyValuePair<int, DateTime>, int>) (keyValuePair_0 => keyValuePair_0.Key)).ToList<int>())
      Class77.dictionary_0.Remove(key);
  }

  public static Composite smethod_6(
    int int_84,
    CanRunDecoratorDelegate canRunDecoratorDelegate_0,
    string string_0,
    Action action_0 = null)
  {
    return Class77.smethod_0(int_84, (Class144.Delegate43) (object_0 => Class77.WoWUnit_0), canRunDecoratorDelegate_0, string_0, action_0, true);
  }

  public static bool smethod_7(int int_84, WoWUnit woWUnit_0, bool bool_0)
  {
    if (Class59.smethod_0(int_84))
      return false;
    SpellFindResults spellFindResults;
    if (!SpellManager.FindSpell(int_84, ref spellFindResults) && !Class77.LocalPlayer_0.smethod_5(int_84))
    {
      Class77.delegate32_1((object) "CanCast: spell not known ", (object) int_84);
      return false;
    }
    WoWSpell woWspell = spellFindResults != null ? spellFindResults.Override ?? spellFindResults.Original : WoWSpell.FromId(int_84);
    return (!bool_0 || (!woWspell.IsMeleeSpell || woWUnit_0.smethod_6(true)) && (!woWspell.HasRange || Class70.smethod_2(woWUnit_0) <= (double) woWspell.MaxRange)) && (woWspell.CanCast || spellFindResults != null && !WoWSpell.op_Equality(spellFindResults.Override, (WoWSpell) null) && spellFindResults.Original.CanCast);
  }

  public static void smethod_8()
  {
    if (((WoWUnit) Class77.LocalPlayer_0).IsAutoAttacking)
      return;
    Lua.DoString("StartAttack()", "WoW.lua");
  }

  public static void smethod_9()
  {
    if (!((WoWUnit) Class77.LocalPlayer_0).IsAutoAttacking)
      return;
    Lua.DoString("SpellCancelQueuedSpell(); StopAttack();", "WoW.lua");
  }

  public static void smethod_10(WoWUnit woWUnit_0)
  {
    Class77.LocalPlayer_0.SetFocus((WoWObject) woWUnit_0);
    Class50.woWUnit_1 = woWUnit_0;
    Lua.DoString("TargetFrame_Update(FocusFrame)", "WoW.lua");
    Class77.delegate32_1((object) $"[AutoFocus] Set focus to: {((WoWObject) woWUnit_0).SafeName}{(object) DateTime.UtcNow.Millisecond}");
  }

  public static void smethod_11() => Lua.DoString("ClearFocus()", "WoW.lua");

  private delegate void Delegate32(params object[] args);
}
