﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class42
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using GreyMagic;
using Styx;
using Styx.Common;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Runtime.InteropServices;
using System.Windows.Media;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class42
{
  private static bool bool_0;
  private static Class42.Delegate15 delegate15_0 = new Class42.Delegate15(Class62.smethod_0);

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static bool Boolean_0 => VitalicSettings.Instance.AcceptQueues;

  [DllImport("User32.dll", SetLastError = true)]
  private static extern void SwitchToThisWindow(IntPtr intptr_0, bool bool_1);

  [DllImport("User32.dll", SetLastError = true)]
  private static extern IntPtr GetForegroundWindow();

  public static void Initialise() => Class42.Attach();

  public static void Attach()
  {
    if (Class42.bool_0 || !Class42.Boolean_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.UPDATE_BATTLEFIELD_STATUS, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.LFG_PROPOSAL_SHOW, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_2)));
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.LFG_ROLE_CHECK_SHOW, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_3)));
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.READY_CHECK, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_4)));
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.PLAYER_DEAD, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_5)));
    Class42.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class42.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.UPDATE_BATTLEFIELD_STATUS, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.LFG_PROPOSAL_SHOW, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_2)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.LFG_ROLE_CHECK_SHOW, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_3)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.READY_CHECK, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_4)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.PLAYER_DEAD, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_5)));
    Class42.bool_0 = false;
  }

  public static void Shutdown() => Class42.smethod_0();

  private static void smethod_1(object sender, LuaEventArgs e)
  {
    if (!Class42.Boolean_0 || Battlegrounds.GetBGIndexWithStatus((BattlegroundStatus) 2) == -1)
      return;
    Battlegrounds.AcceptBattlegroundConfirmation();
    if (!VitalicSettings.Instance.AlertQueues)
      return;
    if (Class42.GetForegroundWindow() != ((MemoryBase) StyxWoW.Memory).Process.MainWindowHandle)
      Class42.SwitchToThisWindow(((MemoryBase) StyxWoW.Memory).Process.MainWindowHandle, true);
    Class140.smethod_8(Enum16.const_1);
  }

  private static void smethod_2(object sender, LuaEventArgs e)
  {
    if (!Class42.Boolean_0)
      return;
    Lua.DoString("AcceptProposal()", "WoW.lua");
    Logging.Write(Colors.HotPink, "Auto-accepted an LFG queue at {0}", new object[1]
    {
      (object) DateTime.UtcNow.ToString()
    });
    if (!VitalicSettings.Instance.AlertQueues)
      return;
    if (Class42.GetForegroundWindow() != ((MemoryBase) StyxWoW.Memory).Process.MainWindowHandle)
      Class42.SwitchToThisWindow(((MemoryBase) StyxWoW.Memory).Process.MainWindowHandle, true);
    Class140.smethod_8(Enum16.const_1);
  }

  private static void smethod_3(object sender, LuaEventArgs e)
  {
    if (!Class42.Boolean_0)
      return;
    using (StyxWoW.Memory.AcquireFrame())
    {
      Lua.DoString("RunMacroText('/click RolePollPopupRoleButtonDPS')", "WoW.lua");
      Lua.DoString("LFDRoleCheckPopupAccept_OnClick()", "WoW.lua");
      Lua.DoString("LFDRoleCheckPopup:Hide()", "WoW.lua");
    }
    Logging.Write(Colors.HotPink, "Auto-accepted a role check at {0}", new object[1]
    {
      (object) DateTime.UtcNow.ToString()
    });
  }

  private static void smethod_4(object sender, LuaEventArgs e)
  {
    if (!Class42.Boolean_0)
      return;
    Lua.DoString("RunMacroText('/click ReadyCheckFrameYesButton')", "WoW.lua");
    Logging.Write(Colors.HotPink, "Auto-accepted a ready check at {0}", new object[1]
    {
      (object) DateTime.UtcNow.ToString()
    });
  }

  private static void smethod_5(object sender, LuaEventArgs e)
  {
    if (!Class42.Boolean_0)
      return;
    Lua.DoString("RepopMe()", "WoW.lua");
  }

  private delegate void Delegate15(params object[] args);
}
