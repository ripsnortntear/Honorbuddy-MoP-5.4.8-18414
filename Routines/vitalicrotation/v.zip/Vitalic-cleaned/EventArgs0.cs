﻿// Decompiled with JetBrains decompiler
// Type: ns1.EventArgs0
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Globalization;
using System.Linq;

#nullable disable
namespace ns1;

internal class EventArgs0 : LuaEventArgs
{
  public Lazy<Class37.Types> lazy_0;
  public Lazy<ulong> lazy_1;
  public Lazy<WoWUnit> lazy_2;
  public Lazy<Enum13> lazy_3;
  public Lazy<ulong> lazy_4;
  public Lazy<WoWUnit> lazy_5;
  public Lazy<Enum13> lazy_6;
  public Lazy<int> lazy_7;
  public Lazy<WoWSpell> lazy_8;

  public EventArgs0(string string_0, uint uint_0, object[] object_0)
    : base(string_0, uint_0, object_0)
  {
    this.lazy_0 = new Lazy<Class37.Types>((Func<Class37.Types>) (() => this.Types_0));
    this.lazy_1 = new Lazy<ulong>((Func<ulong>) (() => this.UInt64_0));
    this.lazy_2 = new Lazy<WoWUnit>((Func<WoWUnit>) (() => this.WoWUnit_0));
    this.lazy_3 = new Lazy<Enum13>((Func<Enum13>) (() => this.Enum13_0));
    this.lazy_4 = new Lazy<ulong>((Func<ulong>) (() => this.UInt64_1));
    this.lazy_5 = new Lazy<WoWUnit>((Func<WoWUnit>) (() => this.WoWUnit_1));
    this.lazy_6 = new Lazy<Enum13>((Func<Enum13>) (() => this.Enum13_1));
    this.lazy_7 = new Lazy<int>((Func<int>) (() => this.Int32_0));
    this.lazy_8 = new Lazy<WoWSpell>((Func<WoWSpell>) (() => this.WoWSpell_0));
  }

  public double Double_0 => (double) this.Args[0];

  private Class37.Types Types_0
  {
    get => (Class37.Types) Enum.Parse(typeof (Class37.Types), this.Args[1].ToString());
  }

  private ulong UInt64_0 => EventArgs0.smethod_0(this.Args[3]);

  private WoWUnit WoWUnit_0
  {
    get
    {
      return ObjectManager.GetObjectsOfType<WoWUnit>(true, true).FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_0 =>
      {
        if (!((WoWObject) woWUnit_0).IsValid)
          return false;
        return (long) ((WoWObject) woWUnit_0).Guid == (long) this.lazy_1.Value || (long) ((WoWObject) woWUnit_0).DescriptorGuid == (long) this.lazy_1.Value;
      }));
    }
  }

  public string String_0 => this.Args[4].ToString();

  private Enum13 Enum13_0 => (Enum13) (double) this.Args[5];

  private ulong UInt64_1 => EventArgs0.smethod_0(this.Args[7]);

  private WoWUnit WoWUnit_1
  {
    get
    {
      return ObjectManager.GetObjectsOfType<WoWUnit>(true, true).FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_0 =>
      {
        if (!((WoWObject) woWUnit_0).IsValid)
          return false;
        return (long) ((WoWObject) woWUnit_0).Guid == (long) this.lazy_4.Value || (long) ((WoWObject) woWUnit_0).DescriptorGuid == (long) this.lazy_4.Value;
      }));
    }
  }

  public string String_1 => this.Args[8].ToString();

  private Enum13 Enum13_1 => (Enum13) (double) this.Args[9];

  private int Int32_0
  {
    get
    {
      try
      {
        return (int) (double) this.Args[11];
      }
      catch (Exception ex)
      {
        return 0;
      }
    }
  }

  private WoWSpell WoWSpell_0 => WoWSpell.FromId(this.lazy_7.Value);

  public WoWSpellSchool WoWSpellSchool_0 => (WoWSpellSchool) (int) (double) this.Args[13];

  private static ulong smethod_0(object object_0)
  {
    string s = object_0.ToString().Replace("0x", string.Empty);
    if (string.IsNullOrEmpty(s))
      return 0;
    try
    {
      return ulong.Parse(s, NumberStyles.HexNumber);
    }
    catch
    {
    }
    return 0;
  }
}
