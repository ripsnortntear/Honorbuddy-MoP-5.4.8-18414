﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class87
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals;

#nullable disable
namespace ns1;

internal class Class87 : Class84
{
  public static uint UInt32_0
  {
    get
    {
      WoWAura auraById = Class84.WoWUnit_0.GetAuraById(115189);
      return !WoWAura.op_Inequality(auraById, (WoWAura) null) ? 0U : auraById.StackCount;
    }
  }

  public static Composite Composite_4
  {
    get
    {
      return (Composite) new PrioritySelector(new Composite[30]
      {
        Class84.smethod_1(),
        Class93.smethod_4(),
        Class116.smethod_4(),
        Class101.smethod_4(),
        Class113.smethod_4(),
        Class117.smethod_4(),
        Class118.smethod_6(),
        Class122.smethod_5(),
        Class102.smethod_4(),
        Class115.smethod_5(),
        Class112.smethod_4(),
        Class105.smethod_4(),
        Class106.smethod_4(),
        Class111.smethod_4(),
        Class124.smethod_5(),
        Class123.smethod_4(),
        Class119.smethod_4(),
        Class92.smethod_4(),
        Class104.smethod_4(),
        Class103.smethod_4(),
        Class97.smethod_4(),
        Class109.smethod_4(),
        Class114.smethod_4(),
        Class121.smethod_4(),
        Class129.smethod_4(),
        Class120.smethod_4(),
        Class127.smethod_4(),
        Class126.smethod_4(),
        Class128.smethod_4(),
        Class108.smethod_4()
      });
    }
  }
}
