﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class44
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class44
{
  private const int int_0 = 81748;
  private const int int_1 = 81744;
  private static bool bool_0;
  private static Class44.Delegate17 delegate17_0 = new Class44.Delegate17(Class62.smethod_0);
  private static DateTime dateTime_0;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static double Double_0 => (DateTime.UtcNow - Class44.dateTime_0).TotalSeconds;

  public static void Initialise() => Class44.Attach();

  public static void Attach()
  {
    if (Class44.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.CHAT_MSG_BG_SYSTEM_ALLIANCE, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.CHAT_MSG_BG_SYSTEM_HORDE, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_2)));
    Class44.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class44.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.CHAT_MSG_BG_SYSTEM_ALLIANCE, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.CHAT_MSG_BG_SYSTEM_HORDE, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_2)));
    Class44.bool_0 = false;
  }

  public static void Shutdown() => Class44.smethod_0();

  private static void smethod_1(object sender, LuaEventArgs e)
  {
    if (Class53.smethod_3((WoWUnit) Class44.LocalPlayer_0, 81744) || !((WoWPlayer) Class44.LocalPlayer_0).IsAlliance && !Class53.smethod_3((WoWUnit) Class44.LocalPlayer_0, 81748))
      return;
    Class62.smethod_1((object) "[FlagReturn] Scanning for flag");
    Class44.dateTime_0 = DateTime.UtcNow;
  }

  private static void smethod_2(object sender, LuaEventArgs e)
  {
    if (Class53.smethod_3((WoWUnit) Class44.LocalPlayer_0, 81748) || !((WoWPlayer) Class44.LocalPlayer_0).IsHorde && !Class53.smethod_3((WoWUnit) Class44.LocalPlayer_0, 81744))
      return;
    Class62.smethod_1((object) "[FlagReturn] Scanning for flag");
    Class44.dateTime_0 = DateTime.UtcNow;
  }

  private delegate void Delegate17(params object[] args);
}
