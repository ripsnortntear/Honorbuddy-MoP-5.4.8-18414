﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class120
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

#nullable disable
namespace ns1;

internal class Class120 : Class91
{
  private static bool Boolean_21
  {
    get
    {
      bool flag1 = Class71.CurrentSpec == 259;
      bool flag2 = Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_0);
      if ((Class74.smethod_3(1833) > 0.5 ? 1 : (!flag2 ? 0 : (flag1 ? 1 : (Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_0) ? 1 : 0)))) == 0)
        return false;
      return (Class91.Int32_0 != 1943 || flag2) && Class91.Int32_0 != 1833 || flag1;
    }
  }

  private static bool Boolean_22
  {
    get
    {
      WoWAura auraById = Class91.WoWUnit_0.GetAuraById(408);
      if (!WoWAura.op_Inequality(auraById, (WoWAura) null))
        return false;
      if ((double) (auraById.Duration / 1000U) <= 4.5 || Class91.Int32_0 != 408)
        return true;
      return Class71.CurrentSpec == 259 && !Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 32645);
    }
  }

  private static bool Boolean_23
  {
    get
    {
      Class68.Struct22 struct22 = Class91.WoWUnit_0.smethod_6(Class68.Enum14.const_0);
      if (!Class65.Boolean_0 || !Class144.Boolean_3 && (!struct22.bool_0 || struct22.double_0 >= 1.0 || struct22.timeSpan_0.TotalSeconds <= 5.0))
        return false;
      return Class91.Int32_0 == 2098 || Class91.Int32_2 == 32645 || Class91.Int32_2 == 5171;
    }
  }

  private static bool Boolean_24
  {
    get
    {
      return !Class120.Boolean_25 && Class91.Double_4 < 30.0 && !Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 51713) || (double) Class91.WoWUnit_0.CurrentHealth < Class91.Double_6;
    }
  }

  private static bool Boolean_25
  {
    get
    {
      if (!Class91.Boolean_1 || Class61.Int32_0 <= 1 && !Class53.smethod_3(Class91.WoWUnit_0, 113742) || Class71.CurrentSpec == 259 && Class59.smethod_2(79140) >= 50.0)
        return false;
      return Class71.CurrentSpec != 261 || !Class53.smethod_3(Class91.WoWUnit_0, 91021) || Class91.Double_4 > 60.0 || !Class59.smethod_0(51713) || Class59.smethod_2(51713) < 48.0;
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class120.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class120.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    return Class77.smethod_1(137619, Class120.canRunDecoratorDelegate_0, "Marked for Death");
  }
}
