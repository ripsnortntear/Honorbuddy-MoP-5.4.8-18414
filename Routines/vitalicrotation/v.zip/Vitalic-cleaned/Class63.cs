﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class63
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

internal static class Class63
{
  private static Class63.Delegate26 delegate26_0 = new Class63.Delegate26(Class62.smethod_0);
  private static Class63.Delegate26 delegate26_1 = new Class63.Delegate26(Class62.smethod_1);
  private static IEnumerable<WoWUnit> ienumerable_0;
  private static IEnumerable<WoWUnit> ienumerable_1;
  private static IEnumerable<WoWUnit> ienumerable_2;
  private static readonly Dictionary<ulong, Class63.Struct19> dictionary_0 = new Dictionary<ulong, Class63.Struct19>();
  private static readonly Dictionary<ulong, Class63.Struct20> dictionary_1 = new Dictionary<ulong, Class63.Struct20>();
  public static readonly HashSet<uint> hashSet_0 = new HashSet<uint>()
  {
    31146U,
    54344U,
    46647U,
    32546U,
    31144U,
    32543U,
    32667U,
    32542U,
    32666U,
    30527U,
    67127U,
    88375U
  };

  static Class63()
  {
    Class144.Event_0 += (Class144.Delegate42) ((sender, e) =>
    {
      Class63.smethod_5();
      Class63.smethod_7();
    });
  }

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static ulong UInt64_0 => Class50.ulong_0;

  internal static IEnumerable<WoWUnit> IEnumerable_0
  {
    get
    {
      if (Class63.ienumerable_0 != null)
        return Class63.ienumerable_0;
      IEnumerable<WoWUnit> source = (IEnumerable<WoWUnit>) Class51.smethod_0<List<WoWUnit>>("attackable_units");
      if (source == null)
      {
        source = ObjectManager.GetObjectsOfType<WoWUnit>(true, false).Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_0 =>
        {
          if (!((WoWObject) woWUnit_0).IsValid || woWUnit_0.IsDead || !woWUnit_0.CanSelect || !woWUnit_0.Attackable || !Class63.LocalPlayer_0.smethod_0(woWUnit_0) || woWUnit_0.IsNonCombatPet || woWUnit_0.IsCritter)
            return false;
          return Class41.bool_1 || ((WoWObject) woWUnit_0).Distance < 40.0;
        }));
        Class51.smethod_1<List<WoWUnit>>(source.ToList<WoWUnit>(), "attackable_units", 3000);
      }
      if (Class63.ienumerable_0 == null)
        Class63.ienumerable_0 = source;
      return source;
    }
  }

  internal static IEnumerable<WoWUnit> IEnumerable_1
  {
    get
    {
      if (Class63.ienumerable_1 != null)
        return Class63.ienumerable_1;
      IEnumerable<WoWUnit> source = (IEnumerable<WoWUnit>) Class51.smethod_0<List<WoWUnit>>("units_in_melee");
      if (source == null)
      {
        source = Class63.IEnumerable_0.Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_0 => Class63.smethod_6(woWUnit_0)));
        Class51.smethod_1<List<WoWUnit>>(source.ToList<WoWUnit>(), "units_in_melee", 1250);
      }
      if (Class63.ienumerable_1 == null)
        Class63.ienumerable_1 = source;
      return source;
    }
  }

  internal static IEnumerable<WoWUnit> IEnumerable_2
  {
    get
    {
      if (Class63.ienumerable_2 != null)
        return Class63.ienumerable_2;
      IEnumerable<WoWUnit> source = (IEnumerable<WoWUnit>) Class51.smethod_0<List<WoWUnit>>("enemy_healers");
      if (source == null)
      {
        source = Class63.IEnumerable_0.Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_0 => ((WoWObject) woWUnit_0).IsValid && woWUnit_0.IsPlayer && woWUnit_0.smethod_17()));
        Class51.smethod_1<List<WoWUnit>>(source.ToList<WoWUnit>(), "enemy_healers", 2500);
      }
      if (Class63.ienumerable_2 == null)
        Class63.ienumerable_2 = source;
      return source;
    }
  }

  internal static IEnumerable<WoWUnit> IEnumerable_3
  {
    get
    {
      return Class63.IEnumerable_0.Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_0 => ((WoWObject) woWUnit_0).IsValid && WoWObject.op_Equality((WoWObject) woWUnit_0.CurrentTarget, (WoWObject) Class63.LocalPlayer_0)));
    }
  }

  public static Composite smethod_0()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class63.actionDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class63.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_13));
    }
    // ISSUE: reference to a compiler-generated field
    return (Composite) new Action(Class63.actionDelegate_0);
  }

  public static bool smethod_1(WoWUnit woWUnit_0)
  {
    return Class63.hashSet_0.Contains(((WoWObject) woWUnit_0).Entry);
  }

  public static bool smethod_2(WoWUnit woWUnit_0)
  {
    if (!WoWObject.op_Inequality((WoWObject) woWUnit_0, (WoWObject) null) || !((WoWObject) woWUnit_0).IsValid)
      return false;
    return woWUnit_0.IsPlayer || Class63.smethod_1(woWUnit_0) || Class144.Boolean_3;
  }

  public static bool smethod_3(WoWUnit woWUnit_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class63.Class64 class64 = new Class63.Class64();
    // ISSUE: reference to a compiler-generated field
    class64.woWUnit_0 = woWUnit_0.IsPlayer ? woWUnit_0 : woWUnit_0.CreatedByUnit;
    // ISSUE: reference to a compiler-generated field
    if (WoWObject.op_Equality((WoWObject) null, (WoWObject) class64.woWUnit_0))
      return false;
    // ISSUE: reference to a compiler-generated method
    // ISSUE: reference to a compiler-generated method
    return ((IEnumerable<ulong>) Class63.LocalPlayer_0.GroupInfo.PartyMemberGuids).Any<ulong>(new Func<ulong, bool>(class64.method_0)) || ((IEnumerable<ulong>) Class63.LocalPlayer_0.GroupInfo.RaidMemberGuids).Any<ulong>(new Func<ulong, bool>(class64.method_1));
  }

  public static bool smethod_4(this WoWUnit woWUnit_0, double double_0 = 2.0)
  {
    Class63.Struct19 struct19;
    if (Class63.dictionary_0.TryGetValue(((WoWObject) woWUnit_0).Guid, out struct19))
    {
      if (struct19.double_0 <= double_0 || struct19.dateTime_0 - TimeSpan.FromSeconds(double_0) > DateTime.UtcNow)
        return struct19.bool_0;
      Class63.dictionary_0.Remove(((WoWObject) woWUnit_0).Guid);
    }
    bool lineOfSpellSight = woWUnit_0.InLineOfSpellSight;
    Class63.dictionary_0.Add(((WoWObject) woWUnit_0).Guid, new Class63.Struct19(DateTime.UtcNow + TimeSpan.FromSeconds(double_0), double_0, lineOfSpellSight));
    return lineOfSpellSight;
  }

  public static void smethod_5()
  {
    foreach (ulong key in Class63.dictionary_0.Where<KeyValuePair<ulong, Class63.Struct19>>((Func<KeyValuePair<ulong, Class63.Struct19>, bool>) (keyValuePair_0 => keyValuePair_0.Value.dateTime_0 < DateTime.UtcNow)).Select<KeyValuePair<ulong, Class63.Struct19>, ulong>((Func<KeyValuePair<ulong, Class63.Struct19>, ulong>) (keyValuePair_0 => keyValuePair_0.Key)).ToList<ulong>())
      Class63.dictionary_0.Remove(key);
  }

  public static bool smethod_6(this WoWUnit woWUnit_0, bool bool_0 = false)
  {
    ulong guid = ((WoWObject) woWUnit_0).Guid;
    Class63.Struct20 struct20;
    if (Class63.dictionary_1.TryGetValue(guid, out struct20))
      return struct20.bool_0;
    bool bool_1 = woWUnit_0.smethod_2(bool_0) <= 3.5;
    int num = (long) guid == (long) Class63.UInt64_0 ? 50 : 250;
    Class63.dictionary_1.Add(guid, new Class63.Struct20(DateTime.UtcNow + TimeSpan.FromMilliseconds((double) num), bool_1));
    return bool_1;
  }

  public static void smethod_7()
  {
    foreach (ulong key in Class63.dictionary_1.Where<KeyValuePair<ulong, Class63.Struct20>>((Func<KeyValuePair<ulong, Class63.Struct20>, bool>) (keyValuePair_0 => keyValuePair_0.Value.dateTime_0 < DateTime.UtcNow)).Select<KeyValuePair<ulong, Class63.Struct20>, ulong>((Func<KeyValuePair<ulong, Class63.Struct20>, ulong>) (keyValuePair_0 => keyValuePair_0.Key)).ToList<ulong>())
      Class63.dictionary_1.Remove(key);
  }

  private delegate void Delegate26(params object[] args);

  private struct Struct19(DateTime dateTime_1, double double_1, bool bool_1)
  {
    public DateTime dateTime_0 = dateTime_1;
    public double double_0 = double_1;
    public bool bool_0 = bool_1;
  }

  private struct Struct20(DateTime dateTime_1, bool bool_1)
  {
    public DateTime dateTime_0 = dateTime_1;
    public bool bool_0 = bool_1;
  }
}
