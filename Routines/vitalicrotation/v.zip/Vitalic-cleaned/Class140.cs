﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class140
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using A;
using Styx.Common;
using Styx.CommonBot;
using Styx.WoWInternals;
using System;
using System.Collections.Generic;
using System.IO;
using System.Media;
using System.Reflection;
using System.Text.RegularExpressions;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class140
{
  private static string string_0;
  private static bool bool_0;
  public static bool bool_1 = VitalicSettings.Instance.SpellAlertsEnabled;
  public static bool bool_2 = VitalicSettings.Instance.LogMessagesEnabled;
  private static Assembly assembly_0 = Assembly.GetExecutingAssembly();
  public static readonly Class140.Struct24 struct24_0 = new Class140.Struct24(0.0, 0.75, 1.0);
  public static readonly Class140.Struct24 struct24_1 = new Class140.Struct24(0.5, 1.0, 0.0);
  public static readonly Class140.Struct24 struct24_2 = new Class140.Struct24(1.0, 1.0, 0.0);
  public static readonly Class140.Struct24 struct24_3 = new Class140.Struct24(1.0, 0.65, 0.0);
  public static readonly Class140.Struct24 struct24_4 = new Class140.Struct24(1.0, 0.0, 0.0);
  public static readonly Class140.Struct24 struct24_5 = new Class140.Struct24(0.93, 0.51, 0.93);
  public static readonly Class140.Struct24 struct24_6 = new Class140.Struct24(1.0, 1.0, 1.0);
  public static readonly Class140.Struct24 struct24_7 = new Class140.Struct24(0.67, 0.83, 0.45);
  private static Dictionary<Enum16, SoundPlayer> dictionary_0 = new Dictionary<Enum16, SoundPlayer>()
  {
    {
      Enum16.const_0,
      Class140.smethod_0("interrupt.wav")
    },
    {
      Enum16.const_2,
      Class140.smethod_0("event.wav")
    },
    {
      Enum16.const_1,
      Class140.smethod_0("ready.wav")
    },
    {
      Enum16.const_3,
      Class140.smethod_0("bigwigs_alarm.wav")
    }
  };
  private static DateTime dateTime_0;

  private static SoundPlayer smethod_0(string string_1)
  {
    Stream stream = \u0020\u0006.\u0001(string_1);
    if (stream != null)
      return new SoundPlayer(stream);
    string str = $"{Utilities.AssemblyDirectory}\\Routines\\Vitalic\\Resources\\{string_1}";
    return File.Exists(str) ? new SoundPlayer(str) : new SoundPlayer();
  }

  public static void smethod_1()
  {
    if (!Class140.bool_0)
    {
      // ISSUE: reference to a compiler-generated field
      if (Class140.onBotStartDelegate_0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: method pointer
        Class140.onBotStartDelegate_0 = new BotEvents.OnBotStartDelegate((object) null, __methodptr(smethod_10));
      }
      // ISSUE: reference to a compiler-generated field
      BotEvents.OnBotStarted += Class140.onBotStartDelegate_0;
      Class41.Event_0 += (EventHandler) ((sender, e) => Class140.smethod_1());
    }
    Class140.bool_0 = true;
    if (!Class140.bool_1 || Class140.bool_0 && Class140.smethod_2())
      return;
    Lua.DoString("ZoneTextFrame.icon = ZoneTextFrame:CreateTexture('ZoneTextFrameIcon', 0)\r\n                    ZoneTextFrame:SetScript('OnHide', function() ZoneTextFrame.icon:SetTexture(nil) end)\r\n                    ZoneTextFrame.icon:SetWidth(35)\r\n\t\t\t        ZoneTextFrame.icon:SetHeight(35)\r\n                    ZoneTextFrame.icon:SetTexCoord(.08, .92, .08, .92)\r\n                ", "WoW.lua");
    if (!VitalicSettings.Instance.AlertFontsEnabled)
      return;
    Class140.smethod_3();
  }

  public static bool smethod_2() => Lua.GetReturnVal<bool>("return ZoneTextFrame.icon ~= nil", 0U);

  public static void smethod_3()
  {
    Lua.DoString("if not strmatch(ZoneTextString:GetFont(), 'calibrib') then\r\n\t            ZoneTextString:SetFont([[Fonts\\calibrib.ttf]], 28, 'OUTLINE')\r\n\t            PVPInfoTextString:SetFont([[Fonts\\calibrib.ttf]], 20, 'OUTLINE')\r\n\t            SubZoneTextString:SetFont([[Fonts\\calibrib.ttf]], 20, 'OUTLINE')\r\n\t            UIErrorsFrame:SetFont([[Fonts\\calibrib.ttf]], 16, 'OUTLINE')\r\n            end", "WoW.lua");
  }

  public static void smethod_4()
  {
    Lua.DoString("if not strmatch(ZoneTextString:GetFont(), 'FRIZQT') then\r\n\t\t        ZoneTextString:SetFont([[Fonts\\FRIZQT__.TTF]], 28, 'THICKOUTLINE')\r\n\t\t        PVPInfoTextString:SetFont([[Fonts\\FRIZQT__.TTF]], 22, 'OUTLINE, THICKOUTLINE')\r\n\t\t        SubZoneTextString:SetFont([[Fonts\\FRIZQT__.TTF]], 26, 'THICKOUTLINE')\r\n\t\t        UIErrorsFrame:SetFont([[Fonts\\FRIZQT__.TTF]], 16)\r\n\t        end", "WoW.lua");
  }

  public static void smethod_5(
    string string_1,
    Class140.Struct24 struct24_8,
    int int_0,
    bool bool_3 = false)
  {
    if (string_1 == Class140.string_0)
      return;
    if (Class140.bool_1)
      Lua.DoString("ZoneTextString:SetText(\"{0}\")\r\n                    PVPInfoTextString:SetText('')\r\n                    ZoneTextFrame.startTime = GetTime()\r\n                    ZoneTextFrame.fadeInTime = 0\r\n\t\t\t        ZoneTextFrame.holdTime = 1\r\n\t\t\t        ZoneTextFrame.fadeOutTime = 2\r\n                    ZoneTextString:SetTextColor({1}, {2}, {3})\r\n                    ZoneTextFrame.icon:SetPoint('LEFT', ZoneTextString, ((ZoneTextString:GetWidth() / 2) - (ZoneTextString:GetStringWidth() / 2) - 43), 1)\r\n                    ZoneTextFrame.icon:SetTexture(select(3, GetSpellInfo({4})))\r\n\t\t\t        ZoneTextFrame:Show()\r\n                ", new object[5]
      {
        (object) string_1,
        (object) struct24_8.double_0,
        (object) struct24_8.double_1,
        (object) struct24_8.double_2,
        (object) int_0
      });
    Class140.string_0 = string_1;
    if (bool_3)
      return;
    Class140.smethod_9(string_1);
  }

  public static void smethod_6(
    string string_1,
    Class140.Struct24 struct24_8,
    WoWSpell woWSpell_0,
    bool bool_3 = false)
  {
    Class140.smethod_5(string_1, struct24_8, woWSpell_0.Id, bool_3);
  }

  public static void smethod_7(string string_1, Class140.Struct24 struct24_8, bool bool_3 = false)
  {
    if (string_1 == Class140.string_0)
      return;
    if (Class140.bool_1)
      Lua.DoString("UIErrorsFrame:AddMessage(\"{0}\", {1}, {2}, {3})", new object[4]
      {
        (object) string_1,
        (object) struct24_8.double_0,
        (object) struct24_8.double_1,
        (object) struct24_8.double_2
      });
    Class140.string_0 = string_1;
    if (bool_3)
      return;
    Class140.smethod_9(string_1);
  }

  public static void smethod_8(Enum16 enum16_0)
  {
    if (!VitalicSettings.Instance.SoundAlertsEnabled || !Class140.dictionary_0.ContainsKey(enum16_0) || !(DateTime.UtcNow - Class140.dateTime_0 > TimeSpan.FromSeconds(1.0)))
      return;
    Class140.dictionary_0[enum16_0].Play();
    Class140.dateTime_0 = DateTime.UtcNow;
  }

  public static void smethod_9(string string_1)
  {
    if (Class140.bool_2)
      Lua.DoString("print('[{0}] {1}')", new object[2]
      {
        (object) DateTime.UtcNow.ToString(),
        (object) string_1
      });
    else
      Logging.Write(new Regex("(?i)\\|cff\\w{6}").Replace(string_1, ""));
  }

  public struct Struct24(double double_3, double double_4, double double_5)
  {
    public double double_0 = double_3;
    public double double_1 = double_4;
    public double double_2 = double_5;
  }
}
