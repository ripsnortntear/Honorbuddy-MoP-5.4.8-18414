﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class84
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Linq;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class84
{
  private static Class84.Delegate33 delegate33_0 = new Class84.Delegate33(Class62.smethod_0);
  private static Class84.Delegate33 delegate33_1 = new Class84.Delegate33(Class62.smethod_1);
  private static DateTime dateTime_0;
  private static WoWUnit woWUnit_0;
  private static WoWUnit woWUnit_1;

  protected static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  protected static WoWUnit WoWUnit_1 => Class50.woWUnit_2;

  protected static WoWUnit WoWUnit_2 => Class50.woWUnit_1;

  public static Composite smethod_0()
  {
    return (Composite) new GClass71(new Composite[8]
    {
      Class134.smethod_0(),
      Class53.smethod_8(),
      Class141.smethod_1(),
      Class63.smethod_0(),
      Class80.Composite_0,
      Class84.smethod_3(),
      Class84.smethod_2(),
      Class84.Composite_2
    });
  }

  public static Composite smethod_1()
  {
    return (Composite) new GClass71(new Composite[9]
    {
      Class134.smethod_0(),
      Class53.smethod_8(),
      Class141.smethod_1(),
      Class63.smethod_0(),
      Class80.Composite_0,
      Class84.smethod_3(),
      Class84.smethod_2(),
      Class84.Composite_2,
      Class84.Composite_0
    });
  }

  private static Composite Composite_0
  {
    get
    {
      if (Class84.actionDelegate_0 == null)
        Class84.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_5));
      return (Composite) new Action(Class84.actionDelegate_0);
    }
  }

  private static Composite smethod_2()
  {
    return (Composite) new GClass70("Targeting", new Composite[4]
    {
      Class141.Composite_0,
      Class61.Composite_3,
      Class61.Composite_2,
      Class84.Composite_1
    });
  }

  private static Composite smethod_3()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class84.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class84.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    return (Composite) new GClass69("Pause Check", Class84.canRunDecoratorDelegate_0, (Composite) new ActionAlwaysSucceed());
  }

  private static bool Boolean_0
  {
    get
    {
      Class84.woWUnit_1 = ObjectManager.GetObjectsOfType<WoWUnit>(false).FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_2 => woWUnit_2.IsTotem && !woWUnit_2.IsDead && Class141.dictionary_4.ContainsKey((int) woWUnit_2.CreatedBySpellId) && Class141.dictionary_0.ContainsKey(Class141.dictionary_4[(int) woWUnit_2.CreatedBySpellId]) && (VitalicSettings.Instance.TotemStomp & Class141.dictionary_4[(int) woWUnit_2.CreatedBySpellId]) != Totems.None && WoWObject.op_Inequality((WoWObject) woWUnit_2, (WoWObject) Class84.WoWUnit_0) && Class63.smethod_6(woWUnit_2) && ((WoWObject) Class84.LocalPlayer_0).IsFacing((WoWObject) woWUnit_2) && Class84.LocalPlayer_0.smethod_0(woWUnit_2)));
      return WoWObject.op_Inequality((WoWObject) Class84.woWUnit_1, (WoWObject) null);
    }
  }

  private static int Int32_0
  {
    get
    {
      if (Class71.CurrentSpec == 261)
        return 16511;
      if (Class71.CurrentSpec != 259)
        return 84617;
      return !Class53.smethod_3((WoWUnit) Class84.LocalPlayer_0, 121153) ? 1329 : 111240;
    }
  }

  public static int Int32_1 => Class71.CurrentSpec == 259 ? 32645 : 2098;

  public static Composite smethod_4(Class144.Delegate43 delegate43_1)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class84.Class88 class88 = new Class84.Class88();
    // ISSUE: reference to a compiler-generated field
    class88.delegate43_0 = delegate43_1;
    Composite[] compositeArray1 = new Composite[4]
    {
      Class84.Composite_3,
      null,
      null,
      null
    };
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: method pointer
    CanRunDecoratorDelegate decoratorDelegate1 = new CanRunDecoratorDelegate((object) class88, __methodptr(method_0));
    // ISSUE: method pointer
    // ISSUE: method pointer
    Composite[] compositeArray3 = new Composite[2]
    {
      (Composite) new Decorator(new CanRunDecoratorDelegate((object) class88, __methodptr(method_1)), (Composite) new Action(new ActionSucceedDelegate((object) class88, __methodptr(method_2)))),
      null
    };
    Composite[] compositeArray4 = compositeArray3;
    TimeSpan timeSpan1 = TimeSpan.FromMilliseconds(1000.0);
    // ISSUE: reference to a compiler-generated field
    if (Class84.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class84.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1_1 = Class84.canRunDecoratorDelegate_1;
    // ISSUE: method pointer
    Action action = new Action(new ActionSucceedDelegate((object) class88, __methodptr(method_3)));
    WaitContinue waitContinue1 = new WaitContinue(timeSpan1, decoratorDelegate1_1, (Composite) action);
    compositeArray4[1] = (Composite) waitContinue1;
    Sequence sequence1 = new Sequence(compositeArray3);
    Decorator decorator1 = new Decorator(decoratorDelegate1, (Composite) sequence1);
    compositeArray2[1] = (Composite) decorator1;
    Composite[] compositeArray5 = compositeArray1;
    // ISSUE: method pointer
    CanRunDecoratorDelegate decoratorDelegate2 = new CanRunDecoratorDelegate((object) class88, __methodptr(method_4));
    // ISSUE: method pointer
    Composite[] compositeArray6 = new Composite[2]
    {
      (Composite) new Action(new ActionSucceedDelegate((object) class88, __methodptr(method_5))),
      null
    };
    Composite[] compositeArray7 = compositeArray6;
    TimeSpan timeSpan2 = TimeSpan.FromMilliseconds(500.0);
    // ISSUE: reference to a compiler-generated field
    if (Class84.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class84.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate2_1 = Class84.canRunDecoratorDelegate_2;
    ActionAlwaysSucceed actionAlwaysSucceed1 = new ActionAlwaysSucceed();
    WaitContinue waitContinue2 = new WaitContinue(timeSpan2, decoratorDelegate2_1, (Composite) actionAlwaysSucceed1);
    compositeArray7[1] = (Composite) waitContinue2;
    Sequence sequence2 = new Sequence(compositeArray6);
    Decorator decorator2 = new Decorator(decoratorDelegate2, (Composite) sequence2);
    compositeArray5[2] = (Composite) decorator2;
    Composite[] compositeArray8 = compositeArray1;
    // ISSUE: method pointer
    CanRunDecoratorDelegate decoratorDelegate3 = new CanRunDecoratorDelegate((object) class88, __methodptr(method_6));
    // ISSUE: method pointer
    Composite[] compositeArray9 = new Composite[2]
    {
      (Composite) new Action(new ActionSucceedDelegate((object) class88, __methodptr(method_7))),
      null
    };
    Composite[] compositeArray10 = compositeArray9;
    TimeSpan timeSpan3 = TimeSpan.FromMilliseconds(500.0);
    // ISSUE: reference to a compiler-generated field
    if (Class84.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class84.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_10));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate3_1 = Class84.canRunDecoratorDelegate_3;
    ActionAlwaysSucceed actionAlwaysSucceed2 = new ActionAlwaysSucceed();
    WaitContinue waitContinue3 = new WaitContinue(timeSpan3, decoratorDelegate3_1, (Composite) actionAlwaysSucceed2);
    compositeArray10[1] = (Composite) waitContinue3;
    Sequence sequence3 = new Sequence(compositeArray9);
    Decorator decorator3 = new Decorator(decoratorDelegate3, (Composite) sequence3);
    compositeArray8[3] = (Composite) decorator3;
    return (Composite) new PrioritySelector(compositeArray1);
  }

  private static Composite Composite_1
  {
    get
    {
      Composite[] compositeArray1 = new Composite[2];
      Composite[] compositeArray2 = compositeArray1;
      if (Class84.canRunDecoratorDelegate_4 == null)
        Class84.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_11));
      CanRunDecoratorDelegate decoratorDelegate4 = Class84.canRunDecoratorDelegate_4;
      Composite[] compositeArray3 = new Composite[2]
      {
        Class84.smethod_4((Class144.Delegate43) (object_0 => Class84.woWUnit_1)),
        null
      };
      Composite[] compositeArray4 = compositeArray3;
      if (Class84.canRunDecoratorDelegate_5 == null)
        Class84.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_13));
      CanRunDecoratorDelegate decoratorDelegate5 = Class84.canRunDecoratorDelegate_5;
      Composite[] compositeArray5 = new Composite[3];
      Composite[] compositeArray6 = compositeArray5;
      if (Class84.actionSucceedDelegate_0 == null)
        Class84.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_14));
      Action action1 = new Action(Class84.actionSucceedDelegate_0);
      compositeArray6[0] = (Composite) action1;
      Composite[] compositeArray7 = compositeArray5;
      if (Class84.actionSucceedDelegate_1 == null)
        Class84.actionSucceedDelegate_1 = new ActionSucceedDelegate((object) null, __methodptr(smethod_15));
      Action action2 = new Action(Class84.actionSucceedDelegate_1);
      compositeArray7[1] = (Composite) action2;
      Composite[] compositeArray8 = compositeArray5;
      TimeSpan timeSpan = TimeSpan.FromMilliseconds(500.0);
      if (Class84.canRunDecoratorDelegate_6 == null)
        Class84.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_16));
      CanRunDecoratorDelegate decoratorDelegate6 = Class84.canRunDecoratorDelegate_6;
      ActionAlwaysFail actionAlwaysFail = new ActionAlwaysFail();
      WaitContinue waitContinue = new WaitContinue(timeSpan, decoratorDelegate6, (Composite) actionAlwaysFail);
      compositeArray8[2] = (Composite) waitContinue;
      Sequence sequence = new Sequence(compositeArray5);
      Decorator decorator1 = new Decorator(decoratorDelegate5, (Composite) sequence);
      compositeArray4[1] = (Composite) decorator1;
      PrioritySelector prioritySelector = new PrioritySelector(compositeArray3);
      Decorator decorator2 = new Decorator(decoratorDelegate4, (Composite) prioritySelector);
      compositeArray2[0] = (Composite) decorator2;
      Composite[] compositeArray9 = compositeArray1;
      if (Class84.canRunDecoratorDelegate_7 == null)
        Class84.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_17));
      CanRunDecoratorDelegate decoratorDelegate7 = Class84.canRunDecoratorDelegate_7;
      if (Class84.actionDelegate_1 == null)
        Class84.actionDelegate_1 = new ActionDelegate((object) null, __methodptr(smethod_18));
      Action action3 = new Action(Class84.actionDelegate_1);
      Decorator decorator3 = new Decorator(decoratorDelegate7, (Composite) action3);
      compositeArray9[1] = (Composite) decorator3;
      return (Composite) new PrioritySelector(compositeArray1);
    }
  }

  private static TimeSpan TimeSpan_0
  {
    get
    {
      return Class77.Int32_0 == 58984 ? TimeSpan.FromMilliseconds(500.0) : TimeSpan.FromMilliseconds((double) VitalicSettings.Instance.ManualCastPause);
    }
  }

  private static Composite Composite_2
  {
    get
    {
      Composite[] compositeArray1 = new Composite[2];
      Composite[] compositeArray2 = compositeArray1;
      if (Class84.canRunDecoratorDelegate_8 == null)
        Class84.canRunDecoratorDelegate_8 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_20));
      CanRunDecoratorDelegate decoratorDelegate8 = Class84.canRunDecoratorDelegate_8;
      if (Class84.actionSucceedDelegate_2 == null)
        Class84.actionSucceedDelegate_2 = new ActionSucceedDelegate((object) null, __methodptr(smethod_21));
      Action action = new Action(Class84.actionSucceedDelegate_2);
      Decorator decorator1 = new Decorator(decoratorDelegate8, (Composite) action);
      compositeArray2[0] = (Composite) decorator1;
      Composite[] compositeArray3 = compositeArray1;
      if (Class84.canRunDecoratorDelegate_9 == null)
        Class84.canRunDecoratorDelegate_9 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_22));
      Decorator decorator2 = new Decorator(Class84.canRunDecoratorDelegate_9, (Composite) new ActionAlwaysSucceed());
      compositeArray3[1] = (Composite) decorator2;
      return (Composite) new GClass70("Manual Cast Pause", compositeArray1);
    }
  }

  public static Composite Composite_3
  {
    get
    {
      Composite[] compositeArray1 = new Composite[3];
      Composite[] compositeArray2 = compositeArray1;
      if (Class84.canRunDecoratorDelegate_10 == null)
        Class84.canRunDecoratorDelegate_10 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_23));
      CanRunDecoratorDelegate decoratorDelegate10 = Class84.canRunDecoratorDelegate_10;
      if (Class84.canRunDecoratorDelegate_11 == null)
        Class84.canRunDecoratorDelegate_11 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_24));
      Composite composite1 = Class77.smethod_1(32645, Class84.canRunDecoratorDelegate_11, "Envenom (Dump)");
      Decorator decorator1 = new Decorator(decoratorDelegate10, composite1);
      compositeArray2[0] = (Composite) decorator1;
      Composite[] compositeArray3 = compositeArray1;
      if (Class84.canRunDecoratorDelegate_12 == null)
        Class84.canRunDecoratorDelegate_12 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_25));
      CanRunDecoratorDelegate decoratorDelegate12 = Class84.canRunDecoratorDelegate_12;
      if (Class84.canRunDecoratorDelegate_13 == null)
        Class84.canRunDecoratorDelegate_13 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_26));
      Composite composite2 = Class77.smethod_2(73651, Class84.canRunDecoratorDelegate_13, "Recuperate (Dump)");
      Decorator decorator2 = new Decorator(decoratorDelegate12, composite2);
      compositeArray3[1] = (Composite) decorator2;
      Composite[] compositeArray4 = compositeArray1;
      if (Class84.canRunDecoratorDelegate_14 == null)
        Class84.canRunDecoratorDelegate_14 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_27));
      CanRunDecoratorDelegate decoratorDelegate14 = Class84.canRunDecoratorDelegate_14;
      if (Class84.canRunDecoratorDelegate_15 == null)
        Class84.canRunDecoratorDelegate_15 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_28));
      Composite composite3 = Class77.smethod_2(5171, Class84.canRunDecoratorDelegate_15, "Slice and Dice (Dump)");
      Decorator decorator3 = new Decorator(decoratorDelegate14, composite3);
      compositeArray4[2] = (Composite) decorator3;
      return (Composite) new PrioritySelector(compositeArray1);
    }
  }

  private delegate void Delegate33(params object[] args);
}
