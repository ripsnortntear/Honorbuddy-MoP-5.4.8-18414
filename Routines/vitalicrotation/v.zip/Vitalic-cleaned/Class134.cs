﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class134
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.CommonBot;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class134
{
  private static Class134.Delegate35 delegate35_0 = new Class134.Delegate35(Class62.smethod_0);
  private static Class134.Delegate35 delegate35_1 = new Class134.Delegate35(Class62.smethod_1);
  private static Class134 class134_0;
  public Lazy<double> lazy_0 = new Lazy<double>(new Func<double>(((Class70) Class134.LocalPlayer_0).smethod_1));
  public Lazy<double> lazy_1 = new Lazy<double>(new Func<double>(Class91.smethod_3));
  public Lazy<bool> lazy_2 = new Lazy<bool>(new Func<bool>(Class91.smethod_1));
  public Lazy<bool> lazy_3 = new Lazy<bool>(new Func<bool>(Class121.smethod_5));
  public Lazy<double> lazy_4 = new Lazy<double>(new Func<double>(Class91.smethod_2));
  public Lazy<WoWPlayer> lazy_5 = new Lazy<WoWPlayer>(new Func<WoWPlayer>(((Class70) Class134.LocalPlayer_0.GroupInfo).smethod_20));
  public Lazy<bool> lazy_6 = new Lazy<bool>((Func<bool>) (() => ((WoWUnit) Class134.LocalPlayer_0).smethod_4()));
  public Lazy<double> lazy_7 = new Lazy<double>((Func<double>) (() => ((WoWUnit) Class134.LocalPlayer_0).HealthPercent));
  public Lazy<double> lazy_8 = new Lazy<double>((Func<double>) (() =>
  {
    double totalMilliseconds = SpellManager.GlobalCooldownLeft.TotalMilliseconds;
    if (totalMilliseconds <= 1500.0)
      return totalMilliseconds;
    Class51.Class52<DateTime> class52 = Class51.smethod_0<Class51.Class52<DateTime>>("gcd_remaining");
    if (class52 == null)
    {
      using (StyxWoW.Memory.AcquireFrame())
      {
        Class51.Class52<DateTime> gparam_0 = new Class51.Class52<DateTime>();
        TimeSpan cooldownTimeLeft = Class77.woWSpell_0.CooldownTimeLeft;
        gparam_0.Value = cooldownTimeLeft.TotalMilliseconds <= 0.0 ? DateTime.MinValue : DateTime.UtcNow + cooldownTimeLeft;
        Class51.smethod_1<Class51.Class52<DateTime>>(gparam_0, "gcd_remaining", cooldownTimeLeft.TotalMilliseconds > 0.0 ? (int) cooldownTimeLeft.TotalMilliseconds : 500);
        return cooldownTimeLeft.TotalMilliseconds;
      }
    }
    return class52.Value == DateTime.MinValue ? 0.0 : (class52.Value - DateTime.UtcNow).TotalMilliseconds;
  }));
  public Lazy<bool> lazy_9 = new Lazy<bool>(new Func<bool>(Class144.smethod_0));
  public Lazy<bool> lazy_10 = new Lazy<bool>(new Func<bool>(Class144.smethod_1));
  public Lazy<bool> lazy_11 = new Lazy<bool>(new Func<bool>(Class144.smethod_2));
  public Lazy<bool> lazy_12 = new Lazy<bool>((Func<bool>) (() => Class134.LocalPlayer_0.smethod_0(Class134.WoWUnit_0)));
  public Lazy<bool> lazy_13 = new Lazy<bool>((Func<bool>) (() => Class134.LocalPlayer_0.smethod_0(Class134.WoWUnit_1)));
  public Lazy<bool> lazy_14 = new Lazy<bool>((Func<bool>) (() => !WoWObject.op_Equality((WoWObject) Class134.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class134.WoWUnit_0).IsValid && Class63.smethod_6(Class134.WoWUnit_0)));
  public Lazy<bool> lazy_15 = new Lazy<bool>((Func<bool>) (() => !WoWObject.op_Equality((WoWObject) Class134.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class134.WoWUnit_0).IsValid && Class63.smethod_4(Class134.WoWUnit_0)));
  public Lazy<bool> lazy_16 = new Lazy<bool>((Func<bool>) (() => !WoWObject.op_Equality((WoWObject) Class134.WoWUnit_1, (WoWObject) null) && ((WoWObject) Class134.WoWUnit_1).IsValid && Class63.smethod_6(Class134.WoWUnit_1)));
  public Lazy<bool> lazy_17 = new Lazy<bool>((Func<bool>) (() => !WoWObject.op_Equality((WoWObject) Class134.WoWUnit_1, (WoWObject) null) && ((WoWObject) Class134.WoWUnit_1).IsValid && Class63.smethod_4(Class134.WoWUnit_1)));
  public Lazy<double> lazy_18 = new Lazy<double>((Func<double>) (() => !WoWObject.op_Equality((WoWObject) Class134.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class134.WoWUnit_0).IsValid ? Class134.WoWUnit_0.HealthPercent : 0.0));
  public Lazy<bool> lazy_19 = new Lazy<bool>((Func<bool>) (() =>
  {
    if (!VitalicSettings.Instance.PveMode || Class41.bool_1 || Class41.bool_2)
      return false;
    return WoWObject.op_Equality((WoWObject) Class134.WoWUnit_0, (WoWObject) null) || !Class134.WoWUnit_0.IsPlayer;
  }));
  public Lazy<uint> lazy_20 = new Lazy<uint>((Func<uint>) (() => Class87.UInt32_0));
  public Lazy<IEnumerable<WoWUnit>> lazy_21 = new Lazy<IEnumerable<WoWUnit>>((Func<IEnumerable<WoWUnit>>) (() => Class61.IEnumerable_0));
  public Lazy<IEnumerable<WoWUnit>> lazy_22 = new Lazy<IEnumerable<WoWUnit>>((Func<IEnumerable<WoWUnit>>) (() => Class61.IEnumerable_1));

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static WoWUnit WoWUnit_1 => Class50.woWUnit_1;

  public static Class134 Class134_0
  {
    get
    {
      if (Class134.class134_0 == null)
        Class134.class134_0 = new Class134();
      return Class134.class134_0;
    }
  }

  public static Composite smethod_0()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class134.actionDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class134.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_1));
    }
    // ISSUE: reference to a compiler-generated field
    return (Composite) new Action(Class134.actionDelegate_0);
  }

  private delegate void Delegate35(params object[] args);
}
