﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class102
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

internal class Class102 : Class91
{
  public static Class137.MacroTargets macroTargets_0;

  private static WoWUnit WoWUnit_2
  {
    get
    {
      if (!Class144.class82_0.method_6(Enum18.const_1))
        return Class91.WoWUnit_0;
      Class144.class82_0.method_5(0.1, Enum18.const_1);
      return Class91.WoWUnit_1;
    }
  }

  private static WoWUnit WoWUnit_3
  {
    get
    {
      switch (Class102.macroTargets_0)
      {
        case Class137.MacroTargets.None:
          return Class102.WoWUnit_2;
        case Class137.MacroTargets.Target:
          return Class91.WoWUnit_0;
        case Class137.MacroTargets.Focus:
          return Class91.WoWUnit_1;
        default:
          return Class137.woWUnit_0;
      }
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class102.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class102.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class102.canRunDecoratorDelegate_0;
    Composite[] compositeArray1 = new Composite[2];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class102.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class102.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class102.canRunDecoratorDelegate_1;
    // ISSUE: reference to a compiler-generated field
    if (Class102.actionDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class102.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    Action action = new Action(Class102.actionDelegate_0);
    Decorator decorator = new Decorator(decoratorDelegate1, (Composite) action);
    compositeArray2[0] = (Composite) decorator;
    Composite[] compositeArray3 = compositeArray1;
    Class144.Delegate43 delegate43_4 = (Class144.Delegate43) (object_0 => Class102.WoWUnit_3);
    // ISSUE: reference to a compiler-generated field
    if (Class102.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class102.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate2 = Class102.canRunDecoratorDelegate_2;
    Action action_0 = (Action) (() =>
    {
      if (Class102.macroTargets_0 == Class137.MacroTargets.None)
        return;
      Class91.delegate34_1((object) ("[Macro] Casted spell: Blind on " + Class102.macroTargets_0.ToString()));
    });
    Composite composite = Class77.smethod_0(2094, delegate43_4, decoratorDelegate2, "Blind", action_0, true);
    compositeArray3[1] = composite;
    PrioritySelector prioritySelector = new PrioritySelector(compositeArray1);
    return (Composite) new Decorator(decoratorDelegate0, (Composite) prioritySelector);
  }
}
