﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class62
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System.Text;
using System.Windows.Media;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class62
{
  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static ulong UInt64_0 => Class50.ulong_0;

  public static void smethod_0(params object[] object_0)
  {
    StringBuilder stringBuilder = new StringBuilder();
    foreach (object obj in object_0)
    {
      if (obj is string)
        stringBuilder.Append(" " + obj);
      else
        stringBuilder.Append(" " + obj.ToString());
    }
    Logging.Write(stringBuilder.ToString().Trim());
  }

  public static void smethod_1(params object[] object_0)
  {
    if (!VitalicSettings.Instance.DiagnosticMode)
      return;
    Class62.smethod_0(object_0);
  }

  public static void smethod_2(string string_0, WoWUnit woWUnit_0)
  {
    Color color = WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) Class62.LocalPlayer_0) ? Colors.GreenYellow : Colors.PaleTurquoise;
    WoWUnit woWUnit_0_1 = woWUnit_0;
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) Class62.LocalPlayer_0) && WoWObject.op_Inequality((WoWObject) Class62.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class62.WoWUnit_0).IsValid)
      woWUnit_0_1 = Class62.WoWUnit_0;
    double num1 = WoWObject.op_Inequality((WoWObject) Class62.WoWUnit_0, (WoWObject) null) ? Class134.Class134_0.lazy_1.Value : 0.0;
    string str = woWUnit_0_1.smethod_17() ? "Healer" : (woWUnit_0_1.smethod_18() ? "Melee" : "Caster") + (!woWUnit_0_1.smethod_15() || woWUnit_0_1.smethod_12() ? "" : " Silencable");
    bool flag1 = WoWObject.op_Inequality((WoWObject) Class62.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class62.WoWUnit_0).IsValid && Class144.Boolean_4;
    bool flag2 = WoWObject.op_Inequality((WoWObject) Class62.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class62.WoWUnit_0).IsValid && Class144.Boolean_5;
    bool flag3 = WoWObject.op_Inequality((WoWObject) Class62.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class62.WoWUnit_0).IsValid && Class134.Class134_0.lazy_2.Value;
    double num2 = 0.0;
    double num3 = 0.0;
    if (WoWObject.op_Inequality((WoWObject) Class62.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class62.WoWUnit_0).IsValid)
    {
      num2 = Class62.WoWUnit_0.smethod_6(Class68.Enum14.const_0).double_0;
      num3 = Class62.WoWUnit_0.smethod_6(Class68.Enum14.const_2).double_0;
    }
    if (VitalicSettings.Instance.DiagnosticMode)
      Logging.Write(color, "[Casting] {0} on {1} (CPs: {2} / {13}, Energy: {3}, LSpell: {4} / {5} / {6}, BA: {7}, Dist: {8}, CA: {22}, Melee: {9}, LC: {10}, HP: {14} / {11}, HB: {12}, RTK: {15}, RTB: {16}, IB: {20}, IL: {21}, IC: {17}, ED: {18}, Type: {19}), SDR: {23}, SiDR: {24}", new object[25]
      {
        (object) string_0,
        WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) Class62.LocalPlayer_0) ? (object) "Me" : (object) ((WoWObject) woWUnit_0).SafeName,
        (object) Class62.LocalPlayer_0.ComboPoints.ToString(),
        (object) ((WoWUnit) Class62.LocalPlayer_0).CurrentEnergy.ToString(),
        (object) Class77.Int32_0.ToString(),
        (object) Class77.Int32_1.ToString(),
        (object) Class77.Int32_2.ToString(),
        (object) Class134.Class134_0.lazy_4.Value,
        (object) Class70.smethod_2(woWUnit_0_1).ToString("#.##"),
        (object) Class63.smethod_6(woWUnit_0_1),
        (object) Class62.LocalPlayer_0.smethod_7(),
        (object) (int) Class134.Class134_0.lazy_18.Value,
        (object) woWUnit_0_1.smethod_14(),
        (object) Class62.LocalPlayer_0.RawComboPoints.ToString(),
        (object) (int) Class134.Class134_0.lazy_7.Value,
        (object) Class134.Class134_0.lazy_3.Value,
        (object) flag3,
        (object) Class134.Class134_0.lazy_11.Value,
        (object) num1,
        (object) str,
        (object) flag1,
        (object) flag2,
        (object) Class62.LocalPlayer_0.smethod_0(woWUnit_0_1),
        (object) num2,
        (object) num3
      });
    else
      Logging.Write(color, "[Casting] {0} on {1}", new object[2]
      {
        (object) string_0,
        WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) Class62.LocalPlayer_0) ? (object) "Me" : (object) ((WoWObject) woWUnit_0).SafeName
      });
  }

  public static void smethod_3(WoWUnit woWUnit_0)
  {
    if (WoWObject.op_Equality((WoWObject) Class62.WoWUnit_0, (WoWObject) null) || !((WoWObject) Class62.WoWUnit_0).IsValid || !Class63.smethod_6(Class62.WoWUnit_0) || Class62.LocalPlayer_0.smethod_7())
      return;
    string str = woWUnit_0.smethod_17() ? "Healer" : (woWUnit_0.smethod_18() ? "Melee" : "Caster") + (!woWUnit_0.smethod_15() || woWUnit_0.smethod_12() ? "" : " Silencable");
    bool flag1 = WoWObject.op_Inequality((WoWObject) Class62.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class62.WoWUnit_0).IsValid && Class144.Boolean_4;
    bool flag2 = WoWObject.op_Inequality((WoWObject) Class62.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class62.WoWUnit_0).IsValid && Class144.Boolean_5;
    if (!VitalicSettings.Instance.DiagnosticMode)
      return;
    Logging.Write("[Target Info] Name: {0}, CPs: {2} / {13}, Energy: {3}, LSpell: {4} / {5} / {6} / {22}, GCD: {24}, BA: {7}, CA: {23}, Dist: {8}, Melee: {9}, LostControl: {10}, HP: {14} / {11}, HB: {12}, RTK: {15}, RTB: {16}, IB: {20}, IL: {21}, IC: {17}, ED: {18}, Type: {19}", new object[25]
    {
      (object) ((WoWObject) woWUnit_0).SafeName,
      (object) string.Empty,
      (object) Class62.LocalPlayer_0.ComboPoints.ToString(),
      (object) ((WoWUnit) Class62.LocalPlayer_0).CurrentEnergy.ToString(),
      (object) Class77.Int32_0.ToString(),
      (object) Class77.Int32_1.ToString(),
      (object) Class77.Int32_2.ToString(),
      (object) Class134.Class134_0.lazy_4.Value,
      (object) Class70.smethod_2(woWUnit_0).ToString("#.##"),
      (object) Class63.smethod_6(woWUnit_0),
      (object) Class62.LocalPlayer_0.smethod_7(),
      (object) (int) Class134.Class134_0.lazy_18.Value,
      (object) woWUnit_0.smethod_14(),
      (object) Class62.LocalPlayer_0.RawComboPoints.ToString(),
      (object) (int) Class134.Class134_0.lazy_7.Value,
      (object) Class134.Class134_0.lazy_3.Value,
      (object) Class134.Class134_0.lazy_2.Value,
      (object) Class134.Class134_0.lazy_11.Value,
      (object) Class134.Class134_0.lazy_1.Value,
      (object) str,
      (object) flag1,
      (object) flag2,
      (object) Class77.Double_0,
      (object) Class62.LocalPlayer_0.smethod_0(woWUnit_0),
      (object) SpellManager.GlobalCooldownLeft.TotalSeconds
    });
  }

  public static void smethod_4(int int_0, WoWUnit woWUnit_0)
  {
    Class62.smethod_2(WoWSpell.FromId(int_0).Name, woWUnit_0);
  }
}
