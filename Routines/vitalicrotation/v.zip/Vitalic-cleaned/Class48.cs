﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class48
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class48
{
  private static bool bool_0;
  private static Class48.Delegate21 delegate21_0 = new Class48.Delegate21(Class62.smethod_0);
  private static Class48.Delegate21 delegate21_1 = new Class48.Delegate21(Class62.smethod_1);
  public static bool bool_1;
  public static readonly HashSet<WoWSpellMechanic> hashSet_0 = new HashSet<WoWSpellMechanic>()
  {
    (WoWSpellMechanic) 18,
    (WoWSpellMechanic) 2,
    (WoWSpellMechanic) 1,
    (WoWSpellMechanic) 24,
    (WoWSpellMechanic) 14,
    (WoWSpellMechanic) 17,
    (WoWSpellMechanic) 30,
    (WoWSpellMechanic) 20,
    (WoWSpellMechanic) 10,
    (WoWSpellMechanic) 13,
    (WoWSpellMechanic) 12,
    (WoWSpellMechanic) 23,
    (WoWSpellMechanic) 5
  };

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static void Initialise()
  {
    Class48.Attach();
    Class41.Event_0 += (EventHandler) ((sender, e) => Class48.bool_1 = false);
  }

  public static void Attach()
  {
    if (Class48.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.UNIT_FLAGS, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_3)));
    Class37.smethod_3(Class37.WoWEvents.UNIT_FLAGS, "return args[1] == 'player'");
    Class37.smethod_8(Class37.Types.SPELL_CAST_SUCCESS, new Class37.Delegate11(Class48.smethod_1));
    Class48.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class48.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.UNIT_FLAGS, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_3)));
    Class37.smethod_4(Class37.WoWEvents.UNIT_FLAGS);
    Class37.smethod_9(Class37.Types.SPELL_CAST_SUCCESS, new Class37.Delegate11(Class48.smethod_1));
    Class48.bool_0 = false;
  }

  public static void Shutdown() => Class48.smethod_0();

  private static void smethod_1(EventArgs0 eventArgs0_0)
  {
    if (eventArgs0_0.lazy_0.Value != Class37.Types.SPELL_CAST_SUCCESS || eventArgs0_0.lazy_7.Value != 59752 && eventArgs0_0.lazy_7.Value != 42292 && eventArgs0_0.lazy_7.Value != 7744 || (long) eventArgs0_0.lazy_1.Value != (long) ((WoWObject) Class48.LocalPlayer_0).Guid)
      return;
    Class48.bool_1 = false;
  }

  private static void smethod_2()
  {
    WoWAura woWaura = ((IEnumerable<WoWAura>) ((WoWUnit) Class48.LocalPlayer_0).GetAllAuras()).FirstOrDefault<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => !Class53.list_0.Contains(woWAura_0.SpellId) && Class48.hashSet_0.Contains(woWAura_0.Spell.Mechanic)));
    if (WoWAura.op_Equality(woWaura, (WoWAura) null))
      woWaura = ((WoWUnit) Class48.LocalPlayer_0).GetAuraById(52459);
    if (WoWAura.op_Inequality(woWaura, (WoWAura) null))
      Class48.delegate21_1((object) $"[Event] Lost control of character ({woWaura.Name})");
    else if (Class48.bool_1)
      Class48.delegate21_1((object) "[Event] Gained control of character");
    Class48.bool_1 = WoWAura.op_Inequality(woWaura, (WoWAura) null);
  }

  private static void smethod_3(object sender, LuaEventArgs e) => Class48.smethod_2();

  private delegate void Delegate21(params object[] args);
}
