﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class123
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;

#nullable disable
namespace ns1;

internal class Class123 : Class91
{
  private static int Int32_4
  {
    get
    {
      if (Class71.CurrentSpec == 259)
        return 1;
      return Class91.Boolean_6 ? 12 : 2;
    }
  }

  private static int Int32_5 => 6 + Class91.LocalPlayer_0.RawComboPoints * 6;

  private static int Int32_6 => Class91.LocalPlayer_0.RawComboPoints;

  private static int Int32_7
  {
    get
    {
      if (Class71.CurrentSpec == 259)
        return 1;
      return Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 5171) ? 4 : 2;
    }
  }

  private static bool Boolean_21
  {
    get
    {
      return Class91.Boolean_4 && Class91.Boolean_6 && Class91.WoWUnit_0.smethod_14() && (double) Class123.Int32_5 > Class91.Double_5 * 2.0 + 4.0 && (double) Class123.Int32_5 > Class65.smethod_1(5171) * 2.0;
    }
  }

  private static bool Boolean_22
  {
    get
    {
      return !Class91.WoWUnit_0.smethod_14() && (Class91.Int32_0 != 703 && Class91.Int32_0 != 1833 || Class91.Double_4 < 35.0);
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[5];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class123.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class123.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    DecoratorContinue decoratorContinue1 = new DecoratorContinue(Class123.canRunDecoratorDelegate_0, (Composite) new ActionAlwaysFail());
    compositeArray2[0] = (Composite) decoratorContinue1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class123.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class123.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    DecoratorContinue decoratorContinue2 = new DecoratorContinue(Class123.canRunDecoratorDelegate_1, (Composite) new ActionAlwaysFail());
    compositeArray3[1] = (Composite) decoratorContinue2;
    Composite[] compositeArray4 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class123.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class123.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    DecoratorContinue decoratorContinue3 = new DecoratorContinue(Class123.canRunDecoratorDelegate_2, (Composite) new ActionAlwaysFail());
    compositeArray4[2] = (Composite) decoratorContinue3;
    Composite[] compositeArray5 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class123.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class123.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    DecoratorContinue decoratorContinue4 = new DecoratorContinue(Class123.canRunDecoratorDelegate_3, (Composite) new ActionAlwaysFail());
    compositeArray5[3] = (Composite) decoratorContinue4;
    Composite[] compositeArray6 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class123.canRunDecoratorDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class123.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite = Class77.smethod_2(5171, Class123.canRunDecoratorDelegate_4, "Slice and Dice");
    compositeArray6[4] = composite;
    return (Composite) new Sequence(compositeArray1);
  }
}
