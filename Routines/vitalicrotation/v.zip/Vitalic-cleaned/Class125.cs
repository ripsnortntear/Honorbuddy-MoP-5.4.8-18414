﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class125
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using System;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class125 : Class91
{
  private static int Int32_4
  {
    get
    {
      if (VitalicSettings.Instance.MainHandPoison > 0)
        return VitalicSettings.Instance.MainHandPoison;
      switch (Class71.CurrentSpec - 259)
      {
        case 0:
          return 2823;
        case 1:
        case 2:
          return 8679;
        default:
          return 8679;
      }
    }
  }

  private static int Int32_5
  {
    get
    {
      if (VitalicSettings.Instance.OffHandPoison > 0)
        return VitalicSettings.Instance.OffHandPoison;
      if (Class91.LocalPlayer_0.smethod_4(14))
        return 108215;
      if (Class91.LocalPlayer_0.smethod_4(8))
        return 108211;
      switch (Class71.CurrentSpec - 259)
      {
        case 0:
        case 1:
        case 2:
          return 5761;
        default:
          return 5761;
      }
    }
  }

  public static Composite smethod_4()
  {
    TimeSpan timeSpan_1 = TimeSpan.FromSeconds(0.1);
    Composite[] compositeArray1 = new Composite[2];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class125.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class125.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class125.canRunDecoratorDelegate_0;
    // ISSUE: reference to a compiler-generated field
    if (Class125.actionSucceedDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class125.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    Action action1 = new Action(Class125.actionSucceedDelegate_0);
    Decorator decorator1 = new Decorator(decoratorDelegate0, (Composite) action1);
    compositeArray2[0] = (Composite) decorator1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class125.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class125.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class125.canRunDecoratorDelegate_1;
    // ISSUE: reference to a compiler-generated field
    if (Class125.actionSucceedDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class125.actionSucceedDelegate_1 = new ActionSucceedDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    Action action2 = new Action(Class125.actionSucceedDelegate_1);
    Decorator decorator2 = new Decorator(decoratorDelegate1, (Composite) action2);
    compositeArray3[1] = (Composite) decorator2;
    PrioritySelector composite_0 = new PrioritySelector(compositeArray1);
    return (Composite) new GClass72(timeSpan_1, (Composite) composite_0);
  }
}
