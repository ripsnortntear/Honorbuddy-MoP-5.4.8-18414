﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class128
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;

#nullable disable
namespace ns1;

internal class Class128 : Class91
{
  private static bool Boolean_21
  {
    get
    {
      if (Class91.LocalPlayer_0.smethod_4(15) || !Class91.WoWUnit_0.smethod_12() || Class91.Double_2 > 100.0 || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_12))
        return true;
      return Class91.LocalPlayer_0.ComboPoints > 3 && Class91.Boolean_16;
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class128.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class128.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    return Class77.smethod_1(1329, Class128.canRunDecoratorDelegate_0, "Mutilate");
  }
}
