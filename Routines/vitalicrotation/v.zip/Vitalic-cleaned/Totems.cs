﻿// Decompiled with JetBrains decompiler
// Type: VitalicEliteRogue.Totems
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using System;

#nullable disable
namespace VitalicEliteRogue;

[Flags]
internal enum Totems
{
  None = 0,
  SpiritLink = 1,
  Earthgrab = 2,
  HealingStream = 4,
  HealingTide = 8,
  Capacitor = 16, // 0x00000010
  Grounding = 32, // 0x00000020
  Windwalk = 64, // 0x00000040
}
