﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class107
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class107 : Class91
{
  private static double Double_9 => Class85.Double_0;

  private static bool Boolean_21 => Class91.WoWUnit_0.CreatedBySpellId == 108921U;

  private static bool Boolean_22
  {
    get
    {
      double num = Class65.smethod_1(115192);
      bool boolean22;
      if (boolean22 = Class91.smethod_0() && Class91.WoWUnit_0.smethod_15() && (Class91.Double_2 < 50.0 || num <= 1.5) && (!Class53.smethod_3(Class91.WoWUnit_0, 1330) && !Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_2) || !Class53.smethod_3(Class91.WoWUnit_0, 1833) && !Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_0)) && (Class91.LocalPlayer_0.ComboPoints < 4 || !Class91.Boolean_16 || !Class91.WoWUnit_0.smethod_14()))
      {
        Class62.smethod_3(Class91.WoWUnit_0);
        Class91.delegate34_1((object) "Subterfuge pooling:", (object) "IsSubterfugeOpening()", (object) Class91.smethod_0(), (object) "Energy:", (object) Class91.Double_2, (object) "SubterfugeRemains", (object) num, (object) "ReadyToKidneyShot", (object) Class91.Boolean_16, (object) "cps", (object) Class91.LocalPlayer_0.ComboPoints, (object) "silence/stun", (object) (bool) (Class53.smethod_3(Class91.WoWUnit_0, 1330) || Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_2) ? (Class53.smethod_3(Class91.WoWUnit_0, 1833) ? 0 : (!Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_0) ? 1 : 0)) : 1));
      }
      return boolean22;
    }
  }

  private static bool Boolean_23
  {
    get
    {
      return VitalicSettings.Instance.LazyPooling && !Class144.Boolean_4 && !Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_12) && Class91.Double_4 > 30.0 && !Class91.WoWUnit_0.smethod_5(91021) && Class65.smethod_1(5171) > 4.0 && (!Class91.Boolean_17 || Class91.WoWUnit_0.smethod_14()) && !Class107.Boolean_21 && Class91.Double_2 < (Class91.Boolean_8 ? 70.0 : 50.0);
    }
  }

  private static bool Boolean_24
  {
    get
    {
      if (Class91.LocalPlayer_0.smethod_4(15) || !Class91.WoWUnit_0.smethod_12() || Class91.Double_2 > 80.0 || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_12))
        return true;
      return Class91.LocalPlayer_0.ComboPoints > 3 && Class91.Boolean_16;
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class107.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class107.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    return Class77.smethod_1(53, Class107.canRunDecoratorDelegate_0, "Backstab");
  }
}
