﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class100
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.CommonBot;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class100 : Class91
{
  private static double Double_9 => Class85.Double_0;

  private static bool Boolean_21
  {
    get => (double) ((WoWUnit) Class91.LocalPlayer_0).MovementInfo.CurrentSpeed < 7.0;
  }

  private static bool Boolean_22 => (double) Class91.WoWUnit_0.MovementInfo.CurrentSpeed < 7.0;

  private static double Double_10 => VitalicSettings.Instance.HemoDelay;

  private static double Double_11 => Class32.Double_0;

  private static bool Boolean_23
  {
    get => Class91.WoWUnit_0.CreatedBySpellId == 108921U || Class91.WoWUnit_0.IsTotem;
  }

  private static bool Boolean_24
  {
    get
    {
      if (Class91.LocalPlayer_0.smethod_4(15) || !Class91.WoWUnit_0.smethod_12() || Class91.Double_2 > 80.0 || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_12))
        return true;
      return Class91.LocalPlayer_0.ComboPoints > 3 && Class91.Boolean_16;
    }
  }

  private static bool Boolean_25
  {
    get
    {
      return VitalicSettings.Instance.LazyPooling && !Class144.Boolean_4 && !Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_12) && Class91.Double_4 > 30.0 && !Class91.WoWUnit_0.smethod_5(91021) && Class65.smethod_1(5171) > 4.0 && (!Class91.Boolean_17 || Class91.WoWUnit_0.smethod_14()) && !Class100.Boolean_23 ? Class91.Double_2 < (!Class91.Boolean_8 || Class91.Double_3 <= 50.0 || Class91.Boolean_16 ? 40.0 : 70.0) : Class91.Double_2 < 35.0;
    }
  }

  private static bool Boolean_26
  {
    get
    {
      return VitalicSettings.Instance.HemoDelay > 0.0 && (Class91.Double_4 > 20.0 && Class91.Double_3 > 40.0 && Class100.Boolean_22 && Class91.Double_2 < (double) (((WoWUnit) Class91.LocalPlayer_0).MaxEnergy - 20U) || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_12) || !Class91.WoWUnit_0.IsTargetingMeOrPet) && (!Class53.smethod_3(Class91.WoWUnit_0, 1330) || !Class91.Boolean_16) && Class65.smethod_1(5171) > 6.0 && !Class144.Boolean_3;
    }
  }

  private static bool Boolean_27
  {
    get
    {
      if (VitalicSettings.Instance.AlwaysUseHemo)
        return true;
      if (Class100.Boolean_26)
      {
        if (Class91.LocalPlayer_0.smethod_21(Class91.WoWUnit_0, Class100.Double_10))
          return true;
      }
      else if (!Class91.LocalPlayer_0.IsBehind(Class91.WoWUnit_0))
        return true;
      return !SpellManager.HasSpell(53) || Class100.Boolean_23 || Class91.WoWUnit_0.Class == 4 && !Class53.smethod_3(Class91.WoWUnit_0, 89775) && Class91.Int32_0 != 16511;
    }
  }

  private static bool Boolean_28
  {
    get
    {
      double num = Class65.smethod_1(115192);
      if (!Class91.smethod_0() || !Class91.WoWUnit_0.smethod_15() || Class91.Double_2 >= 50.0 && num > 1.5 || (Class53.smethod_3(Class91.WoWUnit_0, 1330) || Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_2)) && (Class53.smethod_3(Class91.WoWUnit_0, 1833) || Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_0)))
        return false;
      return Class91.LocalPlayer_0.ComboPoints < 4 || !Class91.Boolean_16 || !Class91.WoWUnit_0.smethod_14();
    }
  }

  private static Composite Composite_0
  {
    get
    {
      if (Class100.actionDelegate_0 == null)
        Class100.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_5));
      return (Composite) new Action(Class100.actionDelegate_0);
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[3]
    {
      Class100.Composite_0,
      null,
      null
    };
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class100.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class100.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite1 = Class77.smethod_1(16511, Class100.canRunDecoratorDelegate_0, "Hemo (Sanguinary Vein)");
    compositeArray2[1] = composite1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class100.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class100.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite2 = Class77.smethod_1(16511, Class100.canRunDecoratorDelegate_1, "Hemo");
    compositeArray3[2] = composite2;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
