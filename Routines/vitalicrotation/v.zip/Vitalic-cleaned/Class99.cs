﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class99
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class99 : Class91
{
  private static bool Boolean_21 => Class91.LocalPlayer_0.smethod_4(17);

  private static double Double_9 => Class85.Double_0;

  private static double Double_10 => Class91.Double_2 + Class91.Double_7 * Class91.Double_5;

  private static double Double_11 => Class91.Double_2 + Class91.Double_7 * Class74.smethod_3(1833);

  private static double Double_12 => Class91.Double_2 + Class91.Double_7 * Class74.smethod_3(1330);

  private static bool Boolean_22
  {
    get
    {
      return Class91.LocalPlayer_0.smethod_4(18) && Class91.Boolean_16 && Class91.UInt32_0 < 3U && Class91.Double_4 > 30.0;
    }
  }

  private static uint UInt32_1
  {
    get
    {
      WoWAura auraById = Class91.WoWUnit_0.GetAuraById(113952);
      return !WoWAura.op_Inequality(auraById, (WoWAura) null) ? 0U : auraById.StackCount;
    }
  }

  private static bool Boolean_23
  {
    get
    {
      Class68.Struct22 struct22 = Class91.WoWUnit_0.smethod_6(Class68.Enum14.const_0);
      Class91.delegate34_1((object) "evisc kidneydelay", (object) Class91.Boolean_16, (object) "on dr", (object) struct22.bool_0, (object) struct22.double_0, (object) struct22.timeSpan_0.TotalSeconds, (object) "cs remains", (object) Class74.smethod_3(1833), (object) "gs remains", (object) Class74.smethod_3(1330), (object) "pp stacks", (object) Class99.UInt32_1, (object) "energy after cs", (object) Class99.Double_11);
      Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_0);
      double num1 = Class74.smethod_3(1833);
      double num2 = Class74.smethod_3(1330);
      if (!Class91.Boolean_16 || !VitalicSettings.Instance.AutoKidney && Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 51713) || Class53.smethod_3(Class91.WoWUnit_0, 1833) && num1 >= 2.0 && (num1 >= 2.5 || Class99.Double_11 >= 60.0) || Class53.smethod_3(Class91.WoWUnit_0, 1330) && Class91.WoWUnit_0.smethod_15() && !Class91.WoWUnit_0.smethod_16() && (num2 >= 1.5 && Class99.Double_12 >= 70.0 || Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 51713)) || !Class91.WoWUnit_0.smethod_14() || (double) Class91.WoWUnit_0.CurrentHealth <= Class91.Double_6 || Class91.WoWUnit_0.Class == 8)
        return false;
      return !Class99.Boolean_21 || !Class91.LocalPlayer_0.smethod_3(56801) && Class91.Double_2 < 80.0 || Class91.Int32_0 != 137619 || num1 < (Class124.bool_0 ? 1.0 : 1.5);
    }
  }

  private static bool Boolean_24
  {
    get
    {
      Class68.Struct22 struct22 = Class91.WoWUnit_0.smethod_6(Class68.Enum14.const_0);
      Class91.delegate34_1((object) "lazy evisc kidneydelay", (object) Class91.Boolean_16, (object) "on dr", (object) struct22.bool_0, (object) struct22.double_0, (object) struct22.timeSpan_0.TotalSeconds, (object) "cs remains", (object) Class74.smethod_3(1833), (object) "gs remains", (object) Class74.smethod_3(1330), (object) "pp stacks", (object) Class99.UInt32_1, (object) "energy after cs", (object) Class99.Double_11, (object) "energy after gs", (object) Class99.Double_12);
      if (!VitalicSettings.Instance.AutoKidney || !Class91.Boolean_16 || Class91.Boolean_6 || (double) Class91.WoWUnit_0.CurrentHealth <= Class91.Double_6 || !Class91.WoWUnit_0.smethod_14() || Class91.Double_2 >= (double) (((WoWUnit) Class91.LocalPlayer_0).MaxEnergy - 10U) || Class99.Boolean_21 && Class91.Int32_0 == 137619 && Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_12, 1.5) || Class53.smethod_3(Class91.WoWUnit_0, 1330) && Class91.WoWUnit_0.smethod_15() && Class74.smethod_3(1330) >= 1.5 && (Class99.Double_12 >= 90.0 || Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 115192)))
        return false;
      return !Class53.smethod_3(Class91.WoWUnit_0, 1833) || Class74.smethod_3(1833) < 2.5 || Class99.Double_11 < 70.0;
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[3];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class99.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class99.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite1 = Class77.smethod_1(2098, Class99.canRunDecoratorDelegate_0, "Eviscerate (Burst)");
    compositeArray2[0] = composite1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class99.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class99.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite2 = Class77.smethod_1(2098, Class99.canRunDecoratorDelegate_1, "Eviscerate (Double)");
    compositeArray3[1] = composite2;
    Composite[] compositeArray4 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class99.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class99.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite3 = Class77.smethod_1(2098, Class99.canRunDecoratorDelegate_2, "Eviscerate");
    compositeArray4[2] = composite3;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
