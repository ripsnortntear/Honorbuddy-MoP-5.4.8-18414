﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class130
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.CommonBot.Frames;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

internal class Class130 : Class91
{
  private static bool Boolean_21
  {
    get
    {
      return Class91.Boolean_13 && ((WoWObject) Class91.WoWUnit_1).Distance < 12.0 && !Class91.WoWUnit_1.Combat && !Class91.WoWUnit_1.smethod_0(Class68.Enum15.const_11);
    }
  }

  private static bool Boolean_22 => Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 148385);

  private static bool Boolean_23
  {
    get
    {
      if (Class91.Boolean_1 || Class91.Boolean_2 || Class41.Boolean_0 || Class130.Boolean_22)
        return false;
      return (DateTime.UtcNow - Class46.dateTime_0).TotalSeconds < 2.0 || LootFrame.Instance.IsVisible;
    }
  }

  public static void smethod_4()
  {
    if (Class51.smethod_4("cooldown_115191"))
      Class51.smethod_3("cooldown_115191");
    if (!Class51.smethod_4("cooldown_1784"))
      return;
    Class51.smethod_3("cooldown_1784");
  }

  public static double Double_9
  {
    get => Class91.LocalPlayer_0.smethod_4(2) ? Class59.smethod_2(115191) : Class59.smethod_2(1784);
  }

  public static Composite smethod_5()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class130.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class130.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    return Class77.smethod_4(1784, Class130.canRunDecoratorDelegate_0, "Stealth", (Action) (() =>
    {
      Class77.smethod_9();
      Class91.Boolean_20 = false;
      Class140.smethod_7("Re-stealthing", Class140.struct24_1);
      if (!Class91.Boolean_19)
        return;
      Class137.smethod_8(Class137.Macro.Restealth);
      Class46.bool_2 = false;
      Class140.smethod_9("Restealth: |cffb73737Disabled");
    }));
  }
}
