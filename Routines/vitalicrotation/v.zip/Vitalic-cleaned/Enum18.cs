﻿// Decompiled with JetBrains decompiler
// Type: ns1.Enum18
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

#nullable disable
namespace ns1;

internal enum Enum18
{
  const_0,
  const_1,
  const_2,
  const_3,
}
