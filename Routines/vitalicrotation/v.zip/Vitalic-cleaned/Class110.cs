﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class110
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class110 : Class91
{
  public static bool bool_0;
  public static DateTime dateTime_0;

  static Class110()
  {
    Class41.Event_0 += (EventHandler) ((sender, e) =>
    {
      Class110.bool_0 = true;
      Class110.dateTime_0 = DateTime.MinValue;
    });
  }

  private static bool Boolean_21
  {
    get
    {
      if (Class91.Boolean_3)
      {
        if (Class110.bool_0)
        {
          if (!Class61.list_0.Contains((WoWClass) 3) && Class61.list_0.Contains((WoWClass) 4))
            Class110.bool_0 = false;
        }
        else if (Class61.list_0.Contains((WoWClass) 3))
          Class110.bool_0 = true;
      }
      else if (!Class110.bool_0)
      {
        if (Class110.dateTime_0 != DateTime.MinValue && DateTime.UtcNow - Class110.dateTime_0 > TimeSpan.FromSeconds(2.0))
          Class110.bool_0 = true;
        if (Class61.Double_0 > 5.0 && Class110.dateTime_0 == DateTime.MinValue && !Class91.Boolean_12)
          Class110.bool_0 = true;
      }
      return !Class91.LocalPlayer_0.PartyMembers.All<WoWPlayer>((Func<WoWPlayer, bool>) (woWPlayer_0 => ((WoWUnit) woWPlayer_0).smethod_7(66, 32612, 1784, 115191, 5215))) && Class110.bool_0;
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class110.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class110.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class110.canRunDecoratorDelegate_0;
    // ISSUE: reference to a compiler-generated field
    if (Class110.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class110.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite = Class77.smethod_2(114018, Class110.canRunDecoratorDelegate_1, "Shroud of Concealment", (Action) (() => Class140.smethod_7("Casted Shroud of Concealment", Class140.struct24_2)));
    return (Composite) new Decorator(decoratorDelegate0, composite);
  }
}
