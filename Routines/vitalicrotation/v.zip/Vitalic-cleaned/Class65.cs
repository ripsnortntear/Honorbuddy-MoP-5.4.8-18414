﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class65
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

internal static class Class65
{
  private static Class65.Delegate27 delegate27_0 = new Class65.Delegate27(Class62.smethod_0);
  public static readonly Dictionary<int, bool> dictionary_0 = new Dictionary<int, bool>()
  {
    {
      31884,
      true
    },
    {
      1719,
      true
    },
    {
      77801,
      false
    },
    {
      114049,
      true
    },
    {
      106952,
      true
    },
    {
      106951,
      true
    },
    {
      106731,
      true
    },
    {
      51271,
      true
    },
    {
      51713,
      true
    },
    {
      19574,
      false
    },
    {
      34692,
      false
    },
    {
      34471,
      false
    },
    {
      107574,
      true
    },
    {
      126679,
      true
    },
    {
      126690,
      true
    },
    {
      126700,
      true
    },
    {
      126707,
      true
    },
    {
      121471,
      true
    },
    {
      3045,
      false
    },
    {
      116740,
      true
    }
  };
  public static readonly HashSet<int> hashSet_0 = new HashSet<int>()
  {
    642,
    110700,
    1022,
    45438,
    19263,
    47585,
    122465,
    148467,
    110617,
    110715,
    110696
  };
  public static readonly HashSet<int> hashSet_1 = new HashSet<int>()
  {
    48792,
    110575,
    46924,
    51690,
    108201,
    118009,
    110575,
    116849
  };
  public static readonly HashSet<int> hashSet_2 = new HashSet<int>()
  {
    131557,
    131558,
    96267,
    31821,
    104773,
    122291,
    124487,
    124488
  };
  public static readonly HashSet<int> hashSet_3 = new HashSet<int>()
  {
    1044,
    114896,
    54216
  };
  private static readonly HashSet<int> hashSet_4 = new HashSet<int>()
  {
    51713,
    121471,
    13750
  };
  private static readonly HashSet<int> hashSet_5 = new HashSet<int>()
  {
    112055,
    121164,
    121175,
    121176,
    121177,
    44521,
    23333,
    23335,
    34976,
    141210,
    140876,
    1543,
    770,
    102355
  };

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static bool Boolean_0
  {
    get
    {
      return Class71.CurrentSpec == 259 && WoWObject.op_Inequality((WoWObject) Class65.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class65.WoWUnit_0).IsValid && Class53.smethod_3(Class65.WoWUnit_0, 79140) || ((WoWUnit) Class65.LocalPlayer_0).smethod_0().Any<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => Class65.hashSet_4.Contains(woWAura_0.SpellId)));
    }
  }

  public static bool Boolean_1
  {
    get
    {
      return !((WoWUnit) Class65.LocalPlayer_0).smethod_0().Any<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => Class65.hashSet_5.Contains(woWAura_0.SpellId)));
    }
  }

  public static double smethod_0(string string_0, WoWUnit woWUnit_0 = null, bool bool_0 = true)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class65.Class66 class66 = new Class65.Class66();
    // ISSUE: reference to a compiler-generated field
    class66.string_0 = string_0;
    // ISSUE: reference to a compiler-generated field
    class66.bool_0 = bool_0;
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null))
      woWUnit_0 = (WoWUnit) Class65.LocalPlayer_0;
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null) || !((WoWObject) woWUnit_0).IsValid)
      return 0.0;
    // ISSUE: reference to a compiler-generated method
    WoWAura woWaura = woWUnit_0.smethod_1().FirstOrDefault<WoWAura>(new Func<WoWAura, bool>(class66.method_0));
    return WoWAura.op_Equality(woWaura, (WoWAura) null) ? 0.0 : woWaura.TimeLeft.TotalSeconds;
  }

  public static double smethod_1(int int_0, WoWUnit woWUnit_0 = null, bool bool_0 = true)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class65.Class67 class67 = new Class65.Class67();
    // ISSUE: reference to a compiler-generated field
    class67.int_0 = int_0;
    // ISSUE: reference to a compiler-generated field
    class67.bool_0 = bool_0;
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null))
      woWUnit_0 = (WoWUnit) Class65.LocalPlayer_0;
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null) || !((WoWObject) woWUnit_0).IsValid)
      return 0.0;
    // ISSUE: reference to a compiler-generated method
    WoWAura woWaura = woWUnit_0.smethod_1().FirstOrDefault<WoWAura>(new Func<WoWAura, bool>(class67.method_0));
    return WoWAura.op_Equality(woWaura, (WoWAura) null) ? 0.0 : woWaura.TimeLeft.TotalSeconds;
  }

  private delegate void Delegate27(params object[] args);
}
