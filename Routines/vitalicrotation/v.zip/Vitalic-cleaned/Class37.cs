﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class37
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using JetBrains.Annotations;
using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

#nullable disable
namespace ns1;

[UsedImplicitly]
internal static class Class37
{
  private static Class37.Delegate10 delegate10_0 = new Class37.Delegate10(Class62.smethod_0);
  private static readonly HashSet<Type> hashSet_0 = new HashSet<Type>();
  private static readonly Dictionary<Class37.Types, List<Class37.Delegate11>> dictionary_0 = new Dictionary<Class37.Types, List<Class37.Delegate11>>();

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  internal static void smethod_0()
  {
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.COMBAT_LOG_EVENT_UNFILTERED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_7)));
    Class141.Attach();
    foreach (Type type in Assembly.GetExecutingAssembly().GetTypes())
    {
      if (type.IsClass && (Attribute0) Attribute.GetCustomAttribute((MemberInfo) type, typeof (Attribute0)) != null)
      {
        if (!Class37.hashSet_0.Contains(type))
          Class37.hashSet_0.Add(type);
        MethodInfo method = type.GetMethod("Initialise");
        if (method != (MethodInfo) null)
          method.Invoke((object) null, (object[]) null);
      }
    }
  }

  internal static void smethod_1()
  {
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.COMBAT_LOG_EVENT_UNFILTERED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_7)));
    foreach (Type type in Class37.hashSet_0)
    {
      MethodInfo method = type.GetMethod("Shutdown");
      if (method != (MethodInfo) null)
        method.Invoke((object) null, (object[]) null);
    }
  }

  internal static void smethod_2()
  {
    foreach (Type type in Class37.hashSet_0)
    {
      MethodInfo method = type.GetMethod("Attach");
      if (method != (MethodInfo) null)
        method.Invoke((object) null, (object[]) null);
    }
  }

  public static void smethod_3(Class37.WoWEvents woWEvents_0, string string_0)
  {
    Lua.Events.AddFilter(woWEvents_0.ToString(), string_0);
  }

  public static void smethod_4(Class37.WoWEvents woWEvents_0)
  {
    Lua.DoString("SetCVar('scriptErrors', '0')", "WoW.lua");
    Lua.Events.RemoveFilter(woWEvents_0.ToString());
    Lua.DoString("SetCVar('scriptErrors', '1')", "WoW.lua");
  }

  public static void smethod_5(
    Class37.WoWEvents woWEvents_0,
    LuaEventHandlerDelegate luaEventHandlerDelegate_0)
  {
    Lua.Events.AttachEvent(woWEvents_0.ToString(), luaEventHandlerDelegate_0);
  }

  public static void smethod_6(
    Class37.WoWEvents woWEvents_0,
    LuaEventHandlerDelegate luaEventHandlerDelegate_0)
  {
    Lua.Events.DetachEvent(woWEvents_0.ToString(), luaEventHandlerDelegate_0);
  }

  private static void smethod_7(object sender, LuaEventArgs e)
  {
    EventArgs0 args = new EventArgs0(e.EventName, e.FireTimeStamp, e.Args);
    Class37.Types key = args.lazy_0.Value;
    List<Class37.Delegate11> delegate11List;
    if (!Enum.IsDefined(typeof (Class37.Types), (object) key) || !Class37.dictionary_0.TryGetValue(key, out delegate11List))
      return;
    foreach (Class37.Delegate11 delegate11 in delegate11List)
      delegate11(args);
  }

  public static void smethod_8(Class37.Types types_0, Class37.Delegate11 delegate11_0)
  {
    List<Class37.Delegate11> delegate11List;
    if (!Class37.dictionary_0.TryGetValue(types_0, out delegate11List))
    {
      Class37.dictionary_0.Add(types_0, new List<Class37.Delegate11>()
      {
        delegate11_0
      });
      Class37.smethod_4(Class37.WoWEvents.COMBAT_LOG_EVENT_UNFILTERED);
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("return ");
      foreach (Class37.Types key in Class37.dictionary_0.Keys)
        stringBuilder.Append($"args[2] == '{(object) key}' or ");
      Class37.smethod_3(Class37.WoWEvents.COMBAT_LOG_EVENT_UNFILTERED, stringBuilder.ToString().TrimEnd(" or ".ToArray<char>()));
    }
    else
      delegate11List.Add(delegate11_0);
  }

  public static void smethod_9(Class37.Types types_0, Class37.Delegate11 delegate11_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class37.Class38 class38 = new Class37.Class38();
    // ISSUE: reference to a compiler-generated field
    class38.delegate11_0 = delegate11_0;
    List<Class37.Delegate11> source;
    if (!Class37.dictionary_0.TryGetValue(types_0, out source))
      return;
    // ISSUE: reference to a compiler-generated method
    source.RemoveAll(new Predicate<Class37.Delegate11>(class38.method_0));
    if (source.Count<Class37.Delegate11>() != 0)
      return;
    Class37.dictionary_0.Remove(types_0);
  }

  private delegate void Delegate10(params object[] args);

  public enum WoWEvents
  {
    COMBAT_LOG_EVENT_UNFILTERED,
    PLAYER_TARGET_CHANGED,
    PLAYER_FOCUS_CHANGED,
    PLAYER_TALENT_UPDATE,
    ACTIVE_TALENT_GROUP_CHANGED,
    GLYPH_UPDATED,
    UNIT_FLAGS,
    PLAYER_REGEN_ENABLED,
    PLAYER_REGEN_DISABLED,
    PLAYER_ENTERING_WORLD,
    UPDATE_BATTLEFIELD_STATUS,
    LFG_PROPOSAL_SHOW,
    LFG_ROLE_CHECK_SHOW,
    READY_CHECK,
    PLAYER_DEAD,
    DUEL_FINISHED,
    UNIT_SPELLCAST_SENT,
    UNIT_SPELLCAST_FAILED,
    ARENA_OPPONENT_UPDATE,
    CHAT_MSG_BG_SYSTEM_ALLIANCE,
    CHAT_MSG_BG_SYSTEM_HORDE,
  }

  public enum Types
  {
    SPELL_CAST_SUCCESS,
    SPELL_AURA_APPLIED,
    SPELL_AURA_REMOVED,
    SPELL_AURA_REFRESH,
    SPELL_PERIODIC_AURA_REMOVED,
    SWING_DAMAGE,
    SWING_MISSED,
    RANGE_DAMAGE,
    RANGE_MISSED,
    SPELL_DAMAGE,
    SPELL_PERIODIC_DAMAGE,
    SPELL_MISSED,
    SPELL_CAST_START,
    UNIT_DIED,
    UNIT_DESTROYED,
  }

  public delegate void Delegate11(EventArgs0 args);
}
