﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class36
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class36
{
  private static bool bool_0;
  private static Class36.Delegate9 delegate9_0 = new Class36.Delegate9(Class62.smethod_0);
  private static DateTime dateTime_0;
  private static WoWSpell woWSpell_0 = WoWSpell.FromId(1856);
  private static WoWSpell woWSpell_1 = WoWSpell.FromId(58984);

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static double Double_0 => (DateTime.UtcNow - Class36.dateTime_0).TotalSeconds;

  public static void Initialise() => Class36.Attach();

  public static void Attach()
  {
    if (Class36.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.UNIT_SPELLCAST_SENT, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    Class37.smethod_3(Class37.WoWEvents.UNIT_SPELLCAST_SENT, "return args[1] == 'player'");
    Class36.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class36.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.UNIT_SPELLCAST_SENT, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    Class37.smethod_4(Class37.WoWEvents.UNIT_SPELLCAST_SENT);
    Class36.bool_0 = false;
  }

  public static void Shutdown() => Class36.smethod_0();

  private static void smethod_1(object sender, LuaEventArgs e)
  {
    string str = e.Args[1].ToString();
    if (str == Class36.woWSpell_0.LocalizedName || str == Class36.woWSpell_0.Name)
    {
      Class49.woWSpell_0 = Class36.woWSpell_0;
      Class77.smethod_9();
      Class36.dateTime_0 = DateTime.UtcNow;
      Class36.delegate9_0((object) "Vanish detected: stop attack");
      if (Class140.bool_2)
        Class140.smethod_9("Vanish detected: stop attack");
    }
    if (!(str == Class36.woWSpell_1.LocalizedName) && !(str == Class36.woWSpell_1.Name))
      return;
    Class49.woWSpell_0 = Class36.woWSpell_1;
    Class77.smethod_9();
    Class36.delegate9_0((object) "Shadowmeld detected: stop attack");
    if (!Class140.bool_2)
      return;
    Class140.smethod_9("Shadowmeld detected: stop attack");
  }

  private delegate void Delegate9(params object[] args);
}
