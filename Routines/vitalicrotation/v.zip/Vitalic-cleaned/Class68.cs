﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class68
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.Common;
using Styx.CommonBot;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Media;

#nullable disable
namespace ns1;

[Attribute0]
internal static class Class68
{
  private static Class68.Delegate28 delegate28_0 = new Class68.Delegate28(Class62.smethod_0);
  private static Class68.Delegate28 delegate28_1 = new Class68.Delegate28(Class62.smethod_1);
  private static readonly HashSet<int> hashSet_0 = new HashSet<int>();
  private static readonly HashSet<int> hashSet_1 = new HashSet<int>();
  private static readonly HashSet<int> hashSet_2 = new HashSet<int>();
  private static readonly HashSet<int> hashSet_3 = new HashSet<int>();
  private static readonly HashSet<int> hashSet_4 = new HashSet<int>();
  private static bool bool_0;
  private static Dictionary<ulong, Dictionary<Class68.Enum14, Class68.Struct21>> dictionary_0;
  private static readonly HashSet<int> hashSet_5 = new HashSet<int>()
  {
    108194,
    115001,
    91800,
    47481,
    91797,
    102795,
    22570,
    5211,
    9005,
    110698,
    117526,
    24394,
    118271,
    44572,
    119381,
    105593,
    853,
    64044,
    1833,
    408,
    30283,
    89766,
    132168,
    46968,
    105771,
    20549,
    118905,
    107570,
    145585,
    132169,
    120086,
    119392,
    115752,
    96201,
    126355,
    126423,
    50519,
    56626,
    90337
  };
  private static readonly HashSet<int> hashSet_6 = new HashSet<int>()
  {
    96294,
    91807,
    339,
    19975,
    113770,
    45334,
    102359,
    110693,
    19185,
    136634,
    50245,
    54706,
    4167,
    122,
    111340,
    116706,
    113275,
    123407,
    113275,
    87194,
    114404,
    115197,
    64695,
    63685,
    107566,
    39965,
    55536,
    13099,
    33395
  };
  private static readonly HashSet<int> hashSet_7 = new HashSet<int>()
  {
    47476,
    78675,
    81261,
    34490,
    55021,
    102051,
    116709,
    31935,
    15487,
    1330,
    24259,
    115782,
    18498,
    25046,
    28730,
    50613,
    69179,
    80483
  };
  private static readonly HashSet<int> hashSet_8 = new HashSet<int>()
  {
    91644,
    50541,
    117368,
    140023,
    64058,
    51722,
    118093,
    676
  };
  private static readonly HashSet<int> hashSet_9 = new HashSet<int>()
  {
    113004,
    113056,
    5246,
    20511,
    1513,
    145067,
    8122,
    113792,
    2094,
    137143,
    5782,
    118699,
    5484,
    132412,
    115268,
    6358,
    105421
  };
  private static readonly HashSet<int> hashSet_10 = new HashSet<int>()
  {
    3355,
    6770,
    1776,
    51514,
    19386,
    118,
    61305,
    28272,
    61721,
    61780,
    28271,
    82691,
    115078,
    20066
  };
  private static readonly HashSet<int> hashSet_11 = new HashSet<int>()
  {
    19503,
    99,
    31661,
    88625
  };
  private static readonly HashSet<int> hashSet_12 = new HashSet<int>()
  {
    113953
  };
  private static readonly HashSet<int> hashSet_13 = new HashSet<int>()
  {
    115001,
    91800,
    91797,
    102795,
    5211,
    110698,
    853,
    44572,
    1833,
    408,
    113953,
    30283,
    89766,
    132168,
    105771,
    50245,
    54706,
    4167,
    19503,
    126246,
    96201,
    136634,
    7922,
    117526,
    107570,
    132169,
    111397,
    6789,
    19386
  };

  static Class68()
  {
    Class144.Event_0 += (Class144.Delegate42) ((sender, e) => Class68.smethod_3());
    // ISSUE: reference to a compiler-generated field
    if (Class68.onBotStopDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class68.onBotStopDelegate_0 = new BotEvents.OnBotStopDelegate((object) null, __methodptr(smethod_10));
    }
    // ISSUE: reference to a compiler-generated field
    BotEvents.OnBotStopped += Class68.onBotStopDelegate_0;
    Class41.Event_0 += (EventHandler) ((sender, e) =>
    {
      if (Class41.bool_3)
        Class68.smethod_2();
      else
        Class68.Attach();
    });
    Class68.hashSet_0.UnionWith((IEnumerable<int>) Class68.hashSet_10);
    Class68.hashSet_0.UnionWith((IEnumerable<int>) Class68.hashSet_11);
    Class68.hashSet_0.UnionWith((IEnumerable<int>) Class68.hashSet_5);
    Class68.hashSet_0.UnionWith((IEnumerable<int>) Class68.hashSet_12);
    Class68.hashSet_0.UnionWith((IEnumerable<int>) Class68.hashSet_7);
    Class68.hashSet_0.UnionWith((IEnumerable<int>) Class68.hashSet_9);
    Class68.hashSet_0.UnionWith((IEnumerable<int>) Class68.hashSet_6);
    Class68.hashSet_0.UnionWith((IEnumerable<int>) Class68.hashSet_8);
    Class68.hashSet_0.UnionWith((IEnumerable<int>) Class68.hashSet_13);
    Class68.hashSet_1.UnionWith((IEnumerable<int>) Class68.hashSet_5);
    Class68.hashSet_1.UnionWith((IEnumerable<int>) Class68.hashSet_12);
    Class68.hashSet_2.UnionWith((IEnumerable<int>) Class68.hashSet_10);
    Class68.hashSet_2.UnionWith((IEnumerable<int>) Class68.hashSet_11);
    Class68.hashSet_3.UnionWith((IEnumerable<int>) Class68.hashSet_5);
    Class68.hashSet_3.UnionWith((IEnumerable<int>) Class68.hashSet_12);
    Class68.hashSet_3.UnionWith((IEnumerable<int>) Class68.hashSet_10);
    Class68.hashSet_3.UnionWith((IEnumerable<int>) Class68.hashSet_11);
    Class68.hashSet_3.UnionWith((IEnumerable<int>) Class68.hashSet_9);
    Class68.hashSet_3.UnionWith((IEnumerable<int>) Class68.hashSet_8);
    Class68.hashSet_4.UnionWith((IEnumerable<int>) Class68.hashSet_5);
    Class68.hashSet_4.UnionWith((IEnumerable<int>) Class68.hashSet_12);
    Class68.hashSet_4.UnionWith((IEnumerable<int>) Class68.hashSet_10);
    Class68.hashSet_4.UnionWith((IEnumerable<int>) Class68.hashSet_11);
    Class68.hashSet_4.UnionWith((IEnumerable<int>) Class68.hashSet_9);
  }

  public static bool smethod_0(this WoWUnit woWUnit_0, Class68.Enum15 enum15_0, double double_0 = 0.0)
  {
    switch (enum15_0)
    {
      case Class68.Enum15.const_0:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_5, double_0);
      case Class68.Enum15.const_1:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_12, double_0);
      case Class68.Enum15.const_2:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_9, double_0);
      case Class68.Enum15.const_3:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_7, double_0);
      case Class68.Enum15.const_4:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_2, double_0);
      case Class68.Enum15.const_5:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_6, double_0);
      case Class68.Enum15.const_6:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_8, double_0);
      case Class68.Enum15.const_7:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_2, double_0);
      case Class68.Enum15.const_8:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_13, double_0);
      case Class68.Enum15.const_9:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_3, double_0);
      case Class68.Enum15.const_10:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_4, double_0);
      case Class68.Enum15.const_11:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_0, double_0);
      case Class68.Enum15.const_12:
        return Class68.smethod_1(woWUnit_0, Class68.hashSet_1, double_0);
      default:
        return false;
    }
  }

  private static bool smethod_1(WoWUnit woWUnit_0, HashSet<int> hashSet_14, double double_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class68.Class69 class69 = new Class68.Class69();
    // ISSUE: reference to a compiler-generated field
    class69.hashSet_0 = hashSet_14;
    // ISSUE: reference to a compiler-generated field
    class69.double_0 = double_0;
    // ISSUE: reference to a compiler-generated field
    // ISSUE: reference to a compiler-generated method
    // ISSUE: reference to a compiler-generated method
    return class69.double_0 == 0.0 ? woWUnit_0.smethod_0().Any<WoWAura>(new Func<WoWAura, bool>(class69.method_0)) : woWUnit_0.smethod_0().OrderByDescending<WoWAura, TimeSpan>((Func<WoWAura, TimeSpan>) (woWAura_0 => woWAura_0.TimeLeft)).Any<WoWAura>(new Func<WoWAura, bool>(class69.method_1));
  }

  public static void Initialise()
  {
    Class68.dictionary_0 = new Dictionary<ulong, Dictionary<Class68.Enum14, Class68.Struct21>>();
    Class68.Attach();
    Logging.Write((LogLevel) 2, Colors.LightGreen, "DR Tracker Initialised");
  }

  public static void Attach()
  {
    if (Class68.bool_0 || Class41.bool_3)
      return;
    Class37.smethod_8(Class37.Types.SPELL_AURA_REMOVED, new Class37.Delegate11(Class68.smethod_7));
    Class37.smethod_8(Class37.Types.SPELL_AURA_REFRESH, new Class37.Delegate11(Class68.smethod_7));
    Class68.bool_0 = true;
  }

  public static void smethod_2()
  {
    if (!Class68.bool_0)
      return;
    Class37.smethod_9(Class37.Types.SPELL_AURA_REMOVED, new Class37.Delegate11(Class68.smethod_7));
    Class37.smethod_9(Class37.Types.SPELL_AURA_REFRESH, new Class37.Delegate11(Class68.smethod_7));
    Class68.smethod_4();
    Class68.bool_0 = false;
  }

  public static void smethod_3()
  {
    if (!Class68.bool_0)
      return;
    List<ulong> ulongList = new List<ulong>();
    List<Class68.Enum14> enum14List = new List<Class68.Enum14>();
    foreach (KeyValuePair<ulong, Dictionary<Class68.Enum14, Class68.Struct21>> keyValuePair1 in Class68.dictionary_0)
    {
      enum14List.Clear();
      int num = 0;
      foreach (KeyValuePair<Class68.Enum14, Class68.Struct21> keyValuePair2 in keyValuePair1.Value)
      {
        if ((keyValuePair2.Value.dateTime_0 - DateTime.UtcNow).TotalSeconds < 0.0)
          enum14List.Add(keyValuePair2.Key);
        else
          ++num;
      }
      foreach (Class68.Enum14 key in enum14List)
        keyValuePair1.Value.Remove(key);
      if (num == 0)
        ulongList.Add(keyValuePair1.Key);
    }
    foreach (ulong key in ulongList)
      Class68.dictionary_0.Remove(key);
  }

  public static void smethod_4() => Class68.dictionary_0.Clear();

  public static bool smethod_5(this WoWUnit woWUnit_0, Class68.Enum14 enum14_0, double double_0 = 1.0)
  {
    Dictionary<Class68.Enum14, Class68.Struct21> dictionary;
    Class68.Struct21 struct21;
    return Class68.dictionary_0.TryGetValue(((WoWObject) woWUnit_0).Guid, out dictionary) && dictionary.TryGetValue(enum14_0, out struct21) && struct21.double_0 <= double_0;
  }

  public static Class68.Struct22 smethod_6(
    this WoWUnit woWUnit_0,
    Class68.Enum14 enum14_0,
    double double_0 = 1.0)
  {
    Class68.Struct22 struct22 = new Class68.Struct22();
    Dictionary<Class68.Enum14, Class68.Struct21> dictionary;
    Class68.Struct21 struct21;
    if (Class68.dictionary_0.TryGetValue(((WoWObject) woWUnit_0).Guid, out dictionary) && dictionary.TryGetValue(enum14_0, out struct21))
    {
      struct22.bool_0 = struct21.double_0 <= double_0;
      struct22.double_0 = struct21.double_0;
      struct22.int_0 = struct21.int_0;
      struct22.timeSpan_0 = struct21.dateTime_0 - DateTime.UtcNow;
      return struct22;
    }
    struct22.bool_0 = false;
    return struct22;
  }

  private static void smethod_7(EventArgs0 eventArgs0_0)
  {
    ulong ulong_0 = eventArgs0_0.lazy_4.Value;
    if (ulong_0 == 0UL || eventArgs0_0.lazy_0.Value != Class37.Types.SPELL_AURA_REFRESH && eventArgs0_0.lazy_0.Value != Class37.Types.SPELL_AURA_REMOVED || (eventArgs0_0.lazy_6.Value & Enum13.flag_10) == (Enum13) 0)
      return;
    int int_0 = eventArgs0_0.lazy_7.Value;
    if (Class68.hashSet_5.Contains(int_0))
      Class68.smethod_8(ulong_0, Class68.Enum14.const_0, int_0);
    else if (Class68.hashSet_10.Contains(int_0))
      Class68.smethod_8(ulong_0, Class68.Enum14.const_3, int_0);
    else if (Class68.hashSet_6.Contains(int_0))
      Class68.smethod_8(ulong_0, Class68.Enum14.const_4, int_0);
    else if (Class68.hashSet_7.Contains(int_0))
      Class68.smethod_8(ulong_0, Class68.Enum14.const_2, int_0);
    else if (Class68.hashSet_9.Contains(int_0))
      Class68.smethod_8(ulong_0, Class68.Enum14.const_1, int_0);
    else if (Class68.hashSet_8.Contains(int_0))
    {
      Class68.smethod_8(ulong_0, Class68.Enum14.const_5, int_0);
    }
    else
    {
      if (!Class68.hashSet_12.Contains(int_0))
        return;
      Class68.smethod_8(ulong_0, Class68.Enum14.const_6, int_0);
    }
  }

  internal static void smethod_8(ulong ulong_0, Class68.Enum14 enum14_0, int int_0)
  {
    Dictionary<Class68.Enum14, Class68.Struct21> dictionary;
    if (!Class68.dictionary_0.ContainsKey(ulong_0))
    {
      dictionary = new Dictionary<Class68.Enum14, Class68.Struct21>();
      Class68.dictionary_0.Add(ulong_0, dictionary);
    }
    else
      Class68.dictionary_0.TryGetValue(ulong_0, out dictionary);
    if (!dictionary.ContainsKey(enum14_0))
    {
      dictionary.Add(enum14_0, new Class68.Struct21()
      {
        double_0 = 1.0,
        int_0 = int_0,
        dateTime_0 = DateTime.UtcNow + TimeSpan.FromSeconds(enum14_0 == Class68.Enum14.const_0 ? 19.0 : 18.0)
      });
    }
    else
    {
      Class68.Struct21 struct21_1;
      dictionary.TryGetValue(enum14_0, out struct21_1);
      Class68.Struct21 struct21_2 = new Class68.Struct21();
      struct21_2.double_0 = Class68.NextDR(struct21_1.double_0);
      struct21_2.int_0 = int_0;
      struct21_2.dateTime_0 = DateTime.UtcNow + TimeSpan.FromSeconds(enum14_0 == Class68.Enum14.const_0 ? 19.0 : 18.0);
      dictionary.Remove(enum14_0);
      dictionary.Add(enum14_0, struct21_2);
    }
  }

  private static double NextDR(double diminished)
  {
    if (diminished == 1.0)
      return 0.5;
    return diminished == 0.5 ? 0.25 : 0.0;
  }

  private delegate void Delegate28(params object[] args);

  public enum Enum14
  {
    const_0,
    const_1,
    const_2,
    const_3,
    const_4,
    const_5,
    const_6,
  }

  public enum Enum15
  {
    const_0,
    const_1,
    const_2,
    const_3,
    const_4,
    const_5,
    const_6,
    const_7,
    const_8,
    const_9,
    const_10,
    const_11,
    const_12,
  }

  public struct Struct21
  {
    public double double_0;
    public int int_0;
    public DateTime dateTime_0;
  }

  public struct Struct22
  {
    public bool bool_0;
    public double double_0;
    public int int_0;
    public TimeSpan timeSpan_0;
  }
}
