﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class103
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;

#nullable disable
namespace ns1;

internal class Class103 : Class91
{
  private static Lazy<bool> lazy_0 = new Lazy<bool>((Func<bool>) (() => !string.IsNullOrEmpty(Lua.GetReturnVal<string>($"return GetItemSpell({(object) ((WoWObject) Class103.WoWItem_2).Entry})", 0U))));
  private static HashSet<uint> hashSet_0 = new HashSet<uint>()
  {
    100603U,
    100195U,
    94373U,
    99772U,
    91099U,
    100043U,
    103342U,
    102659U,
    103145U,
    102856U
  };

  private static WoWItem WoWItem_0 => Class91.LocalPlayer_0.Inventory.Equipped.Trinket1;

  private static WoWItem WoWItem_1 => Class91.LocalPlayer_0.Inventory.Equipped.Trinket2;

  private static WoWItem WoWItem_2 => Class91.LocalPlayer_0.Inventory.Equipped.Hands;

  private static bool Boolean_21
  {
    get
    {
      return WoWObject.op_Inequality((WoWObject) Class103.WoWItem_0, (WoWObject) null) && Class103.hashSet_0.Contains(Class103.WoWItem_0.ItemInfo.Id) && !Class59.smethod_1(Class103.WoWItem_0);
    }
  }

  private static bool Boolean_22
  {
    get
    {
      return WoWObject.op_Inequality((WoWObject) Class103.WoWItem_1, (WoWObject) null) && Class103.hashSet_0.Contains(Class103.WoWItem_1.ItemInfo.Id) && !Class59.smethod_1(Class103.WoWItem_1);
    }
  }

  private static bool Boolean_23
  {
    get
    {
      return !WoWObject.op_Equality((WoWObject) null, (WoWObject) Class103.WoWItem_2) && Class103.lazy_0.Value && !Class59.smethod_1(Class103.WoWItem_2);
    }
  }

  private static Composite Composite_0
  {
    get
    {
      Composite[] compositeArray1 = new Composite[3];
      Composite[] compositeArray2 = compositeArray1;
      if (Class103.canRunDecoratorDelegate_0 == null)
        Class103.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
      CanRunDecoratorDelegate decoratorDelegate0 = Class103.canRunDecoratorDelegate_0;
      if (Class103.actionSucceedDelegate_0 == null)
        Class103.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_6));
      Action action1 = new Action(Class103.actionSucceedDelegate_0);
      Decorator decorator1 = new Decorator(decoratorDelegate0, (Composite) action1);
      compositeArray2[0] = (Composite) decorator1;
      Composite[] compositeArray3 = compositeArray1;
      if (Class103.canRunDecoratorDelegate_1 == null)
        Class103.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
      CanRunDecoratorDelegate decoratorDelegate1 = Class103.canRunDecoratorDelegate_1;
      if (Class103.actionSucceedDelegate_1 == null)
        Class103.actionSucceedDelegate_1 = new ActionSucceedDelegate((object) null, __methodptr(smethod_8));
      Action action2 = new Action(Class103.actionSucceedDelegate_1);
      Decorator decorator2 = new Decorator(decoratorDelegate1, (Composite) action2);
      compositeArray3[1] = (Composite) decorator2;
      compositeArray1[2] = (Composite) new ActionAlwaysSucceed();
      return (Composite) new PrioritySelector(compositeArray1);
    }
  }

  private static Composite Composite_1
  {
    get
    {
      Composite[] compositeArray1 = new Composite[2];
      Composite[] compositeArray2 = compositeArray1;
      if (Class103.canRunDecoratorDelegate_2 == null)
        Class103.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
      CanRunDecoratorDelegate decoratorDelegate2 = Class103.canRunDecoratorDelegate_2;
      if (Class103.actionSucceedDelegate_2 == null)
        Class103.actionSucceedDelegate_2 = new ActionSucceedDelegate((object) null, __methodptr(smethod_10));
      Action action1 = new Action(Class103.actionSucceedDelegate_2);
      Decorator decorator1 = new Decorator(decoratorDelegate2, (Composite) action1);
      compositeArray2[0] = (Composite) decorator1;
      Composite[] compositeArray3 = compositeArray1;
      if (Class103.canRunDecoratorDelegate_3 == null)
        Class103.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_11));
      CanRunDecoratorDelegate decoratorDelegate3 = Class103.canRunDecoratorDelegate_3;
      if (Class103.actionSucceedDelegate_3 == null)
        Class103.actionSucceedDelegate_3 = new ActionSucceedDelegate((object) null, __methodptr(smethod_12));
      Action action2 = new Action(Class103.actionSucceedDelegate_3);
      Decorator decorator2 = new Decorator(decoratorDelegate3, (Composite) action2);
      compositeArray3[1] = (Composite) decorator2;
      return (Composite) new PrioritySelector(compositeArray1);
    }
  }

  private static Composite Composite_2
  {
    get
    {
      Composite[] compositeArray1 = new Composite[3]
      {
        Class103.Composite_1,
        null,
        null
      };
      Composite[] compositeArray2 = compositeArray1;
      if (Class103.canRunDecoratorDelegate_4 == null)
        Class103.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_13));
      CanRunDecoratorDelegate decoratorDelegate4 = Class103.canRunDecoratorDelegate_4;
      if (Class103.actionSucceedDelegate_4 == null)
        Class103.actionSucceedDelegate_4 = new ActionSucceedDelegate((object) null, __methodptr(smethod_14));
      Action action = new Action(Class103.actionSucceedDelegate_4);
      Decorator decorator = new Decorator(decoratorDelegate4, (Composite) action);
      compositeArray2[1] = (Composite) decorator;
      compositeArray1[2] = (Composite) new ActionAlwaysSucceed();
      return (Composite) new PrioritySelector(compositeArray1);
    }
  }

  private static Composite Composite_3
  {
    get
    {
      if (Class103.canRunDecoratorDelegate_5 == null)
        Class103.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_15));
      CanRunDecoratorDelegate decoratorDelegate5 = Class103.canRunDecoratorDelegate_5;
      if (Class103.actionSucceedDelegate_5 == null)
        Class103.actionSucceedDelegate_5 = new ActionSucceedDelegate((object) null, __methodptr(smethod_16));
      Action action = new Action(Class103.actionSucceedDelegate_5);
      return (Composite) new DecoratorContinue(decoratorDelegate5, (Composite) action);
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[4];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_6 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_17));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate6 = Class103.canRunDecoratorDelegate_6;
    // ISSUE: reference to a compiler-generated field
    if (Class103.actionDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_18));
    }
    // ISSUE: reference to a compiler-generated field
    Action action1 = new Action(Class103.actionDelegate_0);
    Decorator decorator1 = new Decorator(decoratorDelegate6, (Composite) action1);
    compositeArray2[0] = (Composite) decorator1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_7 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_19));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate7 = Class103.canRunDecoratorDelegate_7;
    TimeSpan timeSpan_1 = TimeSpan.FromSeconds(0.25);
    // ISSUE: reference to a compiler-generated field
    if (Class103.retrieveSwitchParameterDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.retrieveSwitchParameterDelegate_0 = new RetrieveSwitchParameterDelegate<WoWSpec>((object) null, __methodptr(smethod_20));
    }
    // ISSUE: reference to a compiler-generated field
    RetrieveSwitchParameterDelegate<WoWSpec> parameterDelegate0 = Class103.retrieveSwitchParameterDelegate_0;
    SwitchArgument<WoWSpec>[] switchArgumentArray1 = new SwitchArgument<WoWSpec>[3];
    SwitchArgument<WoWSpec>[] switchArgumentArray2 = switchArgumentArray1;
    Composite[] compositeArray4 = new Composite[4]
    {
      Class103.Composite_3,
      null,
      null,
      null
    };
    Composite[] compositeArray5 = compositeArray4;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_8 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_8 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_21));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate8 = Class103.canRunDecoratorDelegate_8;
    // ISSUE: reference to a compiler-generated field
    if (Class103.actionSucceedDelegate_6 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.actionSucceedDelegate_6 = new ActionSucceedDelegate((object) null, __methodptr(smethod_22));
    }
    // ISSUE: reference to a compiler-generated field
    Action action2 = new Action(Class103.actionSucceedDelegate_6);
    DecoratorContinue decoratorContinue1 = new DecoratorContinue(decoratorDelegate8, (Composite) action2);
    compositeArray5[1] = (Composite) decoratorContinue1;
    compositeArray4[2] = Class103.Composite_0;
    compositeArray4[3] = Class103.Composite_2;
    SwitchArgument<WoWSpec> switchArgument1 = new SwitchArgument<WoWSpec>((WoWSpec) 261, (Composite) new Sequence(compositeArray4));
    switchArgumentArray2[0] = switchArgument1;
    SwitchArgument<WoWSpec>[] switchArgumentArray3 = switchArgumentArray1;
    Composite[] compositeArray6 = new Composite[4];
    Composite[] compositeArray7 = compositeArray6;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_9 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_9 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_23));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate9 = Class103.canRunDecoratorDelegate_9;
    // ISSUE: reference to a compiler-generated field
    if (Class103.actionSucceedDelegate_7 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.actionSucceedDelegate_7 = new ActionSucceedDelegate((object) null, __methodptr(smethod_24));
    }
    // ISSUE: reference to a compiler-generated field
    Action action3 = new Action(Class103.actionSucceedDelegate_7);
    DecoratorContinue decoratorContinue2 = new DecoratorContinue(decoratorDelegate9, (Composite) action3);
    compositeArray7[0] = (Composite) decoratorContinue2;
    Composite[] compositeArray8 = compositeArray6;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_10 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_10 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_25));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate10 = Class103.canRunDecoratorDelegate_10;
    // ISSUE: reference to a compiler-generated field
    if (Class103.actionSucceedDelegate_8 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.actionSucceedDelegate_8 = new ActionSucceedDelegate((object) null, __methodptr(smethod_26));
    }
    // ISSUE: reference to a compiler-generated field
    Action action4 = new Action(Class103.actionSucceedDelegate_8);
    DecoratorContinue decoratorContinue3 = new DecoratorContinue(decoratorDelegate10, (Composite) action4);
    compositeArray8[1] = (Composite) decoratorContinue3;
    compositeArray6[2] = Class103.Composite_0;
    compositeArray6[3] = Class103.Composite_2;
    SwitchArgument<WoWSpec> switchArgument2 = new SwitchArgument<WoWSpec>((WoWSpec) 259, (Composite) new Sequence(compositeArray6));
    switchArgumentArray3[1] = switchArgument2;
    SwitchArgument<WoWSpec>[] switchArgumentArray4 = switchArgumentArray1;
    Composite[] compositeArray9 = new Composite[3];
    Composite[] compositeArray10 = compositeArray9;
    Composite[] compositeArray11 = new Composite[2];
    Composite[] compositeArray12 = compositeArray11;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_11 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_11 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_27));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate11 = Class103.canRunDecoratorDelegate_11;
    Composite[] compositeArray13 = new Composite[2];
    Composite[] compositeArray14 = compositeArray13;
    // ISSUE: reference to a compiler-generated field
    if (Class103.actionSucceedDelegate_9 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.actionSucceedDelegate_9 = new ActionSucceedDelegate((object) null, __methodptr(smethod_28));
    }
    // ISSUE: reference to a compiler-generated field
    Action action5 = new Action(Class103.actionSucceedDelegate_9);
    compositeArray14[0] = (Composite) action5;
    Composite[] compositeArray15 = compositeArray13;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_12 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_12 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_29));
    }
    // ISSUE: reference to a compiler-generated field
    DecoratorContinue decoratorContinue4 = new DecoratorContinue(Class103.canRunDecoratorDelegate_12, Class103.Composite_3);
    compositeArray15[1] = (Composite) decoratorContinue4;
    Sequence sequence1 = new Sequence(compositeArray13);
    Decorator decorator2 = new Decorator(decoratorDelegate11, (Composite) sequence1);
    compositeArray12[0] = (Composite) decorator2;
    Composite[] compositeArray16 = compositeArray11;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_13 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_13 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_30));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate13 = Class103.canRunDecoratorDelegate_13;
    Composite[] compositeArray17 = new Composite[2];
    Composite[] compositeArray18 = compositeArray17;
    // ISSUE: reference to a compiler-generated field
    if (Class103.actionSucceedDelegate_10 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.actionSucceedDelegate_10 = new ActionSucceedDelegate((object) null, __methodptr(smethod_31));
    }
    // ISSUE: reference to a compiler-generated field
    Action action6 = new Action(Class103.actionSucceedDelegate_10);
    compositeArray18[0] = (Composite) action6;
    Composite[] compositeArray19 = compositeArray17;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_14 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_14 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_32));
    }
    // ISSUE: reference to a compiler-generated field
    DecoratorContinue decoratorContinue5 = new DecoratorContinue(Class103.canRunDecoratorDelegate_14, Class103.Composite_3);
    compositeArray19[1] = (Composite) decoratorContinue5;
    Sequence sequence2 = new Sequence(compositeArray17);
    Decorator decorator3 = new Decorator(decoratorDelegate13, (Composite) sequence2);
    compositeArray16[1] = (Composite) decorator3;
    PrioritySelector prioritySelector = new PrioritySelector(compositeArray11);
    compositeArray10[0] = (Composite) prioritySelector;
    compositeArray9[1] = Class103.Composite_0;
    compositeArray9[2] = Class103.Composite_2;
    SwitchArgument<WoWSpec> switchArgument3 = new SwitchArgument<WoWSpec>((WoWSpec) 260, (Composite) new Sequence(compositeArray9));
    switchArgumentArray4[2] = switchArgument3;
    SwitchArgument<WoWSpec>[] switchArgumentArray5 = switchArgumentArray1;
    Switch<WoWSpec> composite_0 = new Switch<WoWSpec>(parameterDelegate0, switchArgumentArray5);
    GClass72 gclass72 = new GClass72(timeSpan_1, (Composite) composite_0);
    Decorator decorator4 = new Decorator(decoratorDelegate7, (Composite) gclass72);
    compositeArray3[1] = (Composite) decorator4;
    Composite[] compositeArray20 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_15 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_15 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_33));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator5 = new Decorator(Class103.canRunDecoratorDelegate_15, Class103.Composite_1);
    compositeArray20[2] = (Composite) decorator5;
    Composite[] compositeArray21 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_16 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_16 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_34));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate16 = Class103.canRunDecoratorDelegate_16;
    // ISSUE: reference to a compiler-generated field
    if (Class103.canRunDecoratorDelegate_17 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.canRunDecoratorDelegate_17 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_35));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate17 = Class103.canRunDecoratorDelegate_17;
    // ISSUE: reference to a compiler-generated field
    if (Class103.actionSucceedDelegate_11 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class103.actionSucceedDelegate_11 = new ActionSucceedDelegate((object) null, __methodptr(smethod_36));
    }
    // ISSUE: reference to a compiler-generated field
    Action action7 = new Action(Class103.actionSucceedDelegate_11);
    Decorator decorator6 = new Decorator(decoratorDelegate17, (Composite) action7);
    Decorator decorator7 = new Decorator(decoratorDelegate16, (Composite) decorator6);
    compositeArray21[3] = (Composite) decorator7;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
