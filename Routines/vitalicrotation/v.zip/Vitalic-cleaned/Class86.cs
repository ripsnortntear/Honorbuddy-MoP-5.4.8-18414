﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class86
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System.Collections.Generic;

#nullable disable
namespace ns1;

internal class Class86 : Class84
{
  private static readonly HashSet<int> hashSet_0 = new HashSet<int>()
  {
    13750,
    51690,
    73981,
    121471,
    2983
  };

  public static int Int32_2
  {
    get
    {
      int[] numArray = new int[3]{ 84745, 84746, 84747 };
      for (int index = 0; index < 3; ++index)
      {
        if (Class53.smethod_3((WoWUnit) Class84.LocalPlayer_0, numArray[index]))
          return index + 1;
      }
      return 0;
    }
  }

  private static Composite Composite_4
  {
    get
    {
      if (Class86.actionDelegate_2 == null)
        Class86.actionDelegate_2 = new ActionDelegate((object) null, __methodptr(smethod_29));
      return (Composite) new Action(Class86.actionDelegate_2);
    }
  }

  public static Composite Composite_5
  {
    get
    {
      return (Composite) new PrioritySelector(new Composite[32 /*0x20*/]
      {
        Class84.smethod_1(),
        Class86.Composite_4,
        Class93.smethod_4(),
        Class116.smethod_4(),
        Class101.smethod_4(),
        Class113.smethod_4(),
        Class117.smethod_4(),
        Class118.smethod_6(),
        Class122.smethod_5(),
        Class102.smethod_4(),
        Class115.smethod_5(),
        Class112.smethod_4(),
        Class105.smethod_4(),
        Class106.smethod_4(),
        Class111.smethod_4(),
        Class124.smethod_5(),
        Class123.smethod_4(),
        Class119.smethod_4(),
        Class109.smethod_4(),
        Class114.smethod_4(),
        Class94.smethod_4(),
        Class121.smethod_4(),
        Class92.smethod_4(),
        Class104.smethod_4(),
        Class103.smethod_4(),
        Class97.smethod_4(),
        Class129.smethod_4(),
        Class120.smethod_4(),
        Class99.smethod_4(),
        Class98.smethod_4(),
        Class95.smethod_4(),
        Class108.smethod_4()
      });
    }
  }
}
