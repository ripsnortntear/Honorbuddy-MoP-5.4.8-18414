﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class115
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class115 : Class91
{
  private static HashSet<int> hashSet_0 = new HashSet<int>()
  {
    78674,
    19434,
    109259,
    113092,
    30451,
    116,
    102051,
    44614,
    11366,
    8092,
    51505,
    117014,
    116858,
    157701,
    29722,
    6353
  };

  private static int Int32_4 => VitalicSettings.Instance.AutoFeint;

  private static int Int32_5 => VitalicSettings.Instance.FeintLastDamage;

  private static bool Boolean_21 => VitalicSettings.Instance.FeintInMeleeRange;

  private static double Double_9
  {
    get => VitalicSettings.Instance.InterruptDelay + Class144.double_0 / 1000.0;
  }

  private static bool Boolean_22
  {
    get => Class63.IEnumerable_3.Any<WoWUnit>(new Func<WoWUnit, bool>(Class115.smethod_4));
  }

  private static int Int32_6 => (int) (DateTime.UtcNow - Class43.dateTime_0).TotalSeconds;

  private static bool smethod_4(WoWUnit woWUnit_0)
  {
    return woWUnit_0.smethod_7(46924, 51690, 51713) || woWUnit_0.IsCasting && Class115.hashSet_0.Contains(woWUnit_0.CastingSpellId) && woWUnit_0.CurrentCastTimeLeft.TotalSeconds < Class115.Double_9 + 0.2 && (woWUnit_0.smethod_12() || woWUnit_0.smethod_8() || Class70.smethod_2(woWUnit_0) > 12.0);
  }

  public static Composite smethod_5()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class115.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class115.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class115.canRunDecoratorDelegate_0;
    Composite[] compositeArray1 = new Composite[3];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class115.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class115.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite1 = Class77.smethod_2(1966, Class115.canRunDecoratorDelegate_1, "Feint");
    compositeArray2[0] = composite1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class115.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class115.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite2 = Class77.smethod_2(1966, Class115.canRunDecoratorDelegate_2, "Feint");
    compositeArray3[1] = composite2;
    Composite[] compositeArray4 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class115.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class115.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite3 = Class77.smethod_2(1966, Class115.canRunDecoratorDelegate_3, "Feint");
    compositeArray4[2] = composite3;
    PrioritySelector prioritySelector = new PrioritySelector(compositeArray1);
    return (Composite) new Decorator(decoratorDelegate0, (Composite) prioritySelector);
  }
}
