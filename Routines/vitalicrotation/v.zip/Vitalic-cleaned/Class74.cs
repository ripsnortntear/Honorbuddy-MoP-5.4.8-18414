﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class74
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

internal static class Class74
{
  private static Class74.Delegate31 delegate31_0 = new Class74.Delegate31(Class62.smethod_0);
  public static readonly HashSet<int> hashSet_0 = new HashSet<int>()
  {
    33786,
    113506
  };
  private static HashSet<WoWApplyAuraType> hashSet_1 = new HashSet<WoWApplyAuraType>()
  {
    (WoWApplyAuraType) 3,
    (WoWApplyAuraType) 89,
    (WoWApplyAuraType) 4
  };
  private static HashSet<int> hashSet_2 = new HashSet<int>()
  {
    84747,
    84746,
    84745,
    95223,
    71328,
    45181,
    119611,
    118283,
    53651,
    57934,
    100340,
    57723,
    57724,
    80354,
    25771,
    96223,
    95809,
    11196,
    127973,
    35774,
    35775,
    32724,
    32725,
    113942,
    71041,
    26013
  };

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static double smethod_0(string string_0, WoWUnit woWUnit_0 = null, bool bool_0 = false)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class74.Class75 class75 = new Class74.Class75();
    // ISSUE: reference to a compiler-generated field
    class75.string_0 = string_0;
    // ISSUE: reference to a compiler-generated field
    class75.bool_0 = bool_0;
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null))
      woWUnit_0 = Class74.WoWUnit_0;
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null) || !((WoWObject) woWUnit_0).IsValid)
      return 0.0;
    // ISSUE: reference to a compiler-generated method
    WoWAura woWaura = woWUnit_0.smethod_2().FirstOrDefault<WoWAura>(new Func<WoWAura, bool>(class75.method_0));
    return WoWAura.op_Equality(woWaura, (WoWAura) null) ? 0.0 : woWaura.TimeLeft.TotalSeconds;
  }

  public static double smethod_1(int int_0, WoWUnit woWUnit_0 = null, bool bool_0 = false)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class74.Class76 class76 = new Class74.Class76();
    // ISSUE: reference to a compiler-generated field
    class76.int_0 = int_0;
    // ISSUE: reference to a compiler-generated field
    class76.bool_0 = bool_0;
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null))
      woWUnit_0 = Class74.WoWUnit_0;
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null) || !((WoWObject) woWUnit_0).IsValid)
      return 0.0;
    // ISSUE: reference to a compiler-generated method
    WoWAura woWaura = woWUnit_0.smethod_2().FirstOrDefault<WoWAura>(new Func<WoWAura, bool>(class76.method_0));
    return WoWAura.op_Equality(woWaura, (WoWAura) null) ? 0.0 : woWaura.TimeLeft.TotalSeconds;
  }

  public static double smethod_2(int int_0, bool bool_0 = false)
  {
    return Class74.smethod_1(int_0, bool_0: bool_0);
  }

  public static double smethod_3(int int_0) => Class74.smethod_1(int_0);

  public static bool smethod_4(WoWUnit woWUnit_0)
  {
    if (woWUnit_0.smethod_0(Class68.Enum15.const_0))
      return false;
    if (woWUnit_0.smethod_0(Class68.Enum15.const_4))
      return true;
    return woWUnit_0.smethod_7(2094) || Class41.bool_1 && woWUnit_0.smethod_0(Class68.Enum15.const_2) && ((WoWUnit) Class74.LocalPlayer_0).EnergyPercent < 90.0 && Class134.Class134_0.lazy_18.Value > 20.0 && !Class65.Boolean_0;
  }

  public static bool smethod_5(WoWUnit woWUnit_0 = null)
  {
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null))
      woWUnit_0 = (WoWUnit) Class74.LocalPlayer_0;
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null) || !((WoWObject) woWUnit_0).IsValid)
      return false;
    return Class53.smethod_3((WoWUnit) Class74.LocalPlayer_0, 8050) || woWUnit_0.smethod_2().Any<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => Class74.hashSet_1.Contains(woWAura_0.ApplyAuraType) && !Class74.hashSet_2.Contains(woWAura_0.SpellId)));
  }

  private delegate void Delegate31(params object[] args);
}
