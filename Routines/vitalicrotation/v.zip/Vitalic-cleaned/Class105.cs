﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class105
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class105 : Class91
{
  private static WoWAura woWAura_0;
  private static WoWUnit woWUnit_0;
  private static readonly HashSet<int> hashSet_0 = new HashSet<int>()
  {
    31884,
    1719,
    114049,
    106952,
    51271,
    51713,
    19574,
    34692,
    34471,
    107574,
    126679,
    126690,
    126700,
    126707,
    121471,
    3045,
    115193,
    49016,
    116740
  };

  private static int Int32_4 => (int) (DateTime.UtcNow - Class43.dateTime_0).TotalSeconds;

  private static bool Boolean_21
  {
    get
    {
      HashSet<WoWUnit> woWunitSet = new HashSet<WoWUnit>()
      {
        Class91.WoWUnit_0,
        Class91.WoWUnit_1
      };
      if (Class91.Boolean_1)
        woWunitSet.UnionWith(Class91.IEnumerable_1.Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_1 => WoWObject.op_Inequality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_0) && WoWObject.op_Inequality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_1))));
      foreach (WoWUnit woWUnit_0 in woWunitSet)
      {
        if (!WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null) && ((WoWObject) woWUnit_0).IsValid)
        {
          Class105.woWAura_0 = woWUnit_0.smethod_0().FirstOrDefault<WoWAura>((Func<WoWAura, bool>) (woWAura_1 => Class105.hashSet_0.Contains(woWAura_1.SpellId)));
          if (WoWAura.op_Inequality(Class105.woWAura_0, (WoWAura) null) && Class91.LocalPlayer_0.smethod_0(woWUnit_0) && (WoWObject.op_Inequality((WoWObject) woWUnit_0, (WoWObject) Class91.WoWUnit_0) || Class91.Double_4 > 20.0) && Class63.smethod_6(woWUnit_0) && woWUnit_0.smethod_18() && !woWUnit_0.smethod_0(Class68.Enum15.const_9) && !woWUnit_0.smethod_8(true) && !Class53.smethod_3(woWUnit_0, 112947) && !Class74.smethod_4(woWUnit_0) && !woWUnit_0.smethod_5(Class68.Enum14.const_5) && (!woWUnit_0.IsTargetingMeOrPet || !Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 5277)))
          {
            Class105.woWUnit_0 = woWUnit_0;
            return true;
          }
        }
      }
      return false;
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class105.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class105.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class105.canRunDecoratorDelegate_0;
    Class144.Delegate43 delegate43_4 = (Class144.Delegate43) (object_0 => Class105.woWUnit_0);
    // ISSUE: reference to a compiler-generated field
    if (Class105.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class105.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class105.canRunDecoratorDelegate_1;
    Action action_0 = (Action) (() => Class140.smethod_7("Dismantle: " + Class105.woWAura_0.Name, Class140.struct24_2));
    Composite composite = Class77.smethod_0(51722, delegate43_4, decoratorDelegate1, "Dismantle", action_0);
    return (Composite) new Decorator(decoratorDelegate0, composite);
  }
}
