﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class135
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.CommonBot;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class135
{
  private static bool bool_0;
  private static bool bool_1;
  private static Class135.Delegate36 delegate36_0 = new Class135.Delegate36(Class62.smethod_0);

  private static bool Boolean_0 => VitalicSettings.Instance.LowHealthWarning != 0;

  protected static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  public static void smethod_0()
  {
    if (!Class135.bool_0)
    {
      // ISSUE: reference to a compiler-generated field
      if (Class135.onBotStartDelegate_0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: method pointer
        Class135.onBotStartDelegate_0 = new BotEvents.OnBotStartDelegate((object) null, __methodptr(smethod_4));
      }
      // ISSUE: reference to a compiler-generated field
      BotEvents.OnBotStarted += Class135.onBotStartDelegate_0;
      Class41.Event_0 += (EventHandler) ((sender, e) => Class135.smethod_0());
      Class144.Event_0 += (Class144.Delegate42) ((sender, e) =>
      {
        if (!Class135.Boolean_0)
          return;
        double num = Class134.Class134_0.lazy_7.Value;
        if (!Class135.bool_1 && !((WoWUnit) Class135.LocalPlayer_0).IsDead && !((WoWPlayer) Class135.LocalPlayer_0).IsGhost && num < (double) VitalicSettings.Instance.LowHealthWarning)
        {
          Class135.smethod_2();
          Class135.bool_1 = true;
        }
        if (num <= 90.0 || num <= (double) VitalicSettings.Instance.LowHealthWarning)
          return;
        Class135.bool_1 = false;
      });
    }
    if (!Class135.Boolean_0 || Class135.bool_0 && Class135.smethod_1())
      return;
    Lua.DoString("if not ff then ff=CreateFrame('Frame','ff')\r\n                        ff:SetToplevel(true)ff:SetFrameStrata('FULLSCREEN_DIALOG')\r\n                        ff:SetAllPoints(UIParent)ff:EnableMouse(false)\r\n                        ff:Hide()\r\n                        ff.texture=ff:CreateTexture(nil,'BACKGROUND')\r\n                        ff.texture:SetTexture([[Interface\\FullScreenTextures\\LowHealth]])ff.texture:SetAllPoints(UIParent)\r\n                        ff.texture:SetBlendMode('ADD')\r\n                        ff:SetScript('OnShow',function(QDnlt)QDnlt.elapsed=0;QDnlt:SetAlpha(0)end)\r\n                        ff:SetScript('OnUpdate',function(LmcA2auZ,Q)Q=LmcA2auZ.elapsed+Q\r\n                        if Q<3.5 then local ZA=Q%1.3\r\n                        if ZA<0.15 then LmcA2auZ:SetAlpha(\r\n                        ZA/0.15)elseif ZA<0.9 then\r\n                        LmcA2auZ:SetAlpha(1- (ZA-0.15)/0.6)else LmcA2auZ:SetAlpha(0)end else LmcA2auZ:Hide()end;LmcA2auZ.elapsed=Q end)end\r\n                ", "WoW.lua");
    Class135.bool_0 = true;
  }

  public static bool smethod_1() => Lua.GetReturnVal<bool>("return ff ~= nil", 0U);

  public static void smethod_2() => Lua.DoString("ff:Show()", "WoW.lua");

  public static void smethod_3() => Lua.DoString("ff:Hide() ff = nil", "WoW.lua");

  private delegate void Delegate36(params object[] args);
}
