﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class109
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals;
using System;

#nullable disable
namespace ns1;

internal class Class109 : Class91
{
  private static uint UInt32_1
  {
    get
    {
      WoWAura auraById = Class91.WoWUnit_0.GetAuraById(113952);
      return !WoWAura.op_Inequality(auraById, (WoWAura) null) ? 0U : auraById.StackCount;
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class109.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class109.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    return Class77.smethod_1(5938, Class109.canRunDecoratorDelegate_0, "Shiv", (Action) (() => Class140.smethod_7("Casted Shiv (auto)", Class140.struct24_2)));
  }
}
