﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class97
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class97 : Class91
{
  private static WoWAura woWAura_0;
  private static WoWUnit woWUnit_0;

  private static bool Boolean_21
  {
    get
    {
      HashSet<WoWUnit> woWunitSet = new HashSet<WoWUnit>()
      {
        Class91.WoWUnit_0,
        Class91.WoWUnit_1
      };
      if (Class91.Boolean_1)
        woWunitSet.UnionWith(Class91.IEnumerable_1.Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_1 => WoWObject.op_Inequality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_0) && WoWObject.op_Inequality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_1))));
      foreach (WoWUnit woWUnit_0 in woWunitSet)
      {
        if (!WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null) && ((WoWObject) woWUnit_0).IsValid)
        {
          Class97.woWAura_0 = woWUnit_0.smethod_0().FirstOrDefault<WoWAura>((Func<WoWAura, bool>) (woWAura_1 => Class65.dictionary_0.ContainsKey(woWAura_1.SpellId)));
          if (WoWAura.op_Inequality(Class97.woWAura_0, (WoWAura) null) && Class91.LocalPlayer_0.smethod_0(woWUnit_0) && Class63.smethod_6(woWUnit_0) && !woWUnit_0.smethod_5(Class68.Enum14.const_0, Class91.LocalPlayer_0.smethod_4(5) ? 0.5 : 1.0) && !woWUnit_0.smethod_0(Class68.Enum15.const_11) && !woWUnit_0.smethod_17() && !woWUnit_0.smethod_8(true) && !Class53.smethod_3(woWUnit_0, 112947) && (!woWUnit_0.IsTargetingMeOrPet || !Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 5277)))
          {
            Class97.woWUnit_0 = woWUnit_0;
            return true;
          }
        }
      }
      return false;
    }
  }

  private static double Double_9
  {
    get
    {
      WoWAura auraById = ((WoWUnit) Class91.LocalPlayer_0).GetAuraById(51713);
      return WoWAura.op_Equality(auraById, (WoWAura) null) ? 0.0 : ((double) auraById.Duration - auraById.TimeLeft.TotalMilliseconds) / 1000.0;
    }
  }

  private static bool Boolean_22
  {
    get
    {
      return Class53.smethod_3(Class91.WoWUnit_0, 1330) && Class91.WoWUnit_0.smethod_15() && !Class91.WoWUnit_0.smethod_16() && Class74.smethod_3(1330) > 0.5 && !Class124.bool_0;
    }
  }

  private static bool Boolean_23
  {
    get
    {
      Class68.Struct22 struct22 = Class91.WoWUnit_0.smethod_6(Class68.Enum14.const_0);
      if (!struct22.bool_0)
        return false;
      return struct22.double_0 < 1.0 || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_0);
    }
  }

  private static bool Boolean_24
  {
    get
    {
      if (!Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 51713) || !Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_0) && !Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_0) || Class97.Double_9 >= 2.0)
        return false;
      return Class91.Double_2 < 60.0 || Class91.Boolean_16;
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[2];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class97.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class97.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite1 = Class77.smethod_1(1833, Class97.canRunDecoratorDelegate_0, "Cheap Shot");
    compositeArray2[0] = composite1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class97.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class97.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class97.canRunDecoratorDelegate_1;
    Composite[] compositeArray4 = new Composite[2]
    {
      Class84.Composite_3,
      null
    };
    Composite[] compositeArray5 = compositeArray4;
    Class144.Delegate43 delegate43_4 = (Class144.Delegate43) (object_0 => Class97.woWUnit_0);
    // ISSUE: reference to a compiler-generated field
    if (Class97.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class97.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_10));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate2 = Class97.canRunDecoratorDelegate_2;
    Action action_0 = (Action) (() => Class140.smethod_7("Cheap Shot: " + Class97.woWAura_0.Name, Class140.struct24_0));
    Composite composite2 = Class77.smethod_0(1833, delegate43_4, decoratorDelegate2, "Cheap Shot", action_0);
    compositeArray5[1] = composite2;
    PrioritySelector prioritySelector = new PrioritySelector(compositeArray4);
    Decorator decorator = new Decorator(decoratorDelegate1, (Composite) prioritySelector);
    compositeArray3[1] = (Composite) decorator;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
