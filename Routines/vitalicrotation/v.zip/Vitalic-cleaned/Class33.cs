﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class33
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class33
{
  private static bool bool_0;
  private static Class33.Delegate6 delegate6_0 = new Class33.Delegate6(Class62.smethod_0);
  private static WoWSpell woWSpell_0 = WoWSpell.FromId(1856);

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static void Initialise() => Class33.Attach();

  public static void Attach()
  {
    if (Class33.bool_0)
      return;
    Class33.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class33.bool_0)
      return;
    Class33.bool_0 = false;
  }

  public static void Shutdown() => Class33.smethod_0();

  private static void smethod_1(object sender, LuaEventArgs e)
  {
    string str = e.Args[4].ToString();
    if (((WoWUnit) Class33.LocalPlayer_0).smethod_4())
      return;
    string string_0 = "cooldown_" + str;
    if (Class51.smethod_4(string_0))
      Class51.smethod_3(string_0);
    if (Convert.ToInt32(str) != 1856 || !WoWSpell.op_Inequality(Class49.woWSpell_0, (WoWSpell) null) || Class49.woWSpell_0.Id != 1856)
      return;
    Class49.woWSpell_0 = (WoWSpell) null;
  }

  private delegate void Delegate6(params object[] args);
}
