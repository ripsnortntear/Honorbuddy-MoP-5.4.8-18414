﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class98
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;

#nullable disable
namespace ns1;

internal class Class98 : Class91
{
  private static double Double_9
  {
    get
    {
      return ((WoWUnit) Class91.LocalPlayer_0).EnergyPercent <= 80.0 && !Class91.LocalPlayer_0.smethod_4(18) ? 1.3 : 1.1;
    }
  }

  private static bool Boolean_21
  {
    get
    {
      if (Class91.LocalPlayer_0.smethod_4(15) || !Class91.WoWUnit_0.smethod_12() || Class91.Double_2 > 80.0 || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_12))
        return true;
      return Class91.LocalPlayer_0.ComboPoints > 3 && Class91.Boolean_16;
    }
  }

  private static bool Boolean_22
  {
    get
    {
      return Class53.smethod_3(Class91.WoWUnit_0, 1833) && !Class53.smethod_3(Class91.WoWUnit_0, 408) && !Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_0) && Class74.smethod_3(1833) < Class98.Double_9;
    }
  }

  private static bool Boolean_23
  {
    get
    {
      double num = Class65.smethod_1(115192);
      if (!Class91.smethod_0() || !Class91.WoWUnit_0.smethod_15() || Class91.Double_2 >= 70.0 && num >= 1.25 || (Class53.smethod_3(Class91.WoWUnit_0, 1330) || Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_2)) && (Class53.smethod_3(Class91.WoWUnit_0, 1833) || Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_0)))
        return false;
      return Class91.LocalPlayer_0.ComboPoints < 4 || !Class91.Boolean_16 || !Class91.WoWUnit_0.smethod_14();
    }
  }

  private static bool Boolean_24
  {
    get => Class91.Double_2 < 60.0 && Class91.Boolean_8 && Class91.Double_4 > 30.0;
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class98.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class98.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    return Class77.smethod_1(8676, Class98.canRunDecoratorDelegate_0, "Ambush");
  }
}
