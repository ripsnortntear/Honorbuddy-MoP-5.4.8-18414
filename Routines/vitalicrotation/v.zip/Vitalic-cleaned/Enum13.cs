﻿// Decompiled with JetBrains decompiler
// Type: ns1.Enum13
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using System;

#nullable disable
namespace ns1;

[Flags]
internal enum Enum13
{
  flag_0 = 16384, // 0x00004000
  flag_1 = 8192, // 0x00002000
  flag_2 = 4096, // 0x00001000
  flag_3 = 2048, // 0x00000800
  flag_4 = 1024, // 0x00000400
  flag_5 = 512, // 0x00000200
  flag_6 = 256, // 0x00000100
  flag_7 = 64, // 0x00000040
  flag_8 = 32, // 0x00000020
  flag_9 = 16, // 0x00000010
  flag_10 = 8,
  flag_11 = 4,
  flag_12 = 2,
  flag_13 = 1,
  flag_14 = 134217728, // 0x08000000
  flag_15 = 67108864, // 0x04000000
  flag_16 = 33554432, // 0x02000000
  flag_17 = 16777216, // 0x01000000
  flag_18 = 8388608, // 0x00800000
  flag_19 = 4194304, // 0x00400000
  flag_20 = 2097152, // 0x00200000
  flag_21 = 1048576, // 0x00100000
  flag_22 = 524288, // 0x00080000
  flag_23 = 262144, // 0x00040000
  flag_24 = 131072, // 0x00020000
  flag_25 = 65536, // 0x00010000
}
