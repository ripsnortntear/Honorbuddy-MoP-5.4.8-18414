﻿// Decompiled with JetBrains decompiler
// Type: ns1.VitalicForm
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using A;
using Styx.Common;
using Styx.Helpers;
using Styx.WoWInternals;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Windows.Forms.Layout;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class VitalicForm : \u0020\u0007
{
  private const string string_0 = "<style>p {{ margin: 0; padding:0 5px 0 0; }} h3 {{ margin: 0 0 5px 0; }}</style>\r\n                <div style=\"font-family:segoe ui; font-size: 9px\">{0}</div>";
  private const string string_1 = "<style>ul {{margin-left:15px; font-family:consolas; font-size:9px;}} li {{ margin-bottom: 5px; }} h4 {{ margin: 5px 0 8px 0; font-family:consolas; }}</style>{0}";
  private const string string_2 = "Click to set Keybind";
  private static bool bool_0;
  private Keys keys_0;
  private Keys keys_1;
  private Keys keys_2;
  private bool bool_1;
  private Stream stream_0;
  private string string_3 = Utilities.AssemblyDirectory + "\\Routines\\Vitalic\\Resources\\";
  private bool bool_2;
  private \u0010\u0008 \u0010\u0008_0;
  private bool bool_3;
  private IContainer icontainer_0;
  private \u001E\u0008 metroTabControl1;
  private \u0017\u0007 \u0017\u0007_0;
  private \u001F\u0008 tabPageDefensive;
  private \u0008\u0008 \u0008\u0008_0;
  private \u001F\u0008 tabPageUtilities;
  private \u001F\u0008 tabPageOffensive;
  private \u0015\u0008 metroLabel5;
  private \u0015\u0008 metroLabel4;
  private \u0004\u0009 BurstEnergyBar;
  private \u001F\u0008 tabPageAutomation;
  private \u0012\u0008 AutoFocusComboBox;
  private \u0015\u0008 metroLabel19;
  private \u0015\u0008 metroLabel17;
  private \u0003\u0009 CapacitorToggle;
  private \u0012\u0008 AutoFocusTargetsComboBox;
  private \u001F\u0008 tabPageInformation;
  private \u0016\u0007 \u0016\u0007_0;
  private \u001F\u0008 tabPageKeybinds;
  private \u0010\u0008 GarroteKeyBindButton;
  private \u0015\u0008 metroLabel20;
  private \u0010\u0008 BurstKeyBindButton;
  private \u0015\u0008 metroLabel21;
  private \u0015\u0008 metroLabel22;
  private \u0010\u0008 CheapShotKeyBindButton;
  private \u0010\u0008 LazyKeyBindButton;
  private \u0015\u0008 metroLabel23;
  private \u0017\u0008 KeyBindPanel2;
  private \u0017\u0008 KeyBindPanel1;
  private \u0017\u0008 KeyBindPanel3;
  private \u0010\u0008 BlindKeyBindButton;
  private \u0015\u0008 metroLabel24;
  private \u0015\u0008 metroLabel25;
  private \u0001\u0009 TricksTarget;
  private \u0010\u0008 PauseDamageKeyBindButton;
  private \u0015\u0008 metroLabel29;
  private \u0010\u0008 PauseKeyBindButton;
  private \u0015\u0008 metroLabel28;
  private \u0015\u0008 metroLabel30;
  private \u0010\u0008 FocusMacroKeyBindButton;
  private \u0010\u0008 RedirectKidneyKeyBindButton;
  private \u0015\u0008 metroLabel32;
  private \u0010\u0008 GougeKeyBindButton;
  private \u0015\u0008 metroLabel31;
  private \u0010\u0008 BurstNoShadowBladesKeyBindButton;
  private \u0015\u0008 metroLabel33;
  private \u0010\u0008 KidneyShotKeyBindButton;
  private \u0015\u0008 metroLabel34;
  private \u0010\u0008 RestealthKeyBindButton;
  private \u0015\u0008 metroLabel36;
  private \u0010\u0008 SmokeBombKeyBindButton;
  private \u0015\u0008 metroLabel35;
  private \u0010\u0008 FastKickKeyBindButton;
  private \u0015\u0008 metroLabel37;
  private \u0010\u0008 EventsKeyBindButton;
  private \u0015\u0008 metroLabel38;
  private \u0015\u0008 BurstEnergyLabel;
  private \u0015\u0008 BurstEnergyOpenerLabel;
  private \u0015\u0008 metroLabel40;
  private \u0004\u0009 BurstEnergyOpenerBar;
  private \u0015\u0008 metroLabel7;
  private \u0001\u0009 EventBlacklist;
  private \u0019\u0008 SaveSettingsIcon;
  private Class146 groupBox1;
  private Class146 groupBox2;
  private \u0015\u0008 UserName;
  private \u0015\u0008 metroLabel41;
  private \u001E\u0009 RotationNotes;
  private \u001E\u0009 ChangeLog;
  private \u001F\u0008 tabPageInterface;
  private \u0015\u0008 LowHealthWarningLabel;
  private \u0015\u0008 metroLabel39;
  private \u0005\u0009 LowHealthWarningBar;
  private \u0011\u0008 MacrosEnabledCheckBox;
  private \u0011\u0008 SoundAlertsCheckBox;
  private \u0011\u0008 AlertFontsCheckBox;
  private \u0011\u0008 LogMessagesCheckBox;
  private \u0011\u0008 SpellAlertsCheckBox;
  private \u0015\u0008 metroLabel16;
  private \u0011\u0008 StatusFrameCheckBox;
  private \u0015\u0008 metroLabel2;
  private \u0002\u0009 metroTileSwitch;
  private \u0015\u0008 metroLabel27;
  private \u0012\u0008 OffHandPoisonComboBox;
  private \u0015\u0008 metroLabel26;
  private \u0012\u0008 MainHandPoisonComboBox;
  private \u0015\u0008 metroLabel3;
  private \u0015\u0008 CapacitorLabel;
  private \u0017\u0008 metroPanel1;
  private \u0015\u0008 metroLabel13;
  private \u0015\u0008 HealingTideLabel;
  private \u0003\u0009 HealingTideToggle;
  private \u0015\u0008 metroLabel11;
  private \u0015\u0008 HealingStreamLabel;
  private \u0003\u0009 HealingStreamToggle;
  private \u0015\u0008 metroLabel6;
  private \u0015\u0008 SpiritLinkLabel;
  private \u0003\u0009 SpiritLinkToggle;
  private \u0015\u0008 metroLabel15;
  private \u0015\u0008 GroundingLabel;
  private \u0003\u0009 GroundingToggle;
  private \u0015\u0008 metroLabel44;
  private \u0015\u0008 EarthgrabLabel;
  private \u0003\u0009 EarthgrabToggle;
  private \u0017\u0008 metroPanel2;
  private \u0015\u0008 metroLabel46;
  private \u0012\u0008 SubterfugeOpenersComboBox;
  private \u0017\u0008 metroPanel3;
  private \u0011\u0008 LazyPoolingCheckBox;
  private \u0011\u0008 AlwaysUseHemoCheckBox;
  private \u0015\u0008 metroLabel47;
  private \u0015\u0008 metroLabel51;
  private \u0005\u0009 BurstHealthBar;
  private \u0015\u0008 BurstPreparationLabel;
  private \u0015\u0008 metroLabel49;
  private \u0004\u0009 BurstPreparationBar;
  private \u0015\u0008 metroLabel52;
  private \u0012\u0008 BurstStunDRComboBox;
  private \u0015\u0008 HemoDelayLabel;
  private \u0015\u0008 metroLabel55;
  private \u0004\u0009 HemoDelayBar;
  private \u0015\u0008 KidneyShotCPsLabel;
  private \u0015\u0008 metroLabel57;
  private \u0004\u0009 KidneyShotCPsBar;
  private \u0015\u0008 KidneyShotEnergyLabel;
  private \u0015\u0008 metroLabel59;
  private \u0004\u0009 KidneyShotEnergyBar;
  private \u0015\u0008 metroLabel53;
  private \u0012\u0008 CombatBurstComboBox;
  private \u0017\u0008 metroPanel5;
  private \u0017\u0008 metroPanel4;
  private \u0017\u0008 metroPanel6;
  private \u0017\u0008 metroPanel7;
  private \u0017\u0008 metroPanel8;
  private \u0017\u0008 metroPanel9;
  private \u0011\u0008 PvEModeCheckBox;
  private \u0015\u0008 metroLabel18;
  private \u0011\u0008 AcceptQueuesCheckBox;
  private \u0011\u0008 ClickToMoveCheckBox;
  private \u0011\u0008 AlertQueuesCheckBox;
  private \u0011\u0008 AntiAFKCheckBox;
  private \u0011\u0008 DiagnosticModeCheckBox;
  private \u0015\u0008 OpenerTPSLabel;
  private \u0015\u0008 metroLabel62;
  private \u0004\u0009 OpenerTPSBar;
  private \u0017\u0008 metroPanel10;
  private \u0017\u0008 metroPanel12;
  private \u0017\u0008 metroPanel11;
  private \u0015\u0008 HealthstoneHPLabel;
  private \u0015\u0008 metroLabel64;
  private \u0005\u0009 HealthstoneHPBar;
  private \u0015\u0008 RecuperateHPLabel;
  private \u0015\u0008 metroLabel9;
  private \u0005\u0009 RecuperateHPBar;
  private \u0015\u0008 TeammateSupportLabel;
  private \u0015\u0008 metroLabel61;
  private \u0005\u0009 TeammateSupportBar;
  private \u0011\u0008 AutoMoveOnTrapsCheckBox;
  private \u0015\u0008 metroLabel65;
  private \u0011\u0008 ShadowstepTrapsCheckBox;
  private \u0011\u0008 RuptureOverGarroteCheckBox;
  private \u0015\u0008 FeintLastDamageLabel;
  private \u0015\u0008 metroLabel67;
  private \u0004\u0009 FeintLastDamageBar;
  private \u0015\u0008 FeintHPLabel;
  private \u0015\u0008 metroLabel69;
  private \u0011\u0008 FeintInMeleeRangeCheckBox;
  private \u0015\u0008 MacroDelayLabel;
  private \u0015\u0008 metroLabel71;
  private \u0004\u0009 MacroDelayBar;
  private \u0015\u0008 StickyDelayLabel;
  private \u0015\u0008 metroLabel73;
  private \u0004\u0009 StickyDelayBar;
  private \u0017\u0008 metroPanel13;
  private \u0017\u0008 metroPanel14;
  private \u0017\u0008 metroPanel15;
  private \u0011\u0008 AutoRedirectCheckBox;
  private \u0015\u0008 metroLabel74;
  private \u0011\u0008 AutoKidneyCheckBox;
  private \u0011\u0008 AutoShroudCheckBox;
  private \u0011\u0008 AutoPreparationCheckBox;
  private \u0011\u0008 AutoSmokeBombCheckBox;
  private \u0011\u0008 AutoShivCheckBox;
  private \u0011\u0008 AutoFlagReturnCheckBox;
  private \u0011\u0008 AlwaysStealthCheckBox;
  private \u0015\u0008 ShadowstepBufferLabel;
  private \u0015\u0008 metroLabel77;
  private \u0004\u0009 ShadowstepBufferBar;
  private \u0015\u0008 InterruptMinimumLabel;
  private \u0015\u0008 metroLabel79;
  private \u0004\u0009 InterruptMinimumBar;
  private \u0015\u0008 InterruptDelayLabel;
  private \u0015\u0008 metroLabel81;
  private \u0004\u0009 InterruptDelayBar;
  private \u0015\u0008 metroLabel75;
  private \u0015\u0008 GougeNoKickHPLabel;
  private \u0015\u0008 metroLabel83;
  private \u0005\u0009 GougeNoKickHPBar;
  private \u0015\u0008 GougeDelayLabel;
  private \u0015\u0008 metroLabel85;
  private \u0004\u0009 GougeDelayBar;
  private \u0015\u0008 metroLabel86;
  private \u0015\u0008 ShadowstepRangeLabel;
  private \u0015\u0008 metroLabel1;
  private \u0004\u0009 ShadowstepRangeBar;
  private Class146 nonFlickerGroupBox1;
  private \u0011\u0008 AutoBurstOfSpeedCheckBox;
  private \u0005\u0009 FeintHPBar;
  private \u0015\u0008 BurstHealthLabel;
  private \u0015\u0008 ManualCastPauseLabel;
  private \u0015\u0008 metroLabel10;
  private \u0004\u0009 ManualCastPauseBar;
  private \u0010\u0008 AutoKidneyKeyBindButton;
  private \u0015\u0008 metroLabel8;
  private \u0011\u0008 LazyEviscerateCheckBox;
  private \u0011\u0008 AutoTargetCheckBox;
  private \u0015\u0008 metroLabel12;
  private \u0015\u0008 WindwalkLabel;
  private \u0003\u0009 WindwalkToggle;
  private \u0015\u0008 metroLabel14;
  private \u0010\u0008 OpenerModifierKeyBindButton;

  public VitalicForm()
  {
    Thread.CurrentThread.CurrentCulture = new CultureInfo("en-GB");
    this.InitializeComponent();
    this.method_23();
    this.method_25();
    this.method_42();
    this.method_26();
    this.method_29();
  }

  private void metroTabControl1_Selected(object sender, TabControlEventArgs e)
  {
    VitalicSettings.Instance.UILastTab = e.TabPageIndex;
  }

  private void MainHandPoisonComboBox_SelectedIndexChanged(object sender, EventArgs e)
  {
    Class145<int> selectedItem = this.MainHandPoisonComboBox.SelectedItem as Class145<int>;
    VitalicSettings.Instance.MainHandPoison = selectedItem.Key;
    this.method_24();
  }

  private void OffHandPoisonComboBox_SelectedIndexChanged(object sender, EventArgs e)
  {
    Class145<int> selectedItem = this.OffHandPoisonComboBox.SelectedItem as Class145<int>;
    VitalicSettings.Instance.OffHandPoison = selectedItem.Key;
    this.method_24();
  }

  private void StatusFrameCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.StatusFrameEnabled = this.StatusFrameCheckBox.Checked;
    if (this.StatusFrameCheckBox.Checked)
      Class136.smethod_3();
    else
      Class136.smethod_4();
    this.method_24();
  }

  private void SpellAlertsCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.SpellAlertsEnabled = this.SpellAlertsCheckBox.Checked;
    if (this.SpellAlertsCheckBox.Checked)
    {
      Class140.bool_1 = true;
      Class140.smethod_1();
    }
    else
    {
      Class140.bool_1 = false;
      Class140.smethod_4();
    }
    this.method_24();
  }

  private void AlertFontsCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AlertFontsEnabled = this.AlertFontsCheckBox.Checked;
    if (this.AlertFontsCheckBox.Checked)
      Class140.smethod_3();
    else
      Class140.smethod_4();
    this.method_24();
  }

  private void LogMessagesCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.LogMessagesEnabled = this.LogMessagesCheckBox.Checked;
    Class140.bool_2 = this.LogMessagesCheckBox.Checked;
    this.method_24();
  }

  private void SoundAlertsCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.SoundAlertsEnabled = this.SoundAlertsCheckBox.Checked;
    this.method_24();
  }

  private void MacrosEnabledCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.MacrosEnabled = this.MacrosEnabledCheckBox.Checked;
    if (this.bool_1)
      return;
    Class137.smethod_0();
    Class136.smethod_5();
    this.method_24();
  }

  private void KeyBindPanel2_MouseEnter(object sender, EventArgs e)
  {
    if (this.bool_2)
      return;
    this.KeyBindPanel2.Focus();
  }

  private void KeyBindPanel3_MouseEnter(object sender, EventArgs e)
  {
    if (this.bool_2)
      return;
    this.KeyBindPanel3.Focus();
  }

  private void method_0(object sender, EventArgs e)
  {
    this.BurstEnergyLabel.Text = this.BurstEnergyBar.\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void BurstEnergyBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.BurstEnergy = this.BurstEnergyBar.\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_1(object sender, EventArgs e)
  {
    this.BurstEnergyOpenerLabel.Text = this.BurstEnergyOpenerBar.\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void BurstEnergyOpenerBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.BurstEnergyOpener = this.BurstEnergyOpenerBar.\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_2(object sender, EventArgs e)
  {
    this.LowHealthWarningLabel.Text = ((\u0004\u0009) this.LowHealthWarningBar).\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void LowHealthWarningBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.LowHealthWarning = ((\u0004\u0009) this.LowHealthWarningBar).\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_3(object sender, EventArgs e)
  {
    this.HemoDelayLabel.Text = $"{(double) this.HemoDelayBar.\u000F / 10.0:0.##}";
    VitalicForm.bool_0 = true;
  }

  private void HemoDelayBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.HemoDelay = (double) this.HemoDelayBar.\u000F / 10.0;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_4(object sender, EventArgs e)
  {
    this.InterruptDelayLabel.Text = $"{(double) this.InterruptDelayBar.\u000F / 100.0:0.##}";
    VitalicForm.bool_0 = true;
  }

  private void InterruptDelayBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.InterruptDelay = (double) this.InterruptDelayBar.\u000F / 100.0;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_5(object sender, EventArgs e)
  {
    this.InterruptMinimumLabel.Text = $"{(double) this.InterruptMinimumBar.\u000F / 100.0:0.##}";
    VitalicForm.bool_0 = true;
  }

  private void InterruptMinimumBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.InterruptMinimum = (double) this.InterruptMinimumBar.\u000F / 100.0;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_6(object sender, EventArgs e)
  {
    this.ShadowstepBufferLabel.Text = $"{(double) this.ShadowstepBufferBar.\u000F / 100.0:0.##}";
    VitalicForm.bool_0 = true;
  }

  private void ShadowstepBufferBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.InterruptShadowstepBuffer = (double) this.ShadowstepBufferBar.\u000F / 100.0;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_7(object sender, EventArgs e)
  {
    this.GougeDelayLabel.Text = $"{(double) this.GougeDelayBar.\u000F / 100.0:0.##}";
    VitalicForm.bool_0 = true;
  }

  private void GougeDelayBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.GougeDelay = (double) this.GougeDelayBar.\u000F / 100.0;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_8(object sender, EventArgs e)
  {
    this.GougeNoKickHPLabel.Text = ((\u0004\u0009) this.GougeNoKickHPBar).\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void GougeNoKickHPBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.GougeNoKickHP = ((\u0004\u0009) this.GougeNoKickHPBar).\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_9(object sender, EventArgs e)
  {
    this.TeammateSupportLabel.Text = ((\u0004\u0009) this.TeammateSupportBar).\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void TeammateSupportBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.TeammateHP = ((\u0004\u0009) this.TeammateSupportBar).\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_10(object sender, EventArgs e)
  {
    this.RecuperateHPLabel.Text = ((\u0004\u0009) this.RecuperateHPBar).\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void RecuperateHPBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.RecuperateHP = ((\u0004\u0009) this.RecuperateHPBar).\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_11(object sender, EventArgs e)
  {
    this.HealthstoneHPLabel.Text = ((\u0004\u0009) this.HealthstoneHPBar).\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void HealthstoneHPBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.HealthstoneHP = ((\u0004\u0009) this.HealthstoneHPBar).\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_12(object sender, EventArgs e)
  {
    this.FeintHPLabel.Text = ((\u0004\u0009) this.FeintHPBar).\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void FeintHPBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.AutoFeint = ((\u0004\u0009) this.FeintHPBar).\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_13(object sender, EventArgs e)
  {
    this.FeintLastDamageLabel.Text = this.FeintLastDamageBar.\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void FeintLastDamageBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.FeintLastDamage = this.FeintLastDamageBar.\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_14(object sender, EventArgs e)
  {
    this.StickyDelayLabel.Text = $"{(double) this.StickyDelayBar.\u000F / 10.0:0.##}";
    VitalicForm.bool_0 = true;
  }

  private void StickyDelayBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.StickyDelay = (double) this.StickyDelayBar.\u000F / 10.0;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_15(object sender, EventArgs e)
  {
    this.MacroDelayLabel.Text = $"{(double) this.MacroDelayBar.\u000F / 10.0:0.##}";
    VitalicForm.bool_0 = true;
  }

  private void MacroDelayBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.MacroDelay = (double) this.MacroDelayBar.\u000F / 10.0;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_16(object sender, EventArgs e)
  {
    this.BurstPreparationLabel.Text = this.BurstPreparationBar.\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void BurstPreparationBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.BurstPreparation = this.BurstPreparationBar.\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_17(object sender, EventArgs e)
  {
    this.BurstHealthLabel.Text = ((\u0004\u0009) this.BurstHealthBar).\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void BurstHealthBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.BurstHealth = ((\u0004\u0009) this.BurstHealthBar).\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_18(object sender, EventArgs e)
  {
    this.KidneyShotEnergyLabel.Text = this.KidneyShotEnergyBar.\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void KidneyShotEnergyBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.KidneyShotEnergy = this.KidneyShotEnergyBar.\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_19(object sender, EventArgs e)
  {
    this.KidneyShotCPsLabel.Text = this.KidneyShotCPsBar.\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void KidneyShotCPsBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.KidneyShotCPs = this.KidneyShotCPsBar.\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_20(object sender, EventArgs e)
  {
    this.OpenerTPSLabel.Text = this.OpenerTPSBar.\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void OpenerTPSBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.OpenerTPS = this.OpenerTPSBar.\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_21(object sender, EventArgs e)
  {
    this.ShadowstepRangeLabel.Text = this.ShadowstepRangeBar.\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void ShadowstepRangeBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.AutoShadowstep = this.ShadowstepRangeBar.\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void method_22(object sender, EventArgs e)
  {
    this.ManualCastPauseLabel.Text = this.ManualCastPauseBar.\u000F.ToString();
    VitalicForm.bool_0 = true;
  }

  private void ManualCastPauseBar_MouseLeave(object sender, EventArgs e)
  {
    if (!VitalicForm.bool_0)
      return;
    VitalicSettings.Instance.ManualCastPause = this.ManualCastPauseBar.\u000F;
    this.method_24();
    VitalicForm.bool_0 = false;
  }

  private void AutoFocusComboBox_SelectedIndexChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoFocus = this.AutoFocusComboBox.SelectedIndex;
    this.method_24();
  }

  private void BurstStunDRComboBox_SelectedIndexChanged(object sender, EventArgs e)
  {
    Class145<double> selectedItem = this.BurstStunDRComboBox.SelectedItem as Class145<double>;
    VitalicSettings.Instance.BurstStunDR = selectedItem.Key;
    this.method_24();
  }

  private void SubterfugeOpenersComboBox_SelectedIndexChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.SubterfugeOpeners = this.SubterfugeOpenersComboBox.SelectedIndex;
    this.method_24();
  }

  private void CombatBurstComboBox_SelectedIndexChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.CombatBurst = this.CombatBurstComboBox.SelectedIndex;
    this.method_24();
  }

  private void AutoFocusTargetsComboBox_SelectedIndexChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoFocusTargets = this.AutoFocusTargetsComboBox.SelectedIndex;
    this.method_24();
  }

  private void EventBlacklist_Leave(object sender, EventArgs e)
  {
    if (string.IsNullOrEmpty(this.EventBlacklist.Text))
    {
      VitalicSettings.Instance.EventBlacklist = string.Empty;
      Class141.hashSet_0.Clear();
      this.method_24();
    }
    else
    {
      try
      {
        List<int> list = ((IEnumerable<string>) this.EventBlacklist.Text.Trim().Split(',')).Select<string, int>((Func<string, int>) (string_4 => int.Parse(string_4))).ToList<int>();
        List<int> intList = new List<int>();
        Class141.hashSet_0.Clear();
        foreach (int num in list)
        {
          if (!WoWSpell.op_Equality((WoWSpell) null, WoWSpell.FromId(num)))
          {
            if (!Class141.hashSet_0.Contains(num))
              Class141.hashSet_0.Add(num);
            intList.Add(num);
          }
        }
        VitalicSettings.Instance.EventBlacklist = string.Join<int>(", ", (IEnumerable<int>) intList.ToArray());
        this.method_24();
      }
      catch (Exception ex)
      {
        Class62.smethod_0((object) ("Invalid input provided for Event Blacklist: " + this.EventBlacklist.Text));
      }
    }
  }

  private void TricksTarget_Leave(object sender, EventArgs e)
  {
    if (!(VitalicSettings.Instance.TricksTarget != this.TricksTarget.Text))
      return;
    VitalicSettings.Instance.TricksTarget = this.TricksTarget.Text.Trim();
    this.method_24();
  }

  private void CapacitorToggle_CheckedChanged(object sender, EventArgs e)
  {
    this.CapacitorLabel.Text = this.CapacitorToggle.Checked ? "On" : "Off";
    if (this.CapacitorToggle.Checked)
      VitalicSettings.Instance.TotemStomp |= Totems.Capacitor;
    else
      VitalicSettings.Instance.TotemStomp &= ~Totems.Capacitor;
    this.method_24();
  }

  private void SpiritLinkToggle_CheckedChanged(object sender, EventArgs e)
  {
    this.SpiritLinkLabel.Text = this.SpiritLinkToggle.Checked ? "On" : "Off";
    if (this.SpiritLinkToggle.Checked)
      VitalicSettings.Instance.TotemStomp |= Totems.SpiritLink;
    else
      VitalicSettings.Instance.TotemStomp &= ~Totems.SpiritLink;
    this.method_24();
  }

  private void HealingStreamToggle_CheckedChanged(object sender, EventArgs e)
  {
    this.HealingStreamLabel.Text = this.HealingStreamToggle.Checked ? "On" : "Off";
    if (this.HealingStreamToggle.Checked)
      VitalicSettings.Instance.TotemStomp |= Totems.HealingStream;
    else
      VitalicSettings.Instance.TotemStomp &= ~Totems.HealingStream;
    this.method_24();
  }

  private void HealingTideToggle_CheckedChanged(object sender, EventArgs e)
  {
    this.HealingTideLabel.Text = this.HealingTideToggle.Checked ? "On" : "Off";
    if (this.HealingTideToggle.Checked)
      VitalicSettings.Instance.TotemStomp |= Totems.HealingTide;
    else
      VitalicSettings.Instance.TotemStomp &= ~Totems.HealingTide;
    this.method_24();
  }

  private void EarthgrabToggle_CheckedChanged(object sender, EventArgs e)
  {
    this.EarthgrabLabel.Text = this.EarthgrabToggle.Checked ? "On" : "Off";
    if (this.EarthgrabToggle.Checked)
      VitalicSettings.Instance.TotemStomp |= Totems.Earthgrab;
    else
      VitalicSettings.Instance.TotemStomp &= ~Totems.Earthgrab;
    this.method_24();
  }

  private void GroundingToggle_CheckedChanged(object sender, EventArgs e)
  {
    this.GroundingLabel.Text = this.GroundingToggle.Checked ? "On" : "Off";
    if (this.GroundingToggle.Checked)
      VitalicSettings.Instance.TotemStomp |= Totems.Grounding;
    else
      VitalicSettings.Instance.TotemStomp &= ~Totems.Grounding;
    this.method_24();
  }

  private void WindwalkToggle_CheckedChanged(object sender, EventArgs e)
  {
    this.WindwalkLabel.Text = this.WindwalkToggle.Checked ? "On" : "Off";
    if (this.WindwalkToggle.Checked)
      VitalicSettings.Instance.TotemStomp |= Totems.Windwalk;
    else
      VitalicSettings.Instance.TotemStomp &= ~Totems.Windwalk;
    this.method_24();
  }

  private void ShadowstepTrapsCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.ShadowstepTraps = this.ShadowstepTrapsCheckBox.Checked;
    this.method_24();
  }

  private void AutoMoveOnTrapsCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoMoveOnTraps = this.AutoMoveOnTrapsCheckBox.Checked;
    this.method_24();
  }

  private void FeintInMeleeRangeCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.FeintInMeleeRange = this.FeintInMeleeRangeCheckBox.Checked;
    this.method_24();
  }

  private void LazyPoolingCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.LazyPooling = this.LazyPoolingCheckBox.Checked;
    this.method_24();
  }

  private void AlwaysUseHemoCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AlwaysUseHemo = this.AlwaysUseHemoCheckBox.Checked;
    this.method_24();
  }

  private void RuptureOverGarroteCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.RuptureOverGarrote = this.RuptureOverGarroteCheckBox.Checked;
    this.method_24();
  }

  private void PvEModeCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.PveMode = this.PvEModeCheckBox.Checked;
    this.method_24();
    if (this.bool_1)
      return;
    Class136.smethod_5();
  }

  private void AcceptQueuesCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AcceptQueues = this.AcceptQueuesCheckBox.Checked;
    this.method_24();
  }

  private void AlertQueuesCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AlertQueues = this.AlertQueuesCheckBox.Checked;
    this.method_24();
  }

  private void AntiAFKCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AntiAFK = this.AntiAFKCheckBox.Checked;
    this.method_24();
  }

  private void ClickToMoveCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.DisableCTM = this.ClickToMoveCheckBox.Checked;
    this.method_24();
  }

  private void DiagnosticModeCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.DiagnosticMode = this.DiagnosticModeCheckBox.Checked;
    this.method_24();
  }

  private void AutoRedirectCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoRedirect = this.AutoRedirectCheckBox.Checked;
    this.method_24();
  }

  private void AutoKidneyCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoKidney = this.AutoKidneyCheckBox.Checked;
    this.method_24();
  }

  private void AutoPreparationCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoPreparation = this.AutoPreparationCheckBox.Checked;
    this.method_24();
  }

  private void AutoSmokeBombCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoSmokeBomb = this.AutoSmokeBombCheckBox.Checked;
    this.method_24();
  }

  private void AutoShroudCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoShroud = this.AutoShroudCheckBox.Checked;
    this.method_24();
  }

  private void AutoShivCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoShiv = this.AutoShivCheckBox.Checked;
    this.method_24();
  }

  private void AutoBurstOfSpeedCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoBurstOfSpeed = this.AutoBurstOfSpeedCheckBox.Checked;
    this.method_24();
  }

  private void AutoFlagReturnCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoFlagReturn = this.AutoFlagReturnCheckBox.Checked;
    this.method_24();
  }

  private void AlwaysStealthCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AlwaysStealth = this.AlwaysStealthCheckBox.Checked;
    this.method_24();
  }

  private void LazyEviscerateCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.LazyEviscerate = this.LazyEviscerateCheckBox.Checked;
    this.method_24();
  }

  private void AutoTargetCheckBox_CheckedChanged(object sender, EventArgs e)
  {
    VitalicSettings.Instance.AutoTarget = this.AutoTargetCheckBox.Checked;
    this.method_24();
  }

  private void method_23()
  {
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel52, "<p>Set the minimum stun requirements for burst cooldowns to be activated. <i>Full means the profile will only burst if the target can be put into a full stun, Half requires at least a half stun, Any will ignore stun DRs.</i></p>");
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel49, "<p>Number of seconds before burst cooldowns become available that the profile will begin preparing to burst. <i>During this time Kidney Shot will not be used and Slice and Dice/bleeds will be refreshed.</i></p><p><b>Default: 15</b></p>");
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel77, "<p>Adds a buffer to the Interrupt Delay value so that Shadowstep Kicks are performed slightly earlier, increase this value if you feel Shadowstep Kicks are going off too late.</p><p><b>Default: 0.2</b></p>");
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel51, "<p>Set the lowest enemy health at which burst cooldowns will be used. <i>Helps avoid wasting cooldowns on low HP targets.</i></p><p><b>Default: 30</b></p>");
  }

  private void VitalicForm_Load(object sender, EventArgs e)
  {
    this.\u0009 = this.method_35();
    this.Icon = this.method_34();
    this.\u0009(\u0005\u000B.\u0001, this.method_33("cursor.png"), 2, 4);
    this.\u0009(\u0005\u000B.\u0002, this.method_33("cursor_move.png"), 10, 2);
    this.\u0009(\u0005\u000B.\u0003, this.method_33("cursor_text.png"), 12, 12);
    this.\u0009(\u0005\u000B.\u0001);
    this.metroTabControl1.SelectedIndex = VitalicSettings.Instance.UILastTab;
    this.\u0017\u0007_0.\u0003 = (\u000C\u000B) VitalicSettings.Instance.UIColorStyle;
  }

  private void VitalicForm_FormClosing(object sender, FormClosingEventArgs e)
  {
    VitalicSettings.Instance.UIWidth = this.ClientSize.Width;
    VitalicSettings.Instance.UIHeight = this.ClientSize.Height;
    VitalicSettings.Instance.UILocationX = this.Location.X;
    VitalicSettings.Instance.UILocationY = this.Location.Y;
    VitalicSettings.Instance.Save();
  }

  protected void method_24()
  {
    if (this.bool_1)
      return;
    if (!this.SaveSettingsIcon.Visible)
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      VitalicForm.Class142 class142 = new VitalicForm.Class142();
      // ISSUE: reference to a compiler-generated field
      class142.vitalicForm_0 = this;
      this.SaveSettingsIcon.Visible = true;
      this.SaveSettingsIcon.\u000F = true;
      // ISSUE: reference to a compiler-generated field
      class142.timer_0 = new System.Windows.Forms.Timer();
      // ISSUE: reference to a compiler-generated field
      class142.timer_0.Interval = 2;
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated method
      class142.timer_0.Tick += new EventHandler(class142.method_0);
      // ISSUE: reference to a compiler-generated field
      class142.timer_0.Enabled = true;
      // ISSUE: reference to a compiler-generated field
      class142.timer_0.Start();
    }
    VitalicSettings.Instance.Save();
  }

  [DllImport("user32.dll", SetLastError = true)]
  [return: MarshalAs(UnmanagedType.Bool)]
  private static extern bool GetWindowRect(IntPtr intptr_0, ref VitalicForm.Struct25 struct25_0);

  private void method_25()
  {
    if (VitalicSettings.Instance.UILocationX != 0 && VitalicSettings.Instance.UILocationY != 0)
    {
      this.Location = new Point(VitalicSettings.Instance.UILocationX, VitalicSettings.Instance.UILocationY);
    }
    else
    {
      if (UISettings.Instance.MainWindowState == System.Windows.WindowState.Maximized)
      {
        this.CenterToScreen();
        return;
      }
      Process currentProcess = Process.GetCurrentProcess();
      if (currentProcess == null)
        return;
      IntPtr mainWindowHandle = currentProcess.MainWindowHandle;
      VitalicForm.Struct25 struct25_0 = new VitalicForm.Struct25();
      VitalicForm.GetWindowRect(mainWindowHandle, ref struct25_0);
      if (struct25_0.int_2 >= 0 && struct25_0.int_1 >= 0)
        this.Location = new Point(struct25_0.int_2 + 20, struct25_0.int_1);
      else
        this.CenterToScreen();
    }
    this.ClientSize = new Size(VitalicSettings.Instance.UIWidth, VitalicSettings.Instance.UIHeight);
  }

  private void method_26()
  {
    this.bool_1 = true;
    this.MainHandPoisonComboBox.Items.Add((object) new Class145<int>(0, "Default"));
    this.MainHandPoisonComboBox.Items.Add((object) new Class145<int>(8679, "Wound Poison"));
    this.MainHandPoisonComboBox.Items.Add((object) new Class145<int>(2823, "Deadly Poison"));
    this.method_27(this.MainHandPoisonComboBox, VitalicSettings.Instance.MainHandPoison);
    this.OffHandPoisonComboBox.Items.Add((object) new Class145<int>(0, "Default"));
    this.OffHandPoisonComboBox.Items.Add((object) new Class145<int>(5761, "Mind-Numbing Poison"));
    this.OffHandPoisonComboBox.Items.Add((object) new Class145<int>(3408, "Crippling Poison"));
    this.OffHandPoisonComboBox.Items.Add((object) new Class145<int>(108215, "Paralytic Poison"));
    this.OffHandPoisonComboBox.Items.Add((object) new Class145<int>(108211, "Leeching Poison"));
    this.method_27(this.OffHandPoisonComboBox, VitalicSettings.Instance.OffHandPoison);
    this.AutoRedirectCheckBox.Checked = VitalicSettings.Instance.AutoRedirect;
    this.AutoKidneyCheckBox.Checked = VitalicSettings.Instance.AutoKidney;
    this.AutoPreparationCheckBox.Checked = VitalicSettings.Instance.AutoPreparation;
    this.AutoSmokeBombCheckBox.Checked = VitalicSettings.Instance.AutoSmokeBomb;
    this.AutoShroudCheckBox.Checked = VitalicSettings.Instance.AutoShroud;
    this.AutoShivCheckBox.Checked = VitalicSettings.Instance.AutoShiv;
    this.AutoBurstOfSpeedCheckBox.Checked = VitalicSettings.Instance.AutoBurstOfSpeed;
    this.AutoFlagReturnCheckBox.Checked = VitalicSettings.Instance.AutoFlagReturn;
    this.AlwaysStealthCheckBox.Checked = VitalicSettings.Instance.AlwaysStealth;
    this.LazyEviscerateCheckBox.Checked = VitalicSettings.Instance.LazyEviscerate;
    this.AutoTargetCheckBox.Checked = VitalicSettings.Instance.AutoTarget;
    this.ShadowstepRangeBar.\u000F = VitalicSettings.Instance.AutoShadowstep;
    this.TricksTarget.Text = VitalicSettings.Instance.TricksTarget;
    this.EventBlacklist.Text = VitalicSettings.Instance.EventBlacklist;
    this.SpellAlertsCheckBox.Checked = VitalicSettings.Instance.SpellAlertsEnabled;
    this.LogMessagesCheckBox.Checked = VitalicSettings.Instance.LogMessagesEnabled;
    this.StatusFrameCheckBox.Checked = VitalicSettings.Instance.StatusFrameEnabled;
    this.AlertFontsCheckBox.Checked = VitalicSettings.Instance.AlertFontsEnabled;
    this.SoundAlertsCheckBox.Checked = VitalicSettings.Instance.SoundAlertsEnabled;
    this.MacrosEnabledCheckBox.Checked = VitalicSettings.Instance.MacrosEnabled;
    this.LowHealthWarningBar.\u000F = VitalicSettings.Instance.LowHealthWarning;
    this.MacroDelayBar.\u000F = (int) (VitalicSettings.Instance.MacroDelay * 10.0);
    this.StickyDelayBar.\u000F = (int) (VitalicSettings.Instance.StickyDelay * 10.0);
    this.PvEModeCheckBox.Checked = VitalicSettings.Instance.PveMode;
    this.AcceptQueuesCheckBox.Checked = VitalicSettings.Instance.AcceptQueues;
    this.AlertQueuesCheckBox.Checked = VitalicSettings.Instance.AlertQueues;
    this.AntiAFKCheckBox.Checked = VitalicSettings.Instance.AntiAFK;
    this.ClickToMoveCheckBox.Checked = VitalicSettings.Instance.DisableCTM;
    this.DiagnosticModeCheckBox.Checked = VitalicSettings.Instance.DiagnosticMode;
    this.AutoFocusComboBox.SelectedIndex = VitalicSettings.Instance.AutoFocus;
    this.AutoFocusTargetsComboBox.SelectedIndex = VitalicSettings.Instance.AutoFocusTargets;
    this.CapacitorToggle.Checked = (VitalicSettings.Instance.TotemStomp & Totems.Capacitor) != Totems.None;
    this.SpiritLinkToggle.Checked = (VitalicSettings.Instance.TotemStomp & Totems.SpiritLink) != Totems.None;
    this.HealingStreamToggle.Checked = (VitalicSettings.Instance.TotemStomp & Totems.HealingStream) != Totems.None;
    this.HealingTideToggle.Checked = (VitalicSettings.Instance.TotemStomp & Totems.HealingTide) != Totems.None;
    this.EarthgrabToggle.Checked = (VitalicSettings.Instance.TotemStomp & Totems.Earthgrab) != Totems.None;
    this.GroundingToggle.Checked = (VitalicSettings.Instance.TotemStomp & Totems.Grounding) != Totems.None;
    this.WindwalkToggle.Checked = (VitalicSettings.Instance.TotemStomp & Totems.Windwalk) != Totems.None;
    this.OpenerTPSBar.\u000F = VitalicSettings.Instance.OpenerTPS;
    this.ManualCastPauseBar.\u000F = VitalicSettings.Instance.ManualCastPause;
    this.TeammateSupportBar.\u000F = VitalicSettings.Instance.TeammateHP;
    this.RecuperateHPBar.\u000F = VitalicSettings.Instance.RecuperateHP;
    this.HealthstoneHPBar.\u000F = VitalicSettings.Instance.HealthstoneHP;
    this.InterruptDelayBar.\u000F = (int) (VitalicSettings.Instance.InterruptDelay * 100.0);
    this.InterruptMinimumBar.\u000F = (int) (VitalicSettings.Instance.InterruptMinimum * 100.0);
    this.ShadowstepBufferBar.\u000F = (int) (VitalicSettings.Instance.InterruptShadowstepBuffer * 100.0);
    this.GougeDelayBar.\u000F = (int) (VitalicSettings.Instance.GougeDelay * 100.0);
    this.GougeNoKickHPBar.\u000F = VitalicSettings.Instance.GougeNoKickHP;
    this.ShadowstepTrapsCheckBox.Checked = VitalicSettings.Instance.ShadowstepTraps;
    this.AutoMoveOnTrapsCheckBox.Checked = VitalicSettings.Instance.AutoMoveOnTraps;
    this.FeintHPBar.\u000F = VitalicSettings.Instance.AutoFeint;
    this.FeintLastDamageBar.\u000F = VitalicSettings.Instance.FeintLastDamage;
    this.FeintInMeleeRangeCheckBox.Checked = VitalicSettings.Instance.FeintInMeleeRange;
    this.BurstEnergyBar.\u000F = VitalicSettings.Instance.BurstEnergy;
    this.BurstEnergyOpenerBar.\u000F = VitalicSettings.Instance.BurstEnergyOpener;
    this.BurstPreparationBar.\u000F = VitalicSettings.Instance.BurstPreparation;
    this.BurstHealthBar.\u000F = VitalicSettings.Instance.BurstHealth;
    this.BurstStunDRComboBox.Items.Add((object) new Class145<double>(0.5, "Half"));
    this.BurstStunDRComboBox.Items.Add((object) new Class145<double>(1.0, "Full"));
    this.BurstStunDRComboBox.Items.Add((object) new Class145<double>(0.0, "Any"));
    this.method_28(this.BurstStunDRComboBox, VitalicSettings.Instance.BurstStunDR);
    this.SubterfugeOpenersComboBox.SelectedIndex = VitalicSettings.Instance.SubterfugeOpeners;
    this.CombatBurstComboBox.SelectedIndex = VitalicSettings.Instance.CombatBurst;
    this.KidneyShotEnergyBar.\u000F = VitalicSettings.Instance.KidneyShotEnergy;
    this.KidneyShotCPsBar.\u000F = VitalicSettings.Instance.KidneyShotCPs;
    this.HemoDelayBar.\u000F = (int) (VitalicSettings.Instance.HemoDelay * 10.0);
    this.LazyPoolingCheckBox.Checked = VitalicSettings.Instance.LazyPooling;
    this.AlwaysUseHemoCheckBox.Checked = VitalicSettings.Instance.AlwaysUseHemo;
    this.RuptureOverGarroteCheckBox.Checked = VitalicSettings.Instance.RuptureOverGarrote;
    this.bool_1 = false;
    VitalicForm.bool_0 = false;
  }

  private void method_27(\u0012\u0008 _param1, int int_0)
  {
    int num = 0;
    foreach (Class145<int> class145 in _param1.Items)
    {
      if (class145.Key == int_0)
        _param1.SelectedIndex = num;
      ++num;
    }
  }

  private void method_28(\u0012\u0008 _param1, double double_0)
  {
    int num = 0;
    foreach (Class145<double> class145 in _param1.Items)
    {
      if (class145.Key == double_0)
        _param1.SelectedIndex = num;
      ++num;
    }
  }

  private void method_29()
  {
    this.method_30(\u0001\u0007.\u0003);
    this.method_31(\u0001\u0007.\u0005);
    this.method_32(\u0001\u0007.\u0004);
  }

  private void method_30(string string_4) => this.UserName.Text = string_4 + "!";

  private void method_31(string string_4)
  {
    this.ChangeLog.Text = $"<style>ul {{margin-left:15px; font-family:consolas; font-size:9px;}} li {{ margin-bottom: 5px; }} h4 {{ margin: 5px 0 8px 0; font-family:consolas; }}</style>{string_4}";
  }

  private void method_32(string string_4)
  {
    this.RotationNotes.Text = $"<style>p {{ margin: 0; padding:0 5px 0 0; }} h3 {{ margin: 0 0 5px 0; }}</style>\r\n                <div style=\"font-family:segoe ui; font-size: 9px\">{string_4}</div>";
  }

  public bool Boolean_0
  {
    get => this.bool_3;
    set => this.bool_3 = value;
  }

  private Bitmap method_33(string string_4)
  {
    this.stream_0 = \u0020\u0006.\u0001(string_4);
    if (this.stream_0 != null)
      return new Bitmap(this.stream_0);
    string str = this.string_3 + string_4;
    return File.Exists(str) ? (Bitmap) Image.FromFile(str) : new Bitmap(0, 0);
  }

  private Icon method_34()
  {
    Bitmap thumbnailImage = (Bitmap) this.method_33("icon.png").GetThumbnailImage(64 /*0x40*/, 64 /*0x40*/, (Image.GetThumbnailImageAbort) null, IntPtr.Zero);
    thumbnailImage.MakeTransparent();
    return Icon.FromHandle(thumbnailImage.GetHicon());
  }

  private Image method_35() => (Image) this.method_33("title.png");

  private void metroTileSwitch_Click(object sender, EventArgs e)
  {
    int num = (int) (this.\u0017\u0007_0.\u0003 + 1);
    if (num > 13)
      num = 1;
    this.\u0017\u0007_0.\u0003 = (\u000C\u000B) num;
    VitalicSettings.Instance.UIColorStyle = (int) this.\u0017\u0007_0.\u0003;
    this.method_24();
  }

  private void method_36(object sender, EventArgs e)
  {
  }

  private void CheapShotKeyBindButton_MouseUp(object sender, MouseEventArgs e)
  {
    if (this.bool_2)
    {
      Keys keys_3 = this.method_40(this.\u0010\u0008_0, e);
      if (keys_3 == Keys.None)
        return;
      this.method_37(this.\u0010\u0008_0.Name, keys_3);
      this.\u0010\u0008_0.\u0010 = true;
      this.bool_2 = false;
    }
    else
    {
      if (e.Button != MouseButtons.Left)
        return;
      \u0010\u0008 obj = (\u0010\u0008) sender;
      obj.\u0010(true);
      obj.\u0010 = false;
      obj.Text = "Press key combination";
      this.bool_2 = true;
      this.\u0010\u0008_0 = obj;
    }
  }

  private void CheapShotKeyBindButton_Leave(object sender, EventArgs e)
  {
    if (!this.bool_2)
      return;
    this.\u0010\u0008_0.\u0010(false);
    this.\u0010\u0008_0.\u0010 = false;
    this.bool_2 = false;
    this.\u0010\u0008_0 = (\u0010\u0008) null;
    this.VitalicForm_Shown(sender, e);
  }

  private void CheapShotKeyBindButton_KeyDown(object sender, KeyEventArgs e)
  {
    this.method_38(e.KeyCode);
    if (!this.bool_2)
      return;
    Keys keys_3 = this.method_39(this.\u0010\u0008_0, e, VitalicForm.Enum17.const_1);
    switch (keys_3)
    {
      case Keys.None:
        return;
      case Keys.Escape:
        keys_3 = Keys.None;
        this.\u0010\u0008_0.\u0010 = false;
        break;
      default:
        this.\u0010\u0008_0.\u0010 = true;
        break;
    }
    this.method_37(this.\u0010\u0008_0.Name, keys_3);
    this.bool_2 = false;
  }

  private void CheapShotKeyBindButton_KeyUp(object sender, KeyEventArgs e)
  {
    if (!this.bool_2)
      return;
    Keys keys_3 = this.method_39(this.\u0010\u0008_0, e, VitalicForm.Enum17.const_0);
    switch (keys_3)
    {
      case Keys.None:
        return;
      case Keys.Escape:
        keys_3 = Keys.None;
        this.\u0010\u0008_0.\u0010 = false;
        break;
      default:
        this.\u0010\u0008_0.\u0010 = true;
        break;
    }
    this.method_37(this.\u0010\u0008_0.Name, keys_3);
    this.bool_2 = false;
  }

  private void method_37(string string_4, Keys keys_3)
  {
    switch (string_4)
    {
      case "GarroteKeyBindButton":
        VitalicSettings.Instance.GarroteKeyBind = keys_3;
        Class144.class81_0.Keys_0 = keys_3;
        break;
      case "CheapShotKeyBindButton":
        VitalicSettings.Instance.CheapShotKeyBind = keys_3;
        Class144.class81_1.Keys_0 = keys_3;
        break;
      case "BlindKeyBindButton":
        VitalicSettings.Instance.BlindKeyBind = keys_3;
        Class144.class80_0.Keys_0 = keys_3;
        break;
      case "GougeKeyBindButton":
        VitalicSettings.Instance.GougeKeyBind = keys_3;
        Class144.class81_2.Keys_0 = keys_3;
        break;
      case "RedirectKidneyKeyBindButton":
        VitalicSettings.Instance.RedirectKidneyKeyBind = keys_3;
        Class144.class81_3.Keys_0 = keys_3;
        break;
      case "FocusMacroKeyBindButton":
        VitalicSettings.Instance.FocusMacroKeyBind = keys_3;
        Class144.class82_0.Keys_0 = keys_3;
        break;
      case "OpenerModifierKeyBindButton":
        VitalicSettings.Instance.OpenerModifierKeyBind = keys_3;
        Class144.class80_3.Keys_0 = keys_3;
        break;
      case "BurstKeyBindButton":
        VitalicSettings.Instance.BurstKeyBind = keys_3;
        Class144.class80_4.Keys_0 = keys_3;
        break;
      case "BurstNoShadowBladesKeyBindButton":
        VitalicSettings.Instance.BurstNoShadowBladesKeyBind = keys_3;
        Class144.class80_6.Keys_0 = keys_3;
        break;
      case "LazyKeyBindButton":
        VitalicSettings.Instance.LazyKeyBind = keys_3;
        Class144.class80_5.Keys_0 = keys_3;
        break;
      case "PauseKeyBindButton":
        VitalicSettings.Instance.PauseKeyBind = keys_3;
        Class144.class80_8.Keys_0 = keys_3;
        break;
      case "PauseDamageKeyBindButton":
        VitalicSettings.Instance.PauseDamageKeyBind = keys_3;
        Class144.class80_9.Keys_0 = keys_3;
        break;
      case "EventsKeyBindButton":
        VitalicSettings.Instance.EventsKeyBind = keys_3;
        Class144.class80_7.Keys_0 = keys_3;
        break;
      case "RestealthKeyBindButton":
        VitalicSettings.Instance.RestealthKeyBind = keys_3;
        Class144.class80_10.Keys_0 = keys_3;
        break;
      case "FastKickKeyBindButton":
        VitalicSettings.Instance.FastKickKeyBind = keys_3;
        Class144.class80_11.Keys_0 = keys_3;
        break;
      case "SmokeBombKeyBindButton":
        VitalicSettings.Instance.SmokeBombKeyBind = keys_3;
        Class144.class80_2.Keys_0 = keys_3;
        break;
      case "KidneyShotKeyBindButton":
        VitalicSettings.Instance.KidneyShotKeyBind = keys_3;
        Class144.class80_1.Keys_0 = keys_3;
        break;
      case "AutoKidneyKeyBindButton":
        VitalicSettings.Instance.AutoKidneyKeyBind = keys_3;
        Class144.class80_12.Keys_0 = keys_3;
        break;
    }
    Class80.smethod_0();
    this.method_24();
  }

  [DllImport("user32.dll")]
  private static extern short GetAsyncKeyState(Keys keys_3);

  private void method_38(Keys keys_3)
  {
    switch (keys_3)
    {
      case Keys.ShiftKey:
        if (Convert.ToBoolean(VitalicForm.GetAsyncKeyState(Keys.LShiftKey)))
          this.keys_0 = Keys.LShiftKey;
        if (!Convert.ToBoolean(VitalicForm.GetAsyncKeyState(Keys.RShiftKey)))
          break;
        this.keys_0 = Keys.RShiftKey;
        break;
      case Keys.ControlKey:
        if (Convert.ToBoolean(VitalicForm.GetAsyncKeyState(Keys.LControlKey)))
          this.keys_1 = Keys.LControlKey;
        if (!Convert.ToBoolean(VitalicForm.GetAsyncKeyState(Keys.RControlKey)))
          break;
        this.keys_1 = Keys.RControlKey;
        break;
      case Keys.Menu:
        if (Convert.ToBoolean(VitalicForm.GetAsyncKeyState(Keys.LMenu)))
          this.keys_2 = Keys.LMenu;
        if (!Convert.ToBoolean(VitalicForm.GetAsyncKeyState(Keys.RMenu)))
          break;
        this.keys_2 = Keys.RMenu;
        break;
    }
  }

  private Keys method_39(
    \u0010\u0008 _param1,
    KeyEventArgs keyEventArgs_0,
    VitalicForm.Enum17 enum17_0)
  {
    Keys keys = keyEventArgs_0.KeyData;
    string str = (keyEventArgs_0.Shift ? "Shift " : "") + (keyEventArgs_0.Control ? "Ctrl " : "") + (keyEventArgs_0.Alt ? "Alt " : "");
    if (enum17_0 == VitalicForm.Enum17.const_1)
    {
      _param1.Text = str;
      if (keyEventArgs_0.KeyCode == Keys.ShiftKey || keyEventArgs_0.KeyCode == Keys.ControlKey || keyEventArgs_0.KeyCode == Keys.Menu)
        return Keys.None;
    }
    if (keyEventArgs_0.KeyCode >= Keys.D0 && keyEventArgs_0.KeyCode <= Keys.D9)
      str += (string) (object) (keyEventArgs_0.KeyValue - 48 /*0x30*/);
    else if (keyEventArgs_0.KeyCode == Keys.ShiftKey)
    {
      if (this.keys_0 == Keys.LShiftKey)
      {
        keys = keys & ~Keys.ShiftKey | this.keys_0;
        str += "Left Shift";
      }
      else if (this.keys_0 == Keys.RShiftKey)
      {
        keys = keys & ~Keys.ShiftKey | this.keys_0;
        str += "Right Shift";
      }
    }
    else if (keyEventArgs_0.KeyCode == Keys.ControlKey)
    {
      if (this.keys_1 == Keys.LControlKey)
      {
        keys = keys & ~Keys.ControlKey | this.keys_1;
        str += "Left Ctrl";
      }
      else if (this.keys_1 == Keys.RControlKey)
      {
        keys = keys & ~Keys.ControlKey | this.keys_1;
        str += "Right Ctrl";
      }
    }
    else if (keyEventArgs_0.KeyCode == Keys.Menu)
    {
      if (this.keys_2 == Keys.LMenu)
      {
        keys = keys & ~Keys.Menu | this.keys_2;
        str += "Left Alt";
      }
      else if (this.keys_2 == Keys.RMenu)
      {
        keys = keys & ~Keys.Menu | this.keys_2;
        str += "Right Alt";
      }
    }
    else
      str += keyEventArgs_0.KeyCode.ToString();
    if (keyEventArgs_0.KeyCode == Keys.Escape)
      str = "Click to set Keybind";
    _param1.Text = str;
    _param1.\u0010(false);
    return keys;
  }

  private Keys method_40(\u0010\u0008 _param1, MouseEventArgs mouseEventArgs_0)
  {
    string str = "";
    Keys keys = Keys.None;
    Keys modifierKeys = Control.ModifierKeys;
    if (modifierKeys != Keys.None)
    {
      bool flag1 = (modifierKeys & Keys.Shift) != Keys.None;
      bool flag2 = (modifierKeys & Keys.Control) != Keys.None;
      bool flag3 = (modifierKeys & Keys.Alt) != Keys.None;
      str = (flag1 ? "Shift " : "") + (flag2 ? "Ctrl " : "") + (flag3 ? "Alt " : "");
      keys ^= modifierKeys;
    }
    if (mouseEventArgs_0.Button == MouseButtons.Right)
    {
      keys ^= Keys.RButton;
      str += "Right Mouse";
    }
    if (mouseEventArgs_0.Button == MouseButtons.Left)
    {
      keys ^= Keys.LButton;
      str += "Left Mouse";
    }
    if (mouseEventArgs_0.Button == MouseButtons.Middle)
    {
      keys ^= Keys.MButton;
      str += "Middle Mouse";
    }
    if (mouseEventArgs_0.Button == MouseButtons.XButton1)
    {
      keys ^= Keys.XButton1;
      str += "Mouse 4";
    }
    if (mouseEventArgs_0.Button == MouseButtons.XButton2)
    {
      keys ^= Keys.XButton2;
      str += "Mouse 5";
    }
    _param1.Text = str;
    _param1.\u0010(false);
    return keys;
  }

  private IEnumerable<Control> method_41(Control control_0)
  {
    List<Control> controlList = new List<Control>();
    foreach (Control control in (ArrangedElementCollection) control_0.Controls)
    {
      controlList.AddRange(this.method_41(control));
      if (control is \u0001\u0009)
        controlList.Add(control);
    }
    return (IEnumerable<Control>) controlList;
  }

  private void method_42()
  {
    foreach (\u0001\u0009 obj in this.method_41((Control) this))
    {
      // ISSUE: object of a compiler-generated type is created
      // ISSUE: variable of a compiler-generated type
      VitalicForm.Class143 class143 = new VitalicForm.Class143();
      // ISSUE: reference to a compiler-generated field
      class143.vitalicForm_0 = this;
      // ISSUE: reference to a compiler-generated field
      class143.\u0001\u0009_0 = obj;
      // ISSUE: reference to a compiler-generated field
      class143.\u0001\u0009_0.MouseMove += (MouseEventHandler) ((sender, e) => this.\u0009(\u0005\u000B.\u0003));
      // ISSUE: reference to a compiler-generated field
      class143.\u0001\u0009_0.MouseEnter += (EventHandler) ((sender, e) => this.\u0009(\u0005\u000B.\u0003));
      // ISSUE: reference to a compiler-generated field
      // ISSUE: reference to a compiler-generated method
      class143.\u0001\u0009_0.MouseLeave += new EventHandler(class143.method_0);
    }
  }

  private void VitalicForm_Shown(object sender, EventArgs e)
  {
    this.GarroteKeyBindButton.Text = VitalicSettings.Instance.GarroteKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.GarroteKeyBind);
    if (VitalicSettings.Instance.GarroteKeyBind != Keys.None)
      this.GarroteKeyBindButton.\u0010 = true;
    this.CheapShotKeyBindButton.Text = VitalicSettings.Instance.CheapShotKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.CheapShotKeyBind);
    if (VitalicSettings.Instance.CheapShotKeyBind != Keys.None)
      this.CheapShotKeyBindButton.\u0010 = true;
    this.BlindKeyBindButton.Text = VitalicSettings.Instance.BlindKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.BlindKeyBind);
    if (VitalicSettings.Instance.BlindKeyBind != Keys.None)
      this.BlindKeyBindButton.\u0010 = true;
    this.GougeKeyBindButton.Text = VitalicSettings.Instance.GougeKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.GougeKeyBind);
    if (VitalicSettings.Instance.GougeKeyBind != Keys.None)
      this.GougeKeyBindButton.\u0010 = true;
    this.RedirectKidneyKeyBindButton.Text = VitalicSettings.Instance.RedirectKidneyKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.RedirectKidneyKeyBind);
    if (VitalicSettings.Instance.RedirectKidneyKeyBind != Keys.None)
      this.RedirectKidneyKeyBindButton.\u0010 = true;
    this.FocusMacroKeyBindButton.Text = VitalicSettings.Instance.FocusMacroKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.FocusMacroKeyBind);
    if (VitalicSettings.Instance.FocusMacroKeyBind != Keys.None)
      this.FocusMacroKeyBindButton.\u0010 = true;
    this.OpenerModifierKeyBindButton.Text = VitalicSettings.Instance.OpenerModifierKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.OpenerModifierKeyBind);
    if (VitalicSettings.Instance.OpenerModifierKeyBind != Keys.None)
      this.OpenerModifierKeyBindButton.\u0010 = true;
    this.BurstKeyBindButton.Text = VitalicSettings.Instance.BurstKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.BurstKeyBind);
    if (VitalicSettings.Instance.BurstKeyBind != Keys.None)
      this.BurstKeyBindButton.\u0010 = true;
    this.BurstNoShadowBladesKeyBindButton.Text = VitalicSettings.Instance.BurstNoShadowBladesKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.BurstNoShadowBladesKeyBind);
    if (VitalicSettings.Instance.BurstNoShadowBladesKeyBind != Keys.None)
      this.BurstNoShadowBladesKeyBindButton.\u0010 = true;
    this.LazyKeyBindButton.Text = VitalicSettings.Instance.LazyKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.LazyKeyBind);
    if (VitalicSettings.Instance.LazyKeyBind != Keys.None)
      this.LazyKeyBindButton.\u0010 = true;
    this.PauseKeyBindButton.Text = VitalicSettings.Instance.PauseKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.PauseKeyBind);
    if (VitalicSettings.Instance.PauseKeyBind != Keys.None)
      this.PauseKeyBindButton.\u0010 = true;
    this.PauseDamageKeyBindButton.Text = VitalicSettings.Instance.PauseDamageKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.PauseDamageKeyBind);
    if (VitalicSettings.Instance.PauseDamageKeyBind != Keys.None)
      this.PauseDamageKeyBindButton.\u0010 = true;
    this.EventsKeyBindButton.Text = VitalicSettings.Instance.EventsKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.EventsKeyBind);
    if (VitalicSettings.Instance.EventsKeyBind != Keys.None)
      this.EventsKeyBindButton.\u0010 = true;
    this.RestealthKeyBindButton.Text = VitalicSettings.Instance.RestealthKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.RestealthKeyBind);
    if (VitalicSettings.Instance.RestealthKeyBind != Keys.None)
      this.RestealthKeyBindButton.\u0010 = true;
    this.FastKickKeyBindButton.Text = VitalicSettings.Instance.FastKickKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.FastKickKeyBind);
    if (VitalicSettings.Instance.FastKickKeyBind != Keys.None)
      this.FastKickKeyBindButton.\u0010 = true;
    this.SmokeBombKeyBindButton.Text = VitalicSettings.Instance.SmokeBombKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.SmokeBombKeyBind);
    if (VitalicSettings.Instance.SmokeBombKeyBind != Keys.None)
      this.SmokeBombKeyBindButton.\u0010 = true;
    this.KidneyShotKeyBindButton.Text = VitalicSettings.Instance.KidneyShotKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.KidneyShotKeyBind);
    if (VitalicSettings.Instance.KidneyShotKeyBind != Keys.None)
      this.KidneyShotKeyBindButton.\u0010 = true;
    this.AutoKidneyKeyBindButton.Text = VitalicSettings.Instance.AutoKidneyKeyBind == Keys.None ? "Click to set Keybind" : Class80.smethod_6(VitalicSettings.Instance.AutoKidneyKeyBind);
    if (VitalicSettings.Instance.AutoKidneyKeyBind == Keys.None)
      return;
    this.AutoKidneyKeyBindButton.\u0010 = true;
  }

  protected override void Dispose(bool disposing)
  {
    if (disposing && this.icontainer_0 != null)
      this.icontainer_0.Dispose();
    this.bool_3 = true;
    base.Dispose(disposing);
  }

  private void InitializeComponent()
  {
    this.icontainer_0 = (IContainer) new System.ComponentModel.Container();
    \u000C\u0008 obj = new \u000C\u0008();
    this.metroTabControl1 = new \u001E\u0008();
    this.tabPageInformation = new \u001F\u0008();
    this.UserName = new \u0015\u0008();
    this.metroLabel41 = new \u0015\u0008();
    this.groupBox2 = new Class146();
    this.RotationNotes = new \u001E\u0009();
    this.groupBox1 = new Class146();
    this.ChangeLog = new \u001E\u0009();
    this.tabPageUtilities = new \u001F\u0008();
    this.metroPanel9 = new \u0017\u0008();
    this.ManualCastPauseLabel = new \u0015\u0008();
    this.metroLabel10 = new \u0015\u0008();
    this.ManualCastPauseBar = new \u0004\u0009();
    this.OpenerTPSLabel = new \u0015\u0008();
    this.metroLabel62 = new \u0015\u0008();
    this.OpenerTPSBar = new \u0004\u0009();
    this.metroPanel8 = new \u0017\u0008();
    this.metroLabel12 = new \u0015\u0008();
    this.WindwalkLabel = new \u0015\u0008();
    this.WindwalkToggle = new \u0003\u0009();
    this.AutoFocusComboBox = new \u0012\u0008();
    this.metroLabel17 = new \u0015\u0008();
    this.CapacitorToggle = new \u0003\u0009();
    this.AutoFocusTargetsComboBox = new \u0012\u0008();
    this.metroLabel19 = new \u0015\u0008();
    this.metroLabel15 = new \u0015\u0008();
    this.CapacitorLabel = new \u0015\u0008();
    this.GroundingLabel = new \u0015\u0008();
    this.metroLabel3 = new \u0015\u0008();
    this.GroundingToggle = new \u0003\u0009();
    this.SpiritLinkToggle = new \u0003\u0009();
    this.metroLabel44 = new \u0015\u0008();
    this.SpiritLinkLabel = new \u0015\u0008();
    this.EarthgrabLabel = new \u0015\u0008();
    this.metroLabel6 = new \u0015\u0008();
    this.EarthgrabToggle = new \u0003\u0009();
    this.HealingStreamToggle = new \u0003\u0009();
    this.metroLabel13 = new \u0015\u0008();
    this.HealingStreamLabel = new \u0015\u0008();
    this.HealingTideLabel = new \u0015\u0008();
    this.metroLabel11 = new \u0015\u0008();
    this.HealingTideToggle = new \u0003\u0009();
    this.metroPanel7 = new \u0017\u0008();
    this.DiagnosticModeCheckBox = new \u0011\u0008();
    this.PvEModeCheckBox = new \u0011\u0008();
    this.metroLabel18 = new \u0015\u0008();
    this.AcceptQueuesCheckBox = new \u0011\u0008();
    this.ClickToMoveCheckBox = new \u0011\u0008();
    this.AlertQueuesCheckBox = new \u0011\u0008();
    this.AntiAFKCheckBox = new \u0011\u0008();
    this.tabPageInterface = new \u001F\u0008();
    this.metroPanel6 = new \u0017\u0008();
    this.metroLabel2 = new \u0015\u0008();
    this.metroTileSwitch = new \u0002\u0009();
    this.metroPanel5 = new \u0017\u0008();
    this.StickyDelayLabel = new \u0015\u0008();
    this.metroLabel73 = new \u0015\u0008();
    this.StickyDelayBar = new \u0004\u0009();
    this.MacroDelayLabel = new \u0015\u0008();
    this.metroLabel71 = new \u0015\u0008();
    this.MacroDelayBar = new \u0004\u0009();
    this.LowHealthWarningBar = new \u0005\u0009();
    this.metroLabel39 = new \u0015\u0008();
    this.LowHealthWarningLabel = new \u0015\u0008();
    this.metroPanel4 = new \u0017\u0008();
    this.StatusFrameCheckBox = new \u0011\u0008();
    this.metroLabel16 = new \u0015\u0008();
    this.MacrosEnabledCheckBox = new \u0011\u0008();
    this.SpellAlertsCheckBox = new \u0011\u0008();
    this.SoundAlertsCheckBox = new \u0011\u0008();
    this.LogMessagesCheckBox = new \u0011\u0008();
    this.AlertFontsCheckBox = new \u0011\u0008();
    this.tabPageOffensive = new \u001F\u0008();
    this.metroPanel3 = new \u0017\u0008();
    this.LazyEviscerateCheckBox = new \u0011\u0008();
    this.RuptureOverGarroteCheckBox = new \u0011\u0008();
    this.AlwaysUseHemoCheckBox = new \u0011\u0008();
    this.metroLabel47 = new \u0015\u0008();
    this.LazyPoolingCheckBox = new \u0011\u0008();
    this.metroPanel2 = new \u0017\u0008();
    this.HemoDelayLabel = new \u0015\u0008();
    this.metroLabel55 = new \u0015\u0008();
    this.HemoDelayBar = new \u0004\u0009();
    this.KidneyShotCPsLabel = new \u0015\u0008();
    this.metroLabel57 = new \u0015\u0008();
    this.KidneyShotCPsBar = new \u0004\u0009();
    this.KidneyShotEnergyLabel = new \u0015\u0008();
    this.metroLabel59 = new \u0015\u0008();
    this.KidneyShotEnergyBar = new \u0004\u0009();
    this.metroLabel53 = new \u0015\u0008();
    this.CombatBurstComboBox = new \u0012\u0008();
    this.metroLabel46 = new \u0015\u0008();
    this.SubterfugeOpenersComboBox = new \u0012\u0008();
    this.metroPanel1 = new \u0017\u0008();
    this.BurstHealthLabel = new \u0015\u0008();
    this.metroLabel52 = new \u0015\u0008();
    this.BurstStunDRComboBox = new \u0012\u0008();
    this.metroLabel51 = new \u0015\u0008();
    this.BurstHealthBar = new \u0005\u0009();
    this.BurstPreparationLabel = new \u0015\u0008();
    this.metroLabel49 = new \u0015\u0008();
    this.BurstPreparationBar = new \u0004\u0009();
    this.BurstEnergyBar = new \u0004\u0009();
    this.BurstEnergyOpenerLabel = new \u0015\u0008();
    this.metroLabel5 = new \u0015\u0008();
    this.metroLabel40 = new \u0015\u0008();
    this.BurstEnergyLabel = new \u0015\u0008();
    this.BurstEnergyOpenerBar = new \u0004\u0009();
    this.metroLabel4 = new \u0015\u0008();
    this.tabPageAutomation = new \u001F\u0008();
    this.metroPanel13 = new \u0017\u0008();
    this.AutoTargetCheckBox = new \u0011\u0008();
    this.AutoBurstOfSpeedCheckBox = new \u0011\u0008();
    this.AlwaysStealthCheckBox = new \u0011\u0008();
    this.AutoShivCheckBox = new \u0011\u0008();
    this.AutoFlagReturnCheckBox = new \u0011\u0008();
    this.AutoRedirectCheckBox = new \u0011\u0008();
    this.metroLabel74 = new \u0015\u0008();
    this.AutoKidneyCheckBox = new \u0011\u0008();
    this.AutoShroudCheckBox = new \u0011\u0008();
    this.AutoPreparationCheckBox = new \u0011\u0008();
    this.AutoSmokeBombCheckBox = new \u0011\u0008();
    this.metroPanel14 = new \u0017\u0008();
    this.nonFlickerGroupBox1 = new Class146();
    this.OffHandPoisonComboBox = new \u0012\u0008();
    this.metroLabel26 = new \u0015\u0008();
    this.metroLabel27 = new \u0015\u0008();
    this.MainHandPoisonComboBox = new \u0012\u0008();
    this.ShadowstepRangeLabel = new \u0015\u0008();
    this.metroLabel1 = new \u0015\u0008();
    this.ShadowstepRangeBar = new \u0004\u0009();
    this.metroPanel15 = new \u0017\u0008();
    this.TricksTarget = new \u0001\u0009();
    this.metroLabel7 = new \u0015\u0008();
    this.EventBlacklist = new \u0001\u0009();
    this.metroLabel25 = new \u0015\u0008();
    this.tabPageDefensive = new \u001F\u0008();
    this.metroPanel12 = new \u0017\u0008();
    this.metroLabel86 = new \u0015\u0008();
    this.AutoMoveOnTrapsCheckBox = new \u0011\u0008();
    this.metroLabel65 = new \u0015\u0008();
    this.ShadowstepTrapsCheckBox = new \u0011\u0008();
    this.metroLabel69 = new \u0015\u0008();
    this.FeintHPBar = new \u0005\u0009();
    this.FeintHPLabel = new \u0015\u0008();
    this.FeintInMeleeRangeCheckBox = new \u0011\u0008();
    this.FeintLastDamageBar = new \u0004\u0009();
    this.metroLabel67 = new \u0015\u0008();
    this.FeintLastDamageLabel = new \u0015\u0008();
    this.metroPanel11 = new \u0017\u0008();
    this.ShadowstepBufferLabel = new \u0015\u0008();
    this.GougeNoKickHPLabel = new \u0015\u0008();
    this.metroLabel77 = new \u0015\u0008();
    this.metroLabel83 = new \u0015\u0008();
    this.ShadowstepBufferBar = new \u0004\u0009();
    this.GougeNoKickHPBar = new \u0005\u0009();
    this.InterruptMinimumLabel = new \u0015\u0008();
    this.GougeDelayLabel = new \u0015\u0008();
    this.metroLabel79 = new \u0015\u0008();
    this.metroLabel85 = new \u0015\u0008();
    this.InterruptMinimumBar = new \u0004\u0009();
    this.GougeDelayBar = new \u0004\u0009();
    this.InterruptDelayLabel = new \u0015\u0008();
    this.metroLabel75 = new \u0015\u0008();
    this.metroLabel81 = new \u0015\u0008();
    this.InterruptDelayBar = new \u0004\u0009();
    this.metroPanel10 = new \u0017\u0008();
    this.HealthstoneHPLabel = new \u0015\u0008();
    this.metroLabel64 = new \u0015\u0008();
    this.HealthstoneHPBar = new \u0005\u0009();
    this.RecuperateHPLabel = new \u0015\u0008();
    this.metroLabel9 = new \u0015\u0008();
    this.RecuperateHPBar = new \u0005\u0009();
    this.TeammateSupportLabel = new \u0015\u0008();
    this.metroLabel61 = new \u0015\u0008();
    this.TeammateSupportBar = new \u0005\u0009();
    this.tabPageKeybinds = new \u001F\u0008();
    this.KeyBindPanel3 = new \u0017\u0008();
    this.FastKickKeyBindButton = new \u0010\u0008();
    this.metroLabel37 = new \u0015\u0008();
    this.RestealthKeyBindButton = new \u0010\u0008();
    this.metroLabel36 = new \u0015\u0008();
    this.SmokeBombKeyBindButton = new \u0010\u0008();
    this.metroLabel35 = new \u0015\u0008();
    this.KidneyShotKeyBindButton = new \u0010\u0008();
    this.metroLabel34 = new \u0015\u0008();
    this.RedirectKidneyKeyBindButton = new \u0010\u0008();
    this.metroLabel32 = new \u0015\u0008();
    this.GougeKeyBindButton = new \u0010\u0008();
    this.metroLabel31 = new \u0015\u0008();
    this.BlindKeyBindButton = new \u0010\u0008();
    this.metroLabel24 = new \u0015\u0008();
    this.KeyBindPanel2 = new \u0017\u0008();
    this.AutoKidneyKeyBindButton = new \u0010\u0008();
    this.metroLabel8 = new \u0015\u0008();
    this.EventsKeyBindButton = new \u0010\u0008();
    this.metroLabel38 = new \u0015\u0008();
    this.BurstNoShadowBladesKeyBindButton = new \u0010\u0008();
    this.metroLabel33 = new \u0015\u0008();
    this.PauseDamageKeyBindButton = new \u0010\u0008();
    this.PauseKeyBindButton = new \u0010\u0008();
    this.metroLabel29 = new \u0015\u0008();
    this.metroLabel28 = new \u0015\u0008();
    this.BurstKeyBindButton = new \u0010\u0008();
    this.metroLabel22 = new \u0015\u0008();
    this.LazyKeyBindButton = new \u0010\u0008();
    this.metroLabel23 = new \u0015\u0008();
    this.KeyBindPanel1 = new \u0017\u0008();
    this.metroLabel14 = new \u0015\u0008();
    this.OpenerModifierKeyBindButton = new \u0010\u0008();
    this.metroLabel30 = new \u0015\u0008();
    this.FocusMacroKeyBindButton = new \u0010\u0008();
    this.GarroteKeyBindButton = new \u0010\u0008();
    this.metroLabel20 = new \u0015\u0008();
    this.metroLabel21 = new \u0015\u0008();
    this.CheapShotKeyBindButton = new \u0010\u0008();
    this.\u0017\u0007_0 = new \u0017\u0007(this.icontainer_0);
    this.\u0008\u0008_0 = new \u0008\u0008();
    this.SaveSettingsIcon = new \u0019\u0008();
    this.\u0016\u0007_0 = new \u0016\u0007(this.icontainer_0);
    this.metroTabControl1.SuspendLayout();
    this.tabPageInformation.SuspendLayout();
    this.groupBox2.SuspendLayout();
    this.groupBox1.SuspendLayout();
    this.tabPageUtilities.SuspendLayout();
    this.metroPanel9.SuspendLayout();
    this.metroPanel8.SuspendLayout();
    this.metroPanel7.SuspendLayout();
    this.tabPageInterface.SuspendLayout();
    this.metroPanel6.SuspendLayout();
    this.metroPanel5.SuspendLayout();
    this.metroPanel4.SuspendLayout();
    this.tabPageOffensive.SuspendLayout();
    this.metroPanel3.SuspendLayout();
    this.metroPanel2.SuspendLayout();
    this.metroPanel1.SuspendLayout();
    this.tabPageAutomation.SuspendLayout();
    this.metroPanel13.SuspendLayout();
    this.metroPanel14.SuspendLayout();
    this.nonFlickerGroupBox1.SuspendLayout();
    this.metroPanel15.SuspendLayout();
    this.tabPageDefensive.SuspendLayout();
    this.metroPanel12.SuspendLayout();
    this.metroPanel11.SuspendLayout();
    this.metroPanel10.SuspendLayout();
    this.tabPageKeybinds.SuspendLayout();
    this.KeyBindPanel3.SuspendLayout();
    this.KeyBindPanel2.SuspendLayout();
    this.KeyBindPanel1.SuspendLayout();
    ((ISupportInitialize) this.\u0017\u0007_0).BeginInit();
    this.SuspendLayout();
    this.metroTabControl1.Controls.Add((Control) this.tabPageInformation);
    this.metroTabControl1.Controls.Add((Control) this.tabPageInterface);
    this.metroTabControl1.Controls.Add((Control) this.tabPageOffensive);
    this.metroTabControl1.Controls.Add((Control) this.tabPageAutomation);
    this.metroTabControl1.Controls.Add((Control) this.tabPageDefensive);
    this.metroTabControl1.Controls.Add((Control) this.tabPageUtilities);
    this.metroTabControl1.Controls.Add((Control) this.tabPageKeybinds);
    this.metroTabControl1.Dock = DockStyle.Fill;
    this.metroTabControl1.Location = new Point(20, 60);
    this.metroTabControl1.Name = "metroTabControl1";
    this.metroTabControl1.SelectedIndex = 0;
    this.metroTabControl1.Size = new Size(572, 345);
    this.metroTabControl1.TabIndex = 0;
    this.\u0008\u0008_0.\u0001((Control) this.metroTabControl1, "");
    this.metroTabControl1.\u000A = true;
    this.metroTabControl1.Selected += new TabControlEventHandler(this.metroTabControl1_Selected);
    this.tabPageInformation.Controls.Add((Control) this.UserName);
    this.tabPageInformation.Controls.Add((Control) this.metroLabel41);
    this.tabPageInformation.Controls.Add((Control) this.groupBox2);
    this.tabPageInformation.Controls.Add((Control) this.groupBox1);
    this.tabPageInformation.\u000F = true;
    this.tabPageInformation.\u0010 = true;
    this.tabPageInformation.\u0011 = false;
    this.tabPageInformation.\u000F = 10;
    this.tabPageInformation.Location = new Point(4, 38);
    this.tabPageInformation.Name = "tabPageInformation";
    this.tabPageInformation.Size = new Size(564, 303);
    this.tabPageInformation.TabIndex = 4;
    this.tabPageInformation.Text = "Information";
    this.\u0008\u0008_0.\u0001((Control) this.tabPageInformation, "");
    this.tabPageInformation.\u0012 = true;
    this.tabPageInformation.\u0013 = false;
    this.tabPageInformation.\u0014 = false;
    this.tabPageInformation.\u0010 = 0;
    this.UserName.AutoSize = true;
    this.UserName.\u000F = \u000F\u000B.\u0003;
    this.UserName.\u000F = \u0010\u000B.\u0003;
    this.UserName.Location = new Point(75, 8);
    this.UserName.Name = "UserName";
    this.UserName.Size = new Size(71, 25);
    this.UserName.TabIndex = 1;
    this.UserName.Text = "Vitalic!";
    this.\u0008\u0008_0.\u0001((Control) this.UserName, "");
    this.metroLabel41.AutoSize = true;
    this.metroLabel41.\u000F = \u000F\u000B.\u0003;
    this.metroLabel41.Location = new Point(-4, 8);
    this.metroLabel41.Name = "metroLabel41";
    this.metroLabel41.Size = new Size(91, 25);
    this.metroLabel41.TabIndex = 0;
    this.metroLabel41.Text = "Welcome, ";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel41, "");
    this.\u0016\u0007_0.\u0005((Control) this.groupBox2, true);
    this.groupBox2.BackColor = System.Drawing.SystemColors.Window;
    this.groupBox2.Controls.Add((Control) this.RotationNotes);
    this.groupBox2.Font = new Font("Segoe UI Light", 8.25f, System.Drawing.FontStyle.Italic, GraphicsUnit.Point, (byte) 0);
    this.groupBox2.Location = new Point(0, 40);
    this.groupBox2.Name = "groupBox2";
    this.groupBox2.Size = new Size(286, 263);
    this.groupBox2.TabIndex = 11;
    this.groupBox2.TabStop = false;
    this.groupBox2.Text = "Rotation notes";
    this.\u0008\u0008_0.\u0001((Control) this.groupBox2, "");
    this.RotationNotes.AutoScroll = true;
    this.RotationNotes.AutoScrollMinSize = new Size(253, 36);
    this.RotationNotes.BackColor = System.Drawing.SystemColors.Window;
    this.RotationNotes.Location = new Point(10, 18);
    this.RotationNotes.Margin = new Padding(0);
    this.RotationNotes.Name = "RotationNotes";
    this.RotationNotes.Size = new Size(270, 233);
    this.RotationNotes.TabIndex = 2;
    this.RotationNotes.Text = "Toggle Focus: Left Shift (allows macros to be casted at your focus target)";
    this.\u0008\u0008_0.\u0001((Control) this.RotationNotes, "");
    this.\u0016\u0007_0.\u0005((Control) this.groupBox1, true);
    this.groupBox1.BackColor = System.Drawing.SystemColors.Window;
    this.groupBox1.Controls.Add((Control) this.ChangeLog);
    this.groupBox1.Font = new Font("Segoe UI Light", 8.25f, System.Drawing.FontStyle.Italic, GraphicsUnit.Point, (byte) 0);
    this.groupBox1.Location = new Point(292, 8);
    this.groupBox1.Name = "groupBox1";
    this.groupBox1.Size = new Size(272, 295);
    this.groupBox1.TabIndex = 9;
    this.groupBox1.TabStop = false;
    this.groupBox1.Text = "Recent changes";
    this.\u0008\u0008_0.\u0001((Control) this.groupBox1, "");
    this.ChangeLog.AutoScroll = true;
    this.ChangeLog.AutoScrollMinSize = new Size(239, 36);
    this.ChangeLog.BackColor = System.Drawing.SystemColors.Window;
    this.ChangeLog.Location = new Point(14, 14);
    this.ChangeLog.Margin = new Padding(0);
    this.ChangeLog.Name = "ChangeLog";
    this.ChangeLog.Size = new Size(256 /*0x0100*/, 264);
    this.ChangeLog.TabIndex = 3;
    this.ChangeLog.Text = "Toggle Focus: Left Shift (allows macros to be casted at your focus target)";
    this.\u0008\u0008_0.\u0001((Control) this.ChangeLog, "");
    this.tabPageUtilities.Controls.Add((Control) this.metroPanel9);
    this.tabPageUtilities.Controls.Add((Control) this.metroPanel8);
    this.tabPageUtilities.Controls.Add((Control) this.metroPanel7);
    this.tabPageUtilities.\u0010 = true;
    this.tabPageUtilities.\u0011 = false;
    this.tabPageUtilities.\u000F = 10;
    this.tabPageUtilities.Location = new Point(4, 38);
    this.tabPageUtilities.Name = "tabPageUtilities";
    this.tabPageUtilities.Padding = new Padding(25);
    this.tabPageUtilities.Size = new Size(564, 303);
    this.tabPageUtilities.TabIndex = 1;
    this.tabPageUtilities.Text = "Utilities";
    this.\u0008\u0008_0.\u0001((Control) this.tabPageUtilities, "");
    this.tabPageUtilities.\u0013 = true;
    this.tabPageUtilities.\u0014 = false;
    this.tabPageUtilities.\u0010 = 10;
    this.tabPageUtilities.Visible = false;
    this.metroPanel9.Controls.Add((Control) this.ManualCastPauseLabel);
    this.metroPanel9.Controls.Add((Control) this.metroLabel10);
    this.metroPanel9.Controls.Add((Control) this.ManualCastPauseBar);
    this.metroPanel9.Controls.Add((Control) this.OpenerTPSLabel);
    this.metroPanel9.Controls.Add((Control) this.metroLabel62);
    this.metroPanel9.Controls.Add((Control) this.OpenerTPSBar);
    this.metroPanel9.\u0011 = true;
    this.metroPanel9.\u0012 = false;
    this.metroPanel9.\u000F = 10;
    this.metroPanel9.Location = new Point(382, 9);
    this.metroPanel9.Name = "metroPanel9";
    this.metroPanel9.Size = new Size(194, 284);
    this.metroPanel9.TabIndex = 36;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel9, "");
    this.metroPanel9.\u0014 = true;
    this.metroPanel9.\u0015 = false;
    this.metroPanel9.\u0010 = 10;
    this.ManualCastPauseLabel.AutoSize = true;
    this.ManualCastPauseLabel.Location = new Point(158, 76);
    this.ManualCastPauseLabel.Name = "ManualCastPauseLabel";
    this.ManualCastPauseLabel.Size = new Size(28, 19);
    this.ManualCastPauseLabel.TabIndex = 40;
    this.ManualCastPauseLabel.Text = "100";
    this.\u0008\u0008_0.\u0001((Control) this.ManualCastPauseLabel, "");
    this.metroLabel10.AutoSize = true;
    this.metroLabel10.Location = new Point(12, 54);
    this.metroLabel10.Name = "metroLabel10";
    this.metroLabel10.Size = new Size(118, 19);
    this.metroLabel10.TabIndex = 39;
    this.metroLabel10.Text = "Manual Cast Pause";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel10, "<p>Set a time (in milliseconds) that the rotation will be paused after a manual cast is detected. <i>Allows you to override the rotation.</i></p><p><b>Default: 100 ms</b></p>");
    this.ManualCastPauseBar.BackColor = Color.Transparent;
    this.ManualCastPauseBar.\u0013 = 10;
    this.ManualCastPauseBar.Location = new Point(15, 76);
    this.ManualCastPauseBar.\u0011 = 500;
    this.ManualCastPauseBar.\u0014 = 50;
    this.ManualCastPauseBar.Name = "ManualCastPauseBar";
    this.ManualCastPauseBar.Size = new Size(139, 23);
    this.ManualCastPauseBar.\u0012 = 10;
    this.ManualCastPauseBar.TabIndex = 38;
    this.ManualCastPauseBar.Text = "ManualCastPauseBar";
    this.\u0008\u0008_0.\u0001((Control) this.ManualCastPauseBar, "");
    this.ManualCastPauseBar.\u000F = 100;
    this.ManualCastPauseBar.\u000F += new EventHandler(this.method_22);
    this.ManualCastPauseBar.MouseLeave += new EventHandler(this.ManualCastPauseBar_MouseLeave);
    this.OpenerTPSLabel.AutoSize = true;
    this.OpenerTPSLabel.Location = new Point(159, 30);
    this.OpenerTPSLabel.Name = "OpenerTPSLabel";
    this.OpenerTPSLabel.Size = new Size(23, 19);
    this.OpenerTPSLabel.TabIndex = 37;
    this.OpenerTPSLabel.Text = "90";
    this.\u0008\u0008_0.\u0001((Control) this.OpenerTPSLabel, "");
    this.metroLabel62.AutoSize = true;
    this.metroLabel62.Location = new Point(11, 6);
    this.metroLabel62.Name = "metroLabel62";
    this.metroLabel62.Size = new Size(80 /*0x50*/, 19);
    this.metroLabel62.TabIndex = 36;
    this.metroLabel62.Text = "Opener TPS";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel62, "<p>Set a dynamic Ticks Per Second value used when opening on a target. <i>Can be useful to make opener abilities more responsive.</i></p><p><b>Default: 30</b></p>");
    this.OpenerTPSBar.BackColor = Color.Transparent;
    this.OpenerTPSBar.Location = new Point(14, 28);
    this.OpenerTPSBar.\u0011 = 90;
    this.OpenerTPSBar.\u0014 = 90;
    this.OpenerTPSBar.Name = "OpenerTPSBar";
    this.OpenerTPSBar.Size = new Size(139, 23);
    this.OpenerTPSBar.TabIndex = 35;
    this.OpenerTPSBar.Text = "metroTrackBar3";
    this.\u0008\u0008_0.\u0001((Control) this.OpenerTPSBar, "");
    this.OpenerTPSBar.\u000F = 30;
    this.OpenerTPSBar.\u000F += new EventHandler(this.method_20);
    this.OpenerTPSBar.MouseLeave += new EventHandler(this.OpenerTPSBar_MouseLeave);
    this.metroPanel8.Controls.Add((Control) this.metroLabel12);
    this.metroPanel8.Controls.Add((Control) this.WindwalkLabel);
    this.metroPanel8.Controls.Add((Control) this.WindwalkToggle);
    this.metroPanel8.Controls.Add((Control) this.AutoFocusComboBox);
    this.metroPanel8.Controls.Add((Control) this.metroLabel17);
    this.metroPanel8.Controls.Add((Control) this.CapacitorToggle);
    this.metroPanel8.Controls.Add((Control) this.AutoFocusTargetsComboBox);
    this.metroPanel8.Controls.Add((Control) this.metroLabel19);
    this.metroPanel8.Controls.Add((Control) this.metroLabel15);
    this.metroPanel8.Controls.Add((Control) this.CapacitorLabel);
    this.metroPanel8.Controls.Add((Control) this.GroundingLabel);
    this.metroPanel8.Controls.Add((Control) this.metroLabel3);
    this.metroPanel8.Controls.Add((Control) this.GroundingToggle);
    this.metroPanel8.Controls.Add((Control) this.SpiritLinkToggle);
    this.metroPanel8.Controls.Add((Control) this.metroLabel44);
    this.metroPanel8.Controls.Add((Control) this.SpiritLinkLabel);
    this.metroPanel8.Controls.Add((Control) this.EarthgrabLabel);
    this.metroPanel8.Controls.Add((Control) this.metroLabel6);
    this.metroPanel8.Controls.Add((Control) this.EarthgrabToggle);
    this.metroPanel8.Controls.Add((Control) this.HealingStreamToggle);
    this.metroPanel8.Controls.Add((Control) this.metroLabel13);
    this.metroPanel8.Controls.Add((Control) this.HealingStreamLabel);
    this.metroPanel8.Controls.Add((Control) this.HealingTideLabel);
    this.metroPanel8.Controls.Add((Control) this.metroLabel11);
    this.metroPanel8.Controls.Add((Control) this.HealingTideToggle);
    this.metroPanel8.\u0011 = true;
    this.metroPanel8.\u0012 = false;
    this.metroPanel8.\u000F = 10;
    this.metroPanel8.Location = new Point(186, 9);
    this.metroPanel8.Name = "metroPanel8";
    this.metroPanel8.\u0010 = true;
    this.metroPanel8.Size = new Size(194, 284);
    this.metroPanel8.TabIndex = 35;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel8, "");
    this.metroPanel8.\u0014 = true;
    this.metroPanel8.\u0015 = false;
    this.metroPanel8.\u0010 = 10;
    this.metroLabel12.AutoSize = true;
    this.metroLabel12.\u000F = \u000F\u000B.\u0001;
    this.metroLabel12.Location = new Point(13, 266);
    this.metroLabel12.Name = "metroLabel12";
    this.metroLabel12.Size = new Size(54, 15);
    this.metroLabel12.TabIndex = 36;
    this.metroLabel12.Text = "Windwalk";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel12, "");
    this.WindwalkLabel.AutoSize = true;
    this.WindwalkLabel.\u000F = \u000F\u000B.\u0001;
    this.WindwalkLabel.Location = new Point(157, 266);
    this.WindwalkLabel.Name = "WindwalkLabel";
    this.WindwalkLabel.Size = new Size(22, 15);
    this.WindwalkLabel.TabIndex = 35;
    this.WindwalkLabel.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.WindwalkLabel, "");
    this.WindwalkToggle.AutoSize = true;
    this.WindwalkToggle.Checked = true;
    this.WindwalkToggle.CheckState = CheckState.Checked;
    this.WindwalkToggle.\u0010 = false;
    this.WindwalkToggle.Location = new Point(101, 266);
    this.WindwalkToggle.Name = "WindwalkToggle";
    this.WindwalkToggle.Size = new Size(50, 17);
    this.WindwalkToggle.TabIndex = 34;
    this.WindwalkToggle.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.WindwalkToggle, "");
    this.WindwalkToggle.\u000A = true;
    this.WindwalkToggle.\u0009 = true;
    this.WindwalkToggle.CheckedChanged += new EventHandler(this.WindwalkToggle_CheckedChanged);
    this.AutoFocusComboBox.FormattingEnabled = true;
    this.AutoFocusComboBox.ItemHeight = 23;
    this.AutoFocusComboBox.Items.AddRange(new object[4]
    {
      (object) "Always",
      (object) "Arenas only",
      (object) "Battlegrounds only",
      (object) "Never"
    });
    this.AutoFocusComboBox.Location = new Point(17, 26);
    this.AutoFocusComboBox.Name = "AutoFocusComboBox";
    this.AutoFocusComboBox.Size = new Size(158, 29);
    this.AutoFocusComboBox.TabIndex = 5;
    this.\u0008\u0008_0.\u0001((Control) this.AutoFocusComboBox, "");
    this.AutoFocusComboBox.\u000A = true;
    this.AutoFocusComboBox.SelectedIndexChanged += new EventHandler(this.AutoFocusComboBox_SelectedIndexChanged);
    this.metroLabel17.AutoSize = true;
    this.metroLabel17.Location = new Point(17, 4);
    this.metroLabel17.Name = "metroLabel17";
    this.metroLabel17.Size = new Size(74, 19);
    this.metroLabel17.TabIndex = 7;
    this.metroLabel17.Text = "Auto Focus";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel17, "Choose whether you want the profile to automatically set your focus target in arenas or battlegrounds, and which targets it should focus.");
    this.CapacitorToggle.AutoSize = true;
    this.CapacitorToggle.Checked = true;
    this.CapacitorToggle.CheckState = CheckState.Checked;
    this.CapacitorToggle.\u0010 = false;
    this.CapacitorToggle.Location = new Point(101, 129);
    this.CapacitorToggle.Name = "CapacitorToggle";
    this.CapacitorToggle.Size = new Size(50, 17);
    this.CapacitorToggle.TabIndex = 14;
    this.CapacitorToggle.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.CapacitorToggle, "");
    this.CapacitorToggle.\u000A = true;
    this.CapacitorToggle.\u0009 = true;
    this.CapacitorToggle.CheckedChanged += new EventHandler(this.CapacitorToggle_CheckedChanged);
    this.AutoFocusTargetsComboBox.FormattingEnabled = true;
    this.AutoFocusTargetsComboBox.ItemHeight = 23;
    this.AutoFocusTargetsComboBox.Items.AddRange(new object[2]
    {
      (object) "Focus Healers + DPS",
      (object) "Focus Healers Only"
    });
    this.AutoFocusTargetsComboBox.Location = new Point(17, 61);
    this.AutoFocusTargetsComboBox.Name = "AutoFocusTargetsComboBox";
    this.AutoFocusTargetsComboBox.Size = new Size(158, 29);
    this.AutoFocusTargetsComboBox.TabIndex = 16 /*0x10*/;
    this.\u0008\u0008_0.\u0001((Control) this.AutoFocusTargetsComboBox, "");
    this.AutoFocusTargetsComboBox.\u000A = true;
    this.AutoFocusTargetsComboBox.SelectedIndexChanged += new EventHandler(this.AutoFocusTargetsComboBox_SelectedIndexChanged);
    this.metroLabel19.AutoSize = true;
    this.metroLabel19.Location = new Point(13, 104);
    this.metroLabel19.Name = "metroLabel19";
    this.metroLabel19.Size = new Size(88, 19);
    this.metroLabel19.TabIndex = 9;
    this.metroLabel19.Text = "Totem Stomp";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel19, "Select which totems you want the profile to automatically target and destroy.");
    this.metroLabel15.AutoSize = true;
    this.metroLabel15.\u000F = \u000F\u000B.\u0001;
    this.metroLabel15.Location = new Point(13, 244);
    this.metroLabel15.Name = "metroLabel15";
    this.metroLabel15.Size = new Size(60, 15);
    this.metroLabel15.TabIndex = 33;
    this.metroLabel15.Text = "Grounding";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel15, "");
    this.CapacitorLabel.AutoSize = true;
    this.CapacitorLabel.\u000F = \u000F\u000B.\u0001;
    this.CapacitorLabel.Location = new Point(157, 129);
    this.CapacitorLabel.Name = "CapacitorLabel";
    this.CapacitorLabel.Size = new Size(22, 15);
    this.CapacitorLabel.TabIndex = 17;
    this.CapacitorLabel.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.CapacitorLabel, "");
    this.GroundingLabel.AutoSize = true;
    this.GroundingLabel.\u000F = \u000F\u000B.\u0001;
    this.GroundingLabel.Location = new Point(157, 244);
    this.GroundingLabel.Name = "GroundingLabel";
    this.GroundingLabel.Size = new Size(22, 15);
    this.GroundingLabel.TabIndex = 32 /*0x20*/;
    this.GroundingLabel.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.GroundingLabel, "");
    this.metroLabel3.AutoSize = true;
    this.metroLabel3.\u000F = \u000F\u000B.\u0001;
    this.metroLabel3.Location = new Point(13, 129);
    this.metroLabel3.Name = "metroLabel3";
    this.metroLabel3.Size = new Size(55, 15);
    this.metroLabel3.TabIndex = 18;
    this.metroLabel3.Text = "Capacitor";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel3, "");
    this.GroundingToggle.AutoSize = true;
    this.GroundingToggle.Checked = true;
    this.GroundingToggle.CheckState = CheckState.Checked;
    this.GroundingToggle.\u0010 = false;
    this.GroundingToggle.Location = new Point(101, 244);
    this.GroundingToggle.Name = "GroundingToggle";
    this.GroundingToggle.Size = new Size(50, 17);
    this.GroundingToggle.TabIndex = 31 /*0x1F*/;
    this.GroundingToggle.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.GroundingToggle, "");
    this.GroundingToggle.\u000A = true;
    this.GroundingToggle.\u0009 = true;
    this.GroundingToggle.CheckedChanged += new EventHandler(this.GroundingToggle_CheckedChanged);
    this.SpiritLinkToggle.AutoSize = true;
    this.SpiritLinkToggle.Checked = true;
    this.SpiritLinkToggle.CheckState = CheckState.Checked;
    this.SpiritLinkToggle.\u0010 = false;
    this.SpiritLinkToggle.Location = new Point(101, 152);
    this.SpiritLinkToggle.Name = "SpiritLinkToggle";
    this.SpiritLinkToggle.Size = new Size(50, 17);
    this.SpiritLinkToggle.TabIndex = 19;
    this.SpiritLinkToggle.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.SpiritLinkToggle, "");
    this.SpiritLinkToggle.\u000A = true;
    this.SpiritLinkToggle.\u0009 = true;
    this.SpiritLinkToggle.CheckedChanged += new EventHandler(this.SpiritLinkToggle_CheckedChanged);
    this.metroLabel44.AutoSize = true;
    this.metroLabel44.\u000F = \u000F\u000B.\u0001;
    this.metroLabel44.Location = new Point(13, 221);
    this.metroLabel44.Name = "metroLabel44";
    this.metroLabel44.Size = new Size(58, 15);
    this.metroLabel44.TabIndex = 30;
    this.metroLabel44.Text = "Earthgrab";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel44, "");
    this.SpiritLinkLabel.AutoSize = true;
    this.SpiritLinkLabel.\u000F = \u000F\u000B.\u0001;
    this.SpiritLinkLabel.Location = new Point(157, 152);
    this.SpiritLinkLabel.Name = "SpiritLinkLabel";
    this.SpiritLinkLabel.Size = new Size(22, 15);
    this.SpiritLinkLabel.TabIndex = 20;
    this.SpiritLinkLabel.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.SpiritLinkLabel, "");
    this.EarthgrabLabel.AutoSize = true;
    this.EarthgrabLabel.\u000F = \u000F\u000B.\u0001;
    this.EarthgrabLabel.Location = new Point(157, 221);
    this.EarthgrabLabel.Name = "EarthgrabLabel";
    this.EarthgrabLabel.Size = new Size(22, 15);
    this.EarthgrabLabel.TabIndex = 29;
    this.EarthgrabLabel.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.EarthgrabLabel, "");
    this.metroLabel6.AutoSize = true;
    this.metroLabel6.\u000F = \u000F\u000B.\u0001;
    this.metroLabel6.Location = new Point(13, 152);
    this.metroLabel6.Name = "metroLabel6";
    this.metroLabel6.Size = new Size(53, 15);
    this.metroLabel6.TabIndex = 21;
    this.metroLabel6.Text = "Spirit Link";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel6, "");
    this.EarthgrabToggle.AutoSize = true;
    this.EarthgrabToggle.Checked = true;
    this.EarthgrabToggle.CheckState = CheckState.Checked;
    this.EarthgrabToggle.\u0010 = false;
    this.EarthgrabToggle.Location = new Point(101, 221);
    this.EarthgrabToggle.Name = "EarthgrabToggle";
    this.EarthgrabToggle.Size = new Size(50, 17);
    this.EarthgrabToggle.TabIndex = 28;
    this.EarthgrabToggle.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.EarthgrabToggle, "");
    this.EarthgrabToggle.\u000A = true;
    this.EarthgrabToggle.\u0009 = true;
    this.EarthgrabToggle.CheckedChanged += new EventHandler(this.EarthgrabToggle_CheckedChanged);
    this.HealingStreamToggle.AutoSize = true;
    this.HealingStreamToggle.Checked = true;
    this.HealingStreamToggle.CheckState = CheckState.Checked;
    this.HealingStreamToggle.\u0010 = false;
    this.HealingStreamToggle.Location = new Point(101, 175);
    this.HealingStreamToggle.Name = "HealingStreamToggle";
    this.HealingStreamToggle.Size = new Size(50, 17);
    this.HealingStreamToggle.TabIndex = 22;
    this.HealingStreamToggle.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.HealingStreamToggle, "");
    this.HealingStreamToggle.\u000A = true;
    this.HealingStreamToggle.\u0009 = true;
    this.HealingStreamToggle.CheckedChanged += new EventHandler(this.HealingStreamToggle_CheckedChanged);
    this.metroLabel13.AutoSize = true;
    this.metroLabel13.\u000F = \u000F\u000B.\u0001;
    this.metroLabel13.Location = new Point(13, 198);
    this.metroLabel13.Name = "metroLabel13";
    this.metroLabel13.Size = new Size(68, 15);
    this.metroLabel13.TabIndex = 27;
    this.metroLabel13.Text = "Healing Tide";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel13, "");
    this.HealingStreamLabel.AutoSize = true;
    this.HealingStreamLabel.\u000F = \u000F\u000B.\u0001;
    this.HealingStreamLabel.Location = new Point(157, 175);
    this.HealingStreamLabel.Name = "HealingStreamLabel";
    this.HealingStreamLabel.Size = new Size(22, 15);
    this.HealingStreamLabel.TabIndex = 23;
    this.HealingStreamLabel.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.HealingStreamLabel, "");
    this.HealingTideLabel.AutoSize = true;
    this.HealingTideLabel.\u000F = \u000F\u000B.\u0001;
    this.HealingTideLabel.Location = new Point(157, 198);
    this.HealingTideLabel.Name = "HealingTideLabel";
    this.HealingTideLabel.Size = new Size(22, 15);
    this.HealingTideLabel.TabIndex = 26;
    this.HealingTideLabel.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.HealingTideLabel, "");
    this.metroLabel11.AutoSize = true;
    this.metroLabel11.\u000F = \u000F\u000B.\u0001;
    this.metroLabel11.Location = new Point(13, 175);
    this.metroLabel11.Name = "metroLabel11";
    this.metroLabel11.Size = new Size(83, 15);
    this.metroLabel11.TabIndex = 24;
    this.metroLabel11.Text = "Healing Stream";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel11, "");
    this.HealingTideToggle.AutoSize = true;
    this.HealingTideToggle.Checked = true;
    this.HealingTideToggle.CheckState = CheckState.Checked;
    this.HealingTideToggle.\u0010 = false;
    this.HealingTideToggle.Location = new Point(101, 198);
    this.HealingTideToggle.Name = "HealingTideToggle";
    this.HealingTideToggle.Size = new Size(50, 17);
    this.HealingTideToggle.TabIndex = 25;
    this.HealingTideToggle.Text = "On";
    this.\u0008\u0008_0.\u0001((Control) this.HealingTideToggle, "");
    this.HealingTideToggle.\u000A = true;
    this.HealingTideToggle.\u0009 = true;
    this.HealingTideToggle.CheckedChanged += new EventHandler(this.HealingTideToggle_CheckedChanged);
    this.metroPanel7.Controls.Add((Control) this.DiagnosticModeCheckBox);
    this.metroPanel7.Controls.Add((Control) this.PvEModeCheckBox);
    this.metroPanel7.Controls.Add((Control) this.metroLabel18);
    this.metroPanel7.Controls.Add((Control) this.AcceptQueuesCheckBox);
    this.metroPanel7.Controls.Add((Control) this.ClickToMoveCheckBox);
    this.metroPanel7.Controls.Add((Control) this.AlertQueuesCheckBox);
    this.metroPanel7.Controls.Add((Control) this.AntiAFKCheckBox);
    this.metroPanel7.\u0011 = true;
    this.metroPanel7.\u0012 = false;
    this.metroPanel7.\u000F = 10;
    this.metroPanel7.Location = new Point(-5, 9);
    this.metroPanel7.Name = "metroPanel7";
    this.metroPanel7.\u0010 = true;
    this.metroPanel7.Size = new Size(188, 284);
    this.metroPanel7.TabIndex = 34;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel7, "");
    this.metroPanel7.\u0014 = true;
    this.metroPanel7.\u0015 = false;
    this.metroPanel7.\u0010 = 10;
    this.DiagnosticModeCheckBox.AutoSize = true;
    this.DiagnosticModeCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.DiagnosticModeCheckBox.\u000F = \u001D\u000B.\u0002;
    this.DiagnosticModeCheckBox.Location = new Point(8, 151);
    this.DiagnosticModeCheckBox.Name = "DiagnosticModeCheckBox";
    this.DiagnosticModeCheckBox.Size = new Size(173, 19);
    this.DiagnosticModeCheckBox.TabIndex = 34;
    this.DiagnosticModeCheckBox.Text = "Enable Diagnostic Mode";
    this.DiagnosticModeCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.DiagnosticModeCheckBox, "Enables the profile's diagnostic mode which will result in more detailed information in the log file.");
    this.DiagnosticModeCheckBox.\u000A = true;
    this.DiagnosticModeCheckBox.CheckedChanged += new EventHandler(this.DiagnosticModeCheckBox_CheckedChanged);
    this.PvEModeCheckBox.AutoSize = true;
    this.PvEModeCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.PvEModeCheckBox.\u000F = \u001D\u000B.\u0002;
    this.PvEModeCheckBox.Location = new Point(8, 26);
    this.PvEModeCheckBox.Name = "PvEModeCheckBox";
    this.PvEModeCheckBox.Size = new Size(131, 19);
    this.PvEModeCheckBox.TabIndex = 28;
    this.PvEModeCheckBox.Text = "Enable PvE Mode";
    this.PvEModeCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.PvEModeCheckBox, "Disables the use of stuns and allows the profile to be used in PvE situations (not optimised for PvE).");
    this.PvEModeCheckBox.\u000A = true;
    this.PvEModeCheckBox.CheckedChanged += new EventHandler(this.PvEModeCheckBox_CheckedChanged);
    this.metroLabel18.AutoSize = true;
    this.metroLabel18.Location = new Point(4, 3);
    this.metroLabel18.Name = "metroLabel18";
    this.metroLabel18.Size = new Size(91, 19);
    this.metroLabel18.TabIndex = 29;
    this.metroLabel18.Text = "Utility Options";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel18, "");
    this.AcceptQueuesCheckBox.AutoSize = true;
    this.AcceptQueuesCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AcceptQueuesCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AcceptQueuesCheckBox.Location = new Point(8, 51);
    this.AcceptQueuesCheckBox.Name = "AcceptQueuesCheckBox";
    this.AcceptQueuesCheckBox.Size = new Size(161, 19);
    this.AcceptQueuesCheckBox.TabIndex = 30;
    this.AcceptQueuesCheckBox.Text = "Enable Accept Queues";
    this.AcceptQueuesCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AcceptQueuesCheckBox, "Enables automatic accepting of dungeon, battleground and arena queues.");
    this.AcceptQueuesCheckBox.\u000A = true;
    this.AcceptQueuesCheckBox.CheckedChanged += new EventHandler(this.AcceptQueuesCheckBox_CheckedChanged);
    this.ClickToMoveCheckBox.AutoSize = true;
    this.ClickToMoveCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.ClickToMoveCheckBox.\u000F = \u001D\u000B.\u0002;
    this.ClickToMoveCheckBox.Location = new Point(8, 126);
    this.ClickToMoveCheckBox.Name = "ClickToMoveCheckBox";
    this.ClickToMoveCheckBox.Size = new Size(159, 19);
    this.ClickToMoveCheckBox.TabIndex = 33;
    this.ClickToMoveCheckBox.Text = "Disable Click To Move";
    this.ClickToMoveCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.ClickToMoveCheckBox, "Disables Click To Move whenever the profile is started.");
    this.ClickToMoveCheckBox.\u000A = true;
    this.ClickToMoveCheckBox.CheckedChanged += new EventHandler(this.ClickToMoveCheckBox_CheckedChanged);
    this.AlertQueuesCheckBox.AutoSize = true;
    this.AlertQueuesCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AlertQueuesCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AlertQueuesCheckBox.Location = new Point(8, 76);
    this.AlertQueuesCheckBox.Name = "AlertQueuesCheckBox";
    this.AlertQueuesCheckBox.Size = new Size(149, 19);
    this.AlertQueuesCheckBox.TabIndex = 31 /*0x1F*/;
    this.AlertQueuesCheckBox.Text = "Enable Alert Queues";
    this.AlertQueuesCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AlertQueuesCheckBox, "Enables sound alerts when a battleground or arena queue pops, will also try to bring your WoW window back to the foreground.");
    this.AlertQueuesCheckBox.\u000A = true;
    this.AlertQueuesCheckBox.CheckedChanged += new EventHandler(this.AlertQueuesCheckBox_CheckedChanged);
    this.AntiAFKCheckBox.AutoSize = true;
    this.AntiAFKCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AntiAFKCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AntiAFKCheckBox.Location = new Point(8, 101);
    this.AntiAFKCheckBox.Name = "AntiAFKCheckBox";
    this.AntiAFKCheckBox.Size = new Size(122, 19);
    this.AntiAFKCheckBox.TabIndex = 32 /*0x20*/;
    this.AntiAFKCheckBox.Text = "Enable Anti AFK";
    this.AntiAFKCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AntiAFKCheckBox, "Enables HB's built-in anti-afk functionality.");
    this.AntiAFKCheckBox.\u000A = true;
    this.AntiAFKCheckBox.CheckedChanged += new EventHandler(this.AntiAFKCheckBox_CheckedChanged);
    this.tabPageInterface.Controls.Add((Control) this.metroPanel6);
    this.tabPageInterface.Controls.Add((Control) this.metroPanel5);
    this.tabPageInterface.Controls.Add((Control) this.metroPanel4);
    this.tabPageInterface.\u0010 = true;
    this.tabPageInterface.\u0011 = false;
    this.tabPageInterface.\u000F = 10;
    this.tabPageInterface.Location = new Point(4, 38);
    this.tabPageInterface.Name = "tabPageInterface";
    this.tabPageInterface.Size = new Size(564, 303);
    this.tabPageInterface.TabIndex = 6;
    this.tabPageInterface.Text = "Interface";
    this.\u0008\u0008_0.\u0001((Control) this.tabPageInterface, "");
    this.tabPageInterface.\u0013 = true;
    this.tabPageInterface.\u0014 = false;
    this.tabPageInterface.\u0010 = 10;
    this.tabPageInterface.Visible = false;
    this.metroPanel6.Controls.Add((Control) this.metroLabel2);
    this.metroPanel6.Controls.Add((Control) this.metroTileSwitch);
    this.metroPanel6.\u0011 = true;
    this.metroPanel6.\u0012 = false;
    this.metroPanel6.\u000F = 10;
    this.metroPanel6.Location = new Point(382, 9);
    this.metroPanel6.Name = "metroPanel6";
    this.metroPanel6.Size = new Size(194, 284);
    this.metroPanel6.TabIndex = 36;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel6, "");
    this.metroPanel6.\u0014 = true;
    this.metroPanel6.\u0015 = false;
    this.metroPanel6.\u0010 = 10;
    this.metroLabel2.AutoSize = true;
    this.metroLabel2.Location = new Point(10, 6);
    this.metroLabel2.Name = "metroLabel2";
    this.metroLabel2.Size = new Size(80 /*0x50*/, 19);
    this.metroLabel2.TabIndex = 33;
    this.metroLabel2.Text = "GUI Options";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel2, "");
    this.metroTileSwitch.ActiveControl = (Control) null;
    this.metroTileSwitch.Location = new Point(13, 28);
    this.metroTileSwitch.Name = "metroTileSwitch";
    this.metroTileSwitch.Size = new Size(166, 59);
    this.metroTileSwitch.TabIndex = 32 /*0x20*/;
    this.metroTileSwitch.Text = "Switch GUI Style";
    this.metroTileSwitch.\u000F = ContentAlignment.MiddleCenter;
    this.metroTileSwitch.\u000F = \u0012\u000B.\u0002;
    this.\u0008\u0008_0.\u0001((Control) this.metroTileSwitch, "Switch colors!");
    this.metroTileSwitch.\u000A = true;
    this.metroTileSwitch.Click += new EventHandler(this.metroTileSwitch_Click);
    this.metroPanel5.Controls.Add((Control) this.StickyDelayLabel);
    this.metroPanel5.Controls.Add((Control) this.metroLabel73);
    this.metroPanel5.Controls.Add((Control) this.StickyDelayBar);
    this.metroPanel5.Controls.Add((Control) this.MacroDelayLabel);
    this.metroPanel5.Controls.Add((Control) this.metroLabel71);
    this.metroPanel5.Controls.Add((Control) this.MacroDelayBar);
    this.metroPanel5.Controls.Add((Control) this.LowHealthWarningBar);
    this.metroPanel5.Controls.Add((Control) this.metroLabel39);
    this.metroPanel5.Controls.Add((Control) this.LowHealthWarningLabel);
    this.metroPanel5.\u0011 = true;
    this.metroPanel5.\u0012 = false;
    this.metroPanel5.\u000F = 10;
    this.metroPanel5.Location = new Point(186, 9);
    this.metroPanel5.Name = "metroPanel5";
    this.metroPanel5.\u0010 = true;
    this.metroPanel5.Size = new Size(194, 284);
    this.metroPanel5.TabIndex = 35;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel5, "");
    this.metroPanel5.\u0014 = true;
    this.metroPanel5.\u0015 = false;
    this.metroPanel5.\u0010 = 10;
    this.StickyDelayLabel.AutoSize = true;
    this.StickyDelayLabel.Location = new Point(158, 121);
    this.StickyDelayLabel.Name = "StickyDelayLabel";
    this.StickyDelayLabel.Size = new Size(14, 19);
    this.StickyDelayLabel.TabIndex = 37;
    this.StickyDelayLabel.Text = "1";
    this.\u0008\u0008_0.\u0001((Control) this.StickyDelayLabel, "");
    this.metroLabel73.AutoSize = true;
    this.metroLabel73.Location = new Point(10, 104);
    this.metroLabel73.Name = "metroLabel73";
    this.metroLabel73.Size = new Size(77, 19);
    this.metroLabel73.TabIndex = 36;
    this.metroLabel73.Text = "Sticky Delay";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel73, "<p>Sets the stickyness period (in seconds) after using an HB keybind.</p><p><b>Default: 1</b></p>");
    this.StickyDelayBar.BackColor = Color.Transparent;
    this.StickyDelayBar.Location = new Point(13, 126);
    this.StickyDelayBar.\u0011 = 50;
    this.StickyDelayBar.\u0014 = 50;
    this.StickyDelayBar.Name = "StickyDelayBar";
    this.StickyDelayBar.Size = new Size(139, 23);
    this.StickyDelayBar.TabIndex = 35;
    this.StickyDelayBar.Text = "metroTrackBar12";
    this.\u0008\u0008_0.\u0001((Control) this.StickyDelayBar, "");
    this.StickyDelayBar.\u000F = 10;
    this.StickyDelayBar.\u000F += new EventHandler(this.method_14);
    this.StickyDelayBar.MouseLeave += new EventHandler(this.StickyDelayBar_MouseLeave);
    this.MacroDelayLabel.AutoSize = true;
    this.MacroDelayLabel.Location = new Point(158, 75);
    this.MacroDelayLabel.Name = "MacroDelayLabel";
    this.MacroDelayLabel.Size = new Size(16 /*0x10*/, 19);
    this.MacroDelayLabel.TabIndex = 34;
    this.MacroDelayLabel.Text = "2";
    this.\u0008\u0008_0.\u0001((Control) this.MacroDelayLabel, "");
    this.metroLabel71.AutoSize = true;
    this.metroLabel71.Location = new Point(10, 54);
    this.metroLabel71.Name = "metroLabel71";
    this.metroLabel71.Size = new Size(83, 19);
    this.metroLabel71.TabIndex = 33;
    this.metroLabel71.Text = "Macro Delay";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel71, "<p>Minimum seconds elapsed after enabling a macro before it can be disabled. <i>Allows you to spam the macro without toggling it off.</i></p><p><b>Default: 2</b></p>");
    this.MacroDelayBar.BackColor = Color.Transparent;
    this.MacroDelayBar.Location = new Point(13, 76);
    this.MacroDelayBar.\u0011 = 50;
    this.MacroDelayBar.\u0014 = 50;
    this.MacroDelayBar.Name = "MacroDelayBar";
    this.MacroDelayBar.Size = new Size(139, 23);
    this.MacroDelayBar.TabIndex = 32 /*0x20*/;
    this.MacroDelayBar.Text = "metroTrackBar11";
    this.\u0008\u0008_0.\u0001((Control) this.MacroDelayBar, "");
    this.MacroDelayBar.\u000F = 20;
    this.MacroDelayBar.\u000F += new EventHandler(this.method_15);
    this.MacroDelayBar.MouseLeave += new EventHandler(this.MacroDelayBar_MouseLeave);
    this.LowHealthWarningBar.BackColor = Color.Transparent;
    this.LowHealthWarningBar.Location = new Point(13, 25);
    this.LowHealthWarningBar.\u0014 = 20;
    this.LowHealthWarningBar.Name = "LowHealthWarningBar";
    this.LowHealthWarningBar.Size = new Size(139, 23);
    this.LowHealthWarningBar.\u0012 = 5;
    this.LowHealthWarningBar.TabIndex = 29;
    this.LowHealthWarningBar.Text = "metroTrackBar1";
    this.\u0008\u0008_0.\u0001((Control) this.LowHealthWarningBar, "");
    this.LowHealthWarningBar.\u000F = 30;
    this.LowHealthWarningBar.\u000F += new EventHandler(this.method_2);
    this.LowHealthWarningBar.MouseLeave += new EventHandler(this.LowHealthWarningBar_MouseLeave);
    this.metroLabel39.AutoSize = true;
    this.metroLabel39.Location = new Point(10, 3);
    this.metroLabel39.Name = "metroLabel39";
    this.metroLabel39.Size = new Size(126, 19);
    this.metroLabel39.TabIndex = 30;
    this.metroLabel39.Text = "Low Health Warning";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel39, "Will show a red screen alert when at low health. <b>Default: 30</b>");
    this.LowHealthWarningLabel.AutoSize = true;
    this.LowHealthWarningLabel.Location = new Point(158, 25);
    this.LowHealthWarningLabel.Name = "LowHealthWarningLabel";
    this.LowHealthWarningLabel.Size = new Size(23, 19);
    this.LowHealthWarningLabel.TabIndex = 31 /*0x1F*/;
    this.LowHealthWarningLabel.Text = "30";
    this.\u0008\u0008_0.\u0001((Control) this.LowHealthWarningLabel, "");
    this.metroPanel4.Controls.Add((Control) this.StatusFrameCheckBox);
    this.metroPanel4.Controls.Add((Control) this.metroLabel16);
    this.metroPanel4.Controls.Add((Control) this.MacrosEnabledCheckBox);
    this.metroPanel4.Controls.Add((Control) this.SpellAlertsCheckBox);
    this.metroPanel4.Controls.Add((Control) this.SoundAlertsCheckBox);
    this.metroPanel4.Controls.Add((Control) this.LogMessagesCheckBox);
    this.metroPanel4.Controls.Add((Control) this.AlertFontsCheckBox);
    this.metroPanel4.\u0011 = true;
    this.metroPanel4.\u0012 = false;
    this.metroPanel4.\u000F = 10;
    this.metroPanel4.Location = new Point(-5, 9);
    this.metroPanel4.Name = "metroPanel4";
    this.metroPanel4.\u0010 = true;
    this.metroPanel4.Size = new Size(188, 284);
    this.metroPanel4.TabIndex = 34;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel4, "");
    this.metroPanel4.\u0014 = true;
    this.metroPanel4.\u0015 = false;
    this.metroPanel4.\u0010 = 10;
    this.StatusFrameCheckBox.AutoSize = true;
    this.StatusFrameCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.StatusFrameCheckBox.\u000F = \u001D\u000B.\u0002;
    this.StatusFrameCheckBox.Location = new Point(8, 26);
    this.StatusFrameCheckBox.Name = "StatusFrameCheckBox";
    this.StatusFrameCheckBox.Size = new Size(149, 19);
    this.StatusFrameCheckBox.TabIndex = 22;
    this.StatusFrameCheckBox.Text = "Enable Status Frame";
    this.StatusFrameCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.StatusFrameCheckBox, "Enables the in-game status frame.");
    this.StatusFrameCheckBox.\u000A = true;
    this.StatusFrameCheckBox.CheckedChanged += new EventHandler(this.StatusFrameCheckBox_CheckedChanged);
    this.metroLabel16.AutoSize = true;
    this.metroLabel16.Location = new Point(4, 3);
    this.metroLabel16.Name = "metroLabel16";
    this.metroLabel16.Size = new Size(109, 19);
    this.metroLabel16.TabIndex = 23;
    this.metroLabel16.Text = "In-game Options";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel16, "");
    this.MacrosEnabledCheckBox.AutoSize = true;
    this.MacrosEnabledCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.MacrosEnabledCheckBox.\u000F = \u001D\u000B.\u0002;
    this.MacrosEnabledCheckBox.Location = new Point(8, 152);
    this.MacrosEnabledCheckBox.Name = "MacrosEnabledCheckBox";
    this.MacrosEnabledCheckBox.Size = new Size(114, 19);
    this.MacrosEnabledCheckBox.TabIndex = 28;
    this.MacrosEnabledCheckBox.Text = "Enable Macros";
    this.MacrosEnabledCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.MacrosEnabledCheckBox, "Enables in-game macro support. <i>See the forum thread for which macros are supported.</i>");
    this.MacrosEnabledCheckBox.\u000A = true;
    this.MacrosEnabledCheckBox.CheckedChanged += new EventHandler(this.MacrosEnabledCheckBox_CheckedChanged);
    this.SpellAlertsCheckBox.AutoSize = true;
    this.SpellAlertsCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.SpellAlertsCheckBox.\u000F = \u001D\u000B.\u0002;
    this.SpellAlertsCheckBox.Location = new Point(8, 51);
    this.SpellAlertsCheckBox.Name = "SpellAlertsCheckBox";
    this.SpellAlertsCheckBox.Size = new Size(136, 19);
    this.SpellAlertsCheckBox.TabIndex = 24;
    this.SpellAlertsCheckBox.Text = "Enable Spell Alerts";
    this.SpellAlertsCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.SpellAlertsCheckBox, "Enables the on-screen spell alert system.");
    this.SpellAlertsCheckBox.\u000A = true;
    this.SpellAlertsCheckBox.CheckedChanged += new EventHandler(this.SpellAlertsCheckBox_CheckedChanged);
    this.SoundAlertsCheckBox.AutoSize = true;
    this.SoundAlertsCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.SoundAlertsCheckBox.\u000F = \u001D\u000B.\u0002;
    this.SoundAlertsCheckBox.Location = new Point(8, 126);
    this.SoundAlertsCheckBox.Name = "SoundAlertsCheckBox";
    this.SoundAlertsCheckBox.Size = new Size(147, 19);
    this.SoundAlertsCheckBox.TabIndex = 27;
    this.SoundAlertsCheckBox.Text = "Enable Sound Alerts";
    this.SoundAlertsCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.SoundAlertsCheckBox, "Enables in-game sound alerts when key events occur like interrupts or spell counters.");
    this.SoundAlertsCheckBox.\u000A = true;
    this.SoundAlertsCheckBox.CheckedChanged += new EventHandler(this.SoundAlertsCheckBox_CheckedChanged);
    this.LogMessagesCheckBox.AutoSize = true;
    this.LogMessagesCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.LogMessagesCheckBox.\u000F = \u001D\u000B.\u0002;
    this.LogMessagesCheckBox.Location = new Point(8, 76);
    this.LogMessagesCheckBox.Name = "LogMessagesCheckBox";
    this.LogMessagesCheckBox.Size = new Size(156, 19);
    this.LogMessagesCheckBox.TabIndex = 25;
    this.LogMessagesCheckBox.Text = "Enable Log Messages";
    this.LogMessagesCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.LogMessagesCheckBox, "Enables in-game log messages (does not use the chat system in any way).");
    this.LogMessagesCheckBox.\u000A = true;
    this.LogMessagesCheckBox.CheckedChanged += new EventHandler(this.LogMessagesCheckBox_CheckedChanged);
    this.AlertFontsCheckBox.AutoSize = true;
    this.AlertFontsCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AlertFontsCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AlertFontsCheckBox.Location = new Point(8, 101);
    this.AlertFontsCheckBox.Name = "AlertFontsCheckBox";
    this.AlertFontsCheckBox.Size = new Size(136, 19);
    this.AlertFontsCheckBox.TabIndex = 26;
    this.AlertFontsCheckBox.Text = "Enable Alert Fonts";
    this.AlertFontsCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AlertFontsCheckBox, "Enables custom fonts for spell alerts. <i>Requires font to be installed.</i>");
    this.AlertFontsCheckBox.\u000A = true;
    this.AlertFontsCheckBox.CheckedChanged += new EventHandler(this.AlertFontsCheckBox_CheckedChanged);
    this.tabPageOffensive.Controls.Add((Control) this.metroPanel3);
    this.tabPageOffensive.Controls.Add((Control) this.metroPanel2);
    this.tabPageOffensive.Controls.Add((Control) this.metroPanel1);
    this.tabPageOffensive.Controls.Add((Control) this.metroLabel4);
    this.tabPageOffensive.\u000F = true;
    this.tabPageOffensive.\u0010 = true;
    this.tabPageOffensive.\u0011 = false;
    this.tabPageOffensive.\u000F = 10;
    this.tabPageOffensive.Location = new Point(4, 38);
    this.tabPageOffensive.Name = "tabPageOffensive";
    this.tabPageOffensive.Padding = new Padding(25);
    this.tabPageOffensive.Size = new Size(564, 303);
    this.tabPageOffensive.TabIndex = 2;
    this.tabPageOffensive.Text = "Offensive";
    this.\u0008\u0008_0.\u0001((Control) this.tabPageOffensive, "");
    this.tabPageOffensive.\u0012 = true;
    this.tabPageOffensive.\u0013 = true;
    this.tabPageOffensive.\u0014 = false;
    this.tabPageOffensive.\u0010 = 10;
    this.tabPageOffensive.Visible = false;
    this.metroPanel3.Controls.Add((Control) this.LazyEviscerateCheckBox);
    this.metroPanel3.Controls.Add((Control) this.RuptureOverGarroteCheckBox);
    this.metroPanel3.Controls.Add((Control) this.AlwaysUseHemoCheckBox);
    this.metroPanel3.Controls.Add((Control) this.metroLabel47);
    this.metroPanel3.Controls.Add((Control) this.LazyPoolingCheckBox);
    this.metroPanel3.\u0011 = true;
    this.metroPanel3.\u0012 = false;
    this.metroPanel3.\u000F = 10;
    this.metroPanel3.Location = new Point(382, 9);
    this.metroPanel3.Name = "metroPanel3";
    this.metroPanel3.Size = new Size(194, 284);
    this.metroPanel3.TabIndex = 22;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel3, "");
    this.metroPanel3.\u0014 = true;
    this.metroPanel3.\u0015 = false;
    this.metroPanel3.\u0010 = 10;
    this.LazyEviscerateCheckBox.AutoSize = true;
    this.LazyEviscerateCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.LazyEviscerateCheckBox.\u000F = \u001D\u000B.\u0002;
    this.LazyEviscerateCheckBox.Location = new Point(11, 102);
    this.LazyEviscerateCheckBox.Name = "LazyEviscerateCheckBox";
    this.LazyEviscerateCheckBox.Size = new Size(116, 19);
    this.LazyEviscerateCheckBox.TabIndex = 47;
    this.LazyEviscerateCheckBox.Text = "Lazy Eviscerate";
    this.LazyEviscerateCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.LazyEviscerateCheckBox, "Enable or disable usage of Eviscerate outside of burst windows.");
    this.LazyEviscerateCheckBox.\u000A = true;
    this.LazyEviscerateCheckBox.CheckedChanged += new EventHandler(this.LazyEviscerateCheckBox_CheckedChanged);
    this.RuptureOverGarroteCheckBox.AutoSize = true;
    this.RuptureOverGarroteCheckBox.\u000F = \u001D\u000B.\u0002;
    this.RuptureOverGarroteCheckBox.Location = new Point(11, 77);
    this.RuptureOverGarroteCheckBox.Name = "RuptureOverGarroteCheckBox";
    this.RuptureOverGarroteCheckBox.Size = new Size(159, 19);
    this.RuptureOverGarroteCheckBox.TabIndex = 23;
    this.RuptureOverGarroteCheckBox.Text = "Rupture Over Garrote";
    this.\u0008\u0008_0.\u0001((Control) this.RuptureOverGarroteCheckBox, "If enabled the Assassination rotation will overlap Garrote and Rupture. <i>The double bleed is typically worth it because Rupture ticks every two seconds as opposed to Garrote's 3.</i>");
    this.RuptureOverGarroteCheckBox.\u000A = true;
    this.RuptureOverGarroteCheckBox.CheckedChanged += new EventHandler(this.RuptureOverGarroteCheckBox_CheckedChanged);
    this.AlwaysUseHemoCheckBox.AutoSize = true;
    this.AlwaysUseHemoCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AlwaysUseHemoCheckBox.Location = new Point(11, 52);
    this.AlwaysUseHemoCheckBox.Name = "AlwaysUseHemoCheckBox";
    this.AlwaysUseHemoCheckBox.Size = new Size(135, 19);
    this.AlwaysUseHemoCheckBox.TabIndex = 22;
    this.AlwaysUseHemoCheckBox.Text = "Always Use Hemo";
    this.\u0008\u0008_0.\u0001((Control) this.AlwaysUseHemoCheckBox, "If enabled the Subtlety rotation will always use Hemorrhage over Backstab. <i>Enable this if you are using swords.</i>");
    this.AlwaysUseHemoCheckBox.\u000A = true;
    this.AlwaysUseHemoCheckBox.CheckedChanged += new EventHandler(this.AlwaysUseHemoCheckBox_CheckedChanged);
    this.metroLabel47.AutoSize = true;
    this.metroLabel47.Location = new Point(8, 4);
    this.metroLabel47.Name = "metroLabel47";
    this.metroLabel47.Size = new Size(113, 19);
    this.metroLabel47.TabIndex = 21;
    this.metroLabel47.Text = "Offensive Options";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel47, "");
    this.LazyPoolingCheckBox.AutoSize = true;
    this.LazyPoolingCheckBox.\u000F = \u001D\u000B.\u0002;
    this.LazyPoolingCheckBox.Location = new Point(11, 28);
    this.LazyPoolingCheckBox.Name = "LazyPoolingCheckBox";
    this.LazyPoolingCheckBox.Size = new Size(102, 19);
    this.LazyPoolingCheckBox.TabIndex = 11;
    this.LazyPoolingCheckBox.Text = "Lazy Pooling";
    this.\u0008\u0008_0.\u0001((Control) this.LazyPoolingCheckBox, "Enables energy pooling when not bursting to preserve energy for other abilities.");
    this.LazyPoolingCheckBox.\u000A = true;
    this.LazyPoolingCheckBox.CheckedChanged += new EventHandler(this.LazyPoolingCheckBox_CheckedChanged);
    this.metroPanel2.Controls.Add((Control) this.HemoDelayLabel);
    this.metroPanel2.Controls.Add((Control) this.metroLabel55);
    this.metroPanel2.Controls.Add((Control) this.HemoDelayBar);
    this.metroPanel2.Controls.Add((Control) this.KidneyShotCPsLabel);
    this.metroPanel2.Controls.Add((Control) this.metroLabel57);
    this.metroPanel2.Controls.Add((Control) this.KidneyShotCPsBar);
    this.metroPanel2.Controls.Add((Control) this.KidneyShotEnergyLabel);
    this.metroPanel2.Controls.Add((Control) this.metroLabel59);
    this.metroPanel2.Controls.Add((Control) this.KidneyShotEnergyBar);
    this.metroPanel2.Controls.Add((Control) this.metroLabel53);
    this.metroPanel2.Controls.Add((Control) this.CombatBurstComboBox);
    this.metroPanel2.Controls.Add((Control) this.metroLabel46);
    this.metroPanel2.Controls.Add((Control) this.SubterfugeOpenersComboBox);
    this.metroPanel2.\u0011 = true;
    this.metroPanel2.\u0012 = false;
    this.metroPanel2.\u000F = 10;
    this.metroPanel2.Location = new Point(186, 9);
    this.metroPanel2.Name = "metroPanel2";
    this.metroPanel2.\u0010 = true;
    this.metroPanel2.Size = new Size(194, 284);
    this.metroPanel2.TabIndex = 21;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel2, "");
    this.metroPanel2.\u0014 = true;
    this.metroPanel2.\u0015 = false;
    this.metroPanel2.\u0010 = 10;
    this.HemoDelayLabel.AutoSize = true;
    this.HemoDelayLabel.Location = new Point(158, 245);
    this.HemoDelayLabel.Name = "HemoDelayLabel";
    this.HemoDelayLabel.Size = new Size(16 /*0x10*/, 19);
    this.HemoDelayLabel.TabIndex = 31 /*0x1F*/;
    this.HemoDelayLabel.Text = "2";
    this.\u0008\u0008_0.\u0001((Control) this.HemoDelayLabel, "");
    this.metroLabel55.AutoSize = true;
    this.metroLabel55.Location = new Point(10, 223);
    this.metroLabel55.Name = "metroLabel55";
    this.metroLabel55.Size = new Size(120, 19);
    this.metroLabel55.TabIndex = 30;
    this.metroLabel55.Text = "Hemorrhage Delay";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel55, "<p>Delays use of Hemorrhage to provide time to get behind a target. <i>Useful for maximising number of Backstabs.</i></p><p><b>Default: 2</b></p>");
    this.HemoDelayBar.BackColor = Color.Transparent;
    this.HemoDelayBar.\u0013 = 10;
    this.HemoDelayBar.Location = new Point(13, 245);
    this.HemoDelayBar.\u0011 = 50;
    this.HemoDelayBar.\u0014 = 50;
    this.HemoDelayBar.Name = "HemoDelayBar";
    this.HemoDelayBar.Size = new Size(139, 23);
    this.HemoDelayBar.TabIndex = 29;
    this.HemoDelayBar.Text = "metroTrackBar3";
    this.\u0008\u0008_0.\u0001((Control) this.HemoDelayBar, "");
    this.HemoDelayBar.\u000F = 20;
    this.HemoDelayBar.\u000F += new EventHandler(this.method_3);
    this.HemoDelayBar.MouseLeave += new EventHandler(this.HemoDelayBar_MouseLeave);
    this.KidneyShotCPsLabel.AutoSize = true;
    this.KidneyShotCPsLabel.Location = new Point(158, 198);
    this.KidneyShotCPsLabel.Name = "KidneyShotCPsLabel";
    this.KidneyShotCPsLabel.Size = new Size(28, 19);
    this.KidneyShotCPsLabel.TabIndex = 28;
    this.KidneyShotCPsLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.KidneyShotCPsLabel, "");
    this.metroLabel57.AutoSize = true;
    this.metroLabel57.Location = new Point(10, 174);
    this.metroLabel57.Name = "metroLabel57";
    this.metroLabel57.Size = new Size(103, 19);
    this.metroLabel57.TabIndex = 27;
    this.metroLabel57.Text = "Kidney Shot CPs";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel57, "<p>Minimum number of combo points required for the Kidney Shot hotkey to  cast Kidney Shot.</p><p><b>Default: 4</b></p>");
    this.KidneyShotCPsBar.BackColor = Color.Transparent;
    this.KidneyShotCPsBar.\u0013 = 1;
    this.KidneyShotCPsBar.Location = new Point(13, 196);
    this.KidneyShotCPsBar.\u0011 = 5;
    this.KidneyShotCPsBar.\u0010 = 1;
    this.KidneyShotCPsBar.\u0014 = 4;
    this.KidneyShotCPsBar.Name = "KidneyShotCPsBar";
    this.KidneyShotCPsBar.Size = new Size(139, 23);
    this.KidneyShotCPsBar.TabIndex = 26;
    this.KidneyShotCPsBar.Text = "metroTrackBar4";
    this.\u0008\u0008_0.\u0001((Control) this.KidneyShotCPsBar, "");
    this.KidneyShotCPsBar.\u000F = 4;
    this.KidneyShotCPsBar.\u000F += new EventHandler(this.method_19);
    this.KidneyShotCPsBar.MouseLeave += new EventHandler(this.KidneyShotCPsBar_MouseLeave);
    this.KidneyShotEnergyLabel.AutoSize = true;
    this.KidneyShotEnergyLabel.Location = new Point(158, 148);
    this.KidneyShotEnergyLabel.Name = "KidneyShotEnergyLabel";
    this.KidneyShotEnergyLabel.Size = new Size(28, 19);
    this.KidneyShotEnergyLabel.TabIndex = 25;
    this.KidneyShotEnergyLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.KidneyShotEnergyLabel, "");
    this.metroLabel59.AutoSize = true;
    this.metroLabel59.Location = new Point(10, 126);
    this.metroLabel59.Name = "metroLabel59";
    this.metroLabel59.Size = new Size(121, 19);
    this.metroLabel59.TabIndex = 24;
    this.metroLabel59.Text = "Kidney Shot Energy";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel59, "<p>Minimum energy required to cast Kidney Shot. <i>Affects Kidney Shot hotkey and Auto Kidney.</i></p><p><b>Default: 70</b></p>");
    this.KidneyShotEnergyBar.BackColor = Color.Transparent;
    this.KidneyShotEnergyBar.Location = new Point(13, 148);
    this.KidneyShotEnergyBar.\u0011 = 120;
    this.KidneyShotEnergyBar.\u0014 = 24;
    this.KidneyShotEnergyBar.Name = "KidneyShotEnergyBar";
    this.KidneyShotEnergyBar.Size = new Size(139, 23);
    this.KidneyShotEnergyBar.\u0012 = 5;
    this.KidneyShotEnergyBar.TabIndex = 23;
    this.KidneyShotEnergyBar.Text = "metroTrackBar1";
    this.\u0008\u0008_0.\u0001((Control) this.KidneyShotEnergyBar, "");
    this.KidneyShotEnergyBar.\u000F = 90;
    this.KidneyShotEnergyBar.\u000F += new EventHandler(this.method_18);
    this.KidneyShotEnergyBar.MouseLeave += new EventHandler(this.KidneyShotEnergyBar_MouseLeave);
    this.metroLabel53.AutoSize = true;
    this.metroLabel53.Location = new Point(17, 64 /*0x40*/);
    this.metroLabel53.Name = "metroLabel53";
    this.metroLabel53.Size = new Size(90, 19);
    this.metroLabel53.TabIndex = 22;
    this.metroLabel53.Text = "Combat Burst";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel53, "Choose how you want to use Shadow Blades when playing as Combat.");
    this.CombatBurstComboBox.FormattingEnabled = true;
    this.CombatBurstComboBox.ItemHeight = 23;
    this.CombatBurstComboBox.Items.AddRange(new object[2]
    {
      (object) "ShB + Killing Spree",
      (object) "ShB + Adrenaline Rush"
    });
    this.CombatBurstComboBox.Location = new Point(17, 86);
    this.CombatBurstComboBox.Name = "CombatBurstComboBox";
    this.CombatBurstComboBox.Size = new Size(158, 29);
    this.CombatBurstComboBox.TabIndex = 21;
    this.\u0008\u0008_0.\u0001((Control) this.CombatBurstComboBox, "");
    this.CombatBurstComboBox.\u000A = true;
    this.CombatBurstComboBox.SelectedIndexChanged += new EventHandler(this.CombatBurstComboBox_SelectedIndexChanged);
    this.metroLabel46.AutoSize = true;
    this.metroLabel46.Location = new Point(17, 4);
    this.metroLabel46.Name = "metroLabel46";
    this.metroLabel46.Size = new Size((int) sbyte.MaxValue, 19);
    this.metroLabel46.TabIndex = 20;
    this.metroLabel46.Text = "Subterfuge Openers";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel46, "Choose whether you want the profile to cast Cheap Shot and Garrote during Subterfuge.");
    this.SubterfugeOpenersComboBox.FormattingEnabled = true;
    this.SubterfugeOpenersComboBox.ItemHeight = 23;
    this.SubterfugeOpenersComboBox.Items.AddRange(new object[3]
    {
      (object) "Always",
      (object) "Burst Mode only",
      (object) "Never"
    });
    this.SubterfugeOpenersComboBox.Location = new Point(17, 26);
    this.SubterfugeOpenersComboBox.Name = "SubterfugeOpenersComboBox";
    this.SubterfugeOpenersComboBox.Size = new Size(158, 29);
    this.SubterfugeOpenersComboBox.TabIndex = 19;
    this.\u0008\u0008_0.\u0001((Control) this.SubterfugeOpenersComboBox, "");
    this.SubterfugeOpenersComboBox.\u000A = true;
    this.SubterfugeOpenersComboBox.SelectedIndexChanged += new EventHandler(this.SubterfugeOpenersComboBox_SelectedIndexChanged);
    this.metroPanel1.Controls.Add((Control) this.BurstHealthLabel);
    this.metroPanel1.Controls.Add((Control) this.metroLabel52);
    this.metroPanel1.Controls.Add((Control) this.BurstStunDRComboBox);
    this.metroPanel1.Controls.Add((Control) this.metroLabel51);
    this.metroPanel1.Controls.Add((Control) this.BurstHealthBar);
    this.metroPanel1.Controls.Add((Control) this.BurstPreparationLabel);
    this.metroPanel1.Controls.Add((Control) this.metroLabel49);
    this.metroPanel1.Controls.Add((Control) this.BurstPreparationBar);
    this.metroPanel1.Controls.Add((Control) this.BurstEnergyBar);
    this.metroPanel1.Controls.Add((Control) this.BurstEnergyOpenerLabel);
    this.metroPanel1.Controls.Add((Control) this.metroLabel5);
    this.metroPanel1.Controls.Add((Control) this.metroLabel40);
    this.metroPanel1.Controls.Add((Control) this.BurstEnergyLabel);
    this.metroPanel1.Controls.Add((Control) this.BurstEnergyOpenerBar);
    this.metroPanel1.\u0011 = true;
    this.metroPanel1.\u0012 = false;
    this.metroPanel1.\u000F = 10;
    this.metroPanel1.Location = new Point(-5, 9);
    this.metroPanel1.Name = "metroPanel1";
    this.metroPanel1.\u0010 = true;
    this.metroPanel1.Size = new Size(188, 284);
    this.metroPanel1.TabIndex = 18;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel1, "");
    this.metroPanel1.\u0014 = true;
    this.metroPanel1.\u0015 = false;
    this.metroPanel1.\u0010 = 10;
    this.BurstHealthLabel.AutoSize = true;
    this.BurstHealthLabel.Location = new Point(153, 171);
    this.BurstHealthLabel.Name = "BurstHealthLabel";
    this.BurstHealthLabel.Size = new Size(28, 19);
    this.BurstHealthLabel.TabIndex = 23;
    this.BurstHealthLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.BurstHealthLabel, "");
    this.metroLabel52.AutoSize = true;
    this.metroLabel52.Location = new Point(8, 201);
    this.metroLabel52.Name = "metroLabel52";
    this.metroLabel52.Size = new Size(88, 19);
    this.metroLabel52.TabIndex = 22;
    this.metroLabel52.Text = "Burst Stun DR";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel52, "");
    this.BurstStunDRComboBox.FormattingEnabled = true;
    this.BurstStunDRComboBox.ItemHeight = 23;
    this.BurstStunDRComboBox.Location = new Point(8, 223);
    this.BurstStunDRComboBox.Name = "BurstStunDRComboBox";
    this.BurstStunDRComboBox.Size = new Size(158, 29);
    this.BurstStunDRComboBox.TabIndex = 21;
    this.\u0008\u0008_0.\u0001((Control) this.BurstStunDRComboBox, "");
    this.BurstStunDRComboBox.\u000A = true;
    this.BurstStunDRComboBox.SelectedIndexChanged += new EventHandler(this.BurstStunDRComboBox_SelectedIndexChanged);
    this.metroLabel51.AutoSize = true;
    this.metroLabel51.Location = new Point(6, 149);
    this.metroLabel51.Name = "metroLabel51";
    this.metroLabel51.Size = new Size(79, 19);
    this.metroLabel51.TabIndex = 21;
    this.metroLabel51.Text = "Burst Health";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel51, "<p>Set the lowest enemy health at which burst cooldowns will be used. <i>Helps avoid wasting cooldowns on targets that are about to die.</i></p><p><b>Default: 30</b></p>");
    this.BurstHealthBar.BackColor = Color.Transparent;
    this.BurstHealthBar.Location = new Point(8, 171);
    this.BurstHealthBar.\u0014 = 20;
    this.BurstHealthBar.Name = "BurstHealthBar";
    this.BurstHealthBar.Size = new Size(139, 23);
    this.BurstHealthBar.\u0012 = 5;
    this.BurstHealthBar.TabIndex = 20;
    this.BurstHealthBar.Text = "metroTrackBar2";
    this.\u0008\u0008_0.\u0001((Control) this.BurstHealthBar, "");
    this.BurstHealthBar.\u000F = 30;
    this.BurstHealthBar.\u000F += new EventHandler(this.method_17);
    this.BurstHealthBar.MouseLeave += new EventHandler(this.BurstHealthBar_MouseLeave);
    this.BurstPreparationLabel.AutoSize = true;
    this.BurstPreparationLabel.Location = new Point(153, 124);
    this.BurstPreparationLabel.Name = "BurstPreparationLabel";
    this.BurstPreparationLabel.Size = new Size(28, 19);
    this.BurstPreparationLabel.TabIndex = 19;
    this.BurstPreparationLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.BurstPreparationLabel, "");
    this.metroLabel49.AutoSize = true;
    this.metroLabel49.Location = new Point(6, 100);
    this.metroLabel49.Name = "metroLabel49";
    this.metroLabel49.Size = new Size(111, 19);
    this.metroLabel49.TabIndex = 18;
    this.metroLabel49.Text = "Burst Preparation";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel49, "");
    this.BurstPreparationBar.BackColor = Color.Transparent;
    this.BurstPreparationBar.Location = new Point(8, 122);
    this.BurstPreparationBar.\u0011 = 20;
    this.BurstPreparationBar.\u0014 = 20;
    this.BurstPreparationBar.Name = "BurstPreparationBar";
    this.BurstPreparationBar.Size = new Size(139, 23);
    this.BurstPreparationBar.TabIndex = 17;
    this.BurstPreparationBar.Text = "metroTrackBar1";
    this.\u0008\u0008_0.\u0001((Control) this.BurstPreparationBar, "");
    this.BurstPreparationBar.\u000F = 15;
    this.BurstPreparationBar.\u000F += new EventHandler(this.method_16);
    this.BurstPreparationBar.MouseLeave += new EventHandler(this.BurstPreparationBar_MouseLeave);
    this.BurstEnergyBar.BackColor = Color.Transparent;
    this.BurstEnergyBar.Location = new Point(8, 26);
    this.BurstEnergyBar.\u0011 = 120;
    this.BurstEnergyBar.\u0010 = 10;
    this.BurstEnergyBar.\u0014 = 22;
    this.BurstEnergyBar.Name = "BurstEnergyBar";
    this.BurstEnergyBar.Size = new Size(139, 23);
    this.BurstEnergyBar.\u0012 = 5;
    this.BurstEnergyBar.TabIndex = 4;
    this.BurstEnergyBar.Text = "metroTrackBar1";
    this.\u0008\u0008_0.\u0001((Control) this.BurstEnergyBar, "");
    this.BurstEnergyBar.\u000F = 90;
    this.BurstEnergyBar.\u000F += new EventHandler(this.method_0);
    this.BurstEnergyBar.MouseLeave += new EventHandler(this.BurstEnergyBar_MouseLeave);
    this.BurstEnergyOpenerLabel.AutoSize = true;
    this.BurstEnergyOpenerLabel.Location = new Point(153, 76);
    this.BurstEnergyOpenerLabel.Name = "BurstEnergyOpenerLabel";
    this.BurstEnergyOpenerLabel.Size = new Size(28, 19);
    this.BurstEnergyOpenerLabel.TabIndex = 16 /*0x10*/;
    this.BurstEnergyOpenerLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.BurstEnergyOpenerLabel, "");
    this.metroLabel5.AutoSize = true;
    this.metroLabel5.Location = new Point(6, 4);
    this.metroLabel5.Name = "metroLabel5";
    this.metroLabel5.Size = new Size(82, 19);
    this.metroLabel5.TabIndex = 8;
    this.metroLabel5.Text = "Burst Energy";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel5, "Minimum energy required to use burst cooldowns (when not stealthed). <b>Default: 90</b>");
    this.metroLabel40.AutoSize = true;
    this.metroLabel40.Location = new Point(6, 52);
    this.metroLabel40.Name = "metroLabel40";
    this.metroLabel40.Size = new Size(139, 19);
    this.metroLabel40.TabIndex = 15;
    this.metroLabel40.Text = "Burst Energy (Opener)";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel40, "<p>Minimum energy required to use burst cooldowns (after opening).</p><p><b>Default: 70</b></p>");
    this.BurstEnergyLabel.AutoSize = true;
    this.BurstEnergyLabel.Location = new Point(153, 27);
    this.BurstEnergyLabel.Name = "BurstEnergyLabel";
    this.BurstEnergyLabel.Size = new Size(28, 19);
    this.BurstEnergyLabel.TabIndex = 13;
    this.BurstEnergyLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.BurstEnergyLabel, "");
    this.BurstEnergyOpenerBar.BackColor = Color.Transparent;
    this.BurstEnergyOpenerBar.Location = new Point(8, 74);
    this.BurstEnergyOpenerBar.\u0011 = 120;
    this.BurstEnergyOpenerBar.\u0010 = 10;
    this.BurstEnergyOpenerBar.\u0014 = 22;
    this.BurstEnergyOpenerBar.Name = "BurstEnergyOpenerBar";
    this.BurstEnergyOpenerBar.Size = new Size(139, 23);
    this.BurstEnergyOpenerBar.\u0012 = 5;
    this.BurstEnergyOpenerBar.TabIndex = 14;
    this.BurstEnergyOpenerBar.Text = "metroTrackBar1";
    this.\u0008\u0008_0.\u0001((Control) this.BurstEnergyOpenerBar, "");
    this.BurstEnergyOpenerBar.\u000F = 90;
    this.BurstEnergyOpenerBar.\u000F += new EventHandler(this.method_1);
    this.BurstEnergyOpenerBar.MouseLeave += new EventHandler(this.BurstEnergyOpenerBar_MouseLeave);
    this.metroLabel4.Location = new Point(0, 0);
    this.metroLabel4.Name = "metroLabel4";
    this.metroLabel4.Size = new Size(100, 23);
    this.metroLabel4.TabIndex = 17;
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel4, "");
    this.tabPageAutomation.Controls.Add((Control) this.metroPanel13);
    this.tabPageAutomation.Controls.Add((Control) this.metroPanel14);
    this.tabPageAutomation.Controls.Add((Control) this.metroPanel15);
    this.tabPageAutomation.\u0010 = true;
    this.tabPageAutomation.\u0011 = false;
    this.tabPageAutomation.\u000F = 10;
    this.tabPageAutomation.Location = new Point(4, 38);
    this.tabPageAutomation.Name = "tabPageAutomation";
    this.tabPageAutomation.Padding = new Padding(25);
    this.tabPageAutomation.Size = new Size(564, 303);
    this.tabPageAutomation.TabIndex = 3;
    this.tabPageAutomation.Text = "Automation";
    this.\u0008\u0008_0.\u0001((Control) this.tabPageAutomation, "");
    this.tabPageAutomation.\u0013 = true;
    this.tabPageAutomation.\u0014 = false;
    this.tabPageAutomation.\u0010 = 10;
    this.tabPageAutomation.Visible = false;
    this.metroPanel13.Controls.Add((Control) this.AutoTargetCheckBox);
    this.metroPanel13.Controls.Add((Control) this.AutoBurstOfSpeedCheckBox);
    this.metroPanel13.Controls.Add((Control) this.AlwaysStealthCheckBox);
    this.metroPanel13.Controls.Add((Control) this.AutoShivCheckBox);
    this.metroPanel13.Controls.Add((Control) this.AutoFlagReturnCheckBox);
    this.metroPanel13.Controls.Add((Control) this.AutoRedirectCheckBox);
    this.metroPanel13.Controls.Add((Control) this.metroLabel74);
    this.metroPanel13.Controls.Add((Control) this.AutoKidneyCheckBox);
    this.metroPanel13.Controls.Add((Control) this.AutoShroudCheckBox);
    this.metroPanel13.Controls.Add((Control) this.AutoPreparationCheckBox);
    this.metroPanel13.Controls.Add((Control) this.AutoSmokeBombCheckBox);
    this.metroPanel13.\u0011 = true;
    this.metroPanel13.\u0012 = false;
    this.metroPanel13.\u000F = 10;
    this.metroPanel13.Location = new Point(-5, 9);
    this.metroPanel13.Name = "metroPanel13";
    this.metroPanel13.\u0010 = true;
    this.metroPanel13.Size = new Size(188, 284);
    this.metroPanel13.TabIndex = 24;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel13, "");
    this.metroPanel13.\u0014 = true;
    this.metroPanel13.\u0015 = false;
    this.metroPanel13.\u0010 = 10;
    this.AutoTargetCheckBox.AutoSize = true;
    this.AutoTargetCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AutoTargetCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AutoTargetCheckBox.Location = new Point(8, 250);
    this.AutoTargetCheckBox.Name = "AutoTargetCheckBox";
    this.AutoTargetCheckBox.Size = new Size(98, 19);
    this.AutoTargetCheckBox.TabIndex = 46;
    this.AutoTargetCheckBox.Text = "Auto Target";
    this.AutoTargetCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AutoTargetCheckBox, "After a target dies or your target is cleared the next nearest enemy will be automatically targeted.");
    this.AutoTargetCheckBox.\u000A = true;
    this.AutoTargetCheckBox.CheckedChanged += new EventHandler(this.AutoTargetCheckBox_CheckedChanged);
    this.AutoBurstOfSpeedCheckBox.AutoSize = true;
    this.AutoBurstOfSpeedCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AutoBurstOfSpeedCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AutoBurstOfSpeedCheckBox.Location = new Point(8, 175);
    this.AutoBurstOfSpeedCheckBox.Name = "AutoBurstOfSpeedCheckBox";
    this.AutoBurstOfSpeedCheckBox.Size = new Size(148, 19);
    this.AutoBurstOfSpeedCheckBox.TabIndex = 45;
    this.AutoBurstOfSpeedCheckBox.Text = "Auto Burst of Speed";
    this.AutoBurstOfSpeedCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AutoBurstOfSpeedCheckBox, "Enables automatic use of Burst of Speed. <i>Will only cast when moving.</i>");
    this.AutoBurstOfSpeedCheckBox.\u000A = true;
    this.AutoBurstOfSpeedCheckBox.CheckedChanged += new EventHandler(this.AutoBurstOfSpeedCheckBox_CheckedChanged);
    this.AlwaysStealthCheckBox.AutoSize = true;
    this.AlwaysStealthCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AlwaysStealthCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AlwaysStealthCheckBox.Location = new Point(8, 225);
    this.AlwaysStealthCheckBox.Name = "AlwaysStealthCheckBox";
    this.AlwaysStealthCheckBox.Size = new Size(113, 19);
    this.AlwaysStealthCheckBox.TabIndex = 44;
    this.AlwaysStealthCheckBox.Text = "Always Stealth";
    this.AlwaysStealthCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AlwaysStealthCheckBox, "Will always cast Stealth when available, not just after leaving combat. <i>Only active in instanced PvP and duels.</i>");
    this.AlwaysStealthCheckBox.\u000A = true;
    this.AlwaysStealthCheckBox.CheckedChanged += new EventHandler(this.AlwaysStealthCheckBox_CheckedChanged);
    this.AutoShivCheckBox.AutoSize = true;
    this.AutoShivCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AutoShivCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AutoShivCheckBox.Location = new Point(8, 151);
    this.AutoShivCheckBox.Name = "AutoShivCheckBox";
    this.AutoShivCheckBox.Size = new Size(84, 19);
    this.AutoShivCheckBox.TabIndex = 42;
    this.AutoShivCheckBox.Text = "Auto Shiv";
    this.AutoShivCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AutoShivCheckBox, "Enables automatic use of Shiv. <i>Will cast when you have the Paralytic Poison talent to root the enemy.</i>");
    this.AutoShivCheckBox.\u000A = true;
    this.AutoShivCheckBox.CheckedChanged += new EventHandler(this.AutoShivCheckBox_CheckedChanged);
    this.AutoFlagReturnCheckBox.AutoSize = true;
    this.AutoFlagReturnCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AutoFlagReturnCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AutoFlagReturnCheckBox.Location = new Point(8, 200);
    this.AutoFlagReturnCheckBox.Name = "AutoFlagReturnCheckBox";
    this.AutoFlagReturnCheckBox.Size = new Size(129, 19);
    this.AutoFlagReturnCheckBox.TabIndex = 43;
    this.AutoFlagReturnCheckBox.Text = "Auto Flag Return";
    this.AutoFlagReturnCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AutoFlagReturnCheckBox, "Enables automatic returning of flags in battlegrounds.");
    this.AutoFlagReturnCheckBox.\u000A = true;
    this.AutoFlagReturnCheckBox.CheckedChanged += new EventHandler(this.AutoFlagReturnCheckBox_CheckedChanged);
    this.AutoRedirectCheckBox.AutoSize = true;
    this.AutoRedirectCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AutoRedirectCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AutoRedirectCheckBox.Location = new Point(8, 26);
    this.AutoRedirectCheckBox.Name = "AutoRedirectCheckBox";
    this.AutoRedirectCheckBox.Size = new Size(108, 19);
    this.AutoRedirectCheckBox.TabIndex = 35;
    this.AutoRedirectCheckBox.Text = "Auto Redirect";
    this.AutoRedirectCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AutoRedirectCheckBox, "Enables automatic use of Redirect.");
    this.AutoRedirectCheckBox.\u000A = true;
    this.AutoRedirectCheckBox.CheckedChanged += new EventHandler(this.AutoRedirectCheckBox_CheckedChanged);
    this.metroLabel74.AutoSize = true;
    this.metroLabel74.Location = new Point(4, 3);
    this.metroLabel74.Name = "metroLabel74";
    this.metroLabel74.Size = new Size(128 /*0x80*/, 19);
    this.metroLabel74.TabIndex = 36;
    this.metroLabel74.Text = "Automation Options";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel74, "");
    this.AutoKidneyCheckBox.AutoSize = true;
    this.AutoKidneyCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AutoKidneyCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AutoKidneyCheckBox.Location = new Point(8, 51);
    this.AutoKidneyCheckBox.Name = "AutoKidneyCheckBox";
    this.AutoKidneyCheckBox.Size = new Size(100, 19);
    this.AutoKidneyCheckBox.TabIndex = 37;
    this.AutoKidneyCheckBox.Text = "Auto Kidney";
    this.AutoKidneyCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AutoKidneyCheckBox, "Enables automatic use of Kidney Shot. <i>Will cast with 5 combo points and when the target has a bleed.</i>");
    this.AutoKidneyCheckBox.\u000A = true;
    this.AutoKidneyCheckBox.CheckedChanged += new EventHandler(this.AutoKidneyCheckBox_CheckedChanged);
    this.AutoShroudCheckBox.AutoSize = true;
    this.AutoShroudCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AutoShroudCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AutoShroudCheckBox.Location = new Point(8, 126);
    this.AutoShroudCheckBox.Name = "AutoShroudCheckBox";
    this.AutoShroudCheckBox.Size = new Size(103, 19);
    this.AutoShroudCheckBox.TabIndex = 40;
    this.AutoShroudCheckBox.Text = "Auto Shroud";
    this.AutoShroudCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AutoShroudCheckBox, "Enables automatic use of Shroud of Concealment during arenas. <i>Will delay casting against Rogue teams.</i>");
    this.AutoShroudCheckBox.\u000A = true;
    this.AutoShroudCheckBox.CheckedChanged += new EventHandler(this.AutoShroudCheckBox_CheckedChanged);
    this.AutoPreparationCheckBox.AutoSize = true;
    this.AutoPreparationCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AutoPreparationCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AutoPreparationCheckBox.Location = new Point(8, 76);
    this.AutoPreparationCheckBox.Name = "AutoPreparationCheckBox";
    this.AutoPreparationCheckBox.Size = new Size(130, 19);
    this.AutoPreparationCheckBox.TabIndex = 38;
    this.AutoPreparationCheckBox.Text = "Auto Preparation";
    this.AutoPreparationCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AutoPreparationCheckBox, "Enables automatic use of Preparation. <i>Will cast when Vanish, Evasion and Dismantle are on cooldown.</i>");
    this.AutoPreparationCheckBox.\u000A = true;
    this.AutoPreparationCheckBox.CheckedChanged += new EventHandler(this.AutoPreparationCheckBox_CheckedChanged);
    this.AutoSmokeBombCheckBox.AutoSize = true;
    this.AutoSmokeBombCheckBox.CheckAlign = ContentAlignment.TopCenter;
    this.AutoSmokeBombCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AutoSmokeBombCheckBox.Location = new Point(8, 101);
    this.AutoSmokeBombCheckBox.Name = "AutoSmokeBombCheckBox";
    this.AutoSmokeBombCheckBox.Size = new Size(140, 19);
    this.AutoSmokeBombCheckBox.TabIndex = 39;
    this.AutoSmokeBombCheckBox.Text = "Auto Smoke Bomb";
    this.AutoSmokeBombCheckBox.TextAlign = ContentAlignment.BottomCenter;
    this.\u0008\u0008_0.\u0001((Control) this.AutoSmokeBombCheckBox, "Enables automatic use of Smoke Bomb during arenas. <i>Will cast during burst cooldowns when the target is stunned and the enemy healer is not close by.</i>");
    this.AutoSmokeBombCheckBox.\u000A = true;
    this.AutoSmokeBombCheckBox.CheckedChanged += new EventHandler(this.AutoSmokeBombCheckBox_CheckedChanged);
    this.metroPanel14.Controls.Add((Control) this.nonFlickerGroupBox1);
    this.metroPanel14.Controls.Add((Control) this.ShadowstepRangeLabel);
    this.metroPanel14.Controls.Add((Control) this.metroLabel1);
    this.metroPanel14.Controls.Add((Control) this.ShadowstepRangeBar);
    this.metroPanel14.\u0011 = true;
    this.metroPanel14.\u0012 = false;
    this.metroPanel14.\u000F = 10;
    this.metroPanel14.Location = new Point(186, 9);
    this.metroPanel14.Name = "metroPanel14";
    this.metroPanel14.\u0010 = true;
    this.metroPanel14.Size = new Size(194, 284);
    this.metroPanel14.TabIndex = 25;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel14, "");
    this.metroPanel14.\u0014 = true;
    this.metroPanel14.\u0015 = false;
    this.metroPanel14.\u0010 = 10;
    this.\u0016\u0007_0.\u0005((Control) this.nonFlickerGroupBox1, true);
    this.nonFlickerGroupBox1.BackColor = System.Drawing.SystemColors.Window;
    this.nonFlickerGroupBox1.Controls.Add((Control) this.OffHandPoisonComboBox);
    this.nonFlickerGroupBox1.Controls.Add((Control) this.metroLabel26);
    this.nonFlickerGroupBox1.Controls.Add((Control) this.metroLabel27);
    this.nonFlickerGroupBox1.Controls.Add((Control) this.MainHandPoisonComboBox);
    this.nonFlickerGroupBox1.Font = new Font("Segoe UI Light", 8.25f, System.Drawing.FontStyle.Italic, GraphicsUnit.Point, (byte) 0);
    this.nonFlickerGroupBox1.Location = new Point(9, 5);
    this.nonFlickerGroupBox1.Name = "nonFlickerGroupBox1";
    this.nonFlickerGroupBox1.Size = new Size(172, 142);
    this.nonFlickerGroupBox1.TabIndex = 28;
    this.nonFlickerGroupBox1.TabStop = false;
    this.nonFlickerGroupBox1.Text = "Poisons";
    this.\u0008\u0008_0.\u0001((Control) this.nonFlickerGroupBox1, "");
    this.OffHandPoisonComboBox.FormattingEnabled = true;
    this.OffHandPoisonComboBox.ItemHeight = 23;
    this.OffHandPoisonComboBox.Location = new Point(7, 100);
    this.OffHandPoisonComboBox.Name = "OffHandPoisonComboBox";
    this.OffHandPoisonComboBox.Size = new Size(158, 29);
    this.OffHandPoisonComboBox.TabIndex = 22;
    this.\u0008\u0008_0.\u0001((Control) this.OffHandPoisonComboBox, "");
    this.OffHandPoisonComboBox.\u000A = true;
    this.OffHandPoisonComboBox.SelectedIndexChanged += new EventHandler(this.OffHandPoisonComboBox_SelectedIndexChanged);
    this.metroLabel26.AutoSize = true;
    this.metroLabel26.Location = new Point(7, 18);
    this.metroLabel26.Name = "metroLabel26";
    this.metroLabel26.Size = new Size(115, 19);
    this.metroLabel26.TabIndex = 21;
    this.metroLabel26.Text = "Main Hand Poison";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel26, "Select a main hand poison if you want to override the default poison.");
    this.metroLabel27.AutoSize = true;
    this.metroLabel27.Location = new Point(7, 78);
    this.metroLabel27.Name = "metroLabel27";
    this.metroLabel27.Size = new Size(105, 19);
    this.metroLabel27.TabIndex = 23;
    this.metroLabel27.Text = "Off Hand Poison";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel27, "Select an off hand hand poison if you want to override the default poison.");
    this.MainHandPoisonComboBox.FormattingEnabled = true;
    this.MainHandPoisonComboBox.ItemHeight = 23;
    this.MainHandPoisonComboBox.Location = new Point(7, 40);
    this.MainHandPoisonComboBox.Name = "MainHandPoisonComboBox";
    this.MainHandPoisonComboBox.Size = new Size(158, 29);
    this.MainHandPoisonComboBox.TabIndex = 20;
    this.\u0008\u0008_0.\u0001((Control) this.MainHandPoisonComboBox, "");
    this.MainHandPoisonComboBox.\u000A = true;
    this.MainHandPoisonComboBox.SelectedIndexChanged += new EventHandler(this.MainHandPoisonComboBox_SelectedIndexChanged);
    this.ShadowstepRangeLabel.AutoSize = true;
    this.ShadowstepRangeLabel.Location = new Point(161, 177);
    this.ShadowstepRangeLabel.Name = "ShadowstepRangeLabel";
    this.ShadowstepRangeLabel.Size = new Size(28, 19);
    this.ShadowstepRangeLabel.TabIndex = 27;
    this.ShadowstepRangeLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.ShadowstepRangeLabel, "");
    this.metroLabel1.AutoSize = true;
    this.metroLabel1.Location = new Point(13, 155);
    this.metroLabel1.Name = "metroLabel1";
    this.metroLabel1.Size = new Size(120, 19);
    this.metroLabel1.TabIndex = 26;
    this.metroLabel1.Text = "Shadowstep Range";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel1, "<p>Set the minimum range at which Shadowstep will be cast automatically. <i>Will only be cast when facing and moving towards an enemy.</i></p><p><b>Default: 15</b></p>");
    this.ShadowstepRangeBar.BackColor = Color.Transparent;
    this.ShadowstepRangeBar.\u0013 = 1;
    this.ShadowstepRangeBar.Location = new Point(16 /*0x10*/, 177);
    this.ShadowstepRangeBar.\u0011 = 25;
    this.ShadowstepRangeBar.\u0014 = 25;
    this.ShadowstepRangeBar.Name = "ShadowstepRangeBar";
    this.ShadowstepRangeBar.Size = new Size(139, 23);
    this.ShadowstepRangeBar.TabIndex = 25;
    this.ShadowstepRangeBar.Text = "metroTrackBar1";
    this.\u0008\u0008_0.\u0001((Control) this.ShadowstepRangeBar, "");
    this.ShadowstepRangeBar.\u000F = 25;
    this.ShadowstepRangeBar.\u000F += new EventHandler(this.method_21);
    this.ShadowstepRangeBar.MouseLeave += new EventHandler(this.ShadowstepRangeBar_MouseLeave);
    this.metroPanel15.Controls.Add((Control) this.TricksTarget);
    this.metroPanel15.Controls.Add((Control) this.metroLabel7);
    this.metroPanel15.Controls.Add((Control) this.EventBlacklist);
    this.metroPanel15.Controls.Add((Control) this.metroLabel25);
    this.metroPanel15.\u0011 = true;
    this.metroPanel15.\u0012 = false;
    this.metroPanel15.\u000F = 10;
    this.metroPanel15.Location = new Point(382, 9);
    this.metroPanel15.Name = "metroPanel15";
    this.metroPanel15.Size = new Size(194, 284);
    this.metroPanel15.TabIndex = 26;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel15, "");
    this.metroPanel15.\u0014 = true;
    this.metroPanel15.\u0015 = false;
    this.metroPanel15.\u0010 = 10;
    this.TricksTarget.BackColor = System.Drawing.SystemColors.ActiveCaption;
    this.TricksTarget.\u000F = \u0017\u000B.\u0002;
    this.TricksTarget.\u000F = new string[0];
    this.TricksTarget.Location = new Point(15, 26);
    this.TricksTarget.\u000F = (int) short.MaxValue;
    this.TricksTarget.Name = "TricksTarget";
    this.TricksTarget.\u000F = char.MinValue;
    this.TricksTarget.\u000F = "Player Name";
    this.TricksTarget.\u000F = ScrollBars.None;
    this.TricksTarget.\u0010 = "";
    this.TricksTarget.Size = new Size(158, 27);
    this.TricksTarget.TabIndex = 14;
    this.\u0008\u0008_0.\u0001((Control) this.TricksTarget, "Textbox Tooltip");
    this.TricksTarget.\u000A = true;
    this.TricksTarget.Leave += new EventHandler(this.TricksTarget_Leave);
    this.metroLabel7.AutoSize = true;
    this.metroLabel7.Location = new Point(15, 64 /*0x40*/);
    this.metroLabel7.Margin = new Padding(3);
    this.metroLabel7.Name = "metroLabel7";
    this.metroLabel7.Size = new Size(89, 19);
    this.metroLabel7.TabIndex = 17;
    this.metroLabel7.Text = "Event Blacklist";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel7, "Allows you to supply a list of spell ids separated by a comma, the event framework will not cast blacklisted spells.");
    this.EventBlacklist.AllowDrop = true;
    this.EventBlacklist.BackColor = System.Drawing.SystemColors.ActiveCaption;
    this.EventBlacklist.\u000F = \u0017\u000B.\u0002;
    this.EventBlacklist.\u000F = new string[0];
    this.EventBlacklist.Location = new Point(15, 86);
    this.EventBlacklist.\u000F = (int) short.MaxValue;
    this.EventBlacklist.Name = "EventBlacklist";
    this.EventBlacklist.\u000F = char.MinValue;
    this.EventBlacklist.\u000F = "e.g. 2094, 31224";
    this.EventBlacklist.\u000F = ScrollBars.None;
    this.EventBlacklist.\u0010 = "";
    this.EventBlacklist.Size = new Size(158, 27);
    this.EventBlacklist.TabIndex = 16 /*0x10*/;
    this.\u0008\u0008_0.\u0001((Control) this.EventBlacklist, "Textbox Tooltip");
    this.EventBlacklist.\u000A = true;
    this.EventBlacklist.Leave += new EventHandler(this.EventBlacklist_Leave);
    this.metroLabel25.AutoSize = true;
    this.metroLabel25.Location = new Point(15, 3);
    this.metroLabel25.Margin = new Padding(3);
    this.metroLabel25.Name = "metroLabel25";
    this.metroLabel25.Size = new Size(79, 19);
    this.metroLabel25.TabIndex = 15;
    this.metroLabel25.Text = "Tricks Target";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel25, "Name of a player you want to cast Tricks of the Trade on.");
    this.tabPageDefensive.Controls.Add((Control) this.metroPanel12);
    this.tabPageDefensive.Controls.Add((Control) this.metroPanel11);
    this.tabPageDefensive.Controls.Add((Control) this.metroPanel10);
    this.tabPageDefensive.\u000F = true;
    this.tabPageDefensive.\u0010 = true;
    this.tabPageDefensive.\u0011 = false;
    this.tabPageDefensive.\u000F = 10;
    this.tabPageDefensive.Location = new Point(4, 38);
    this.tabPageDefensive.Name = "tabPageDefensive";
    this.tabPageDefensive.Padding = new Padding(25);
    this.tabPageDefensive.Size = new Size(564, 303);
    this.tabPageDefensive.TabIndex = 0;
    this.tabPageDefensive.Text = "Defensive";
    this.\u0008\u0008_0.\u0001((Control) this.tabPageDefensive, "");
    this.tabPageDefensive.\u0012 = true;
    this.tabPageDefensive.\u0013 = true;
    this.tabPageDefensive.\u0014 = false;
    this.tabPageDefensive.\u0010 = 10;
    this.tabPageDefensive.Visible = false;
    this.metroPanel12.Controls.Add((Control) this.metroLabel86);
    this.metroPanel12.Controls.Add((Control) this.AutoMoveOnTrapsCheckBox);
    this.metroPanel12.Controls.Add((Control) this.metroLabel65);
    this.metroPanel12.Controls.Add((Control) this.ShadowstepTrapsCheckBox);
    this.metroPanel12.Controls.Add((Control) this.metroLabel69);
    this.metroPanel12.Controls.Add((Control) this.FeintHPBar);
    this.metroPanel12.Controls.Add((Control) this.FeintHPLabel);
    this.metroPanel12.Controls.Add((Control) this.FeintInMeleeRangeCheckBox);
    this.metroPanel12.Controls.Add((Control) this.FeintLastDamageBar);
    this.metroPanel12.Controls.Add((Control) this.metroLabel67);
    this.metroPanel12.Controls.Add((Control) this.FeintLastDamageLabel);
    this.metroPanel12.\u0011 = true;
    this.metroPanel12.\u0012 = false;
    this.metroPanel12.\u000F = 10;
    this.metroPanel12.Location = new Point(382, 9);
    this.metroPanel12.Name = "metroPanel12";
    this.metroPanel12.Size = new Size(194, 284);
    this.metroPanel12.TabIndex = 4;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel12, "");
    this.metroPanel12.\u0014 = true;
    this.metroPanel12.\u0015 = false;
    this.metroPanel12.\u0010 = 10;
    this.metroLabel86.AutoSize = true;
    this.metroLabel86.\u000F = \u0010\u000B.\u0003;
    this.metroLabel86.Location = new Point(8, 83);
    this.metroLabel86.Name = "metroLabel86";
    this.metroLabel86.Size = new Size(81, 19);
    this.metroLabel86.TabIndex = 45;
    this.metroLabel86.Text = "Feint Logic";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel86, "");
    this.AutoMoveOnTrapsCheckBox.AutoSize = true;
    this.AutoMoveOnTrapsCheckBox.\u000F = \u001D\u000B.\u0002;
    this.AutoMoveOnTrapsCheckBox.Location = new Point(11, 52);
    this.AutoMoveOnTrapsCheckBox.Name = "AutoMoveOnTrapsCheckBox";
    this.AutoMoveOnTrapsCheckBox.Size = new Size(154, 19);
    this.AutoMoveOnTrapsCheckBox.TabIndex = 26;
    this.AutoMoveOnTrapsCheckBox.Text = "Auto Move On Traps";
    this.\u0008\u0008_0.\u0001((Control) this.AutoMoveOnTrapsCheckBox, "If enabled the profile will try to move your character precisely to the location of the Freezing Trap.");
    this.AutoMoveOnTrapsCheckBox.\u000A = true;
    this.AutoMoveOnTrapsCheckBox.CheckedChanged += new EventHandler(this.AutoMoveOnTrapsCheckBox_CheckedChanged);
    this.metroLabel65.AutoSize = true;
    this.metroLabel65.Location = new Point(8, 4);
    this.metroLabel65.Name = "metroLabel65";
    this.metroLabel65.Size = new Size(114, 19);
    this.metroLabel65.TabIndex = 25;
    this.metroLabel65.Text = "Defensive Options";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel65, "");
    this.ShadowstepTrapsCheckBox.AutoSize = true;
    this.ShadowstepTrapsCheckBox.\u000F = \u001D\u000B.\u0002;
    this.ShadowstepTrapsCheckBox.Location = new Point(11, 28);
    this.ShadowstepTrapsCheckBox.Name = "ShadowstepTrapsCheckBox";
    this.ShadowstepTrapsCheckBox.Size = new Size(136, 19);
    this.ShadowstepTrapsCheckBox.TabIndex = 24;
    this.ShadowstepTrapsCheckBox.Text = "Shadowstep Traps";
    this.\u0008\u0008_0.\u0001((Control) this.ShadowstepTrapsCheckBox, "If enabled the profile will try to eat traps for your healer, assuming they are crowd-controlled when the Freezing Trap is cast.");
    this.ShadowstepTrapsCheckBox.\u000A = true;
    this.ShadowstepTrapsCheckBox.CheckedChanged += new EventHandler(this.ShadowstepTrapsCheckBox_CheckedChanged);
    this.metroLabel69.AutoSize = true;
    this.metroLabel69.Location = new Point(11, 107);
    this.metroLabel69.Name = "metroLabel69";
    this.metroLabel69.Size = new Size(58, 19);
    this.metroLabel69.TabIndex = 39;
    this.metroLabel69.Text = "Feint HP";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel69, "<p>Minimum health required to cast Feint.</p><p><b>Default: 60</b></p>");
    this.FeintHPBar.BackColor = Color.Transparent;
    this.FeintHPBar.Location = new Point(14, 129);
    this.FeintHPBar.\u0014 = 20;
    this.FeintHPBar.Name = "FeintHPBar";
    this.FeintHPBar.Size = new Size(139, 23);
    this.FeintHPBar.\u0012 = 5;
    this.FeintHPBar.TabIndex = 38;
    this.FeintHPBar.Text = "metroTrackBar1";
    this.\u0008\u0008_0.\u0001((Control) this.FeintHPBar, "");
    this.FeintHPBar.\u000F = 90;
    this.FeintHPBar.\u000F += new EventHandler(this.method_12);
    this.FeintHPBar.MouseLeave += new EventHandler(this.FeintHPBar_MouseLeave);
    this.FeintHPLabel.AutoSize = true;
    this.FeintHPLabel.Location = new Point(159, 131);
    this.FeintHPLabel.Name = "FeintHPLabel";
    this.FeintHPLabel.Size = new Size(28, 19);
    this.FeintHPLabel.TabIndex = 40;
    this.FeintHPLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.FeintHPLabel, "");
    this.FeintInMeleeRangeCheckBox.AutoSize = true;
    this.FeintInMeleeRangeCheckBox.\u000F = \u001D\u000B.\u0002;
    this.FeintInMeleeRangeCheckBox.Location = new Point(14, 206);
    this.FeintInMeleeRangeCheckBox.Name = "FeintInMeleeRangeCheckBox";
    this.FeintInMeleeRangeCheckBox.Size = new Size(154, 19);
    this.FeintInMeleeRangeCheckBox.TabIndex = 44;
    this.FeintInMeleeRangeCheckBox.Text = "Feint In Melee Range";
    this.\u0008\u0008_0.\u0001((Control) this.FeintInMeleeRangeCheckBox, "Enables or disables the use of Feint when in melee range, disabling can prevent unnecessary Feint spam when trying to kill a target, but may  in turn require more manual usage of Feint.");
    this.FeintInMeleeRangeCheckBox.\u000A = true;
    this.FeintInMeleeRangeCheckBox.CheckedChanged += new EventHandler(this.FeintInMeleeRangeCheckBox_CheckedChanged);
    this.FeintLastDamageBar.BackColor = Color.Transparent;
    this.FeintLastDamageBar.Location = new Point(14, 177);
    this.FeintLastDamageBar.\u0011 = 20;
    this.FeintLastDamageBar.\u0014 = 20;
    this.FeintLastDamageBar.Name = "FeintLastDamageBar";
    this.FeintLastDamageBar.Size = new Size(139, 23);
    this.FeintLastDamageBar.TabIndex = 41;
    this.FeintLastDamageBar.Text = "metroTrackBar9";
    this.\u0008\u0008_0.\u0001((Control) this.FeintLastDamageBar, "");
    this.FeintLastDamageBar.\u000F = 20;
    this.FeintLastDamageBar.\u000F += new EventHandler(this.method_13);
    this.FeintLastDamageBar.MouseLeave += new EventHandler(this.FeintLastDamageBar_MouseLeave);
    this.metroLabel67.AutoSize = true;
    this.metroLabel67.Location = new Point(11, 155);
    this.metroLabel67.Name = "metroLabel67";
    this.metroLabel67.Size = new Size(117, 19);
    this.metroLabel67.TabIndex = 42;
    this.metroLabel67.Text = "Feint Last Damage";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel67, "<p>Set the number of seconds of not taking damage after which the profile will no longer cast Feint.</p><p><b>Default: 5</b></p>");
    this.FeintLastDamageLabel.AutoSize = true;
    this.FeintLastDamageLabel.Location = new Point(159, 179);
    this.FeintLastDamageLabel.Name = "FeintLastDamageLabel";
    this.FeintLastDamageLabel.Size = new Size(28, 19);
    this.FeintLastDamageLabel.TabIndex = 43;
    this.FeintLastDamageLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.FeintLastDamageLabel, "");
    this.metroPanel11.Controls.Add((Control) this.ShadowstepBufferLabel);
    this.metroPanel11.Controls.Add((Control) this.GougeNoKickHPLabel);
    this.metroPanel11.Controls.Add((Control) this.metroLabel77);
    this.metroPanel11.Controls.Add((Control) this.metroLabel83);
    this.metroPanel11.Controls.Add((Control) this.ShadowstepBufferBar);
    this.metroPanel11.Controls.Add((Control) this.GougeNoKickHPBar);
    this.metroPanel11.Controls.Add((Control) this.InterruptMinimumLabel);
    this.metroPanel11.Controls.Add((Control) this.GougeDelayLabel);
    this.metroPanel11.Controls.Add((Control) this.metroLabel79);
    this.metroPanel11.Controls.Add((Control) this.metroLabel85);
    this.metroPanel11.Controls.Add((Control) this.InterruptMinimumBar);
    this.metroPanel11.Controls.Add((Control) this.GougeDelayBar);
    this.metroPanel11.Controls.Add((Control) this.InterruptDelayLabel);
    this.metroPanel11.Controls.Add((Control) this.metroLabel75);
    this.metroPanel11.Controls.Add((Control) this.metroLabel81);
    this.metroPanel11.Controls.Add((Control) this.InterruptDelayBar);
    this.metroPanel11.\u0011 = true;
    this.metroPanel11.\u0012 = false;
    this.metroPanel11.\u000F = 10;
    this.metroPanel11.Location = new Point(186, 9);
    this.metroPanel11.Name = "metroPanel11";
    this.metroPanel11.\u0010 = true;
    this.metroPanel11.Size = new Size(194, 284);
    this.metroPanel11.TabIndex = 3;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel11, "");
    this.metroPanel11.\u0014 = true;
    this.metroPanel11.\u0015 = false;
    this.metroPanel11.\u0010 = 10;
    this.ShadowstepBufferLabel.AutoSize = true;
    this.ShadowstepBufferLabel.Location = new Point(159, 150);
    this.ShadowstepBufferLabel.Name = "ShadowstepBufferLabel";
    this.ShadowstepBufferLabel.Size = new Size(26, 19);
    this.ShadowstepBufferLabel.TabIndex = 46;
    this.ShadowstepBufferLabel.Text = "0.2";
    this.\u0008\u0008_0.\u0001((Control) this.ShadowstepBufferLabel, "");
    this.GougeNoKickHPLabel.AutoSize = true;
    this.GougeNoKickHPLabel.Location = new Point(159, 246);
    this.GougeNoKickHPLabel.Name = "GougeNoKickHPLabel";
    this.GougeNoKickHPLabel.Size = new Size(23, 19);
    this.GougeNoKickHPLabel.TabIndex = 50;
    this.GougeNoKickHPLabel.Text = "80";
    this.\u0008\u0008_0.\u0001((Control) this.GougeNoKickHPLabel, "");
    this.metroLabel77.AutoSize = true;
    this.metroLabel77.Location = new Point(11, 126);
    this.metroLabel77.Name = "metroLabel77";
    this.metroLabel77.Size = new Size(118, 19);
    this.metroLabel77.TabIndex = 45;
    this.metroLabel77.Text = "Shadowstep Buffer";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel77, "");
    this.metroLabel83.AutoSize = true;
    this.metroLabel83.Location = new Point(11, 222);
    this.metroLabel83.Name = "metroLabel83";
    this.metroLabel83.Size = new Size(117, 19);
    this.metroLabel83.TabIndex = 49;
    this.metroLabel83.Text = "Gouge No Kick HP";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel83, "<p>Minimum target health required to Gouge when Kick is on cooldown, useful to prevent Gouging casts when the target is not under any pressure.</p><p><b>Default: 70</b></p>");
    this.ShadowstepBufferBar.BackColor = Color.Transparent;
    this.ShadowstepBufferBar.Location = new Point(14, 148);
    this.ShadowstepBufferBar.\u0011 = 50;
    this.ShadowstepBufferBar.\u0010 = 10;
    this.ShadowstepBufferBar.\u0014 = 8;
    this.ShadowstepBufferBar.Name = "ShadowstepBufferBar";
    this.ShadowstepBufferBar.Size = new Size(139, 23);
    this.ShadowstepBufferBar.\u0012 = 5;
    this.ShadowstepBufferBar.TabIndex = 44;
    this.ShadowstepBufferBar.Text = "metroTrackBar13";
    this.\u0008\u0008_0.\u0001((Control) this.ShadowstepBufferBar, "");
    this.ShadowstepBufferBar.\u000F = 20;
    this.ShadowstepBufferBar.\u000F += new EventHandler(this.method_6);
    this.ShadowstepBufferBar.MouseLeave += new EventHandler(this.ShadowstepBufferBar_MouseLeave);
    this.GougeNoKickHPBar.BackColor = Color.Transparent;
    this.GougeNoKickHPBar.Location = new Point(14, 244);
    this.GougeNoKickHPBar.\u0014 = 20;
    this.GougeNoKickHPBar.Name = "GougeNoKickHPBar";
    this.GougeNoKickHPBar.Size = new Size(139, 23);
    this.GougeNoKickHPBar.\u0012 = 5;
    this.GougeNoKickHPBar.TabIndex = 48 /*0x30*/;
    this.GougeNoKickHPBar.Text = "metroTrackBar16";
    this.\u0008\u0008_0.\u0001((Control) this.GougeNoKickHPBar, "");
    this.GougeNoKickHPBar.\u000F = 80 /*0x50*/;
    this.GougeNoKickHPBar.\u000F += new EventHandler(this.method_8);
    this.GougeNoKickHPBar.MouseLeave += new EventHandler(this.GougeNoKickHPBar_MouseLeave);
    this.InterruptMinimumLabel.AutoSize = true;
    this.InterruptMinimumLabel.Location = new Point(159, 102);
    this.InterruptMinimumLabel.Name = "InterruptMinimumLabel";
    this.InterruptMinimumLabel.Size = new Size(26, 19);
    this.InterruptMinimumLabel.TabIndex = 43;
    this.InterruptMinimumLabel.Text = "0.2";
    this.\u0008\u0008_0.\u0001((Control) this.InterruptMinimumLabel, "");
    this.GougeDelayLabel.AutoSize = true;
    this.GougeDelayLabel.Location = new Point(159, 197);
    this.GougeDelayLabel.Name = "GougeDelayLabel";
    this.GougeDelayLabel.Size = new Size(26, 19);
    this.GougeDelayLabel.TabIndex = 47;
    this.GougeDelayLabel.Text = "0.7";
    this.\u0008\u0008_0.\u0001((Control) this.GougeDelayLabel, "");
    this.metroLabel79.AutoSize = true;
    this.metroLabel79.Location = new Point(11, 78);
    this.metroLabel79.Name = "metroLabel79";
    this.metroLabel79.Size = new Size(119, 19);
    this.metroLabel79.TabIndex = 42;
    this.metroLabel79.Text = "Interrupt Minimum";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel79, "<p>Minimum delay before interrupting a cast, increase this value if you feel your interrupts are going off too fast.</p><p><b>Default: 0.2</b></p>");
    this.metroLabel85.AutoSize = true;
    this.metroLabel85.Location = new Point(11, 174);
    this.metroLabel85.Name = "metroLabel85";
    this.metroLabel85.Size = new Size(84, 19);
    this.metroLabel85.TabIndex = 46;
    this.metroLabel85.Text = "Gouge Delay";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel85, "<p>Controls how late into a cast the profile will attempt to Gouge.</p><p><b>Default: 0.7</b></p>");
    this.InterruptMinimumBar.BackColor = Color.Transparent;
    this.InterruptMinimumBar.Location = new Point(14, 100);
    this.InterruptMinimumBar.\u0011 = 50;
    this.InterruptMinimumBar.\u0010 = 10;
    this.InterruptMinimumBar.\u0014 = 8;
    this.InterruptMinimumBar.Name = "InterruptMinimumBar";
    this.InterruptMinimumBar.Size = new Size(139, 23);
    this.InterruptMinimumBar.\u0012 = 5;
    this.InterruptMinimumBar.TabIndex = 41;
    this.InterruptMinimumBar.Text = "metroTrackBar14";
    this.\u0008\u0008_0.\u0001((Control) this.InterruptMinimumBar, "");
    this.InterruptMinimumBar.\u000F = 20;
    this.InterruptMinimumBar.\u000F += new EventHandler(this.method_5);
    this.InterruptMinimumBar.MouseLeave += new EventHandler(this.InterruptMinimumBar_MouseLeave);
    this.GougeDelayBar.BackColor = Color.Transparent;
    this.GougeDelayBar.Location = new Point(14, 196);
    this.GougeDelayBar.\u0010 = 10;
    this.GougeDelayBar.\u0014 = 18;
    this.GougeDelayBar.Name = "GougeDelayBar";
    this.GougeDelayBar.Size = new Size(139, 23);
    this.GougeDelayBar.\u0012 = 5;
    this.GougeDelayBar.TabIndex = 45;
    this.GougeDelayBar.Text = "metroTrackBar1";
    this.\u0008\u0008_0.\u0001((Control) this.GougeDelayBar, "");
    this.GougeDelayBar.\u000F = 70;
    this.GougeDelayBar.\u000F += new EventHandler(this.method_7);
    this.GougeDelayBar.MouseLeave += new EventHandler(this.GougeDelayBar_MouseLeave);
    this.InterruptDelayLabel.AutoSize = true;
    this.InterruptDelayLabel.Location = new Point(159, 53);
    this.InterruptDelayLabel.Name = "InterruptDelayLabel";
    this.InterruptDelayLabel.Size = new Size(26, 19);
    this.InterruptDelayLabel.TabIndex = 40;
    this.InterruptDelayLabel.Text = "0.5";
    this.\u0008\u0008_0.\u0001((Control) this.InterruptDelayLabel, "");
    this.metroLabel75.AutoSize = true;
    this.metroLabel75.\u000F = \u0010\u000B.\u0003;
    this.metroLabel75.Location = new Point(10, 4);
    this.metroLabel75.Name = "metroLabel75";
    this.metroLabel75.Size = new Size(108, 19);
    this.metroLabel75.TabIndex = 27;
    this.metroLabel75.Text = "Interrupt Logic";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel75, "");
    this.metroLabel81.AutoSize = true;
    this.metroLabel81.Location = new Point(11, 30);
    this.metroLabel81.Name = "metroLabel81";
    this.metroLabel81.Size = new Size(95, 19);
    this.metroLabel81.TabIndex = 39;
    this.metroLabel81.Text = "Interrupt Delay";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel81, "<p>Remaining cast time at which the profile will attempt to interrupt a cast, increase this value if your interrupts are going off too late.</p><p><b>Default: 0.5</b></p>");
    this.InterruptDelayBar.BackColor = Color.Transparent;
    this.InterruptDelayBar.\u0013 = 10;
    this.InterruptDelayBar.Location = new Point(14, 52);
    this.InterruptDelayBar.\u0010 = 10;
    this.InterruptDelayBar.\u0014 = 18;
    this.InterruptDelayBar.Name = "InterruptDelayBar";
    this.InterruptDelayBar.Size = new Size(139, 23);
    this.InterruptDelayBar.\u0012 = 5;
    this.InterruptDelayBar.TabIndex = 38;
    this.InterruptDelayBar.Text = "metroTrackBar1";
    this.\u0008\u0008_0.\u0001((Control) this.InterruptDelayBar, "");
    this.InterruptDelayBar.\u000F += new EventHandler(this.method_4);
    this.InterruptDelayBar.MouseLeave += new EventHandler(this.InterruptDelayBar_MouseLeave);
    this.metroPanel10.Controls.Add((Control) this.HealthstoneHPLabel);
    this.metroPanel10.Controls.Add((Control) this.metroLabel64);
    this.metroPanel10.Controls.Add((Control) this.HealthstoneHPBar);
    this.metroPanel10.Controls.Add((Control) this.RecuperateHPLabel);
    this.metroPanel10.Controls.Add((Control) this.metroLabel9);
    this.metroPanel10.Controls.Add((Control) this.RecuperateHPBar);
    this.metroPanel10.Controls.Add((Control) this.TeammateSupportLabel);
    this.metroPanel10.Controls.Add((Control) this.metroLabel61);
    this.metroPanel10.Controls.Add((Control) this.TeammateSupportBar);
    this.metroPanel10.\u0011 = true;
    this.metroPanel10.\u0012 = false;
    this.metroPanel10.\u000F = 10;
    this.metroPanel10.Location = new Point(-5, 9);
    this.metroPanel10.Name = "metroPanel10";
    this.metroPanel10.\u0010 = true;
    this.metroPanel10.Size = new Size(188, 284);
    this.metroPanel10.TabIndex = 2;
    this.\u0008\u0008_0.\u0001((Control) this.metroPanel10, "");
    this.metroPanel10.\u0014 = true;
    this.metroPanel10.\u0015 = false;
    this.metroPanel10.\u0010 = 10;
    this.HealthstoneHPLabel.AutoSize = true;
    this.HealthstoneHPLabel.Location = new Point(153, 124);
    this.HealthstoneHPLabel.Name = "HealthstoneHPLabel";
    this.HealthstoneHPLabel.Size = new Size(28, 19);
    this.HealthstoneHPLabel.TabIndex = 37;
    this.HealthstoneHPLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.HealthstoneHPLabel, "");
    this.metroLabel64.AutoSize = true;
    this.metroLabel64.Location = new Point(5, 100);
    this.metroLabel64.Name = "metroLabel64";
    this.metroLabel64.Size = new Size(98, 19);
    this.metroLabel64.TabIndex = 36;
    this.metroLabel64.Text = "Healthstone HP";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel64, "<p>Minimum health required to use Healthstone.</p><p><b>Default: 30</b></p>");
    this.HealthstoneHPBar.BackColor = Color.Transparent;
    this.HealthstoneHPBar.Location = new Point(8, 122);
    this.HealthstoneHPBar.\u0014 = 20;
    this.HealthstoneHPBar.Name = "HealthstoneHPBar";
    this.HealthstoneHPBar.Size = new Size(139, 23);
    this.HealthstoneHPBar.\u0012 = 5;
    this.HealthstoneHPBar.TabIndex = 35;
    this.HealthstoneHPBar.Text = "metroTrackBar8";
    this.\u0008\u0008_0.\u0001((Control) this.HealthstoneHPBar, "");
    this.HealthstoneHPBar.\u000F = 30;
    this.HealthstoneHPBar.\u000F += new EventHandler(this.method_11);
    this.HealthstoneHPBar.MouseLeave += new EventHandler(this.HealthstoneHPBar_MouseLeave);
    this.RecuperateHPLabel.AutoSize = true;
    this.RecuperateHPLabel.Location = new Point(153, 76);
    this.RecuperateHPLabel.Name = "RecuperateHPLabel";
    this.RecuperateHPLabel.Size = new Size(28, 19);
    this.RecuperateHPLabel.TabIndex = 34;
    this.RecuperateHPLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.RecuperateHPLabel, "");
    this.metroLabel9.AutoSize = true;
    this.metroLabel9.Location = new Point(5, 52);
    this.metroLabel9.Name = "metroLabel9";
    this.metroLabel9.Size = new Size(96 /*0x60*/, 19);
    this.metroLabel9.TabIndex = 33;
    this.metroLabel9.Text = "Recuperate HP";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel9, "<p>Minimum health required to cast Recuperate.</p><p><b>Default: 50</b></p>");
    this.RecuperateHPBar.BackColor = Color.Transparent;
    this.RecuperateHPBar.Location = new Point(8, 74);
    this.RecuperateHPBar.\u0014 = 20;
    this.RecuperateHPBar.Name = "RecuperateHPBar";
    this.RecuperateHPBar.Size = new Size(139, 23);
    this.RecuperateHPBar.\u0012 = 5;
    this.RecuperateHPBar.TabIndex = 32 /*0x20*/;
    this.RecuperateHPBar.Text = "metroTrackBar6";
    this.\u0008\u0008_0.\u0001((Control) this.RecuperateHPBar, "");
    this.RecuperateHPBar.\u000F = 59;
    this.RecuperateHPBar.\u000F += new EventHandler(this.method_10);
    this.RecuperateHPBar.MouseLeave += new EventHandler(this.RecuperateHPBar_MouseLeave);
    this.TeammateSupportLabel.AutoSize = true;
    this.TeammateSupportLabel.Location = new Point(153, 27);
    this.TeammateSupportLabel.Name = "TeammateSupportLabel";
    this.TeammateSupportLabel.Size = new Size(28, 19);
    this.TeammateSupportLabel.TabIndex = 31 /*0x1F*/;
    this.TeammateSupportLabel.Text = "120";
    this.\u0008\u0008_0.\u0001((Control) this.TeammateSupportLabel, "");
    this.metroLabel61.AutoSize = true;
    this.metroLabel61.Location = new Point(5, 4);
    this.metroLabel61.Name = "metroLabel61";
    this.metroLabel61.Size = new Size(143, 19);
    this.metroLabel61.TabIndex = 30;
    this.metroLabel61.Text = "Teammate Support HP";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel61, "<p>Minimum health required to use Dismantle, Cheap Shot, Garrote or Shiv when a team member is low on health.</p><p><b>Default: 40</b></p>");
    this.TeammateSupportBar.BackColor = Color.Transparent;
    this.TeammateSupportBar.Location = new Point(8, 26);
    this.TeammateSupportBar.\u0014 = 20;
    this.TeammateSupportBar.Name = "TeammateSupportBar";
    this.TeammateSupportBar.Size = new Size(139, 23);
    this.TeammateSupportBar.\u0012 = 5;
    this.TeammateSupportBar.TabIndex = 29;
    this.TeammateSupportBar.Text = "metroTrackBar1";
    this.\u0008\u0008_0.\u0001((Control) this.TeammateSupportBar, "");
    this.TeammateSupportBar.\u000F = 40;
    this.TeammateSupportBar.\u000F += new EventHandler(this.method_9);
    this.TeammateSupportBar.MouseLeave += new EventHandler(this.TeammateSupportBar_MouseLeave);
    this.tabPageKeybinds.Controls.Add((Control) this.KeyBindPanel3);
    this.tabPageKeybinds.Controls.Add((Control) this.KeyBindPanel2);
    this.tabPageKeybinds.Controls.Add((Control) this.KeyBindPanel1);
    this.tabPageKeybinds.\u000F = true;
    this.tabPageKeybinds.\u0010 = true;
    this.tabPageKeybinds.\u0011 = false;
    this.tabPageKeybinds.\u000F = 10;
    this.tabPageKeybinds.Location = new Point(4, 38);
    this.tabPageKeybinds.Name = "tabPageKeybinds";
    this.tabPageKeybinds.Size = new Size(564, 303);
    this.tabPageKeybinds.TabIndex = 5;
    this.tabPageKeybinds.Text = "Keybinds";
    this.\u0008\u0008_0.\u0001((Control) this.tabPageKeybinds, "");
    this.tabPageKeybinds.\u0012 = true;
    this.tabPageKeybinds.\u0013 = true;
    this.tabPageKeybinds.\u0014 = false;
    this.tabPageKeybinds.\u0010 = 10;
    this.tabPageKeybinds.Visible = false;
    this.KeyBindPanel3.\u0016 = true;
    this.KeyBindPanel3.Controls.Add((Control) this.FastKickKeyBindButton);
    this.KeyBindPanel3.Controls.Add((Control) this.metroLabel37);
    this.KeyBindPanel3.Controls.Add((Control) this.RestealthKeyBindButton);
    this.KeyBindPanel3.Controls.Add((Control) this.metroLabel36);
    this.KeyBindPanel3.Controls.Add((Control) this.SmokeBombKeyBindButton);
    this.KeyBindPanel3.Controls.Add((Control) this.metroLabel35);
    this.KeyBindPanel3.Controls.Add((Control) this.KidneyShotKeyBindButton);
    this.KeyBindPanel3.Controls.Add((Control) this.metroLabel34);
    this.KeyBindPanel3.Controls.Add((Control) this.RedirectKidneyKeyBindButton);
    this.KeyBindPanel3.Controls.Add((Control) this.metroLabel32);
    this.KeyBindPanel3.Controls.Add((Control) this.GougeKeyBindButton);
    this.KeyBindPanel3.Controls.Add((Control) this.metroLabel31);
    this.KeyBindPanel3.Controls.Add((Control) this.BlindKeyBindButton);
    this.KeyBindPanel3.Controls.Add((Control) this.metroLabel24);
    this.KeyBindPanel3.\u000F = true;
    this.KeyBindPanel3.\u0011 = true;
    this.KeyBindPanel3.\u0012 = false;
    this.KeyBindPanel3.\u000F = 10;
    this.KeyBindPanel3.Location = new Point(371, 12);
    this.KeyBindPanel3.Name = "KeyBindPanel3";
    this.KeyBindPanel3.Size = new Size(189, 284);
    this.KeyBindPanel3.TabIndex = 12;
    this.\u0008\u0008_0.\u0001((Control) this.KeyBindPanel3, "");
    this.KeyBindPanel3.\u0013 = true;
    this.KeyBindPanel3.\u0014 = true;
    this.KeyBindPanel3.\u0015 = false;
    this.KeyBindPanel3.\u0010 = 10;
    this.KeyBindPanel3.MouseEnter += new EventHandler(this.KeyBindPanel3_MouseEnter);
    this.FastKickKeyBindButton.Location = new Point(20, 462);
    this.FastKickKeyBindButton.Name = "FastKickKeyBindButton";
    this.FastKickKeyBindButton.Size = new Size(132, 43);
    this.FastKickKeyBindButton.TabIndex = 20;
    this.FastKickKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.FastKickKeyBindButton, "");
    this.FastKickKeyBindButton.\u000A = true;
    this.FastKickKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.FastKickKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.FastKickKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.FastKickKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel37.AutoSize = true;
    this.metroLabel37.\u000F = \u000F\u000B.\u0001;
    this.metroLabel37.Location = new Point(20, 442);
    this.metroLabel37.Name = "metroLabel37";
    this.metroLabel37.Size = new Size(48 /*0x30*/, 15);
    this.metroLabel37.TabIndex = 21;
    this.metroLabel37.Text = "Fast Kick";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel37, "Set the fast kick key. <i>Your next interrupt will be cast as early/fast as possible.</i>");
    this.RestealthKeyBindButton.Location = new Point(20, 388);
    this.RestealthKeyBindButton.Name = "RestealthKeyBindButton";
    this.RestealthKeyBindButton.Size = new Size(132, 43);
    this.RestealthKeyBindButton.TabIndex = 18;
    this.RestealthKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.RestealthKeyBindButton, "");
    this.RestealthKeyBindButton.\u000A = true;
    this.RestealthKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.RestealthKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.RestealthKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.RestealthKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel36.AutoSize = true;
    this.metroLabel36.\u000F = \u000F\u000B.\u0001;
    this.metroLabel36.Location = new Point(20, 368);
    this.metroLabel36.Name = "metroLabel36";
    this.metroLabel36.Size = new Size(92, 15);
    this.metroLabel36.TabIndex = 19;
    this.metroLabel36.Text = "Manual Restealth";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel36, "Set the manual restealth key. <i>Will stop auto-attacking and try to re-stealth as soon as possible.</i>");
    this.SmokeBombKeyBindButton.Location = new Point(20, 314);
    this.SmokeBombKeyBindButton.Name = "SmokeBombKeyBindButton";
    this.SmokeBombKeyBindButton.Size = new Size(132, 43);
    this.SmokeBombKeyBindButton.TabIndex = 16 /*0x10*/;
    this.SmokeBombKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.SmokeBombKeyBindButton, "");
    this.SmokeBombKeyBindButton.\u000A = true;
    this.SmokeBombKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.SmokeBombKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.SmokeBombKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.SmokeBombKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel35.AutoSize = true;
    this.metroLabel35.\u000F = \u000F\u000B.\u0001;
    this.metroLabel35.Location = new Point(20, 294);
    this.metroLabel35.Name = "metroLabel35";
    this.metroLabel35.Size = new Size(75, 15);
    this.metroLabel35.TabIndex = 17;
    this.metroLabel35.Text = "Smoke Bomb";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel35, "Set the Smoke Bomb key.");
    this.KidneyShotKeyBindButton.Location = new Point(20, 240 /*0xF0*/);
    this.KidneyShotKeyBindButton.Name = "KidneyShotKeyBindButton";
    this.KidneyShotKeyBindButton.Size = new Size(132, 43);
    this.KidneyShotKeyBindButton.TabIndex = 14;
    this.KidneyShotKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.KidneyShotKeyBindButton, "");
    this.KidneyShotKeyBindButton.\u000A = true;
    this.KidneyShotKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.KidneyShotKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.KidneyShotKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.KidneyShotKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel34.AutoSize = true;
    this.metroLabel34.\u000F = \u000F\u000B.\u0001;
    this.metroLabel34.Location = new Point(20, 220);
    this.metroLabel34.Name = "metroLabel34";
    this.metroLabel34.Size = new Size(120, 15);
    this.metroLabel34.TabIndex = 15;
    this.metroLabel34.Text = "Kidney Shot + Shuriken";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel34, "Set the Kidney Shot/Shuriken Toss key (will cast Throw if no Shuriken Toss).");
    this.RedirectKidneyKeyBindButton.Location = new Point(20, 166);
    this.RedirectKidneyKeyBindButton.Name = "RedirectKidneyKeyBindButton";
    this.RedirectKidneyKeyBindButton.Size = new Size(132, 43);
    this.RedirectKidneyKeyBindButton.TabIndex = 12;
    this.RedirectKidneyKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.RedirectKidneyKeyBindButton, "");
    this.RedirectKidneyKeyBindButton.\u000A = true;
    this.RedirectKidneyKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.RedirectKidneyKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.RedirectKidneyKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.RedirectKidneyKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel32.AutoSize = true;
    this.metroLabel32.\u000F = \u000F\u000B.\u0001;
    this.metroLabel32.Location = new Point(20, 146);
    this.metroLabel32.Name = "metroLabel32";
    this.metroLabel32.Size = new Size(109, 15);
    this.metroLabel32.TabIndex = 13;
    this.metroLabel32.Text = "Redirect Kidney Shot";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel32, "Set the key to cast Redirect Kidney Shot. <i>Without using the focus modifier the profile will build to 5 combo points and wait for you to switch targets, if holding the focus modifier it will Redirect Kidney Shot your focus target.</i>");
    this.GougeKeyBindButton.Location = new Point(20, 92);
    this.GougeKeyBindButton.Name = "GougeKeyBindButton";
    this.GougeKeyBindButton.Size = new Size(132, 43);
    this.GougeKeyBindButton.TabIndex = 10;
    this.GougeKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.GougeKeyBindButton, "");
    this.GougeKeyBindButton.\u000A = true;
    this.GougeKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.GougeKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.GougeKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.GougeKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel31.AutoSize = true;
    this.metroLabel31.\u000F = \u000F\u000B.\u0001;
    this.metroLabel31.Location = new Point(20, 72);
    this.metroLabel31.Name = "metroLabel31";
    this.metroLabel31.Size = new Size(41, 15);
    this.metroLabel31.TabIndex = 11;
    this.metroLabel31.Text = "Gouge";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel31, "Set the key to cast Gouge.");
    this.BlindKeyBindButton.Location = new Point(20, 17);
    this.BlindKeyBindButton.Name = "BlindKeyBindButton";
    this.BlindKeyBindButton.Size = new Size(132, 43);
    this.BlindKeyBindButton.TabIndex = 8;
    this.BlindKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.BlindKeyBindButton, "");
    this.BlindKeyBindButton.\u000A = true;
    this.BlindKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.BlindKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.BlindKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.BlindKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel24.AutoSize = true;
    this.metroLabel24.\u000F = \u000F\u000B.\u0001;
    this.metroLabel24.Location = new Point(20, -2);
    this.metroLabel24.Name = "metroLabel24";
    this.metroLabel24.Size = new Size(31 /*0x1F*/, 15);
    this.metroLabel24.TabIndex = 9;
    this.metroLabel24.Text = "Blind";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel24, "Set the key to cast Blind.");
    this.KeyBindPanel2.\u0016 = true;
    this.KeyBindPanel2.Controls.Add((Control) this.AutoKidneyKeyBindButton);
    this.KeyBindPanel2.Controls.Add((Control) this.metroLabel8);
    this.KeyBindPanel2.Controls.Add((Control) this.EventsKeyBindButton);
    this.KeyBindPanel2.Controls.Add((Control) this.metroLabel38);
    this.KeyBindPanel2.Controls.Add((Control) this.BurstNoShadowBladesKeyBindButton);
    this.KeyBindPanel2.Controls.Add((Control) this.metroLabel33);
    this.KeyBindPanel2.Controls.Add((Control) this.PauseDamageKeyBindButton);
    this.KeyBindPanel2.Controls.Add((Control) this.PauseKeyBindButton);
    this.KeyBindPanel2.Controls.Add((Control) this.metroLabel29);
    this.KeyBindPanel2.Controls.Add((Control) this.metroLabel28);
    this.KeyBindPanel2.Controls.Add((Control) this.BurstKeyBindButton);
    this.KeyBindPanel2.Controls.Add((Control) this.metroLabel22);
    this.KeyBindPanel2.Controls.Add((Control) this.LazyKeyBindButton);
    this.KeyBindPanel2.Controls.Add((Control) this.metroLabel23);
    this.KeyBindPanel2.\u000F = true;
    this.KeyBindPanel2.\u0011 = true;
    this.KeyBindPanel2.\u0012 = false;
    this.KeyBindPanel2.\u000F = 10;
    this.KeyBindPanel2.Location = new Point(177, 12);
    this.KeyBindPanel2.Name = "KeyBindPanel2";
    this.KeyBindPanel2.\u0010 = true;
    this.KeyBindPanel2.Size = new Size(188, 284);
    this.KeyBindPanel2.TabIndex = 11;
    this.\u0008\u0008_0.\u0001((Control) this.KeyBindPanel2, "");
    this.KeyBindPanel2.\u0013 = true;
    this.KeyBindPanel2.\u0014 = true;
    this.KeyBindPanel2.\u0015 = false;
    this.KeyBindPanel2.\u0010 = 10;
    this.KeyBindPanel2.MouseEnter += new EventHandler(this.KeyBindPanel2_MouseEnter);
    this.AutoKidneyKeyBindButton.Location = new Point(20, 462);
    this.AutoKidneyKeyBindButton.Name = "AutoKidneyKeyBindButton";
    this.AutoKidneyKeyBindButton.Size = new Size(132, 43);
    this.AutoKidneyKeyBindButton.TabIndex = 18;
    this.AutoKidneyKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.AutoKidneyKeyBindButton, "");
    this.AutoKidneyKeyBindButton.\u000A = true;
    this.AutoKidneyKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.AutoKidneyKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.AutoKidneyKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.AutoKidneyKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel8.AutoSize = true;
    this.metroLabel8.\u000F = \u000F\u000B.\u0001;
    this.metroLabel8.Location = new Point(18, 442);
    this.metroLabel8.Name = "metroLabel8";
    this.metroLabel8.Size = new Size(103, 15);
    this.metroLabel8.TabIndex = 19;
    this.metroLabel8.Text = "Toggle Auto Kidney";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel8, "Set the key to enable or disable automatic use of Kidney Shot (outside burst).");
    this.EventsKeyBindButton.Location = new Point(20, 388);
    this.EventsKeyBindButton.Name = "EventsKeyBindButton";
    this.EventsKeyBindButton.Size = new Size(132, 43);
    this.EventsKeyBindButton.TabIndex = 16 /*0x10*/;
    this.EventsKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.EventsKeyBindButton, "");
    this.EventsKeyBindButton.\u000A = true;
    this.EventsKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.EventsKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.EventsKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.EventsKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel38.AutoSize = true;
    this.metroLabel38.\u000F = \u000F\u000B.\u0001;
    this.metroLabel38.Location = new Point(18, 368);
    this.metroLabel38.Name = "metroLabel38";
    this.metroLabel38.Size = new Size(115, 15);
    this.metroLabel38.TabIndex = 17;
    this.metroLabel38.Text = "Enable/Disable Events";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel38, "Set the key to enable or disable the event framework.");
    this.BurstNoShadowBladesKeyBindButton.Location = new Point(20, 92);
    this.BurstNoShadowBladesKeyBindButton.Name = "BurstNoShadowBladesKeyBindButton";
    this.BurstNoShadowBladesKeyBindButton.Size = new Size(132, 43);
    this.BurstNoShadowBladesKeyBindButton.TabIndex = 14;
    this.BurstNoShadowBladesKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.BurstNoShadowBladesKeyBindButton, "");
    this.BurstNoShadowBladesKeyBindButton.\u000A = true;
    this.BurstNoShadowBladesKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.BurstNoShadowBladesKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.BurstNoShadowBladesKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.BurstNoShadowBladesKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel33.AutoSize = true;
    this.metroLabel33.\u000F = \u000F\u000B.\u0001;
    this.metroLabel33.Location = new Point(20, 72);
    this.metroLabel33.Name = "metroLabel33";
    this.metroLabel33.Size = new Size(113, 15);
    this.metroLabel33.TabIndex = 15;
    this.metroLabel33.Text = "Burst Mode (No ShB)";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel33, "Set the key to enable or disable Burst Mode (will not use Shadow Blades).");
    this.PauseDamageKeyBindButton.Location = new Point(20, 314);
    this.PauseDamageKeyBindButton.Name = "PauseDamageKeyBindButton";
    this.PauseDamageKeyBindButton.Size = new Size(132, 43);
    this.PauseDamageKeyBindButton.TabIndex = 12;
    this.PauseDamageKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.PauseDamageKeyBindButton, "");
    this.PauseDamageKeyBindButton.\u000A = true;
    this.PauseDamageKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.PauseDamageKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.PauseDamageKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.PauseDamageKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.PauseKeyBindButton.Location = new Point(20, 240 /*0xF0*/);
    this.PauseKeyBindButton.Name = "PauseKeyBindButton";
    this.PauseKeyBindButton.Size = new Size(132, 43);
    this.PauseKeyBindButton.TabIndex = 10;
    this.PauseKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.PauseKeyBindButton, "");
    this.PauseKeyBindButton.\u000A = true;
    this.PauseKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.PauseKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.PauseKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.PauseKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel29.AutoSize = true;
    this.metroLabel29.\u000F = \u000F\u000B.\u0001;
    this.metroLabel29.Location = new Point(18, 294);
    this.metroLabel29.Name = "metroLabel29";
    this.metroLabel29.Size = new Size(102, 15);
    this.metroLabel29.TabIndex = 13;
    this.metroLabel29.Text = "Pause Damage Key";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel29, "Set the key to pause the damage rotation.");
    this.metroLabel28.AutoSize = true;
    this.metroLabel28.\u000F = \u000F\u000B.\u0001;
    this.metroLabel28.Location = new Point(20, 220);
    this.metroLabel28.Name = "metroLabel28";
    this.metroLabel28.Size = new Size(56, 15);
    this.metroLabel28.TabIndex = 11;
    this.metroLabel28.Text = "Pause Key";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel28, "Set the key to pause the rotation.");
    this.BurstKeyBindButton.Location = new Point(20, 17);
    this.BurstKeyBindButton.Name = "BurstKeyBindButton";
    this.BurstKeyBindButton.Size = new Size(132, 43);
    this.BurstKeyBindButton.TabIndex = 6;
    this.BurstKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.BurstKeyBindButton, "");
    this.BurstKeyBindButton.\u000A = true;
    this.BurstKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.BurstKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.BurstKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.BurstKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel22.AutoSize = true;
    this.metroLabel22.\u000F = \u000F\u000B.\u0001;
    this.metroLabel22.Location = new Point(20, -2);
    this.metroLabel22.Name = "metroLabel22";
    this.metroLabel22.Size = new Size(66, 15);
    this.metroLabel22.TabIndex = 7;
    this.metroLabel22.Text = "Burst Mode";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel22, "Set the key to enable or disable Burst Mode (burst damage rotation).");
    this.LazyKeyBindButton.Location = new Point(20, 166);
    this.LazyKeyBindButton.Name = "LazyKeyBindButton";
    this.LazyKeyBindButton.Size = new Size(132, 43);
    this.LazyKeyBindButton.TabIndex = 8;
    this.LazyKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.LazyKeyBindButton, "");
    this.LazyKeyBindButton.\u000A = true;
    this.LazyKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.LazyKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.LazyKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.LazyKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel23.AutoSize = true;
    this.metroLabel23.\u000F = \u000F\u000B.\u0001;
    this.metroLabel23.Location = new Point(18, 146);
    this.metroLabel23.Name = "metroLabel23";
    this.metroLabel23.Size = new Size(62, 15);
    this.metroLabel23.TabIndex = 9;
    this.metroLabel23.Text = "Lazy Mode";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel23, "Set the key to enable or disable Lazy Mode (basic damage rotation).");
    this.KeyBindPanel1.\u0016 = true;
    this.KeyBindPanel1.Controls.Add((Control) this.metroLabel14);
    this.KeyBindPanel1.Controls.Add((Control) this.OpenerModifierKeyBindButton);
    this.KeyBindPanel1.Controls.Add((Control) this.metroLabel30);
    this.KeyBindPanel1.Controls.Add((Control) this.FocusMacroKeyBindButton);
    this.KeyBindPanel1.Controls.Add((Control) this.GarroteKeyBindButton);
    this.KeyBindPanel1.Controls.Add((Control) this.metroLabel20);
    this.KeyBindPanel1.Controls.Add((Control) this.metroLabel21);
    this.KeyBindPanel1.Controls.Add((Control) this.CheapShotKeyBindButton);
    this.KeyBindPanel1.\u000F = true;
    this.KeyBindPanel1.\u0011 = true;
    this.KeyBindPanel1.\u0012 = false;
    this.KeyBindPanel1.\u000F = 10;
    this.KeyBindPanel1.Location = new Point(-29, 12);
    this.KeyBindPanel1.Name = "KeyBindPanel1";
    this.KeyBindPanel1.\u0010 = true;
    this.KeyBindPanel1.Size = new Size(196, 284);
    this.KeyBindPanel1.TabIndex = 10;
    this.\u0008\u0008_0.\u0001((Control) this.KeyBindPanel1, "");
    this.KeyBindPanel1.\u0013 = true;
    this.KeyBindPanel1.\u0014 = true;
    this.KeyBindPanel1.\u0015 = false;
    this.KeyBindPanel1.\u0010 = 10;
    this.metroLabel14.AutoSize = true;
    this.metroLabel14.\u000F = \u000F\u000B.\u0001;
    this.metroLabel14.Location = new Point(34, 218);
    this.metroLabel14.Name = "metroLabel14";
    this.metroLabel14.Size = new Size(89, 15);
    this.metroLabel14.TabIndex = 9;
    this.metroLabel14.Text = "Opener Modifier";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel14, "Set the  opener modifier key, when holding this and pressing the Garrote key the profile will pool more energy during Subterfuge.");
    this.OpenerModifierKeyBindButton.Location = new Point(34, 238);
    this.OpenerModifierKeyBindButton.Name = "OpenerModifierKeyBindButton";
    this.OpenerModifierKeyBindButton.Size = new Size(132, 43);
    this.OpenerModifierKeyBindButton.TabIndex = 8;
    this.OpenerModifierKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.OpenerModifierKeyBindButton, "");
    this.OpenerModifierKeyBindButton.\u000A = true;
    this.OpenerModifierKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.OpenerModifierKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.OpenerModifierKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.OpenerModifierKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel30.AutoSize = true;
    this.metroLabel30.\u000F = \u000F\u000B.\u0001;
    this.metroLabel30.Location = new Point(34, 146);
    this.metroLabel30.Name = "metroLabel30";
    this.metroLabel30.Size = new Size(80 /*0x50*/, 15);
    this.metroLabel30.TabIndex = 7;
    this.metroLabel30.Text = "Focus Modifier";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel30, "Set the focus modifier key, when using a macro or HB keybind this will cause the ability to be casted at your focus target.");
    this.FocusMacroKeyBindButton.Location = new Point(34, 166);
    this.FocusMacroKeyBindButton.Name = "FocusMacroKeyBindButton";
    this.FocusMacroKeyBindButton.Size = new Size(132, 43);
    this.FocusMacroKeyBindButton.TabIndex = 6;
    this.FocusMacroKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.FocusMacroKeyBindButton, "");
    this.FocusMacroKeyBindButton.\u000A = true;
    this.FocusMacroKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.FocusMacroKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.FocusMacroKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.FocusMacroKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.GarroteKeyBindButton.Location = new Point(34, 18);
    this.GarroteKeyBindButton.Name = "GarroteKeyBindButton";
    this.GarroteKeyBindButton.Size = new Size(132, 43);
    this.GarroteKeyBindButton.TabIndex = 2;
    this.GarroteKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.GarroteKeyBindButton, "");
    this.GarroteKeyBindButton.\u000A = true;
    this.GarroteKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.GarroteKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.GarroteKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.GarroteKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.metroLabel20.AutoSize = true;
    this.metroLabel20.\u000F = \u000F\u000B.\u0001;
    this.metroLabel20.Location = new Point(34, -2);
    this.metroLabel20.Name = "metroLabel20";
    this.metroLabel20.Size = new Size(46, 15);
    this.metroLabel20.TabIndex = 3;
    this.metroLabel20.Text = "Garrote";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel20, "Set the key to cast Garrote.");
    this.metroLabel21.AutoSize = true;
    this.metroLabel21.\u000F = \u000F\u000B.\u0001;
    this.metroLabel21.Location = new Point(34, 72);
    this.metroLabel21.Name = "metroLabel21";
    this.metroLabel21.Size = new Size(65, 15);
    this.metroLabel21.TabIndex = 5;
    this.metroLabel21.Text = "Cheap Shot";
    this.\u0008\u0008_0.\u0001((Control) this.metroLabel21, "Set the key to cast Cheap Shot.");
    this.CheapShotKeyBindButton.Location = new Point(34, 92);
    this.CheapShotKeyBindButton.Name = "CheapShotKeyBindButton";
    this.CheapShotKeyBindButton.Size = new Size(132, 43);
    this.CheapShotKeyBindButton.TabIndex = 4;
    this.CheapShotKeyBindButton.Text = "Click to set keybind";
    this.\u0008\u0008_0.\u0001((Control) this.CheapShotKeyBindButton, "");
    this.CheapShotKeyBindButton.\u000A = true;
    this.CheapShotKeyBindButton.KeyDown += new KeyEventHandler(this.CheapShotKeyBindButton_KeyDown);
    this.CheapShotKeyBindButton.KeyUp += new KeyEventHandler(this.CheapShotKeyBindButton_KeyUp);
    this.CheapShotKeyBindButton.Leave += new EventHandler(this.CheapShotKeyBindButton_Leave);
    this.CheapShotKeyBindButton.MouseUp += new MouseEventHandler(this.CheapShotKeyBindButton_MouseUp);
    this.\u0017\u0007_0.\u0003 = (ContainerControl) this;
    this.\u0008\u0008_0.\u0001 = false;
    this.\u0008\u0008_0.\u0001 = (\u0009\u0008) obj;
    this.\u0008\u0008_0.\u0001 = "";
    this.SaveSettingsIcon.Location = new Point(569, 38);
    this.SaveSettingsIcon.\u0011 = 100;
    this.SaveSettingsIcon.Name = "SaveSettingsIcon";
    this.SaveSettingsIcon.Size = new Size(16 /*0x10*/, 16 /*0x10*/);
    this.SaveSettingsIcon.TabIndex = 1;
    this.\u0008\u0008_0.\u0001((Control) this.SaveSettingsIcon, "");
    this.SaveSettingsIcon.\u000A = true;
    this.SaveSettingsIcon.Visible = false;
    this.AutoScaleDimensions = new SizeF(6f, 13f);
    this.AutoScaleMode = AutoScaleMode.Font;
    this.\u000A = new Padding(0, 3, 0, 0);
    this.\u000A = 300;
    this.ClientSize = new Size(612, 425);
    this.Controls.Add((Control) this.SaveSettingsIcon);
    this.Controls.Add((Control) this.metroTabControl1);
    this.Name = nameof (VitalicForm);
    this.\u0009 = \u0002\u000B.\u0005;
    this.StartPosition = FormStartPosition.Manual;
    this.\u0003 = this.\u0017\u0007_0;
    this.Text = "Vitalic Elite Rogue";
    this.FormClosing += new FormClosingEventHandler(this.VitalicForm_FormClosing);
    this.Load += new EventHandler(this.VitalicForm_Load);
    this.Shown += new EventHandler(this.VitalicForm_Shown);
    this.metroTabControl1.ResumeLayout(false);
    this.tabPageInformation.ResumeLayout(false);
    this.tabPageInformation.PerformLayout();
    this.groupBox2.ResumeLayout(false);
    this.groupBox1.ResumeLayout(false);
    this.tabPageUtilities.ResumeLayout(false);
    this.metroPanel9.ResumeLayout(false);
    this.metroPanel9.PerformLayout();
    this.metroPanel8.ResumeLayout(false);
    this.metroPanel8.PerformLayout();
    this.metroPanel7.ResumeLayout(false);
    this.metroPanel7.PerformLayout();
    this.tabPageInterface.ResumeLayout(false);
    this.metroPanel6.ResumeLayout(false);
    this.metroPanel6.PerformLayout();
    this.metroPanel5.ResumeLayout(false);
    this.metroPanel5.PerformLayout();
    this.metroPanel4.ResumeLayout(false);
    this.metroPanel4.PerformLayout();
    this.tabPageOffensive.ResumeLayout(false);
    this.metroPanel3.ResumeLayout(false);
    this.metroPanel3.PerformLayout();
    this.metroPanel2.ResumeLayout(false);
    this.metroPanel2.PerformLayout();
    this.metroPanel1.ResumeLayout(false);
    this.metroPanel1.PerformLayout();
    this.tabPageAutomation.ResumeLayout(false);
    this.metroPanel13.ResumeLayout(false);
    this.metroPanel13.PerformLayout();
    this.metroPanel14.ResumeLayout(false);
    this.metroPanel14.PerformLayout();
    this.nonFlickerGroupBox1.ResumeLayout(false);
    this.nonFlickerGroupBox1.PerformLayout();
    this.metroPanel15.ResumeLayout(false);
    this.metroPanel15.PerformLayout();
    this.tabPageDefensive.ResumeLayout(false);
    this.metroPanel12.ResumeLayout(false);
    this.metroPanel12.PerformLayout();
    this.metroPanel11.ResumeLayout(false);
    this.metroPanel11.PerformLayout();
    this.metroPanel10.ResumeLayout(false);
    this.metroPanel10.PerformLayout();
    this.tabPageKeybinds.ResumeLayout(false);
    this.KeyBindPanel3.ResumeLayout(false);
    this.KeyBindPanel3.PerformLayout();
    this.KeyBindPanel2.ResumeLayout(false);
    this.KeyBindPanel2.PerformLayout();
    this.KeyBindPanel1.ResumeLayout(false);
    this.KeyBindPanel1.PerformLayout();
    ((ISupportInitialize) this.\u0017\u0007_0).EndInit();
    this.ResumeLayout(false);
  }

  private struct Struct25
  {
    public int int_0;
    public int int_1;
    public int int_2;
    public int int_3;
  }

  private enum Enum17
  {
    const_0,
    const_1,
  }
}
