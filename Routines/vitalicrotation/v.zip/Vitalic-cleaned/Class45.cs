﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class45
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class45
{
  private static bool bool_0;
  private static Class45.Delegate18 delegate18_0 = new Class45.Delegate18(Class62.smethod_0);
  private static DateTime dateTime_0;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static bool Boolean_0 => (DateTime.UtcNow - Class45.dateTime_0).TotalSeconds < 10.0;

  public static void Initialise() => Class45.Attach();

  public static void Attach()
  {
    if (Class45.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.DUEL_FINISHED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    Class45.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class45.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.DUEL_FINISHED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    Class45.bool_0 = false;
  }

  public static void Shutdown() => Class45.smethod_0();

  private static void smethod_1(object sender, LuaEventArgs e)
  {
    Class45.dateTime_0 = DateTime.UtcNow;
  }

  private delegate void Delegate18(params object[] args);
}
