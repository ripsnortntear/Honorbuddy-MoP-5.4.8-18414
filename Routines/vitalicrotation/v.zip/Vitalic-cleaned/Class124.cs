﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class124
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class124 : Class91
{
  public static bool bool_0;
  public static Class137.MacroTargets macroTargets_0;
  private static WoWUnit woWUnit_0;

  private static double Double_9 => Class65.smethod_1(115192);

  private static double Double_10 => Class65.smethod_1(5171);

  private static bool Boolean_21
  {
    get => WoWObject.op_Equality((WoWObject) Class124.WoWUnit_3, (WoWObject) Class91.WoWUnit_0);
  }

  private static bool Boolean_22
  {
    get
    {
      return Class124.bool_0 && Class124.Double_9 > 0.75 && Class91.Double_2 < (double) (((WoWUnit) Class91.LocalPlayer_0).MaxEnergy - 15U) && !Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_0) && !Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_0);
    }
  }

  private static int Int32_4 => 6 + Class124.Int32_5 * 6;

  private static int Int32_5
  {
    get
    {
      return Class91.LocalPlayer_0.RawComboPoints <= 0 ? Class91.LocalPlayer_0.ComboPoints : Class91.LocalPlayer_0.RawComboPoints;
    }
  }

  private static bool Boolean_23
  {
    get
    {
      return !Class124.WoWUnit_3.IsCasting || Class124.WoWUnit_3.CurrentCastTimeLeft.TotalSeconds > 1.0;
    }
  }

  private static WoWSpell WoWSpell_0 => WoWSpell.FromId(5171);

  private static WoWUnit WoWUnit_2
  {
    get
    {
      if (!Class144.class82_0.method_6(Enum18.const_0))
        return Class91.WoWUnit_0;
      Class144.class82_0.method_5(0.1, Enum18.const_0);
      return Class91.WoWUnit_1;
    }
  }

  private static WoWUnit WoWUnit_3
  {
    get
    {
      switch (Class124.macroTargets_0)
      {
        case Class137.MacroTargets.None:
          Class124.woWUnit_0 = Class124.WoWUnit_2;
          return Class124.woWUnit_0;
        case Class137.MacroTargets.Target:
          Class124.woWUnit_0 = Class91.WoWUnit_0;
          break;
        case Class137.MacroTargets.Focus:
          Class124.woWUnit_0 = Class91.WoWUnit_1;
          break;
        default:
          Class124.woWUnit_0 = Class137.woWUnit_0;
          break;
      }
      return Class124.woWUnit_0;
    }
  }

  private static bool Boolean_24
  {
    get
    {
      if (Class144.class81_0.method_2(true) && !Class144.class82_0.method_2(true))
        Class144.class82_0.DateTime_0 = DateTime.MinValue;
      return true;
    }
  }

  private static bool Boolean_25
  {
    get
    {
      if (Class144.class81_1.method_2(true) && !Class144.class82_0.method_2(true))
        Class144.class82_0.DateTime_0 = DateTime.MinValue;
      return true;
    }
  }

  private static double Double_11
  {
    get
    {
      WoWAura auraById = ((WoWUnit) Class91.LocalPlayer_0).GetAuraById(5171);
      return WoWAura.op_Equality(auraById, (WoWAura) null) ? 0.0 : ((double) auraById.Duration - auraById.TimeLeft.TotalMilliseconds) / 1000.0;
    }
  }

  private static double Double_12
  {
    get
    {
      WoWAura auraById = Class91.WoWUnit_0.GetAuraById(1833);
      if (WoWAura.op_Equality(auraById, (WoWAura) null))
        return 0.0;
      return Class91.LocalPlayer_0.smethod_3(56801) ? (double) (auraById.Duration / 1000U) + 0.5 : (double) (auraById.Duration / 1000U);
    }
  }

  private static Composite Composite_0
  {
    get
    {
      if (Class124.actionDelegate_0 == null)
        Class124.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_6));
      return (Composite) new Action(Class124.actionDelegate_0);
    }
  }

  private static WoWUnit WoWUnit_4
  {
    get
    {
      double num = Class70.smethod_2(Class124.WoWUnit_3);
      if (!Class53.smethod_3(Class124.WoWUnit_3, 51753) && num <= 20.0 && (num < 8.0 || Class124.WoWUnit_3.smethod_4(0.5)))
        return Class124.WoWUnit_3;
      return Class91.Boolean_1 ? Class91.IEnumerable_1.FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_1 => !Class53.smethod_3(woWUnit_1, 51753) && Class70.smethod_2(woWUnit_1) <= 20.0 && woWUnit_1.smethod_4(0.5))) : (WoWUnit) null;
    }
  }

  private static Composite Composite_1
  {
    get
    {
      if (Class124.canRunDecoratorDelegate_0 == null)
        Class124.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
      return Class77.smethod_2(121471, Class124.canRunDecoratorDelegate_0, "Shadow Blades (Opener)");
    }
  }

  private static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class124.canRunDecoratorDelegate_1;
    Composite[] compositeArray1 = new Composite[3];
    Composite[] compositeArray2 = compositeArray1;
    Class144.Delegate43 delegate43_4 = (Class144.Delegate43) (object_0 => Class124.WoWUnit_4);
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_11));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate2 = Class124.canRunDecoratorDelegate_2;
    Composite composite1 = Class77.smethod_0(14183, delegate43_4, decoratorDelegate2, "Premeditation (Opener)");
    compositeArray2[0] = composite1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_12));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite2 = Class77.smethod_2(5171, Class124.canRunDecoratorDelegate_3, "Slice and Dice (Opener)");
    compositeArray3[1] = composite2;
    Composite[] compositeArray4 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_13));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite3 = Class77.smethod_2(5171, Class124.canRunDecoratorDelegate_4, "Slice and Dice (Opener)");
    compositeArray4[2] = composite3;
    PrioritySelector prioritySelector = new PrioritySelector(compositeArray1);
    return (Composite) new Decorator(decoratorDelegate1, (Composite) prioritySelector);
  }

  public static Composite smethod_5()
  {
    Composite[] compositeArray1 = new Composite[11];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_5 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_14));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate5 = Class124.canRunDecoratorDelegate_5;
    // ISSUE: reference to a compiler-generated field
    if (Class124.actionSucceedDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_15));
    }
    // ISSUE: reference to a compiler-generated field
    Action action1 = new Action(Class124.actionSucceedDelegate_0);
    Decorator decorator1 = new Decorator(decoratorDelegate5, (Composite) action1);
    compositeArray2[0] = (Composite) decorator1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_6 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_16));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate6 = Class124.canRunDecoratorDelegate_6;
    // ISSUE: reference to a compiler-generated field
    if (Class124.actionDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.actionDelegate_1 = new ActionDelegate((object) null, __methodptr(smethod_17));
    }
    // ISSUE: reference to a compiler-generated field
    Action action2 = new Action(Class124.actionDelegate_1);
    Decorator decorator2 = new Decorator(decoratorDelegate6, (Composite) action2);
    compositeArray3[1] = (Composite) decorator2;
    Composite[] compositeArray4 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_7 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_18));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate7 = Class124.canRunDecoratorDelegate_7;
    // ISSUE: reference to a compiler-generated field
    if (Class124.actionDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.actionDelegate_2 = new ActionDelegate((object) null, __methodptr(smethod_19));
    }
    // ISSUE: reference to a compiler-generated field
    Action action3 = new Action(Class124.actionDelegate_2);
    Decorator decorator3 = new Decorator(decoratorDelegate7, (Composite) action3);
    compositeArray4[2] = (Composite) decorator3;
    compositeArray1[3] = Class124.Composite_0;
    Composite[] compositeArray5 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_8 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_8 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_20));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate8 = Class124.canRunDecoratorDelegate_8;
    Composite[] compositeArray6 = new Composite[6];
    Composite[] compositeArray7 = compositeArray6;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_9 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_9 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_21));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate9 = Class124.canRunDecoratorDelegate_9;
    // ISSUE: reference to a compiler-generated field
    if (Class124.actionSucceedDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.actionSucceedDelegate_1 = new ActionSucceedDelegate((object) null, __methodptr(smethod_22));
    }
    // ISSUE: reference to a compiler-generated field
    Action action4 = new Action(Class124.actionSucceedDelegate_1);
    Decorator decorator4 = new Decorator(decoratorDelegate9, (Composite) action4);
    compositeArray7[0] = (Composite) decorator4;
    Composite[] compositeArray8 = compositeArray6;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_10 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_10 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_23));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate10 = Class124.canRunDecoratorDelegate_10;
    // ISSUE: reference to a compiler-generated field
    if (Class124.actionDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.actionDelegate_3 = new ActionDelegate((object) null, __methodptr(smethod_24));
    }
    // ISSUE: reference to a compiler-generated field
    Action action5 = new Action(Class124.actionDelegate_3);
    Decorator decorator5 = new Decorator(decoratorDelegate10, (Composite) action5);
    compositeArray8[1] = (Composite) decorator5;
    compositeArray6[2] = Class124.smethod_4();
    compositeArray6[3] = Class124.Composite_1;
    Composite[] compositeArray9 = compositeArray6;
    Class144.Delegate43 delegate43_4_1 = (Class144.Delegate43) (object_0 => Class124.WoWUnit_3);
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_11 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_11 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_26));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate11 = Class124.canRunDecoratorDelegate_11;
    Composite composite1 = Class77.smethod_0(703, delegate43_4_1, decoratorDelegate11, "Garrote (Opener)");
    compositeArray9[4] = composite1;
    Composite[] compositeArray10 = compositeArray6;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_12 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_12 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_27));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator6 = new Decorator(Class124.canRunDecoratorDelegate_12, (Composite) new ActionAlwaysSucceed());
    compositeArray10[5] = (Composite) decorator6;
    PrioritySelector prioritySelector1 = new PrioritySelector(compositeArray6);
    Decorator decorator7 = new Decorator(decoratorDelegate8, (Composite) prioritySelector1);
    compositeArray5[4] = (Composite) decorator7;
    Composite[] compositeArray11 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_13 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_13 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_28));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate13 = Class124.canRunDecoratorDelegate_13;
    Composite[] compositeArray12 = new Composite[5];
    Composite[] compositeArray13 = compositeArray12;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_14 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_14 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_29));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate14 = Class124.canRunDecoratorDelegate_14;
    // ISSUE: reference to a compiler-generated field
    if (Class124.actionSucceedDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.actionSucceedDelegate_2 = new ActionSucceedDelegate((object) null, __methodptr(smethod_30));
    }
    // ISSUE: reference to a compiler-generated field
    Action action6 = new Action(Class124.actionSucceedDelegate_2);
    Decorator decorator8 = new Decorator(decoratorDelegate14, (Composite) action6);
    compositeArray13[0] = (Composite) decorator8;
    compositeArray12[1] = Class124.smethod_4();
    Composite[] compositeArray14 = compositeArray12;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_15 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_15 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_31));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator9 = new Decorator(Class124.canRunDecoratorDelegate_15, Class124.Composite_1);
    compositeArray14[2] = (Composite) decorator9;
    Composite[] compositeArray15 = compositeArray12;
    Class144.Delegate43 delegate43_4_2 = (Class144.Delegate43) (object_0 => Class124.WoWUnit_3);
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_16 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_16 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_33));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate16 = Class124.canRunDecoratorDelegate_16;
    Composite composite2 = Class77.smethod_0(1833, delegate43_4_2, decoratorDelegate16, "Cheap Shot (Opener)");
    compositeArray15[3] = composite2;
    Composite[] compositeArray16 = compositeArray12;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_17 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_17 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_34));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator10 = new Decorator(Class124.canRunDecoratorDelegate_17, (Composite) new ActionAlwaysSucceed());
    compositeArray16[4] = (Composite) decorator10;
    PrioritySelector prioritySelector2 = new PrioritySelector(compositeArray12);
    Decorator decorator11 = new Decorator(decoratorDelegate13, (Composite) prioritySelector2);
    compositeArray11[5] = (Composite) decorator11;
    Composite[] compositeArray17 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_18 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_18 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_35));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator12 = new Decorator(Class124.canRunDecoratorDelegate_18, (Composite) new ActionAlwaysSucceed());
    compositeArray17[6] = (Composite) decorator12;
    Composite[] compositeArray18 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_19 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_19 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_36));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate19 = Class124.canRunDecoratorDelegate_19;
    // ISSUE: reference to a compiler-generated field
    if (Class124.actionDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.actionDelegate_4 = new ActionDelegate((object) null, __methodptr(smethod_37));
    }
    // ISSUE: reference to a compiler-generated field
    Action action7 = new Action(Class124.actionDelegate_4);
    Decorator decorator13 = new Decorator(decoratorDelegate19, (Composite) action7);
    compositeArray18[7] = (Composite) decorator13;
    Composite[] compositeArray19 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_20 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_20 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_38));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate20 = Class124.canRunDecoratorDelegate_20;
    Composite[] compositeArray20 = new Composite[3];
    Composite[] compositeArray21 = compositeArray20;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_21 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_21 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_39));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite3 = Class77.smethod_1(703, Class124.canRunDecoratorDelegate_21, "Garrote (Subterfuge)");
    compositeArray21[0] = composite3;
    Composite[] compositeArray22 = compositeArray20;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_22 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_22 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_40));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate22 = Class124.canRunDecoratorDelegate_22;
    // ISSUE: reference to a compiler-generated field
    if (Class124.actionSucceedDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.actionSucceedDelegate_3 = new ActionSucceedDelegate((object) null, __methodptr(smethod_41));
    }
    // ISSUE: reference to a compiler-generated field
    Action action8 = new Action(Class124.actionSucceedDelegate_3);
    Decorator decorator14 = new Decorator(decoratorDelegate22, (Composite) action8);
    compositeArray22[1] = (Composite) decorator14;
    Composite[] compositeArray23 = compositeArray20;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_23 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_23 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_42));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite4 = Class77.smethod_1(1833, Class124.canRunDecoratorDelegate_23, "Cheap Shot (Subterfuge)");
    compositeArray23[2] = composite4;
    PrioritySelector prioritySelector3 = new PrioritySelector(compositeArray20);
    Decorator decorator15 = new Decorator(decoratorDelegate20, (Composite) prioritySelector3);
    compositeArray19[8] = (Composite) decorator15;
    Composite[] compositeArray24 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_24 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_24 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_43));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate24 = Class124.canRunDecoratorDelegate_24;
    // ISSUE: reference to a compiler-generated field
    if (Class124.actionDelegate_5 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.actionDelegate_5 = new ActionDelegate((object) null, __methodptr(smethod_44));
    }
    // ISSUE: reference to a compiler-generated field
    Action action9 = new Action(Class124.actionDelegate_5);
    Decorator decorator16 = new Decorator(decoratorDelegate24, (Composite) action9);
    compositeArray24[9] = (Composite) decorator16;
    Composite[] compositeArray25 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class124.canRunDecoratorDelegate_25 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.canRunDecoratorDelegate_25 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_45));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate25 = Class124.canRunDecoratorDelegate_25;
    // ISSUE: reference to a compiler-generated field
    if (Class124.actionDelegate_6 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class124.actionDelegate_6 = new ActionDelegate((object) null, __methodptr(smethod_46));
    }
    // ISSUE: reference to a compiler-generated field
    Action action10 = new Action(Class124.actionDelegate_6);
    Decorator decorator17 = new Decorator(decoratorDelegate25, (Composite) action10);
    compositeArray25[10] = (Composite) decorator17;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
