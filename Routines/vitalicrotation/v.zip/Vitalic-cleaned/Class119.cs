﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class119
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

internal class Class119 : Class91
{
  public static Class137.MacroTargets macroTargets_0;

  private static WoWUnit WoWUnit_2
  {
    get
    {
      if (!Class144.class82_0.method_6(Enum18.const_2))
        return Class91.WoWUnit_0;
      Class144.class82_0.method_5(0.1, Enum18.const_2);
      return Class91.WoWUnit_1;
    }
  }

  private static WoWUnit WoWUnit_3
  {
    get
    {
      switch (Class119.macroTargets_0)
      {
        case Class137.MacroTargets.None:
          return Class119.WoWUnit_2;
        case Class137.MacroTargets.Target:
          return Class91.WoWUnit_0;
        case Class137.MacroTargets.Focus:
          return Class91.WoWUnit_1;
        default:
          return Class137.woWUnit_0;
      }
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[2];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class119.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class119.canRunDecoratorDelegate_0;
    Composite[] compositeArray3 = new Composite[4];
    Composite[] compositeArray4 = compositeArray3;
    // ISSUE: reference to a compiler-generated field
    if (Class119.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class119.canRunDecoratorDelegate_1;
    Composite[] compositeArray5 = new Composite[4];
    Composite[] compositeArray6 = compositeArray5;
    // ISSUE: reference to a compiler-generated field
    if (Class119.actionSucceedDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    Action action1 = new Action(Class119.actionSucceedDelegate_0);
    compositeArray6[0] = (Composite) action1;
    Composite[] compositeArray7 = compositeArray5;
    // ISSUE: reference to a compiler-generated field
    if (Class119.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate2 = Class119.canRunDecoratorDelegate_2;
    Class144.Delegate43 delegate43_4_1 = (Class144.Delegate43) (object_0 => Class119.WoWUnit_3);
    // ISSUE: reference to a compiler-generated field
    if (Class119.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_10));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate3 = Class119.canRunDecoratorDelegate_3;
    Action action_0_1 = (Action) (() => Class144.class81_3.method_3(2.0));
    Composite composite1 = Class77.smethod_0(84617, delegate43_4_1, decoratorDelegate3, "Revealing Strike", action_0_1, true);
    DecoratorContinue decoratorContinue = new DecoratorContinue(decoratorDelegate2, composite1);
    compositeArray7[1] = (Composite) decoratorContinue;
    Composite[] compositeArray8 = compositeArray5;
    TimeSpan timeSpan = TimeSpan.FromSeconds(2.0);
    // ISSUE: reference to a compiler-generated field
    if (Class119.canRunDecoratorDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_12));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate4 = Class119.canRunDecoratorDelegate_4;
    ActionAlwaysSucceed actionAlwaysSucceed = new ActionAlwaysSucceed();
    WaitContinue waitContinue = new WaitContinue(timeSpan, decoratorDelegate4, (Composite) actionAlwaysSucceed);
    compositeArray8[2] = (Composite) waitContinue;
    Composite[] compositeArray9 = compositeArray5;
    // ISSUE: reference to a compiler-generated field
    if (Class119.canRunDecoratorDelegate_5 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_13));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate5 = Class119.canRunDecoratorDelegate_5;
    // ISSUE: reference to a compiler-generated field
    if (Class119.actionDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_14));
    }
    // ISSUE: reference to a compiler-generated field
    Action action2 = new Action(Class119.actionDelegate_0);
    Decorator decorator1 = new Decorator(decoratorDelegate5, (Composite) action2);
    compositeArray9[3] = (Composite) decorator1;
    Sequence sequence = new Sequence(compositeArray5);
    Decorator decorator2 = new Decorator(decoratorDelegate1, (Composite) sequence);
    compositeArray4[0] = (Composite) decorator2;
    Composite[] compositeArray10 = compositeArray3;
    // ISSUE: reference to a compiler-generated field
    if (Class119.canRunDecoratorDelegate_6 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_15));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator3 = new Decorator(Class119.canRunDecoratorDelegate_6, (Composite) new ActionAlwaysSucceed());
    compositeArray10[1] = (Composite) decorator3;
    Composite[] compositeArray11 = compositeArray3;
    Class144.Delegate43 delegate43_4_2 = (Class144.Delegate43) (object_0 => Class119.WoWUnit_3);
    // ISSUE: reference to a compiler-generated field
    if (Class119.canRunDecoratorDelegate_7 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_17));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate7 = Class119.canRunDecoratorDelegate_7;
    Action action_0_2 = (Action) (() =>
    {
      if (Class119.macroTargets_0 != Class137.MacroTargets.None)
        Class91.delegate34_1((object) ("[Macro] Casted spell: Redirect on " + Class119.macroTargets_0.ToString()));
      Class144.class81_3.method_3(2.0);
    });
    Composite composite2 = Class77.smethod_0(73981, delegate43_4_2, decoratorDelegate7, "Redirect", action_0_2, true);
    compositeArray11[2] = composite2;
    Composite[] compositeArray12 = compositeArray3;
    // ISSUE: reference to a compiler-generated field
    if (Class119.canRunDecoratorDelegate_8 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.canRunDecoratorDelegate_8 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_19));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate8 = Class119.canRunDecoratorDelegate_8;
    // ISSUE: reference to a compiler-generated field
    if (Class119.actionSucceedDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.actionSucceedDelegate_1 = new ActionSucceedDelegate((object) null, __methodptr(smethod_20));
    }
    // ISSUE: reference to a compiler-generated field
    Action action3 = new Action(Class119.actionSucceedDelegate_1);
    Decorator decorator4 = new Decorator(decoratorDelegate8, (Composite) action3);
    compositeArray12[3] = (Composite) decorator4;
    PrioritySelector prioritySelector = new PrioritySelector(compositeArray3);
    Decorator decorator5 = new Decorator(decoratorDelegate0, (Composite) prioritySelector);
    compositeArray2[0] = (Composite) decorator5;
    Composite[] compositeArray13 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class119.canRunDecoratorDelegate_9 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class119.canRunDecoratorDelegate_9 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_21));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite3 = Class77.smethod_6(73981, Class119.canRunDecoratorDelegate_9, "Redirect (Auto)");
    compositeArray13[1] = composite3;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
