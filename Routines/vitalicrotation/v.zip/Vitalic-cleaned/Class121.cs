﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class121
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class121 : Class91
{
  private static double Double_9
  {
    get => VitalicSettings.Instance.InterruptDelay + Class144.double_0 / 1000.0;
  }

  private static bool Boolean_21
  {
    get
    {
      if (!Class91.WoWUnit_0.IsCasting || !Class118.dictionary_0.ContainsKey(Class91.WoWUnit_0.CastingSpellId) || Class91.Int32_0 == 1766 || !Class118.dictionary_0[Class91.WoWUnit_0.CastingSpellId] || Class91.WoWUnit_0.CurrentCastTimeLeft.TotalSeconds >= Class121.Double_9 + 0.2)
        return false;
      return Class59.smethod_0(1766) || Class91.WoWUnit_0.smethod_12();
    }
  }

  private static bool Boolean_22
  {
    get
    {
      return !Class53.smethod_3(Class91.WoWUnit_0, 5277) && !Class53.smethod_3(Class91.WoWUnit_0, 118038) || ((WoWObject) Class91.LocalPlayer_0).IsSafelyBehind((WoWObject) Class91.WoWUnit_0);
    }
  }

  private static uint UInt32_1
  {
    get
    {
      WoWAura auraById = Class91.WoWUnit_0.GetAuraById(113952);
      return !WoWAura.op_Inequality(auraById, (WoWAura) null) ? 0U : auraById.StackCount;
    }
  }

  private static bool Boolean_23
  {
    get
    {
      return Class53.smethod_3(Class91.WoWUnit_0, 1330) && Class91.WoWUnit_0.smethod_15() && !Class91.WoWUnit_0.smethod_16() && Class74.smethod_1(1330, Class91.WoWUnit_0) > 0.45;
    }
  }

  private static bool Boolean_24
  {
    get
    {
      Class68.Struct22 struct22 = Class91.WoWUnit_0.smethod_6(Class68.Enum14.const_0);
      if (!struct22.bool_0)
        return false;
      return struct22.double_0 < 1.0 || struct22.int_0 == 408 || struct22.timeSpan_0.Seconds < 5 || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_0);
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[2];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class121.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class121.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class121.canRunDecoratorDelegate_0;
    Composite[] compositeArray3 = new Composite[2];
    Composite[] compositeArray4 = compositeArray3;
    // ISSUE: reference to a compiler-generated field
    if (Class121.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class121.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator1 = new Decorator(Class121.canRunDecoratorDelegate_1, (Composite) new ActionAlwaysSucceed());
    compositeArray4[0] = (Composite) decorator1;
    Composite[] compositeArray5 = compositeArray3;
    // ISSUE: reference to a compiler-generated field
    if (Class121.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class121.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite1 = Class77.smethod_1(408, Class121.canRunDecoratorDelegate_2, "Kidney Shot (Hotkey)");
    compositeArray5[1] = composite1;
    PrioritySelector prioritySelector1 = new PrioritySelector(compositeArray3);
    Decorator decorator2 = new Decorator(decoratorDelegate0, (Composite) prioritySelector1);
    compositeArray2[0] = (Composite) decorator2;
    Composite[] compositeArray6 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class121.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class121.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate3 = Class121.canRunDecoratorDelegate_3;
    Composite[] compositeArray7 = new Composite[3];
    Composite[] compositeArray8 = compositeArray7;
    // ISSUE: reference to a compiler-generated field
    if (Class121.canRunDecoratorDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class121.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_10));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator3 = new Decorator(Class121.canRunDecoratorDelegate_4, (Composite) new ActionAlwaysSucceed());
    compositeArray8[0] = (Composite) decorator3;
    Composite[] compositeArray9 = compositeArray7;
    // ISSUE: reference to a compiler-generated field
    if (Class121.canRunDecoratorDelegate_5 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class121.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_11));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator4 = new Decorator(Class121.canRunDecoratorDelegate_5, (Composite) new ActionAlwaysSucceed());
    compositeArray9[1] = (Composite) decorator4;
    Composite[] compositeArray10 = compositeArray7;
    // ISSUE: reference to a compiler-generated field
    if (Class121.canRunDecoratorDelegate_6 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class121.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_12));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite2 = Class77.smethod_1(408, Class121.canRunDecoratorDelegate_6, "Kidney Shot");
    compositeArray10[2] = composite2;
    PrioritySelector prioritySelector2 = new PrioritySelector(compositeArray7);
    Decorator decorator5 = new Decorator(decoratorDelegate3, (Composite) prioritySelector2);
    compositeArray6[1] = (Composite) decorator5;
    return (Composite) new PrioritySelector(compositeArray1);
  }

  public static bool smethod_5()
  {
    if (!Class91.Boolean_4)
      return false;
    Class68.Struct22 struct22 = Class91.WoWUnit_0.smethod_6(Class68.Enum14.const_0);
    if (Class59.smethod_2(408) >= 3.5 || Class91.WoWUnit_0.smethod_11() || !Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_6) && Class121.UInt32_1 >= 3U || struct22.bool_0 && ((struct22.double_0 != 1.0 || struct22.int_0 == 408) && struct22.timeSpan_0.TotalSeconds >= 3.0 || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_0)) || Class144.Boolean_3)
      return false;
    return !Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_12, 2.0) || Class91.Double_2 < 60.0;
  }
}
