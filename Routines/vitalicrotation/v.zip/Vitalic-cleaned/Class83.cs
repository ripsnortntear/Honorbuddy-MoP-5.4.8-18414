﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class83
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

#nullable disable
namespace ns1;

[DebuggerNonUserCode]
[CompilerGenerated]
[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "4.0.0.0")]
internal class Class83
{
  private static ResourceManager resourceManager_0;
  private static CultureInfo cultureInfo_0;

  internal Class83()
  {
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static ResourceManager ResourceManager
  {
    get
    {
      if (object.ReferenceEquals((object) Class83.resourceManager_0, (object) null))
        Class83.resourceManager_0 = new ResourceManager("ns1.Class83", typeof (Class83).Assembly);
      return Class83.resourceManager_0;
    }
  }

  [EditorBrowsable(EditorBrowsableState.Advanced)]
  internal static CultureInfo Culture
  {
    get => Class83.cultureInfo_0;
    set => Class83.cultureInfo_0 = value;
  }
}
