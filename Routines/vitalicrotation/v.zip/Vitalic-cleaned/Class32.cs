﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class32
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class32
{
  private static bool bool_0;
  private static Class32.Delegate5 delegate5_0 = new Class32.Delegate5(Class62.smethod_0);
  private static DateTime dateTime_0;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  protected static ulong UInt64_0 => Class50.ulong_0;

  public static double Double_0 => (DateTime.UtcNow - Class32.dateTime_0).TotalSeconds;

  public static void Initialise() => Class32.Attach();

  public static void Attach()
  {
    if (Class32.bool_0)
      return;
    Class37.smethod_8(Class37.Types.SPELL_AURA_APPLIED, new Class37.Delegate11(Class32.smethod_2));
    Class32.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class32.bool_0)
      return;
    Class37.smethod_9(Class37.Types.SPELL_AURA_APPLIED, new Class37.Delegate11(Class32.smethod_2));
    Class32.bool_0 = false;
  }

  public static void Shutdown() => Class32.smethod_0();

  public static void smethod_1() => Class32.dateTime_0 = DateTime.UtcNow;

  private static void smethod_2(EventArgs0 eventArgs0_0)
  {
    if ((long) eventArgs0_0.lazy_1.Value != (long) ((WoWObject) Class32.LocalPlayer_0).Guid || eventArgs0_0.lazy_7.Value != 1833 && eventArgs0_0.lazy_7.Value != 408 && eventArgs0_0.lazy_7.Value != 113953)
      return;
    Class32.dateTime_0 = DateTime.UtcNow;
  }

  private delegate void Delegate5(params object[] args);
}
