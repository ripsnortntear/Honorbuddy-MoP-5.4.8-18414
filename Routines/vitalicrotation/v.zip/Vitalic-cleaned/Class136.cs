﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class136
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.CommonBot;
using Styx.WoWInternals;
using System;
using System.Text;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class136
{
  private static bool bool_0;
  public static bool bool_1 = VitalicSettings.Instance.StatusFrameEnabled;
  private static Class136.Delegate37 delegate37_0 = new Class136.Delegate37(Class62.smethod_0);
  private static Class136.Delegate37 delegate37_1 = new Class136.Delegate37(Class62.smethod_1);

  private static void smethod_0()
  {
    if (!StyxWoW.IsInGame)
      return;
    if (!StyxWoW.IsInWorld)
      return;
    try
    {
      if (!Lua.GetReturnVal<bool>("return StatusFrameMoved ~= nil", 0U))
        return;
      VitalicSettings.Instance.StatusFrameLeft = Lua.GetReturnVal<double>("if sf then return sf:GetLeft() end", 0U);
      VitalicSettings.Instance.StatusFrameBottom = Lua.GetReturnVal<double>("if sf then return sf:GetBottom() end", 0U);
      VitalicSettings.Instance.Save();
    }
    catch (Exception ex)
    {
    }
  }

  public static void smethod_1()
  {
    if (!Class136.bool_0)
    {
      // ISSUE: reference to a compiler-generated field
      if (Class136.onBotStartDelegate_0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: method pointer
        Class136.onBotStartDelegate_0 = new BotEvents.OnBotStartDelegate((object) null, __methodptr(smethod_6));
      }
      // ISSUE: reference to a compiler-generated field
      BotEvents.OnBotStarted += Class136.onBotStartDelegate_0;
      // ISSUE: reference to a compiler-generated field
      if (Class136.onBotStopDelegate_0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: method pointer
        Class136.onBotStopDelegate_0 = new BotEvents.OnBotStopDelegate((object) null, __methodptr(smethod_7));
      }
      // ISSUE: reference to a compiler-generated field
      BotEvents.OnBotStopped += Class136.onBotStopDelegate_0;
      Class41.Event_0 += (EventHandler) ((sender, e) => Class136.smethod_1());
    }
    if (!Class136.bool_1 || Class136.bool_0 && Class136.smethod_2())
      return;
    Lua.DoString("CreateFont('v')\r\n                    v:SetFont('Fonts\\\\calibrib.ttf', 12, 'OUTLINE')\r\n                    v:SetJustifyH('LEFT')\r\n                    if v:GetFont() ~= nil then\r\n\t                    if sf == nil then\r\n\t\t                    sf = CreateFrame('Frame')\r\n\t\t                    sf:ClearAllPoints()\r\n\t\t                    sf:SetHeight(12)\r\n\t\t                    sf:SetWidth(300)\r\n\t\t                    sf:Show()\r\n\t\t                    sf.text = sf:CreateFontString(nil, 'BACKGROUND', 'v')\r\n\t\t                    sf.text:SetAllPoints()\r\n\t\t                    sf:SetPoint('CENTER',GeneralDockManager,-26,20)\r\n\t\t                    sf:SetScript('OnUpdate', StatusFrame_OnUpdate)\r\n\t\t                    sf:EnableMouse(true)\r\n\t\t                    sf:SetMovable(true)\r\n\t\t                    sf:RegisterForDrag('LeftButton')\r\n\t\t                    sf:SetScript('OnDragStart', sf.StartMoving)\r\n\t\t                    sf:SetScript('OnDragStop', function(self) sf.StopMovingOrSizing(self) StatusFrameMoved = true end)\r\n\t                    end\r\n                    end\r\n                ", "WoW.lua");
    if (VitalicSettings.Instance.MacrosEnabled)
      Lua.DoString("if sf then sf.text:SetText('|cffFFBE69Burst: |cFF00FF00Enabled  |cffFFBE69Lazy: |cFF00FF00Enabled  |cffFFBE69Macros: |cffb73737None') end ", "WoW.lua");
    else
      Lua.DoString("if sf then sf.text:SetText('|cffFFBE69Burst: |cFF00FF00Enabled  |cffFFBE69Lazy: |cFF00FF00Enabled') end", "WoW.lua");
    if (VitalicSettings.Instance.StatusFrameLeft != 0.0)
      Lua.DoString("if sf then sf:ClearAllPoints() sf:SetPoint('BOTTOMLEFT', {0}, {1}) end", new object[2]
      {
        (object) VitalicSettings.Instance.StatusFrameLeft,
        (object) VitalicSettings.Instance.StatusFrameBottom
      });
    Class136.bool_0 = true;
  }

  public static bool smethod_2() => Lua.GetReturnVal<bool>("return sf ~= nil", 0U);

  public static void smethod_3()
  {
    Class136.bool_1 = true;
    Class136.smethod_1();
  }

  public static void smethod_4()
  {
    Class136.bool_1 = false;
    Lua.DoString("if sf then sf:Hide() sf = nil end", "WoW.lua");
  }

  public static void smethod_5()
  {
    if (!Class136.bool_1)
      return;
    string str1 = Class144.Boolean_0 ? (Class144.bool_1 ? "|cFF00FF00Enabled" : "|cFF00FF00Enabled*") : "|cffb73737Disabled";
    string str2 = Class144.Boolean_1 ? (Class144.Boolean_3 ? "|cFF00FF00Enabled (PvE)" : "|cFF00FF00Enabled") : "|cffb73737Disabled";
    if (VitalicSettings.Instance.MacrosEnabled)
    {
      bool flag = Class137.smethod_7();
      StringBuilder stringBuilder = new StringBuilder();
      if (flag)
      {
        stringBuilder.Append(Class137.smethod_6());
        if (Class137.smethod_5(Class137.Macro.Garrote))
        {
          if (Class124.macroTargets_0 != Class137.MacroTargets.Target)
            stringBuilder.Append("*");
          else if (Class124.bool_0)
            stringBuilder.Append(" (pool)");
        }
        if (Class137.smethod_5(Class137.Macro.CheapShot) && Class124.macroTargets_0 != Class137.MacroTargets.Target)
          stringBuilder.Append("*");
        if (Class137.smethod_5(Class137.Macro.Gouge) && Class122.macroTargets_0 != Class137.MacroTargets.Target)
          stringBuilder.Append("*");
        if (Class137.smethod_5(Class137.Macro.Blind) && Class102.macroTargets_0 != Class137.MacroTargets.Target)
          stringBuilder.Append("*");
        if (Class137.smethod_5(Class137.Macro.RedirectKidney) && Class119.macroTargets_0 != Class137.MacroTargets.Target)
          stringBuilder.Append("*");
      }
      string str3 = flag ? "|cFF00FF00" + stringBuilder.ToString() : "|cffb73737None";
      Lua.DoString("if sf then sf.text:SetText('|cffFFBE69Burst: {0}  |cffFFBE69Lazy: {1}  |cffFFBE69Macros: {2}') end", new object[3]
      {
        (object) str1,
        (object) str2,
        (object) str3
      });
    }
    else
      Lua.DoString("if sf then sf.text:SetText('|cffFFBE69Burst: {0}  |cffFFBE69Lazy: {1}') end", new object[2]
      {
        (object) str1,
        (object) str2
      });
  }

  private delegate void Delegate37(params object[] args);
}
