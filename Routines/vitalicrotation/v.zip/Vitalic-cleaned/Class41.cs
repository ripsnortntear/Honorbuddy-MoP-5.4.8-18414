﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class41
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.Common;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class41
{
  private static bool bool_0;
  private static Class41.Delegate14 delegate14_0 = new Class41.Delegate14(Class62.smethod_0);
  internal static bool bool_1;
  internal static bool bool_2;
  internal static bool bool_3;
  internal static bool bool_4;
  private static DateTime dateTime_0;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static event EventHandler Event_0;

  internal static bool Boolean_0 => ((WoWPlayer) Class41.LocalPlayer_0).DuelTeamId != 0U;

  public static double Double_0 => (DateTime.UtcNow - Class41.dateTime_0).TotalSeconds;

  public static void Initialise() => Class41.Attach();

  public static void Attach()
  {
    if (Class41.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.PLAYER_ENTERING_WORLD, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_3)));
    Class41.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class41.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.PLAYER_ENTERING_WORLD, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_3)));
    Class41.bool_0 = false;
  }

  public static void Shutdown() => Class41.smethod_0();

  public static void smethod_1() => Class41.dateTime_0 = DateTime.UtcNow;

  public static void smethod_2()
  {
    Class41.bool_1 = Class41.LocalPlayer_0.CurrentMap.IsArena;
    Class41.bool_2 = Class41.LocalPlayer_0.CurrentMap.IsBattleground;
    Class41.bool_3 = Class41.LocalPlayer_0.CurrentMap.IsDungeon || Class41.LocalPlayer_0.CurrentMap.IsRaid;
    Class41.bool_4 = Class41.LocalPlayer_0.IsInInstance;
  }

  private static void smethod_3(object sender, LuaEventArgs e)
  {
    Class41.smethod_2();
    Class144.bool_4 = true;
    Class50.smethod_1();
    if (Class41.eventHandler_0 != null)
      Class41.eventHandler_0((object) null, (EventArgs) null);
    Logging.WriteDiagnostic("[Event] Context change detected");
    Class41.dateTime_0 = DateTime.UtcNow;
  }

  private delegate void Delegate14(params object[] args);
}
