﻿// Decompiled with JetBrains decompiler
// Type: VitalicEliteRogue.VitalicSettings
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.Common;
using Styx.Helpers;
using System.IO;
using System.Windows.Forms;

#nullable disable
namespace VitalicEliteRogue;

internal class VitalicSettings : Settings
{
  public static readonly VitalicSettings Instance = new VitalicSettings();

  private VitalicSettings()
    : base(Path.Combine(Utilities.AssemblyDirectory, "Settings\\Vitalic\\Vitalic.xml"), (string) null)
  {
  }

  [DefaultValue(0)]
  [Setting]
  public Keys GarroteKeyBind { get; set; }

  [Setting]
  [DefaultValue(0)]
  public Keys CheapShotKeyBind { get; set; }

  [Setting]
  [DefaultValue(0)]
  public Keys BlindKeyBind { get; set; }

  [Setting]
  [DefaultValue(0)]
  public Keys GougeKeyBind { get; set; }

  [DefaultValue(0)]
  [Setting]
  public Keys RedirectKidneyKeyBind { get; set; }

  [Setting]
  [DefaultValue(Keys.LShiftKey)]
  public Keys FocusMacroKeyBind { get; set; }

  [Setting]
  [DefaultValue(0)]
  public Keys OpenerModifierKeyBind { get; set; }

  [DefaultValue(Keys.LMenu)]
  [Setting]
  public Keys BurstKeyBind { get; set; }

  [DefaultValue(65700)]
  [Setting]
  public Keys BurstNoShadowBladesKeyBind { get; set; }

  [Setting]
  [DefaultValue(Keys.RShiftKey)]
  public Keys LazyKeyBind { get; set; }

  [Setting]
  [DefaultValue(Keys.LShiftKey)]
  public Keys PauseKeyBind { get; set; }

  [DefaultValue(131236)]
  [Setting]
  public Keys PauseDamageKeyBind { get; set; }

  [Setting]
  [DefaultValue(Keys.RControlKey)]
  public Keys EventsKeyBind { get; set; }

  [DefaultValue(Keys.LControlKey)]
  [Setting]
  public Keys KidneyShotKeyBind { get; set; }

  [Setting]
  [DefaultValue(Keys.XButton2)]
  public Keys SmokeBombKeyBind { get; set; }

  [DefaultValue(0)]
  [Setting]
  public Keys RestealthKeyBind { get; set; }

  [Setting]
  [DefaultValue(0)]
  public Keys FastKickKeyBind { get; set; }

  [DefaultValue(0)]
  [Setting]
  public Keys AutoKidneyKeyBind { get; set; }

  [Setting]
  [DefaultValue(0)]
  public int MainHandPoison { get; set; }

  [DefaultValue(0)]
  [Setting]
  public int OffHandPoison { get; set; }

  [Setting]
  [DefaultValue(612)]
  public int UIWidth { get; set; }

  [Setting]
  [DefaultValue(425)]
  public int UIHeight { get; set; }

  [DefaultValue(0)]
  [Setting]
  public int UILocationX { get; set; }

  [DefaultValue(0)]
  [Setting]
  public int UILocationY { get; set; }

  [Setting]
  [DefaultValue(3)]
  public int UILastTab { get; set; }

  [Setting]
  [DefaultValue(3)]
  public int UIColorStyle { get; set; }

  [DefaultValue(0)]
  [Setting]
  public double StatusFrameLeft { get; set; }

  [DefaultValue(0)]
  [Setting]
  public double StatusFrameBottom { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool StatusFrameEnabled { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool AlertFontsEnabled { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool SpellAlertsEnabled { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool SoundAlertsEnabled { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool LogMessagesEnabled { get; set; }

  [Setting]
  [DefaultValue(2)]
  public double MacroDelay { get; set; }

  [DefaultValue(1)]
  [Setting]
  public double StickyDelay { get; set; }

  [Setting]
  [DefaultValue(false)]
  public bool MacrosEnabled { get; set; }

  [DefaultValue(30)]
  [Setting]
  public int LowHealthWarning { get; set; }

  [DefaultValue(0)]
  [Setting]
  public int SubterfugeOpeners { get; set; }

  [DefaultValue(90)]
  [Setting]
  public int BurstEnergy { get; set; }

  [DefaultValue(70)]
  [Setting]
  public int BurstEnergyOpener { get; set; }

  [DefaultValue(30)]
  [Setting]
  public int BurstHealth { get; set; }

  [Setting]
  [DefaultValue(15)]
  public int BurstPreparation { get; set; }

  [Setting]
  [DefaultValue(0.5)]
  public double BurstStunDR { get; set; }

  [DefaultValue(0)]
  [Setting]
  public int CombatBurst { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool AutoTarget { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool AlwaysStealth { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool AutoRedirect { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool AutoKidney { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool AutoPreparation { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool AutoSmokeBomb { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool AutoShroud { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool AutoBurstOfSpeed { get; set; }

  [DefaultValue(15)]
  [Setting]
  public int AutoShadowstep { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool AutoFlagReturn { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool EventAutoFace { get; set; }

  [DefaultValue("")]
  [Setting]
  public string EventBlacklist { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool AutoShiv { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool LazyEviscerate { get; set; }

  [Setting]
  [DefaultValue(0.5)]
  public double InterruptDelay { get; set; }

  [DefaultValue(0.2)]
  [Setting]
  public double InterruptMinimum { get; set; }

  [Setting]
  [DefaultValue(0.2)]
  public double InterruptShadowstepBuffer { get; set; }

  [DefaultValue(0.7)]
  [Setting]
  public double GougeDelay { get; set; }

  [DefaultValue(80 /*0x50*/)]
  [Setting]
  public int GougeNoKickHP { get; set; }

  [DefaultValue(25)]
  [Setting]
  public int KidneyShotEnergy { get; set; }

  [Setting]
  [DefaultValue(4)]
  public int KidneyShotCPs { get; set; }

  [Setting]
  [DefaultValue(false)]
  public bool AlwaysUseHemo { get; set; }

  [Setting]
  [DefaultValue(2)]
  public double HemoDelay { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool RuptureOverGarrote { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool LazyPooling { get; set; }

  [DefaultValue(30)]
  [Setting]
  public int OpenerTPS { get; set; }

  [DefaultValue("")]
  [Setting]
  public string TricksTarget { get; set; }

  [Setting]
  [DefaultValue(17)]
  public Totems TotemStomp { get; set; }

  [Setting]
  [DefaultValue(30)]
  public int HealthstoneHP { get; set; }

  [Setting]
  [DefaultValue(40)]
  public int TeammateHP { get; set; }

  [DefaultValue(50)]
  [Setting]
  public int RecuperateHP { get; set; }

  [Setting]
  [DefaultValue(60)]
  public int AutoFeint { get; set; }

  [Setting]
  [DefaultValue(5)]
  public int FeintLastDamage { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool FeintInMeleeRange { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool ShadowstepTraps { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool AutoMoveOnTraps { get; set; }

  [DefaultValue(false)]
  [Setting]
  public bool PveMode { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool AcceptQueues { get; set; }

  [Setting]
  [DefaultValue(true)]
  public bool AlertQueues { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool AntiAFK { get; set; }

  [DefaultValue(true)]
  [Setting]
  public bool DisableCTM { get; set; }

  [DefaultValue(false)]
  [Setting]
  public bool DiagnosticMode { get; set; }

  [DefaultValue(100)]
  [Setting]
  public int ManualCastPause { get; set; }

  [Setting]
  [DefaultValue(0)]
  public int AutoFocus { get; set; }

  [DefaultValue(0)]
  [Setting]
  public int AutoFocusTargets { get; set; }
}
