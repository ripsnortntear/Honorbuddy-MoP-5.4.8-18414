﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class116
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.Common;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class116 : Class91
{
  private static WoWUnit woWUnit_0;
  private static WoWUnit woWUnit_1;
  private static WoWUnit woWUnit_2;
  private static Composite composite_0 = Class116.Composite_0;
  private static bool bool_0;
  private static DateTime dateTime_0;
  private static bool bool_1;
  private static HashSet<WoWClass> hashSet_0 = new HashSet<WoWClass>()
  {
    (WoWClass) 4,
    (WoWClass) 11
  };

  static Class116()
  {
    Class144.Event_0 += (Class144.Delegate42) ((sender, e) =>
    {
      Class116.bool_1 = Class116.Boolean_21;
      if (!Class116.bool_1 && DateTime.UtcNow - Class116.dateTime_0 < TimeSpan.FromSeconds(0.5))
        return;
      if (!Composite.op_Inequality(Class116.composite_0, (Composite) null))
        return;
      try
      {
        if (!Class116.bool_0)
        {
          Class116.composite_0.Start((object) null);
          Class116.bool_0 = true;
        }
        Class116.composite_0.Tick((object) null);
        RunStatus? lastStatus = Class116.composite_0.LastStatus;
        if ((lastStatus.GetValueOrDefault() != 1 ? 1 : (!lastStatus.HasValue ? 1 : 0)) != 0)
        {
          Class116.composite_0.Stop((object) null);
          Class116.composite_0.Start((object) null);
        }
        Class116.dateTime_0 = DateTime.UtcNow;
      }
      catch (Exception ex)
      {
        Logging.WriteException(ex);
        Class116.composite_0.Stop((object) null);
        Class116.composite_0.Start((object) null);
        throw;
      }
    });
  }

  private static bool Boolean_21
  {
    get
    {
      return (Class91.Boolean_18 || Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 51713)) && !Class116.Boolean_22 && !Class91.Boolean_3;
    }
  }

  private static bool Boolean_22
  {
    get
    {
      if (WoWObject.op_Inequality((WoWObject) Class116.woWUnit_1, (WoWObject) null) && ((WoWObject) Class116.woWUnit_1).IsValid)
      {
        if (Class74.smethod_1(6770, Class116.woWUnit_1) > 0.5)
          return true;
        Class116.woWUnit_1 = (WoWUnit) null;
      }
      return false;
    }
  }

  private static bool Boolean_23
  {
    get
    {
      Class116.woWUnit_0 = (WoWUnit) ObjectManager.GetObjectsOfType<WoWPlayer>(false, false).FirstOrDefault<WoWPlayer>((Func<WoWPlayer, bool>) (woWPlayer_0 => Class116.hashSet_0.Contains(((WoWUnit) woWPlayer_0).Class) && !((WoWUnit) woWPlayer_0).IsDead && !((WoWUnit) woWPlayer_0).Combat && Class91.LocalPlayer_0.smethod_0((WoWUnit) woWPlayer_0) && Class70.smethod_2((WoWUnit) woWPlayer_0) < 12.0 && ((WoWUnit) woWPlayer_0).smethod_4()));
      if (!WoWObject.op_Inequality((WoWObject) Class116.woWUnit_0, (WoWObject) null))
        return false;
      Class116.woWUnit_2 = Class116.woWUnit_0;
      return true;
    }
  }

  private static Composite Composite_0
  {
    get
    {
      Composite[] compositeArray1 = new Composite[2];
      Composite[] compositeArray2 = compositeArray1;
      if (Class116.canRunDecoratorDelegate_0 == null)
        Class116.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
      CanRunDecoratorDelegate decoratorDelegate0 = Class116.canRunDecoratorDelegate_0;
      if (Class116.actionSucceedDelegate_0 == null)
        Class116.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_8));
      Action action1 = new Action(Class116.actionSucceedDelegate_0);
      Decorator decorator1 = new Decorator(decoratorDelegate0, (Composite) action1);
      compositeArray2[0] = (Composite) decorator1;
      Composite[] compositeArray3 = compositeArray1;
      if (Class116.canRunDecoratorDelegate_1 == null)
        Class116.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
      CanRunDecoratorDelegate decoratorDelegate1 = Class116.canRunDecoratorDelegate_1;
      if (Class116.actionSucceedDelegate_1 == null)
        Class116.actionSucceedDelegate_1 = new ActionSucceedDelegate((object) null, __methodptr(smethod_10));
      Action action2 = new Action(Class116.actionSucceedDelegate_1);
      Decorator decorator2 = new Decorator(decoratorDelegate1, (Composite) action2);
      compositeArray3[1] = (Composite) decorator2;
      return (Composite) new PrioritySelector(compositeArray1);
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[4];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class116.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class116.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_11));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate2 = Class116.canRunDecoratorDelegate_2;
    // ISSUE: reference to a compiler-generated field
    if (Class116.actionDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class116.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_12));
    }
    // ISSUE: reference to a compiler-generated field
    Action action1 = new Action(Class116.actionDelegate_0);
    Decorator decorator1 = new Decorator(decoratorDelegate2, (Composite) action1);
    compositeArray2[0] = (Composite) decorator1;
    Composite[] compositeArray3 = compositeArray1;
    Class144.Delegate43 delegate43_4_1 = (Class144.Delegate43) (object_0 => Class116.woWUnit_2);
    // ISSUE: reference to a compiler-generated field
    if (Class116.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class116.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_14));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate3 = Class116.canRunDecoratorDelegate_3;
    Action action_0 = (Action) (() => Class91.LocalPlayer_0.SetFacing(Class116.woWUnit_2));
    Composite composite1 = Class77.smethod_0(6770, delegate43_4_1, decoratorDelegate3, "Sap", action_0);
    compositeArray3[1] = composite1;
    Composite[] compositeArray4 = compositeArray1;
    Class144.Delegate43 delegate43_4_2 = (Class144.Delegate43) (object_0 => Class116.woWUnit_2);
    // ISSUE: reference to a compiler-generated field
    if (Class116.canRunDecoratorDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class116.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_17));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate4 = Class116.canRunDecoratorDelegate_4;
    Composite composite2 = Class77.smethod_0(2094, delegate43_4_2, decoratorDelegate4, "Blind");
    compositeArray4[2] = composite2;
    Composite[] compositeArray5 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class116.canRunDecoratorDelegate_5 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class116.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_18));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate5 = Class116.canRunDecoratorDelegate_5;
    Composite[] compositeArray6 = new Composite[2];
    Composite[] compositeArray7 = compositeArray6;
    // ISSUE: reference to a compiler-generated field
    if (Class116.canRunDecoratorDelegate_6 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class116.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_19));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate6 = Class116.canRunDecoratorDelegate_6;
    // ISSUE: reference to a compiler-generated field
    if (Class116.actionSucceedDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class116.actionSucceedDelegate_2 = new ActionSucceedDelegate((object) null, __methodptr(smethod_20));
    }
    // ISSUE: reference to a compiler-generated field
    Action action2 = new Action(Class116.actionSucceedDelegate_2);
    DecoratorContinue decoratorContinue = new DecoratorContinue(decoratorDelegate6, (Composite) action2);
    compositeArray7[0] = (Composite) decoratorContinue;
    Composite[] compositeArray8 = compositeArray6;
    // ISSUE: reference to a compiler-generated field
    if (Class116.canRunDecoratorDelegate_7 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class116.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_21));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate7 = Class116.canRunDecoratorDelegate_7;
    // ISSUE: reference to a compiler-generated field
    if (Class116.actionSucceedDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class116.actionSucceedDelegate_3 = new ActionSucceedDelegate((object) null, __methodptr(smethod_22));
    }
    // ISSUE: reference to a compiler-generated field
    Action action3 = new Action(Class116.actionSucceedDelegate_3);
    Decorator decorator2 = new Decorator(decoratorDelegate7, (Composite) action3);
    compositeArray8[1] = (Composite) decorator2;
    Sequence sequence = new Sequence(compositeArray6);
    Decorator decorator3 = new Decorator(decoratorDelegate5, (Composite) sequence);
    compositeArray5[3] = (Composite) decorator3;
    return (Composite) new Class89(compositeArray1);
  }
}
