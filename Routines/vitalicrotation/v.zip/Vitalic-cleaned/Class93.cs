﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class93
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;

#nullable disable
namespace ns1;

internal class Class93 : Class91
{
  private static bool Boolean_21
  {
    get
    {
      if (Class53.smethod_3(Class91.WoWUnit_0, 6770) && ((WoWObject) Class91.WoWUnit_0).Distance <= 28.0)
        return false;
      return ((WoWObject) Class91.WoWUnit_0).Distance > 8.0 || (double) Class91.WoWUnit_0.MovementInfo.CurrentSpeed >= 7.0;
    }
  }

  private static bool Boolean_22
  {
    get
    {
      return ((WoWUnit) Class91.LocalPlayer_0).MovementInfo.MovingForward && (double) ((WoWUnit) Class91.LocalPlayer_0).MovementInfo.TimeMoved > 0.25 && !((WoWUnit) Class91.LocalPlayer_0).MovementInfo.IsStrafing && ((WoWObject) Class91.LocalPlayer_0).IsSafelyFacing((WoWObject) Class91.WoWUnit_0);
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class93.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class93.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    return Class77.smethod_2(2983, Class93.canRunDecoratorDelegate_0, "Sprint");
  }
}
