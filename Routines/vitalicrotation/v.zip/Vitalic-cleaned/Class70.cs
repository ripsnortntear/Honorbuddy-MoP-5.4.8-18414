﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class70
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal static class Class70
{
  private static Class70.Delegate29 delegate29_0 = new Class70.Delegate29(Class62.smethod_0);
  private static DateTime dateTime_0;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static WoWUnit WoWUnit_1 => Class50.woWUnit_1;

  public static bool smethod_0(this LocalPlayer localPlayer_0, WoWUnit woWUnit_0)
  {
    if (WoWObject.op_Equality((WoWObject) woWUnit_0, (WoWObject) null) || !((WoWObject) woWUnit_0).IsValid)
      return false;
    string string_0 = "attackable_" + (object) ((WoWObject) woWUnit_0).Guid;
    Class51.Class52<bool> gparam_0 = Class51.smethod_0<Class51.Class52<bool>>(string_0);
    if (gparam_0 == null || Class144.Boolean_3 || Class41.Boolean_0 || Class41.Double_0 < 3.0)
    {
      gparam_0 = new Class51.Class52<bool>();
      gparam_0.Value = Class41.bool_1 || Class41.bool_2 ? !Class63.smethod_3(woWUnit_0) : !woWUnit_0.IsFriendly || Class63.smethod_1(woWUnit_0);
      Class51.smethod_1<Class51.Class52<bool>>(gparam_0, string_0, 120000);
    }
    return gparam_0.Value;
  }

  public static double smethod_1(this LocalPlayer localPlayer_0)
  {
    Class51.Class52<double> gparam_0 = Class51.smethod_0<Class51.Class52<double>>("energy_regen");
    if (gparam_0 == null)
    {
      using (StyxWoW.Memory.AcquireFrame())
      {
        gparam_0 = new Class51.Class52<double>();
        gparam_0.Value = Lua.GetReturnVal<double>("return GetPowerRegen()", 0U);
        Class51.smethod_1<Class51.Class52<double>>(gparam_0, "energy_regen", 3000);
      }
    }
    return gparam_0.Value;
  }

  public static double smethod_2(this WoWUnit woWUnit_0, bool bool_0 = false)
  {
    double num = bool_0 ? 0.1 : 1.0;
    return ((WoWObject) woWUnit_0).Distance - ((double) woWUnit_0.CombatReach + num);
  }

  public static bool smethod_3(this WoWUnit woWUnit_0, int int_0 = 100)
  {
    return woWUnit_0.IsMoving && (long) woWUnit_0.MovementInfo.TimeMoved >= (long) int_0;
  }

  public static bool smethod_4(this WoWUnit woWUnit_0)
  {
    return woWUnit_0.smethod_7(1784, 115191, 5215, 115193, 115192, 112942);
  }

  public static bool smethod_5(this WoWUnit woWUnit_0)
  {
    return DateTime.UtcNow - Class40.dateTime_0 < TimeSpan.FromSeconds(6.0);
  }

  public static double smethod_6(this WoWUnit woWUnit_0)
  {
    return (DateTime.UtcNow - Class47.dateTime_0).TotalSeconds;
  }

  public static bool smethod_7(this LocalPlayer localPlayer_0) => Class48.bool_1;

  public static bool smethod_8(this WoWUnit woWUnit_0, bool bool_0 = false)
  {
    bool flag = false;
    if (Class53.smethod_3(woWUnit_0, 27827))
      return true;
    if (woWUnit_0.smethod_1().Any<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => Class65.hashSet_0.Contains(woWAura_0.SpellId))))
      flag = true;
    if (woWUnit_0.smethod_2().Any<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => Class74.hashSet_0.Contains(woWAura_0.SpellId))))
      flag = true;
    if (flag && DateTime.UtcNow - Class70.dateTime_0 > TimeSpan.FromSeconds(10.0))
    {
      Class140.smethod_7("Target is immune", Class140.struct24_4);
      Class70.dateTime_0 = DateTime.UtcNow;
    }
    if (flag && (!Class53.smethod_3((WoWUnit) Class70.LocalPlayer_0, 121471) || !woWUnit_0.HasAura(1022)))
      Class77.smethod_9();
    if (bool_0 && woWUnit_0.HasAura(46924))
      flag = true;
    return flag;
  }

  public static bool smethod_9(this WoWUnit woWUnit_0, bool bool_0 = false)
  {
    if (Class65.smethod_1(125174, woWUnit_0, false) <= 0.0)
      return woWUnit_0.smethod_8(bool_0);
    if (DateTime.UtcNow - Class70.dateTime_0 > TimeSpan.FromSeconds(10.0))
    {
      Class140.smethod_7("Target is damage immune", Class140.struct24_4);
      Class70.dateTime_0 = DateTime.UtcNow;
    }
    Class77.smethod_9();
    return true;
  }

  public static bool smethod_10(this WoWUnit woWUnit_0) => woWUnit_0.smethod_7(3411, 114029);

  public static bool smethod_11(this WoWUnit woWUnit_0)
  {
    return woWUnit_0.IsTotem || woWUnit_0.smethod_0().Any<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => Class65.hashSet_1.Contains(woWAura_0.SpellId)));
  }

  public static bool smethod_12(this WoWUnit woWUnit_0)
  {
    return woWUnit_0.smethod_0().Any<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => Class65.hashSet_2.Contains(woWAura_0.SpellId)));
  }

  public static bool smethod_13(this WoWUnit woWUnit_0)
  {
    return woWUnit_0.smethod_0().Any<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => Class65.hashSet_3.Contains(woWAura_0.SpellId)));
  }

  public static bool smethod_14(this WoWUnit woWUnit_0, int int_0 = 1)
  {
    double num = Class74.smethod_2(1943, true);
    return Class71.CurrentSpec == 260 || woWUnit_0.IsTotem || Class71.CurrentSpec == 261 && (num > (double) int_0 || Class74.smethod_2(703, true) > (double) int_0 || Class70.LocalPlayer_0.smethod_3(146631) && Class74.smethod_2(89775, true) > (double) int_0) || Class71.CurrentSpec == 259 && (num > (double) int_0 && num >= 2.0 || !VitalicSettings.Instance.RuptureOverGarrote && Class74.smethod_2(703, true) > (double) int_0);
  }

  public static bool smethod_15(this WoWUnit woWUnit_0)
  {
    bool flag;
    if ((flag = Class63.smethod_1(woWUnit_0)) && woWUnit_0.Level == 70)
      return false;
    WoWClass woWclass = woWUnit_0.Class;
    return flag || woWUnit_0.PowerType == null || woWclass == 6 || woWclass == 11 || woWclass == 9;
  }

  public static bool smethod_16(this WoWUnit woWUnit_0)
  {
    if (woWUnit_0.smethod_17())
      return false;
    WoWClass woWclass = woWUnit_0.Class;
    return woWclass == 8 || woWclass == 7 || woWclass == 6 || woWclass == 2 && woWUnit_0.MaxMana < woWUnit_0.MaxHealth / 2U;
  }

  public static bool smethod_17(this WoWUnit woWUnit_0)
  {
    WoWClass woWclass = woWUnit_0.Class;
    if ((woWclass == 11 || woWclass == 2 || woWclass == 5 || woWclass == 7) && woWUnit_0.MaxMana >= 290000U)
    {
      if (!woWUnit_0.smethod_7(24858, 15473, 324))
        return true;
    }
    return woWclass == 10 && woWUnit_0.PowerType != 3;
  }

  public static bool smethod_18(this WoWUnit woWUnit_0)
  {
    WoWClass woWclass = woWUnit_0.Class;
    return woWclass == 3 || woWclass == 4 || woWclass == 1 || woWclass == 6 || (woWclass == 11 || woWclass == 2 || woWclass == 7) && woWUnit_0.MaxMana < woWUnit_0.MaxHealth / 3U || woWclass == 10 && woWUnit_0.PowerType == 3;
  }

  public static bool smethod_19(this LocalPlayer localPlayer_0, WoWUnit woWUnit_0)
  {
    return Class70.LocalPlayer_0.smethod_4(11) && Class70.smethod_2(woWUnit_0) <= 25.0 && !Class59.smethod_0(36554) && !((WoWUnit) localPlayer_0).HasAura(88611) && !Class137.smethod_5(Class137.Macro.Blind) && !((WoWUnit) Class70.LocalPlayer_0).smethod_0(Class68.Enum15.const_5) && Class63.smethod_4(woWUnit_0);
  }

  public static WoWPlayer smethod_20(this WoWGroupInfo woWGroupInfo_0)
  {
    if (!Class41.bool_1)
      return (WoWPlayer) null;
    int teammateHp = VitalicSettings.Instance.TeammateHP;
    List<WoWPlayer> partyMembers = Class70.LocalPlayer_0.PartyMembers;
    double num = 100.0;
    WoWPlayer woWplayer1 = (WoWPlayer) null;
    if (teammateHp > 0 && partyMembers.Count > 0)
    {
      foreach (WoWPlayer woWplayer2 in partyMembers)
      {
        if (WoWObject.op_Inequality((WoWObject) woWplayer2, (WoWObject) null) && ((WoWObject) woWplayer2).IsValid && !((WoWUnit) woWplayer2).IsDead && !woWplayer2.IsGhost)
        {
          double healthPercent = ((WoWUnit) woWplayer2).HealthPercent;
          if (healthPercent < num)
          {
            num = healthPercent;
            woWplayer1 = woWplayer2;
          }
        }
      }
      if (num <= (double) teammateHp)
        return woWplayer1;
    }
    return (WoWPlayer) null;
  }

  public static bool smethod_21(this LocalPlayer localPlayer_0, WoWUnit woWUnit_0, double double_0)
  {
    if (Class32.Double_0 > double_0)
    {
      if (!Class70.LocalPlayer_0.IsBehind(woWUnit_0))
        return true;
      Class32.smethod_1();
      return false;
    }
    return ((WoWUnit) Class70.LocalPlayer_0).smethod_0(Class68.Enum15.const_5);
  }

  public static bool smethod_22(this LocalPlayer localPlayer_0)
  {
    return Class141.ulong_0 != 0UL || Class141.bool_6;
  }

  private delegate void Delegate29(params object[] args);
}
