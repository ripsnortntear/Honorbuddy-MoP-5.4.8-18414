﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class46
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.CommonBot;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class46
{
  private static bool bool_0;
  private static Class46.Delegate19 delegate19_0 = new Class46.Delegate19(Class62.smethod_0);
  public static bool bool_1;
  public static bool bool_2;
  public static DateTime dateTime_0;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static void Initialise()
  {
    Class46.Attach();
    Class144.Event_0 += (Class144.Delegate42) ((sender, e) =>
    {
      if (VitalicSettings.Instance.MacrosEnabled || !Class144.class80_10.method_2())
        return;
      Class46.bool_2 = !Class46.bool_2;
      if (Class46.bool_2)
        Class140.smethod_9("Restealth: |cFF00FF00Enabled");
      else
        Class140.smethod_9("Restealth: |cffb73737Disabled");
      if (!Class46.bool_2)
        return;
      Mount.Dismount();
    });
  }

  public static void Attach()
  {
    if (Class46.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.PLAYER_REGEN_ENABLED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.PLAYER_REGEN_DISABLED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_2)));
    Class46.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class46.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.PLAYER_REGEN_ENABLED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.PLAYER_REGEN_DISABLED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_2)));
    Class46.bool_0 = false;
  }

  public static void Shutdown() => Class46.smethod_0();

  private static void smethod_1(object sender, LuaEventArgs e)
  {
    if (Class45.Boolean_0)
      return;
    if (Class124.bool_0)
      Class124.bool_0 = false;
    Class46.dateTime_0 = DateTime.UtcNow;
    Class46.bool_1 = true;
  }

  private static void smethod_2(object sender, LuaEventArgs e) => Class46.bool_1 = false;

  private delegate void Delegate19(params object[] args);
}
