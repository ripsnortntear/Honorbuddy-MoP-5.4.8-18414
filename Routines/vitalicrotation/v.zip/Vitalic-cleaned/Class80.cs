﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class80
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.Common;
using Styx.TreeSharp;
using Styx.WoWInternals;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class80
{
  private bool bool_0;
  private bool bool_1;
  private Keys keys_0;
  private Keys keys_1;
  private bool bool_2;
  private bool bool_3;
  private bool bool_4;
  protected DateTime dateTime_0;
  protected double double_0 = VitalicSettings.Instance.StickyDelay;
  private static readonly IntPtr intptr_0 = (IntPtr) 12265772;
  private static bool bool_5;
  private static bool bool_6;
  private static DateTime dateTime_1;
  private static bool bool_7;
  private static bool bool_8;
  private static HashSet<Keys> hashSet_0 = new HashSet<Keys>();
  private static HashSet<Keys> hashSet_1 = new HashSet<Keys>();
  private static HashSet<Keys> hashSet_2 = new HashSet<Keys>();
  private static Keys[] keys_2 = (Keys[]) Enum.GetValues(typeof (Keys));
  private static HashSet<Keys> hashSet_3 = new HashSet<Keys>()
  {
    Keys.LButton,
    Keys.RButton,
    Keys.LWin,
    Keys.RWin,
    Keys.ShiftKey,
    Keys.LShiftKey,
    Keys.RShiftKey,
    Keys.ControlKey,
    Keys.LControlKey,
    Keys.RControlKey,
    Keys.Menu,
    Keys.LMenu,
    Keys.RMenu,
    Keys.Tab,
    Keys.Capital,
    Keys.RButton,
    Keys.LButton
  };
  private static readonly HashSet<string> hashSet_4 = new HashSet<string>()
  {
    "MOVEFORWARD",
    "MOVEBACKWARD",
    "TURNLEFT",
    "TURNRIGHT",
    "STRAFELEFT",
    "STRAFERIGHT",
    "JUMP",
    "TURNORACTION",
    "CAMERAORSELECTORMOVE"
  };

  public Class80() => this.keys_0 = Keys.None;

  public Class80(Keys keys_3)
  {
    this.bool_2 = (keys_3 & Keys.Shift) != Keys.None;
    this.bool_1 = (keys_3 & Keys.Control) != Keys.None;
    this.bool_0 = (keys_3 & Keys.Alt) != Keys.None;
    this.keys_0 = Keys.Shift & keys_3 | Keys.Control & keys_3 | Keys.Alt & keys_3;
  }

  public Class80(bool bool_9) => this.bool_3 = bool_9;

  public Class80(bool bool_9, bool bool_10)
  {
    this.bool_3 = bool_9;
    this.bool_4 = bool_10;
  }

  public DateTime DateTime_0
  {
    get => this.dateTime_0;
    set => this.dateTime_0 = value;
  }

  private bool Boolean_0
  {
    get
    {
      return this.bool_3 || this.keys_1 != this.keys_0 || DateTime.UtcNow - this.dateTime_0 > TimeSpan.FromSeconds(0.3);
    }
  }

  private bool Boolean_1 => this.keys_0 == Keys.LShiftKey || this.keys_0 == Keys.RShiftKey;

  private bool Boolean_2 => this.keys_0 == Keys.LControlKey || this.keys_0 == Keys.RControlKey;

  private bool Boolean_3 => this.keys_0 == Keys.LMenu || this.keys_0 == Keys.RMenu;

  private bool Boolean_4
  {
    get
    {
      return this.bool_4 && !VitalicSettings.Instance.MacrosEnabled && DateTime.UtcNow - this.dateTime_0 < TimeSpan.FromSeconds(this.double_0);
    }
  }

  private bool method_0(bool bool_9, bool bool_10, bool bool_11)
  {
    return bool_9 && Class80.hashSet_0.Contains(this.keys_0) || bool_10 && Class80.hashSet_1.Contains(this.keys_0) || bool_11 && Class80.hashSet_2.Contains(this.keys_0);
  }

  public static Composite Composite_0
  {
    get
    {
      if (Class80.actionDelegate_0 == null)
        Class80.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_7));
      return (Composite) new Action(Class80.actionDelegate_0);
    }
  }

  public Keys Keys_0
  {
    get => this.keys_0;
    set
    {
      this.bool_2 = (value & Keys.Shift) != Keys.None;
      this.bool_1 = (value & Keys.Control) != Keys.None;
      this.bool_0 = (value & Keys.Alt) != Keys.None;
      value ^= Keys.Shift & value | Keys.Control & value | Keys.Alt & value;
      this.keys_0 = value;
    }
  }

  public static void smethod_0()
  {
    Class80.hashSet_0.Clear();
    Class80.hashSet_1.Clear();
    Class80.hashSet_2.Clear();
    foreach (Class80 class80 in Class144.hashSet_0)
      class80.method_1();
  }

  public void method_1()
  {
    if (this.bool_2 && !Class80.hashSet_0.Contains(this.keys_0))
      Class80.hashSet_0.Add(this.keys_0);
    if (this.bool_1 && !Class80.hashSet_1.Contains(this.keys_0))
      Class80.hashSet_1.Add(this.keys_0);
    if (!this.bool_0 || Class80.hashSet_2.Contains(this.keys_0))
      return;
    Class80.hashSet_2.Add(this.keys_0);
  }

  [DllImport("user32.dll")]
  private static extern short GetAsyncKeyState(Keys keys_3);

  public static bool smethod_1(Keys keys_3, bool bool_9 = false)
  {
    return bool_9 ? Class80.GetAsyncKeyState(keys_3) == (short) -32767 : Class80.GetAsyncKeyState(keys_3) != (short) 0;
  }

  [DllImport("user32.dll", SetLastError = true)]
  private static extern IntPtr GetForegroundWindow();

  [DllImport("user32.dll")]
  private static extern int GetWindowThreadProcessId(IntPtr intptr_1, out uint uint_0);

  private static Process smethod_2(IntPtr intptr_1)
  {
    try
    {
      uint uint_0;
      Class80.GetWindowThreadProcessId(intptr_1, out uint_0);
      return Process.GetProcessById((int) uint_0);
    }
    catch
    {
      return (Process) null;
    }
  }

  private static Process smethod_3() => Class80.smethod_2(Class80.GetForegroundWindow());

  public bool method_2(bool bool_9 = false)
  {
    if (this.keys_0 == Keys.None || !Class80.bool_5 || Class80.bool_6 || Class144.smethod_5() || !this.Boolean_0)
      return false;
    bool bool_9_1 = Class80.smethod_1(Keys.ShiftKey);
    bool bool_10 = Class80.smethod_1(Keys.ControlKey);
    bool bool_11 = Class80.smethod_1(Keys.Menu);
    if (this.bool_2 && !bool_9_1 || this.bool_1 && !bool_10 || this.bool_0 && !bool_11)
      return false;
    if ((DateTime.UtcNow - Class80.dateTime_1).TotalSeconds < 1.0)
      Class80.smethod_1(this.keys_0);
    if (this.Boolean_1)
    {
      if (!bool_9 && this.Boolean_4)
        return true;
      if (!Class80.smethod_1(this.keys_0) || bool_10 && !this.bool_1 || bool_11 && !this.bool_0)
        return false;
      this.keys_1 = this.keys_0;
      this.dateTime_0 = DateTime.UtcNow;
      return true;
    }
    if (this.Boolean_2)
    {
      if (!bool_9 && this.Boolean_4)
        return true;
      if (!Class80.smethod_1(this.keys_0) || bool_9_1 && !this.bool_2 || bool_11 && !this.bool_0)
        return false;
      this.keys_1 = this.keys_0;
      this.dateTime_0 = DateTime.UtcNow;
      return true;
    }
    if (this.Boolean_3)
    {
      if (!bool_9 && this.Boolean_4)
        return true;
      if (!Class80.smethod_1(this.keys_0) || bool_9_1 && !this.bool_2 || bool_10 && !this.bool_1)
        return false;
      this.keys_1 = this.keys_0;
      this.dateTime_0 = DateTime.UtcNow;
      return true;
    }
    if (Class80.smethod_1(this.keys_0))
    {
      if ((!Class80.bool_7 && !Class80.bool_8 || this.method_0(bool_9_1, bool_10, bool_11)) && (!this.bool_2 && bool_9_1 || !this.bool_1 && bool_10 || !this.bool_0 && bool_11))
        return false;
      this.keys_1 = this.keys_0;
      this.dateTime_0 = DateTime.UtcNow;
      return true;
    }
    if (!bool_9 && this.Boolean_4)
      return true;
    this.keys_1 = Keys.None;
    return false;
  }

  internal static void smethod_4()
  {
    foreach (Keys keys_3 in Class80.keys_2)
    {
      string returnVal = Lua.GetReturnVal<string>($"return GetBindingAction('{Class80.smethod_6(keys_3)}')", 0U);
      if (Class80.hashSet_4.Contains(returnVal) && !Class80.hashSet_3.Contains(keys_3))
        Class80.hashSet_3.Add(keys_3);
    }
  }

  internal static bool smethod_5()
  {
    if (!Class80.bool_5 || Class80.bool_6 || Class144.smethod_5())
      return false;
    foreach (Keys keys_3 in Class80.keys_2)
    {
      if (!Class80.hashSet_3.Contains(keys_3) && Class80.smethod_1(keys_3, true) && !Class144.hashSet_0.Any<Class80>((Func<Class80, bool>) (class80_0 => class80_0.method_2())))
      {
        Logging.Write("[Manual Cast Pause] Key press {0} detected, pausing for {1} ms", new object[2]
        {
          (object) Class80.smethod_6(keys_3),
          (object) VitalicSettings.Instance.ManualCastPause
        });
        return true;
      }
    }
    return false;
  }

  internal static string smethod_6(Keys keys_3)
  {
    string str1 = ((keys_3 & Keys.Shift) != Keys.None ? "Shift " : "") + ((keys_3 & Keys.Control) != Keys.None ? "Ctrl " : "") + ((keys_3 & Keys.Alt) != Keys.None ? "Alt " : "");
    keys_3 ^= Keys.Shift & keys_3 | Keys.Control & keys_3 | Keys.Alt & keys_3;
    string str2;
    switch (keys_3)
    {
      case Keys.LButton:
        str2 = str1 + "Left Mouse";
        break;
      case Keys.RButton:
        str2 = str1 + "Right Mouse";
        break;
      case Keys.MButton:
        str2 = str1 + "Middle Mouse";
        break;
      case Keys.XButton1:
        str2 = str1 + "Mouse 4";
        break;
      case Keys.XButton2:
        str2 = str1 + "Mouse 5";
        break;
      case Keys.D0:
        str2 = str1 + "0";
        break;
      case Keys.D1:
        str2 = str1 + "1";
        break;
      case Keys.D2:
        str2 = str1 + "2";
        break;
      case Keys.D3:
        str2 = str1 + "3";
        break;
      case Keys.D4:
        str2 = str1 + "4";
        break;
      case Keys.D5:
        str2 = str1 + "5";
        break;
      case Keys.D6:
        str2 = str1 + "6";
        break;
      case Keys.D7:
        str2 = str1 + "7";
        break;
      case Keys.D8:
        str2 = str1 + "8";
        break;
      case Keys.D9:
        str2 = str1 + "9";
        break;
      case Keys.LShiftKey:
        str2 = str1 + "Left Shift";
        break;
      case Keys.RShiftKey:
        str2 = str1 + "Right Shift";
        break;
      case Keys.LControlKey:
        str2 = str1 + "Left Ctrl";
        break;
      case Keys.RControlKey:
        str2 = str1 + "Right Ctrl";
        break;
      case Keys.LMenu:
        str2 = str1 + "Left Alt";
        break;
      case Keys.RMenu:
        str2 = str1 + "Right Alt";
        break;
      default:
        str2 = str1 + keys_3.ToString();
        break;
    }
    return str2;
  }
}
