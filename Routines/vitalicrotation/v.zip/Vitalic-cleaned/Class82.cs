﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class82
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using System;

#nullable disable
namespace ns1;

internal class Class82 : Class81
{
  public Enum18 enum18_0;

  public Class82()
    : base(0.1)
  {
  }

  public void method_5(double double_1, Enum18 enum18_1)
  {
    this.dateTime_0 = DateTime.UtcNow + TimeSpan.FromSeconds(double_1);
    this.enum18_0 = enum18_1;
  }

  public bool method_6(Enum18 enum18_1)
  {
    if (this.method_2(true))
    {
      this.enum18_0 = enum18_1;
      return true;
    }
    return (this.enum18_0 == enum18_1 || (DateTime.UtcNow - this.DateTime_0).TotalSeconds >= 0.0) && this.method_2();
  }
}
