﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class39
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class39
{
  private static bool bool_0;
  private static Class39.Delegate12 delegate12_0 = new Class39.Delegate12(Class62.smethod_0);
  public static WoWUnit woWUnit_0;
  private static DateTime dateTime_0;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  protected static WoWUnit WoWUnit_1 => Class50.woWUnit_1;

  public static double Double_0
  {
    get
    {
      return Class39.dateTime_0 == DateTime.MinValue ? 0.0 : (DateTime.UtcNow - Class39.dateTime_0).TotalSeconds;
    }
  }

  public static void Initialise()
  {
    Class39.Attach();
    Class144.Event_0 += (Class144.Delegate42) ((sender, e) =>
    {
      if (!WoWObject.op_Inequality((WoWObject) Class39.woWUnit_0, (WoWObject) null) || !((WoWObject) Class39.woWUnit_0).IsValid || !WoWObject.op_Inequality((WoWObject) Class39.WoWUnit_1, (WoWObject) null) || !WoWSpell.op_Inequality(Class49.woWSpell_1, (WoWSpell) null) || Class49.woWSpell_1.Id != 1766 && Class49.woWSpell_1.Id != 1776 || !WoWObject.op_Equality((WoWObject) Class39.WoWUnit_1, (WoWObject) Class39.woWUnit_0) || Class39.Double_0 <= 3.0 || Class39.woWUnit_0.IsCasting)
        return;
      Class39.woWUnit_0 = (WoWUnit) null;
      Class77.smethod_11();
    });
  }

  public static void Attach()
  {
    if (Class39.bool_0)
      return;
    Class37.smethod_8(Class37.Types.SPELL_CAST_START, new Class37.Delegate11(Class39.smethod_1));
    Class39.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class39.bool_0)
      return;
    Class37.smethod_9(Class37.Types.SPELL_CAST_START, new Class37.Delegate11(Class39.smethod_1));
    Class39.bool_0 = false;
  }

  public static void Shutdown() => Class39.smethod_0();

  private static void smethod_1(EventArgs0 eventArgs0_0)
  {
    if (eventArgs0_0.lazy_0.Value != Class37.Types.SPELL_CAST_START || eventArgs0_0.lazy_7.Value != 6358 && eventArgs0_0.lazy_7.Value != 115268 && eventArgs0_0.lazy_7.Value != 90337)
      return;
    WoWUnit woWUnit_0 = eventArgs0_0.lazy_2.Value;
    if (!WoWObject.op_Inequality((WoWObject) woWUnit_0, (WoWObject) null) || !woWUnit_0.IsTargetingMeOrPet || !WoWObject.op_Inequality((WoWObject) woWUnit_0, (WoWObject) Class39.WoWUnit_1))
      return;
    Class77.smethod_10(woWUnit_0);
    Class39.woWUnit_0 = woWUnit_0;
    Class39.dateTime_0 = DateTime.UtcNow;
  }

  private delegate void Delegate12(params object[] args);
}
