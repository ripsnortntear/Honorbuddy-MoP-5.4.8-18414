﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class71
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

[Attribute0]
internal static class Class71
{
  private static Class71.Delegate30 delegate30_0 = new Class71.Delegate30(Class62.smethod_0);
  private static bool bool_0;
  private static readonly List<int> list_0 = new List<int>()
  {
    14062,
    108208,
    108209,
    26679,
    108210,
    74001,
    31230,
    108211,
    79008,
    138106,
    36554,
    108212,
    131511,
    108215,
    108216,
    114014,
    137619,
    114015
  };

  static Class71()
  {
    Class71._talents = new List<Class71.Struct23>();
    Class71._glyphs = new HashSet<int>();
    Class71.smethod_0();
  }

  public static void smethod_0()
  {
    if (!Class71.bool_0)
    {
      // ISSUE: method pointer
      Class37.smethod_5(Class37.WoWEvents.PLAYER_TALENT_UPDATE, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_6)));
      // ISSUE: method pointer
      Class37.smethod_5(Class37.WoWEvents.ACTIVE_TALENT_GROUP_CHANGED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_6)));
      // ISSUE: method pointer
      Class37.smethod_5(Class37.WoWEvents.GLYPH_UPDATED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_6)));
      Class71.bool_0 = true;
    }
    Class71.smethod_7();
  }

  public static void smethod_1()
  {
    if (!Class71.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.PLAYER_TALENT_UPDATE, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_6)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.ACTIVE_TALENT_GROUP_CHANGED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_6)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.GLYPH_UPDATED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_6)));
    Class71.bool_0 = false;
  }

  public static void smethod_2() => Class71.smethod_1();

  private static List<Class71.Struct23> _talents { get; set; }

  private static HashSet<int> _glyphs { get; set; }

  public static WoWSpec CurrentSpec { get; private set; }

  public static WoWRace CurrentRace { get; private set; }

  public static bool smethod_3(this LocalPlayer localPlayer_0, int int_0)
  {
    return Class71._glyphs.Contains(int_0);
  }

  public static bool smethod_4(this LocalPlayer localPlayer_0, int int_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: reference to a compiler-generated method
    return Class71._talents.Any<Class71.Struct23>(new Func<Class71.Struct23, bool>(new Class71.Class72()
    {
      int_0 = int_0
    }.method_0));
  }

  public static bool smethod_5(this LocalPlayer localPlayer_0, int int_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: reference to a compiler-generated method
    return Class71._talents.Any<Class71.Struct23>(new Func<Class71.Struct23, bool>(new Class71.Class73()
    {
      int_0 = int_0
    }.method_0));
  }

  private static void smethod_6(object sender, LuaEventArgs e) => Class71.smethod_7();

  public static void smethod_7()
  {
    using (StyxWoW.Memory.AcquireFrame())
    {
      Class71.CurrentSpec = ((WoWPlayer) StyxWoW.Me).Specialization;
      Class71.CurrentRace = ((WoWUnit) StyxWoW.Me).Race;
      Class71._talents.Clear();
      int returnVal1 = Lua.GetReturnVal<int>("return GetNumTalents()", 0U);
      for (int index = 1; index <= returnVal1; ++index)
      {
        if (Lua.GetReturnVal<int>($"return GetTalentInfo({index})", 4U) == 1)
          Class71._talents.Add(new Class71.Struct23()
          {
            int_1 = index,
            int_0 = 1,
            int_2 = Class71.list_0[index - 1]
          });
      }
      Class71._glyphs.Clear();
      int returnVal2 = Lua.GetReturnVal<int>("return GetNumGlyphSockets()", 0U);
      if (returnVal2 == 0)
        return;
      for (int index = 1; index <= returnVal2; ++index)
      {
        int returnVal3 = Lua.GetReturnVal<int>($"local enabled, glyphType, glyphTooltipIndex, glyphSpellID, icon = GetGlyphSocketInfo({index});if (enabled) then return glyphSpellID else return 0 end", 0U);
        try
        {
          if (returnVal3 > 0)
            Class71._glyphs.Add(returnVal3);
        }
        catch (Exception ex)
        {
          Class71.delegate30_0((object) "Error occurred during Glyph scan: ", (object) ex.Message);
        }
      }
    }
  }

  private delegate void Delegate30(params object[] args);

  private struct Struct23
  {
    public int int_0;
    public int int_1;
    public int int_2;
  }
}
