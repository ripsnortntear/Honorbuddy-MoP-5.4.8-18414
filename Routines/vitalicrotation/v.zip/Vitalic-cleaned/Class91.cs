﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class91
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.CommonBot;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class91
{
  protected const double double_0 = 8.0;
  protected const double double_1 = 12.0;
  protected const double double_2 = 28.0;
  protected const float float_0 = 7f;
  protected static Class91.Delegate34 delegate34_0 = new Class91.Delegate34(Class62.smethod_0);
  protected static Class91.Delegate34 delegate34_1 = new Class91.Delegate34(Class62.smethod_1);

  protected static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  protected static WoWUnit WoWUnit_1 => Class50.woWUnit_1;

  protected static bool Boolean_0 => Class91.Double_8 > Math.Max(50.0, Class144.double_0);

  protected static bool Boolean_1 => Class41.bool_1;

  protected static bool Boolean_2 => Class41.bool_2;

  protected static bool Boolean_3 => Class61.Boolean_3;

  protected static int Int32_0 => Class77.Int32_0;

  protected static int Int32_1 => Class77.Int32_1;

  protected static int Int32_2 => Class77.Int32_2;

  protected static double Double_0 => (DateTime.UtcNow - Class50.dateTime_0).TotalSeconds;

  protected static double Double_1 => (DateTime.UtcNow - Class50.dateTime_1).TotalSeconds;

  protected static bool Boolean_4
  {
    get
    {
      return WoWObject.op_Inequality((WoWObject) Class91.WoWUnit_0, (WoWObject) null) && ((WoWObject) Class91.WoWUnit_0).IsValid;
    }
  }

  protected static bool Boolean_5
  {
    get
    {
      return WoWObject.op_Inequality((WoWObject) Class91.WoWUnit_1, (WoWObject) null) && ((WoWObject) Class91.WoWUnit_1).IsValid;
    }
  }

  protected static ulong UInt64_0 => Class50.ulong_0;

  protected static ulong UInt64_1 => Class50.ulong_1;

  protected static bool Boolean_6 => Class91.Double_5 > 0.0;

  protected static bool Boolean_7
  {
    get => Class137.smethod_5(Class137.Macro.RedirectKidney) || Class144.class81_3.method_2();
  }

  protected static double Double_2 => (double) ((WoWUnit) Class91.LocalPlayer_0).CurrentEnergy;

  protected static bool Boolean_8
  {
    get => WoWObject.op_Inequality((WoWObject) Class91.WoWPlayer_0, (WoWObject) null);
  }

  protected static bool Boolean_9 => Class91.Int32_0 != 1856;

  protected static double Double_3 => Class134.Class134_0.lazy_7.Value;

  protected static double Double_4 => Class134.Class134_0.lazy_18.Value;

  protected static bool Boolean_10 => Class134.Class134_0.lazy_14.Value;

  protected static bool Boolean_11 => Class134.Class134_0.lazy_15.Value;

  protected static bool Boolean_12 => Class134.Class134_0.lazy_12.Value;

  protected static bool Boolean_13 => Class134.Class134_0.lazy_13.Value;

  protected static bool Boolean_14 => Class134.Class134_0.lazy_16.Value;

  protected static bool Boolean_15 => Class134.Class134_0.lazy_17.Value;

  protected static double Double_5 => Class134.Class134_0.lazy_4.Value;

  protected static bool Boolean_16 => Class134.Class134_0.lazy_3.Value;

  protected static bool Boolean_17 => Class134.Class134_0.lazy_2.Value;

  protected static double Double_6 => Class134.Class134_0.lazy_1.Value;

  protected static double Double_7 => Class134.Class134_0.lazy_0.Value;

  protected static WoWPlayer WoWPlayer_0 => Class134.Class134_0.lazy_5.Value;

  protected static bool Boolean_18 => Class134.Class134_0.lazy_6.Value;

  protected static double Double_8 => Class134.Class134_0.lazy_8.Value;

  protected static uint UInt32_0 => Class134.Class134_0.lazy_20.Value;

  protected static int Int32_3 => Class86.Int32_2;

  protected static IEnumerable<WoWUnit> IEnumerable_0 => Class63.IEnumerable_2;

  protected static IEnumerable<WoWUnit> IEnumerable_1 => Class61.IEnumerable_2;

  protected static IEnumerable<WoWUnit> IEnumerable_2 => Class61.IEnumerable_3;

  protected static bool Boolean_19
  {
    get => Class46.bool_2 || Class137.smethod_5(Class137.Macro.Restealth);
  }

  protected static bool Boolean_20
  {
    get => Class46.bool_1;
    set => Class46.bool_1 = value;
  }

  protected static bool smethod_0()
  {
    return Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 115192) && !Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 51713) && Class144.Boolean_6 && (VitalicSettings.Instance.SubterfugeOpeners == 0 || VitalicSettings.Instance.SubterfugeOpeners == 1 || Class144.Boolean_0);
  }

  public static bool smethod_1()
  {
    if (!Class144.Boolean_0 || !Class144.Boolean_6 || (Class91.Boolean_1 || Class91.Boolean_2) && !Class63.smethod_2(Class91.WoWUnit_0) || !Class91.Boolean_10 || Class91.LocalPlayer_0.smethod_22() || Class91.Boolean_7 || Class41.bool_2 && Class91.Double_4 < (double) VitalicSettings.Instance.BurstHealth || Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_0, VitalicSettings.Instance.BurstStunDR) || Class91.WoWUnit_0.smethod_11())
      return false;
    switch (Class71.CurrentSpec - 259)
    {
      case 0:
        if (!Class59.smethod_0(79140))
          return true;
        return SpellManager.HasSpell(121471) && !Class59.smethod_0(121471) && Class144.bool_1 && !Class91.Boolean_6;
      case 1:
        return !Class59.smethod_0(51690) && (!Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 13750) || Class91.Int32_3 == 3) && Class91.Int32_3 >= 2 && (Class144.Boolean_3 || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_12, 1.0)) || !Class59.smethod_0(13750);
      case 2:
        if (!Class59.smethod_0(51713))
          return true;
        return SpellManager.HasSpell(121471) && !Class59.smethod_0(121471) && Class144.bool_1 && !Class91.Boolean_6;
      default:
        return false;
    }
  }

  public static double smethod_2()
  {
    int burstPreparation = VitalicSettings.Instance.BurstPreparation;
    if (burstPreparation == 0 || Class144.Boolean_3 || !Class144.Boolean_0 || !Class91.Boolean_4 || !Class144.Boolean_6 || ((WoWUnit) Class91.LocalPlayer_0).smethod_5() || Class91.Boolean_18 || Class91.Boolean_7 || !Class91.Boolean_10 || Class91.Double_4 < (double) VitalicSettings.Instance.BurstHealth || Class65.Boolean_0 || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_0))
      return 0.0;
    switch (Class71.CurrentSpec - 259)
    {
      case 0:
        double num1 = 0.0;
        if (Class59.smethod_0(79140))
        {
          num1 = Class59.smethod_2(79140);
          if (num1 < (double) burstPreparation)
            return num1;
        }
        if (Class144.bool_1 && SpellManager.HasSpell(121471) && Class59.smethod_0(121471))
        {
          double num2 = Class59.smethod_2(121471);
          if (num2 < (double) burstPreparation && (num1 == 0.0 || num1 - num2 > (double) burstPreparation))
            return num2;
          break;
        }
        break;
      case 1:
        if (Class59.smethod_0(13750))
        {
          double num3 = Class59.smethod_2(13750);
          if (num3 < (double) burstPreparation)
            return num3;
        }
        if (Class59.smethod_0(51690) && Class91.Int32_3 >= 1)
        {
          double num4 = Class59.smethod_2(51690);
          if (num4 < (double) burstPreparation)
            return num4;
          break;
        }
        break;
      case 2:
        double num5 = 0.0;
        if (Class59.smethod_0(51713))
        {
          num5 = Class59.smethod_2(51713);
          if (num5 < (double) burstPreparation)
            return num5;
        }
        if (Class144.bool_1 && SpellManager.HasSpell(121471) && Class59.smethod_0(121471))
        {
          double num6 = Class59.smethod_2(121471);
          if (num6 < (double) burstPreparation && (num5 == 0.0 || num5 - num6 > (double) burstPreparation))
            return num6;
          break;
        }
        break;
    }
    return 0.0;
  }

  public static double smethod_3()
  {
    if (Class63.smethod_1(Class91.WoWUnit_0))
      return 0.0;
    double maxHealth1 = (double) ((WoWUnit) Class91.LocalPlayer_0).MaxHealth;
    double maxHealth2 = (double) Class91.WoWUnit_0.MaxHealth;
    double num1 = Class91.Boolean_2 ? 15.0 : 12.5;
    double val2 = maxHealth2 * num1 / 100.0;
    double num2 = maxHealth1 - maxHealth2;
    if (num2 < 0.0)
    {
      double num3 = Math.Abs(num2) / maxHealth1 * 100.0 / 5.0;
      double num4 = Math.Min(maxHealth2 * num3 / 100.0, val2);
      return val2 - num4;
    }
    double num5 = Math.Abs(num2) / maxHealth1 * 100.0 / 2.5;
    double num6 = Math.Min(maxHealth1 * num5 / 100.0, val2);
    return val2 + num6;
  }

  protected delegate void Delegate34(params object[] args);
}
