﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class137
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.CommonBot;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class137
{
  private static bool bool_0;
  private static bool bool_1;
  private static WoWSpell woWSpell_0;
  private static Class137.Delegate38 delegate38_0 = new Class137.Delegate38(Class62.smethod_0);
  private static Class137.Delegate38 delegate38_1 = new Class137.Delegate38(Class62.smethod_1);
  private static Func<string, string> func_0 = new Func<string, string>(CultureInfo.CurrentCulture.TextInfo.ToTitleCase);
  private static Dictionary<Class137.Macro, bool> dictionary_0 = new Dictionary<Class137.Macro, bool>();
  private static Dictionary<Class137.Macro, string> dictionary_1 = new Dictionary<Class137.Macro, string>();
  private static DateTime dateTime_0;
  public static WoWUnit woWUnit_0;
  private static Dictionary<Class137.Macro, string> dictionary_2 = new Dictionary<Class137.Macro, string>()
  {
    {
      Class137.Macro.CheapShot,
      "Cheap Shot"
    },
    {
      Class137.Macro.Garrote,
      "Garrote"
    },
    {
      Class137.Macro.Gouge,
      "Gouge"
    },
    {
      Class137.Macro.Blind,
      "Blind"
    },
    {
      Class137.Macro.RedirectKidney,
      "Redirect Kidney"
    },
    {
      Class137.Macro.FastKick,
      "Fast Kick"
    }
  };

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static WoWUnit WoWUnit_1 => Class50.woWUnit_1;

  public static bool Boolean_0
  {
    get
    {
      return Class137.smethod_5(Class137.Macro.CheapShot) || Class137.smethod_5(Class137.Macro.Garrote) || Class144.class81_1.method_2() || Class144.class81_0.method_2();
    }
  }

  private static double Double_0 => VitalicSettings.Instance.MacroDelay;

  public static void smethod_0()
  {
    if (!Class137.bool_0)
    {
      // ISSUE: reference to a compiler-generated field
      if (Class137.onBotStartDelegate_0 == null)
      {
        // ISSUE: reference to a compiler-generated field
        // ISSUE: method pointer
        Class137.onBotStartDelegate_0 = new BotEvents.OnBotStartDelegate((object) null, __methodptr(smethod_13));
      }
      // ISSUE: reference to a compiler-generated field
      BotEvents.OnBotStarted += Class137.onBotStartDelegate_0;
      Class41.Event_0 += (EventHandler) ((sender, e) => Class137.smethod_0());
      Class144.Event_0 += (Class144.Delegate42) ((sender, e) =>
      {
        if (!VitalicSettings.Instance.MacrosEnabled)
          return;
        Class137.smethod_2();
      });
      Class41.Event_0 += (EventHandler) ((sender, e) => Class137.smethod_9());
      foreach (Class137.Macro key in Enum.GetValues(typeof (Class137.Macro)))
        Class137.dictionary_0.Add(key, false);
      foreach (KeyValuePair<Class137.Macro, bool> keyValuePair in Class137.dictionary_0)
        Class137.dictionary_1.Add(keyValuePair.Key, Class144.smethod_4());
      Class137.bool_0 = true;
    }
    if (!VitalicSettings.Instance.MacrosEnabled || Class137.bool_1 && Class137.smethod_1())
      return;
    foreach (KeyValuePair<Class137.Macro, bool> keyValuePair in Class137.dictionary_0)
    {
      string upper = keyValuePair.Key.ToString().ToUpper();
      Lua.DoString(string.Format("SLASH_{0}1 = '/{1}'\r\n                    function SlashCmdList.{2}(args)\r\n                        {3} = string.len(args) > 0 and args or (not {3})\r\n                    end\r\n                    ", (object) upper, (object) upper, (object) upper, (object) Class137.dictionary_1[keyValuePair.Key], (object) Class137.dictionary_1[keyValuePair.Key]), "WoW.lua");
    }
    StringBuilder stringBuilder = new StringBuilder();
    foreach (KeyValuePair<Class137.Macro, bool> keyValuePair in Class137.dictionary_0)
    {
      string str = Class137.dictionary_1[keyValuePair.Key];
      stringBuilder.AppendFormat("'{0}:'..((type({1})=='string') and {2} or ({3}~=nil and 'true' or 'false')), ", (object) str, (object) str, (object) str, (object) str);
    }
    Lua.DoString($"function gmv() return {stringBuilder.ToString().Remove(stringBuilder.Length - 2)} end", "WoW.lua");
    Class137.bool_1 = true;
  }

  public static bool smethod_1()
  {
    return Lua.GetReturnVal<bool>($"return SLASH_{Class137.Macro.CheapShot.ToString().ToUpper()}1 ~= nil", 0U);
  }

  public static void smethod_2()
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class137.Class138 class138 = new Class137.Class138();
    if (!((WoWUnit) Class137.LocalPlayer_0).IsAlive)
    {
      Class137.smethod_9();
    }
    else
    {
      List<string> returnValues = Lua.GetReturnValues("return gmv()");
      if (returnValues == null)
      {
        Class137.delegate38_1((object) "Failed parsing macro state");
      }
      else
      {
        Dictionary<string, string> dictionary = returnValues.ToDictionary<string, string, string>((Func<string, string>) (string_0 => string_0.Split(':')[0]), (Func<string, string>) (string_0 => string_0.Split(':')[1]));
        if (dictionary.Count == 0)
          return;
        double totalSeconds = (DateTime.UtcNow - Class137.dateTime_0).TotalSeconds;
        // ISSUE: reference to a compiler-generated field
        class138.string_0 = dictionary[Class137.dictionary_1[Class137.Macro.Toggle]];
        // ISSUE: reference to a compiler-generated field
        // ISSUE: reference to a compiler-generated field
        if (!string.IsNullOrEmpty(class138.string_0) && class138.string_0 != "false")
        {
          WoWSpell woWspell = (WoWSpell) null;
          try
          {
            // ISSUE: reference to a compiler-generated field
            woWspell = WoWSpell.FromId(Convert.ToInt32(class138.string_0));
          }
          catch (Exception ex)
          {
          }
          if (WoWSpell.op_Equality(woWspell, (WoWSpell) null))
          {
            // ISSUE: reference to a compiler-generated field
            // ISSUE: reference to a compiler-generated field
            class138.string_0 = Class137.func_0(class138.string_0.ToLower());
            // ISSUE: reference to a compiler-generated method
            woWspell = ((IEnumerable<KeyValuePair<string, WoWSpell>>) SpellManager.Spells).FirstOrDefault<KeyValuePair<string, WoWSpell>>(new Func<KeyValuePair<string, WoWSpell>, bool>(class138.method_0)).Value;
          }
          if (WoWSpell.op_Inequality(woWspell, (WoWSpell) null))
          {
            if ((!Class137.dictionary_0[Class137.Macro.Toggle] || WoWSpell.op_Inequality(woWspell, Class137.woWSpell_0)) && totalSeconds > 0.25 && Class59.smethod_2(woWspell.Id) < 3.0)
            {
              Class137.woWSpell_0 = woWspell;
              Class137.smethod_9(false);
              Class137.dictionary_0[Class137.Macro.Toggle] = true;
              Class137.dateTime_0 = DateTime.UtcNow;
              Class136.smethod_5();
            }
            else if (totalSeconds > Class137.Double_0)
            {
              Class137.dictionary_0[Class137.Macro.Toggle] = false;
              Class137.dateTime_0 = DateTime.UtcNow;
              Class136.smethod_5();
            }
            Lua.DoString(Class137.dictionary_1[Class137.Macro.Toggle] + " = nil", "WoW.lua");
          }
        }
        Class137.MacroTargets macroTargets1 = Class137.smethod_3(dictionary[Class137.dictionary_1[Class137.Macro.CheapShot]]);
        if (macroTargets1 == Class137.MacroTargets.None && Class144.class81_1.method_2())
          macroTargets1 = Class144.class82_0.method_2() ? Class137.MacroTargets.Focus : Class137.MacroTargets.Target;
        if (macroTargets1 != Class137.MacroTargets.None)
        {
          if ((!Class137.dictionary_0[Class137.Macro.CheapShot] || Class124.macroTargets_0 != macroTargets1) && Class77.Int32_0 != 1833 && totalSeconds > 0.25)
          {
            Class137.smethod_9(false);
            Class137.dictionary_0[Class137.Macro.CheapShot] = true;
            Class124.macroTargets_0 = macroTargets1;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class136.smethod_5();
          }
          else if (totalSeconds > Class137.Double_0)
          {
            Class137.dictionary_0[Class137.Macro.CheapShot] = false;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class136.smethod_5();
          }
          Lua.DoString(Class137.dictionary_1[Class137.Macro.CheapShot] + " = nil", "WoW.lua");
        }
        if (Class137.smethod_5(Class137.Macro.CheapShot) && WoWObject.op_Equality((WoWObject) Class137.woWUnit_0, (WoWObject) null))
          Class137.smethod_4(Class124.macroTargets_0);
        Class137.MacroTargets macroTargets2 = Class137.smethod_3(dictionary[Class137.dictionary_1[Class137.Macro.Garrote]]);
        if (macroTargets2 == Class137.MacroTargets.None && Class144.class81_0.method_2())
          macroTargets2 = Class144.class82_0.method_2() ? Class137.MacroTargets.Focus : Class137.MacroTargets.Target;
        if (macroTargets2 != Class137.MacroTargets.None)
        {
          if ((!Class137.dictionary_0[Class137.Macro.Garrote] || Class124.macroTargets_0 != macroTargets2) && Class77.Int32_0 != 703 && totalSeconds > 0.25)
          {
            Class137.smethod_9(false);
            Class137.dictionary_0[Class137.Macro.Garrote] = true;
            Class124.macroTargets_0 = macroTargets2;
            Class137.dateTime_0 = DateTime.UtcNow;
            if (Class144.class80_3.method_2())
              Class124.bool_0 = true;
            Class136.smethod_5();
          }
          else if (totalSeconds > Class137.Double_0)
          {
            Class137.dictionary_0[Class137.Macro.Garrote] = false;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class136.smethod_5();
          }
          Lua.DoString(Class137.dictionary_1[Class137.Macro.Garrote] + " = nil", "WoW.lua");
        }
        if (Class137.smethod_5(Class137.Macro.Garrote) && WoWObject.op_Equality((WoWObject) Class137.woWUnit_0, (WoWObject) null))
          Class137.smethod_4(Class124.macroTargets_0);
        Class137.MacroTargets macroTargets3 = Class137.smethod_3(dictionary[Class137.dictionary_1[Class137.Macro.Gouge]]);
        if (macroTargets3 == Class137.MacroTargets.None && Class144.class81_2.method_2() && !((WoWUnit) Class137.LocalPlayer_0).smethod_4() && !Class53.smethod_3((WoWUnit) Class137.LocalPlayer_0, 51713))
          macroTargets3 = Class144.class82_0.method_2() ? Class137.MacroTargets.Focus : Class137.MacroTargets.Target;
        if (macroTargets3 != Class137.MacroTargets.None)
        {
          if ((!Class137.dictionary_0[Class137.Macro.Gouge] || Class122.macroTargets_0 != macroTargets3) && totalSeconds > 0.25 && Class59.smethod_2(1776) < 3.0)
          {
            Class137.smethod_9(false);
            Class137.dictionary_0[Class137.Macro.Gouge] = true;
            Class122.macroTargets_0 = macroTargets3;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class136.smethod_5();
          }
          else if (totalSeconds > Class137.Double_0)
          {
            Class137.dictionary_0[Class137.Macro.Gouge] = false;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class136.smethod_5();
          }
          Lua.DoString(Class137.dictionary_1[Class137.Macro.Gouge] + " = nil", "WoW.lua");
        }
        if (Class137.smethod_5(Class137.Macro.Gouge) && WoWObject.op_Equality((WoWObject) Class137.woWUnit_0, (WoWObject) null))
          Class137.smethod_4(Class122.macroTargets_0);
        Class137.MacroTargets macroTargets4 = Class137.smethod_3(dictionary[Class137.dictionary_1[Class137.Macro.Blind]]);
        if (macroTargets4 == Class137.MacroTargets.None && Class144.class80_0.method_2())
          macroTargets4 = Class144.class82_0.method_2() ? Class137.MacroTargets.Focus : Class137.MacroTargets.Target;
        if (macroTargets4 != Class137.MacroTargets.None)
        {
          if ((!Class137.dictionary_0[Class137.Macro.Blind] || Class102.macroTargets_0 != macroTargets4) && totalSeconds > 0.25 && Class59.smethod_2(2094) < 3.0)
          {
            Class137.smethod_9(false);
            Class137.dictionary_0[Class137.Macro.Blind] = true;
            Class102.macroTargets_0 = macroTargets4;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class136.smethod_5();
          }
          else if (totalSeconds > Class137.Double_0)
          {
            Class137.dictionary_0[Class137.Macro.Blind] = false;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class136.smethod_5();
          }
          Lua.DoString(Class137.dictionary_1[Class137.Macro.Blind] + " = nil", "WoW.lua");
        }
        if (Class137.smethod_5(Class137.Macro.Blind) && WoWObject.op_Equality((WoWObject) Class137.woWUnit_0, (WoWObject) null))
          Class137.smethod_4(Class102.macroTargets_0);
        Class137.MacroTargets macroTargets5 = Class137.smethod_3(dictionary[Class137.dictionary_1[Class137.Macro.RedirectKidney]]);
        if (macroTargets5 == Class137.MacroTargets.None && Class144.class81_3.method_2())
          macroTargets5 = Class144.class82_0.method_2() ? Class137.MacroTargets.Focus : Class137.MacroTargets.Target;
        if (macroTargets5 != Class137.MacroTargets.None)
        {
          if ((!Class137.dictionary_0[Class137.Macro.RedirectKidney] || Class119.macroTargets_0 != macroTargets5) && totalSeconds > 0.25 && Class59.smethod_2(73981) < 3.0 && Class59.smethod_2(408) < 3.0)
          {
            Class137.smethod_9(false);
            Class137.dictionary_0[Class137.Macro.RedirectKidney] = true;
            Class119.macroTargets_0 = macroTargets5;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class136.smethod_5();
          }
          else if (totalSeconds > Class137.Double_0)
          {
            Class137.dictionary_0[Class137.Macro.RedirectKidney] = false;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class136.smethod_5();
          }
          Lua.DoString(Class137.dictionary_1[Class137.Macro.RedirectKidney] + " = nil", "WoW.lua");
        }
        if (Class137.smethod_5(Class137.Macro.RedirectKidney) && WoWObject.op_Equality((WoWObject) Class137.woWUnit_0, (WoWObject) null))
          Class137.smethod_4(Class119.macroTargets_0);
        if (Class144.class80_10.method_2() || dictionary[Class137.dictionary_1[Class137.Macro.Restealth]] != "false")
        {
          if (!Class137.dictionary_0[Class137.Macro.Restealth] && totalSeconds > 0.25)
          {
            Class137.dictionary_0[Class137.Macro.Restealth] = true;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class140.smethod_9("Restealth: |cFF00FF00Enabled");
          }
          else if (totalSeconds > Class137.Double_0)
          {
            Class137.dictionary_0[Class137.Macro.Restealth] = false;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class140.smethod_9("Restealth: |cffb73737Disabled");
          }
          Lua.DoString(Class137.dictionary_1[Class137.Macro.Restealth] + " = nil", "WoW.lua");
        }
        if (Class144.class80_11.method_2() || dictionary[Class137.dictionary_1[Class137.Macro.FastKick]] != "false")
        {
          if (!Class137.dictionary_0[Class137.Macro.FastKick] && totalSeconds > 0.25)
          {
            Class137.dictionary_0[Class137.Macro.FastKick] = true;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class140.smethod_9("Fast Kick: |cFF00FF00Enabled");
          }
          else if (totalSeconds > Class137.Double_0)
          {
            Class137.dictionary_0[Class137.Macro.FastKick] = false;
            Class137.dateTime_0 = DateTime.UtcNow;
            Class140.smethod_9("Fast Kick: |cffb73737Disabled");
          }
          Lua.DoString(Class137.dictionary_1[Class137.Macro.FastKick] + " = nil", "WoW.lua");
        }
        Class137.smethod_10();
      }
    }
  }

  private static Class137.MacroTargets smethod_3(string string_0)
  {
    Class137.MacroTargets macroTargets = Class137.MacroTargets.None;
    try
    {
      if (string_0 != "false")
        macroTargets = !(string_0 == "true") ? (Class137.MacroTargets) Enum.Parse(typeof (Class137.MacroTargets), char.ToUpperInvariant(string_0[0]).ToString() + string_0.Substring(1)) : Class137.MacroTargets.Target;
    }
    catch (Exception ex)
    {
      Class137.delegate38_1((object) ("[Macro] Invalid unit identifier provided: " + string_0));
    }
    if (macroTargets == Class137.MacroTargets.Target && Class144.class82_0.method_2())
      macroTargets = Class137.MacroTargets.Focus;
    return macroTargets;
  }

  private static void smethod_4(Class137.MacroTargets macroTargets_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: variable of a compiler-generated type
    Class137.Class139 class139 = new Class137.Class139();
    if (macroTargets_0 == Class137.MacroTargets.None || macroTargets_0 == Class137.MacroTargets.Target || macroTargets_0 == Class137.MacroTargets.Focus)
      return;
    string returnVal = Lua.GetReturnVal<string>($"return UnitGUID('{macroTargets_0.ToString()}')", 0U);
    // ISSUE: reference to a compiler-generated field
    class139.ulong_0 = Class137.smethod_12(returnVal);
    // ISSUE: reference to a compiler-generated field
    if (class139.ulong_0 == 0UL)
      return;
    // ISSUE: reference to a compiler-generated method
    Class137.woWUnit_0 = ObjectManager.GetObjectsOfType<WoWUnit>(true, false).FirstOrDefault<WoWUnit>(new Func<WoWUnit, bool>(class139.method_0));
    if (macroTargets_0 != Class137.MacroTargets.Mouseover || !WoWObject.op_Equality((WoWObject) Class137.woWUnit_0, (WoWObject) Class137.WoWUnit_0))
      return;
    Class137.woWUnit_0 = (WoWUnit) null;
  }

  public static bool smethod_5(Class137.Macro macro_0) => Class137.dictionary_0[macro_0];

  public static string smethod_6()
  {
    KeyValuePair<Class137.Macro, bool> keyValuePair = Class137.dictionary_0.FirstOrDefault<KeyValuePair<Class137.Macro, bool>>((Func<KeyValuePair<Class137.Macro, bool>, bool>) (keyValuePair_0 => keyValuePair_0.Value));
    return keyValuePair.Key == Class137.Macro.Toggle ? Class137.woWSpell_0.Name : Class137.dictionary_2[keyValuePair.Key];
  }

  public static bool smethod_7()
  {
    return Class137.dictionary_0.Any<KeyValuePair<Class137.Macro, bool>>((Func<KeyValuePair<Class137.Macro, bool>, bool>) (keyValuePair_0 => keyValuePair_0.Value && keyValuePair_0.Key != Class137.Macro.Restealth && keyValuePair_0.Key != Class137.Macro.FastKick));
  }

  public static void smethod_8(Class137.Macro macro_0)
  {
    Class137.dictionary_0[macro_0] = false;
    Class136.smethod_5();
  }

  public static void smethod_9(bool bool_2 = true)
  {
    foreach (Class137.Macro key in Class137.dictionary_0.Keys.ToList<Class137.Macro>())
      Class137.dictionary_0[key] = false;
    Class137.woWUnit_0 = (WoWUnit) null;
    if (!bool_2)
      return;
    Class136.smethod_5();
  }

  private static void smethod_10()
  {
    if (!Class137.dictionary_0[Class137.Macro.Toggle])
      return;
    Class137.smethod_11();
  }

  private static void smethod_11()
  {
    bool isSelfOnlySpell = Class137.woWSpell_0.IsSelfOnlySpell;
    if (!SpellManager.CanCast(Class137.woWSpell_0, true))
      return;
    if (!isSelfOnlySpell && (!Class137.LocalPlayer_0.smethod_0(Class137.WoWUnit_0) || Class137.WoWUnit_0.smethod_8()))
    {
      Class137.smethod_9();
    }
    else
    {
      if (isSelfOnlySpell)
      {
        LocalPlayer localPlayer0 = Class137.LocalPlayer_0;
      }
      else if (!Class144.class82_0.method_2())
      {
        WoWUnit woWunit0 = Class137.WoWUnit_0;
      }
      else
      {
        WoWUnit woWunit1 = Class137.WoWUnit_1;
      }
      SpellManager.Cast(Class137.woWSpell_0);
      Class140.smethod_7("Casting " + Class137.woWSpell_0.Name, Class140.struct24_2);
      Class137.delegate38_0((object) ("[Toggle Macro] Casted spell: " + Class137.woWSpell_0.Name));
      Class137.smethod_9();
    }
  }

  private static ulong smethod_12(string string_0)
  {
    if (string.IsNullOrEmpty(string_0))
      return 0;
    try
    {
      return ulong.Parse(string_0.Replace("0x", string.Empty), NumberStyles.HexNumber);
    }
    catch
    {
    }
    return 0;
  }

  private delegate void Delegate38(params object[] args);

  public enum Macro
  {
    CheapShot,
    Garrote,
    Gouge,
    Blind,
    Toggle,
    RedirectKidney,
    FastKick,
    Restealth,
  }

  public enum MacroTargets
  {
    None,
    Target,
    Focus,
    Mouseover,
    Arena1,
    Arena2,
    Arena3,
    Arena4,
    Arena5,
  }
}
