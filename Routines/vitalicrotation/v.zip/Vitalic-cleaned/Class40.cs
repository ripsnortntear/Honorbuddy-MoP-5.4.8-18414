﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class40
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class40
{
  private static bool bool_0;
  private static Class40.Delegate13 delegate13_0 = new Class40.Delegate13(Class62.smethod_0);
  public static DateTime dateTime_0;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static void Initialise() => Class40.Attach();

  public static void Attach()
  {
    if (Class40.bool_0)
      return;
    Class37.smethod_8(Class37.Types.SPELL_AURA_APPLIED, new Class37.Delegate11(Class40.smethod_1));
    Class37.smethod_8(Class37.Types.SPELL_AURA_REMOVED, new Class37.Delegate11(Class40.smethod_1));
    Class40.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class40.bool_0)
      return;
    Class37.smethod_9(Class37.Types.SPELL_AURA_APPLIED, new Class37.Delegate11(Class40.smethod_1));
    Class37.smethod_9(Class37.Types.SPELL_AURA_REMOVED, new Class37.Delegate11(Class40.smethod_1));
    Class40.bool_0 = false;
  }

  public static void Shutdown() => Class40.smethod_0();

  private static void smethod_1(EventArgs0 eventArgs0_0)
  {
    if (eventArgs0_0.lazy_0.Value == Class37.Types.SPELL_AURA_APPLIED && (long) eventArgs0_0.lazy_4.Value == (long) ((WoWObject) Class40.LocalPlayer_0).Guid && eventArgs0_0.lazy_7.Value == 115192)
      Class40.dateTime_0 = DateTime.UtcNow;
    if (eventArgs0_0.lazy_0.Value == Class37.Types.SPELL_AURA_REMOVED && (long) eventArgs0_0.lazy_4.Value == (long) ((WoWObject) Class40.LocalPlayer_0).Guid && (eventArgs0_0.lazy_7.Value == 115191 || eventArgs0_0.lazy_7.Value == 1784 || eventArgs0_0.lazy_7.Value == 112942 || eventArgs0_0.lazy_7.Value == 51713))
    {
      Class40.dateTime_0 = DateTime.UtcNow;
      bool flag = ((WoWUnit) Class40.LocalPlayer_0).HasAura(1784) || ((WoWUnit) Class40.LocalPlayer_0).HasAura(115191) || ((WoWUnit) Class40.LocalPlayer_0).HasAura(112942) || ((WoWUnit) Class40.LocalPlayer_0).HasAura(115193);
      Class130.smethod_4();
      if (Class77.Int32_0 == 1856 && !flag)
      {
        Class49.woWSpell_0 = (WoWSpell) null;
        Class62.smethod_1((object) "reset vanish upon exit stealth");
      }
      if (Class137.Boolean_0 && !flag)
      {
        Class137.smethod_9();
        Class144.class81_1.DateTime_0 = DateTime.MinValue;
        Class144.class81_0.DateTime_0 = DateTime.MinValue;
        Class144.class81_2.DateTime_0 = DateTime.MinValue;
      }
      if (Class63.smethod_2(Class40.WoWUnit_0) && Class134.Class134_0.lazy_14.Value)
        Class47.dateTime_0 = DateTime.UtcNow;
    }
    if (eventArgs0_0.lazy_7.Value == 148385)
      Class41.smethod_1();
    if (Class77.Int32_0 != 1856 || eventArgs0_0.lazy_0.Value != Class37.Types.SPELL_AURA_APPLIED || (long) eventArgs0_0.lazy_1.Value != (long) ((WoWObject) Class40.LocalPlayer_0).Guid || eventArgs0_0.lazy_7.Value != 1833 && eventArgs0_0.lazy_7.Value != 703)
      return;
    Class49.woWSpell_0 = (WoWSpell) null;
  }

  private delegate void Delegate13(params object[] args);
}
