﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class129
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;

#nullable disable
namespace ns1;

internal class Class129 : Class91
{
  private static bool Boolean_21
  {
    get => Class91.Boolean_6 && Class91.Double_5 < 10.0 && !Class91.WoWUnit_0.smethod_14(6);
  }

  private static bool Boolean_22
  {
    get
    {
      return Class91.Boolean_17 && Class91.LocalPlayer_0.ComboPoints > 1 && Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 5171) && !Class91.WoWUnit_0.smethod_9();
    }
  }

  private static bool Boolean_23
  {
    get
    {
      return Class91.LocalPlayer_0.ComboPoints > 4 && Class91.Boolean_17 && !Class91.Boolean_16 && !Class91.WoWUnit_0.smethod_14(8);
    }
  }

  private static bool Boolean_24
  {
    get
    {
      return Class91.LocalPlayer_0.ComboPoints > 1 && (double) (4 + Class91.LocalPlayer_0.ComboPoints * 4) > Class91.Double_5 + 8.0;
    }
  }

  private static bool Boolean_25
  {
    get
    {
      if (!Class144.Boolean_4 || Class91.LocalPlayer_0.ComboPoints <= 1 || !Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 51713) && !Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 121471) || Class91.Double_4 <= 30.0)
        return false;
      return Class91.Int32_0 == 1833 || Class74.smethod_3(1833) > 1.5;
    }
  }

  private static bool Boolean_26
  {
    get
    {
      if (!Class144.Boolean_5 || Class144.Boolean_4 || Class91.Double_4 <= 30.0 || Class91.LocalPlayer_0.ComboPoints <= 2 && (!Class129.Boolean_21 || !Class129.Boolean_24) || Class91.Boolean_8 && !Class91.Boolean_6 && Class91.Boolean_16)
        return false;
      return !Class91.smethod_0() || Class91.WoWUnit_0.smethod_5(Class68.Enum14.const_2) || Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_3, 0.5);
    }
  }

  private static int Int32_4 => !Class91.LocalPlayer_0.smethod_4(18) ? 3 : 4;

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class129.retrieveSwitchParameterDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class129.retrieveSwitchParameterDelegate_0 = new RetrieveSwitchParameterDelegate<WoWSpec>((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    RetrieveSwitchParameterDelegate<WoWSpec> parameterDelegate0 = Class129.retrieveSwitchParameterDelegate_0;
    SwitchArgument<WoWSpec>[] switchArgumentArray1 = new SwitchArgument<WoWSpec>[2];
    SwitchArgument<WoWSpec>[] switchArgumentArray2 = switchArgumentArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class129.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class129.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    SwitchArgument<WoWSpec> switchArgument1 = new SwitchArgument<WoWSpec>((WoWSpec) 261, Class77.smethod_1(1943, Class129.canRunDecoratorDelegate_0, "Rupture"));
    switchArgumentArray2[0] = switchArgument1;
    SwitchArgument<WoWSpec>[] switchArgumentArray3 = switchArgumentArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class129.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class129.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    SwitchArgument<WoWSpec> switchArgument2 = new SwitchArgument<WoWSpec>((WoWSpec) 259, Class77.smethod_1(1943, Class129.canRunDecoratorDelegate_1, "Rupture"));
    switchArgumentArray3[1] = switchArgument2;
    SwitchArgument<WoWSpec>[] switchArgumentArray4 = switchArgumentArray1;
    return (Composite) new Switch<WoWSpec>(parameterDelegate0, switchArgumentArray4);
  }
}
