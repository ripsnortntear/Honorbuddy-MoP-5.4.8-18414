﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class144
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.Common;
using Styx.Common.Helpers;
using Styx.CommonBot;
using Styx.CommonBot.Routines;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using System.Windows.Media;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class144 : CombatRoutine
{
  private static string string_0;
  private static Random random_0;
  private static readonly WaitTimer waitTimer_0 = new WaitTimer(TimeSpan.FromMinutes(1.0));
  private static Class144.Delegate41 delegate41_0 = new Class144.Delegate41(Class62.smethod_0);
  private static Class144.Delegate41 delegate41_1 = new Class144.Delegate41(Class62.smethod_1);
  internal static Class81 class81_0 = new Class81();
  internal static Class81 class81_1 = new Class81();
  internal static Class81 class81_2 = new Class81();
  internal static Class80 class80_0 = new Class80(true, true);
  internal static Class81 class81_3 = new Class81();
  internal static Class80 class80_1 = new Class80(true);
  internal static Class80 class80_2 = new Class80(true, true);
  internal static Class82 class82_0 = new Class82();
  internal static Class80 class80_3 = new Class80(true);
  internal static Class80 class80_4 = new Class80();
  internal static Class80 class80_5 = new Class80();
  internal static Class80 class80_6 = new Class80();
  internal static Class80 class80_7 = new Class80();
  internal static Class80 class80_8 = new Class80(true);
  internal static Class80 class80_9 = new Class80(true);
  internal static Class80 class80_10 = new Class80();
  internal static Class80 class80_11 = new Class80();
  internal static Class80 class80_12 = new Class80();
  internal static HashSet<Class80> hashSet_0 = new HashSet<Class80>()
  {
    (Class80) Class144.class81_0,
    (Class80) Class144.class81_1,
    (Class80) Class144.class81_2,
    Class144.class80_0,
    (Class80) Class144.class81_3,
    Class144.class80_1,
    Class144.class80_2,
    (Class80) Class144.class82_0,
    Class144.class80_3,
    Class144.class80_4,
    Class144.class80_5,
    Class144.class80_6,
    Class144.class80_7,
    Class144.class80_8,
    Class144.class80_9,
    Class144.class80_10,
    Class144.class80_11,
    Class144.class80_12
  };
  private static VitalicForm vitalicForm_0;
  private static bool bool_0;
  internal static bool bool_1 = true;
  internal static bool bool_2;
  internal static bool bool_3;
  internal static double double_0;
  internal static bool bool_4;

  public virtual string Name => "Vitalic Elite Rogue PvP Profile [v2.0.3 - Release Candidate]";

  public virtual WoWClass Class => (WoWClass) 4;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static WoWUnit WoWUnit_1 => Class50.woWUnit_1;

  public static event Class144.Delegate42 Event_0;

  internal static bool Boolean_0
  {
    get => Class144.bool_2;
    set
    {
      Class144.bool_2 = value;
      if (Class144.bool_2)
      {
        Class140.smethod_9("Burst Mode: |cFF15E61CEnabled");
        if (Class136.bool_1)
          return;
        Class140.smethod_7("Burst mode enabled", Class140.struct24_1, true);
      }
      else
      {
        Class140.smethod_9("Burst Mode: |cffb73737Disabled");
        if (Class136.bool_1)
          return;
        Class140.smethod_7("Burst mode disabled", Class140.struct24_4, true);
      }
    }
  }

  internal static bool Boolean_1
  {
    get => Class144.bool_3;
    set
    {
      Class144.bool_3 = value;
      if (Class144.bool_3)
      {
        Class140.smethod_9("Lazy Mode: |cFF15E61CEnabled");
        if (Class136.bool_1)
          return;
        Class140.smethod_7("Lazy mode enabled", Class140.struct24_1, true);
      }
      else
      {
        Class140.smethod_9("Lazy Mode: |cffb73737Disabled");
        if (Class136.bool_1)
          return;
        Class140.smethod_7("Lazy mode disabled", Class140.struct24_4, true);
      }
    }
  }

  internal static bool Boolean_2
  {
    get => VitalicSettings.Instance.AutoKidney;
    set
    {
      VitalicSettings.Instance.AutoKidney = value;
      if (VitalicSettings.Instance.AutoKidney)
      {
        Class140.smethod_9("Auto Kidney: |cFF15E61CEnabled");
        Class140.smethod_7("Auto kidney enabled", Class140.struct24_1, true);
      }
      else
      {
        Class140.smethod_9("Auto Kidney: |cffb73737Disabled");
        Class140.smethod_7("Auto kidney disabled", Class140.struct24_4, true);
      }
    }
  }

  internal static bool Boolean_3 => Class134.Class134_0.lazy_19.Value;

  internal static bool Boolean_4 => Class134.Class134_0.lazy_9.Value;

  internal static bool Boolean_5 => Class134.Class134_0.lazy_10.Value;

  internal static bool Boolean_6 => Class134.Class134_0.lazy_11.Value;

  public static bool smethod_0()
  {
    bool flag = Class53.smethod_3((WoWUnit) Class144.LocalPlayer_0, 115192);
    if (Class144.Boolean_0 && Class144.Boolean_6 && Class134.Class134_0.lazy_12.Value && Class134.Class134_0.lazy_14.Value)
    {
      if ((!((WoWUnit) Class144.LocalPlayer_0).smethod_7(115191, 112942) || flag) && (flag || Class65.Boolean_0) && !Class74.smethod_4(Class144.WoWUnit_0) && !Class144.WoWUnit_0.smethod_9())
        return !Class144.WoWUnit_0.IsDead;
    }
    return false;
  }

  public static bool smethod_1()
  {
    if (Class144.Boolean_1 && Class144.Boolean_6 && Class134.Class134_0.lazy_12.Value && Class134.Class134_0.lazy_14.Value)
    {
      if ((!((WoWUnit) Class144.LocalPlayer_0).smethod_7(115191, 112942) || Class53.smethod_3((WoWUnit) Class144.LocalPlayer_0, 115192)) && !Class74.smethod_4(Class144.WoWUnit_0) && !Class144.WoWUnit_0.smethod_9())
        return !Class144.WoWUnit_0.IsDead;
    }
    return false;
  }

  public static bool smethod_2()
  {
    if (!Class65.Boolean_1)
      return true;
    if (Class77.Int32_0 == 1856 || Class53.smethod_3((WoWUnit) Class144.LocalPlayer_0, 58984))
      return false;
    if (((WoWUnit) Class144.LocalPlayer_0).Combat && ((WoWUnit) Class144.LocalPlayer_0).smethod_6() < 4.5 || ((WoWUnit) Class144.LocalPlayer_0).smethod_5() && Class130.Double_9 > 2.0 || Class53.smethod_3((WoWUnit) Class144.LocalPlayer_0, 115192))
      return true;
    return WoWObject.op_Inequality((WoWObject) Class144.WoWUnit_0, (WoWObject) null) && Class134.Class134_0.lazy_18.Value < 30.0;
  }

  public virtual void Initialize()
  {
    if (!StyxWoW.IsInGame || !StyxWoW.IsInWorld)
      return;
    Logging.Write("");
    Logging.Write((LogLevel) 2, Colors.Moccasin, "Welcome to Vitalic Elite Rogue PvP Profile [v2.0.3 - Release Candidate]");
    Logging.Write("");
    Class144.bool_2 = true;
    Class144.bool_3 = true;
    Class41.smethod_2();
    Class37.smethod_0();
    Class140.smethod_1();
    Class136.smethod_1();
    Class137.smethod_0();
    // ISSUE: method pointer
    BotEvents.OnBotStarted += new BotEvents.OnBotStartDelegate((object) this, __methodptr(method_0));
    // ISSUE: method pointer
    BotEvents.OnBotStopped += new BotEvents.OnBotStopDelegate((object) this, __methodptr(method_1));
    Class135.smethod_0();
    Class80.smethod_4();
    Class144.string_0 = Class144.smethod_4();
    Class144.class81_0.Keys_0 = VitalicSettings.Instance.GarroteKeyBind;
    Class144.class81_1.Keys_0 = VitalicSettings.Instance.CheapShotKeyBind;
    Class144.class80_0.Keys_0 = VitalicSettings.Instance.BlindKeyBind;
    Class144.class81_2.Keys_0 = VitalicSettings.Instance.GougeKeyBind;
    Class144.class81_3.Keys_0 = VitalicSettings.Instance.RedirectKidneyKeyBind;
    Class144.class82_0.Keys_0 = VitalicSettings.Instance.FocusMacroKeyBind;
    Class144.class80_3.Keys_0 = VitalicSettings.Instance.OpenerModifierKeyBind;
    Class144.class80_4.Keys_0 = VitalicSettings.Instance.BurstKeyBind;
    Class144.class80_6.Keys_0 = VitalicSettings.Instance.BurstNoShadowBladesKeyBind;
    Class144.class80_5.Keys_0 = VitalicSettings.Instance.LazyKeyBind;
    Class144.class80_8.Keys_0 = VitalicSettings.Instance.PauseKeyBind;
    Class144.class80_9.Keys_0 = VitalicSettings.Instance.PauseDamageKeyBind;
    Class144.class80_7.Keys_0 = VitalicSettings.Instance.EventsKeyBind;
    Class144.class80_10.Keys_0 = VitalicSettings.Instance.RestealthKeyBind;
    Class144.class80_11.Keys_0 = VitalicSettings.Instance.FastKickKeyBind;
    Class144.class80_2.Keys_0 = VitalicSettings.Instance.SmokeBombKeyBind;
    Class144.class80_1.Keys_0 = VitalicSettings.Instance.KidneyShotKeyBind;
    Class144.class80_12.Keys_0 = VitalicSettings.Instance.AutoKidneyKeyBind;
    Class80.smethod_0();
  }

  private void method_0(object object_0)
  {
    Class41.smethod_2();
    Class37.smethod_2();
    Class136.smethod_5();
    Lua.DoString("SetCVar('autoInteract', '0')", "WoW.lua");
    Class144.double_0 = (double) StyxWoW.WoWClient.Latency;
    foreach (WoWObject woWobject in Class144.LocalPlayer_0.GroupInfo.IsInRaid ? (IEnumerable<WoWPlayer>) Class144.LocalPlayer_0.RaidMembers : (IEnumerable<WoWPlayer>) Class144.LocalPlayer_0.PartyMembers)
    {
      string string_0 = "attackable_" + (object) woWobject.Guid;
      if (Class51.smethod_4(string_0))
        Class51.smethod_3(string_0);
    }
    if (!VitalicSettings.Instance.DiagnosticMode)
      return;
    Class144.delegate41_1((object) "Settings on bot start:", (object) new JavaScriptSerializer().Serialize((object) VitalicSettings.Instance));
  }

  private void method_1(object object_0)
  {
    if (!VitalicSettings.Instance.DiagnosticMode)
      return;
    Class144.delegate41_1((object) "Settings on bot stop:", (object) new JavaScriptSerializer().Serialize((object) VitalicSettings.Instance));
  }

  public virtual void ShutDown()
  {
    // ISSUE: method pointer
    BotEvents.OnBotStarted -= new BotEvents.OnBotStartDelegate((object) this, __methodptr(method_0));
    // ISSUE: method pointer
    BotEvents.OnBotStopped -= new BotEvents.OnBotStopDelegate((object) this, __methodptr(method_1));
    Class37.smethod_1();
    base.ShutDown();
  }

  public static string smethod_3() => Class144.string_0;

  public static string smethod_4()
  {
    string str = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuioplkjhgfdsazxcvbnm_";
    int capacity = 5;
    if (Class144.random_0 == null)
      Class144.random_0 = new Random();
    StringBuilder stringBuilder = new StringBuilder(capacity);
    for (int index = 0; index < capacity; ++index)
      stringBuilder.Append(str[Class144.random_0.Next(str.Length)]);
    return stringBuilder.ToString();
  }

  public virtual bool WantButton => true;

  public static bool smethod_5()
  {
    return Class144.vitalicForm_0 != null && !Class144.vitalicForm_0.Boolean_0 && Class144.vitalicForm_0.\u000C();
  }

  public virtual void OnButtonPress()
  {
    if (Class144.vitalicForm_0 != null && !Class144.vitalicForm_0.Boolean_0)
    {
      Class144.vitalicForm_0.WindowState = FormWindowState.Normal;
      Class144.vitalicForm_0.Activate();
    }
    else
    {
      Class144.vitalicForm_0 = new VitalicForm();
      Class144.vitalicForm_0.Show();
    }
  }

  public virtual void Pulse()
  {
    Class144.bool_4 = StyxWoW.IsInGame && StyxWoW.IsInWorld;
    if (!Class144.bool_4)
      return;
    if (Class144.class80_4.method_2())
    {
      Class144.bool_1 = true;
      Class144.bool_0 = false;
      Class144.Boolean_0 = !Class144.Boolean_0;
      Class136.smethod_5();
    }
    if (Class144.class80_6.method_2())
    {
      if (!Class144.Boolean_0)
      {
        Class144.Boolean_0 = true;
        Class144.bool_1 = false;
      }
      else if (Class144.Boolean_0 && Class144.bool_1)
      {
        if (Class144.bool_0)
        {
          Class144.Boolean_0 = false;
        }
        else
        {
          Class144.bool_1 = false;
          Class144.bool_0 = false;
        }
      }
      else if (Class144.Boolean_0 && !Class144.bool_1)
      {
        Class144.Boolean_0 = true;
        Class144.bool_1 = true;
        Class144.bool_0 = true;
      }
      Class136.smethod_5();
    }
    if (Class144.class80_5.method_2())
    {
      Class144.Boolean_1 = !Class144.Boolean_1;
      Class136.smethod_5();
    }
    if (Class144.class80_12.method_2())
      Class144.Boolean_2 = !VitalicSettings.Instance.AutoKidney;
    if (Class144.delegate42_0 != null)
      Class144.delegate42_0((object) this, (EventArgs) null);
    if (!VitalicSettings.Instance.AntiAFK || !Class144.waitTimer_0.IsFinished || ((WoWUnit) Class144.LocalPlayer_0).smethod_6() <= 60.0)
      return;
    StyxWoW.ResetAfk();
    Class144.waitTimer_0.Reset();
  }

  public virtual Composite PreCombatBuffBehavior
  {
    get
    {
      if (Class144.canRunDecoratorDelegate_0 == null)
        Class144.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
      return (Composite) new Decorator(Class144.canRunDecoratorDelegate_0, (Composite) new PrioritySelector(new Composite[19]
      {
        Class84.smethod_0(),
        Class130.smethod_5(),
        Class116.smethod_4(),
        Class101.smethod_4(),
        Class113.smethod_4(),
        Class125.smethod_4(),
        Class102.smethod_4(),
        Class124.smethod_5(),
        Class123.smethod_4(),
        Class119.smethod_4(),
        Class118.smethod_6(),
        Class122.smethod_5(),
        Class92.smethod_4(),
        Class115.smethod_5(),
        Class114.smethod_4(),
        Class112.smethod_4(),
        Class111.smethod_4(),
        Class110.smethod_4(),
        Class108.smethod_4()
      }));
    }
  }

  public virtual Composite CombatBehavior
  {
    get
    {
      if (Class144.retrieveSwitchParameterDelegate_0 == null)
        Class144.retrieveSwitchParameterDelegate_0 = new RetrieveSwitchParameterDelegate<WoWSpec>((object) null, __methodptr(smethod_7));
      return (Composite) new Switch<WoWSpec>(Class144.retrieveSwitchParameterDelegate_0, new SwitchArgument<WoWSpec>[3]
      {
        new SwitchArgument<WoWSpec>((WoWSpec) 259, Class87.Composite_4),
        new SwitchArgument<WoWSpec>((WoWSpec) 261, Class85.Composite_5),
        new SwitchArgument<WoWSpec>((WoWSpec) 260, Class86.Composite_5)
      });
    }
  }

  private delegate void Delegate41(params object[] args);

  public delegate void Delegate42(object sender, EventArgs e);

  public delegate WoWUnit Delegate43(object unit);
}
