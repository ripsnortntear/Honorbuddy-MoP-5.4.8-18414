﻿// Decompiled with JetBrains decompiler
// Type: ns1.GClass69
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;

#nullable disable
namespace ns1;

public class GClass69 : Decorator
{
  public string string_0;

  public GClass69(
    string string_1,
    CanRunDecoratorDelegate canRunDecoratorDelegate_0,
    Composite composite_0)
    : base(canRunDecoratorDelegate_0, composite_0)
  {
    this.string_0 = string_1;
  }
}
