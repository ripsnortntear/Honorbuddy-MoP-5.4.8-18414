﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class35
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals.WoWObjects;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class35
{
  private static bool bool_0;
  private static Class35.Delegate8 delegate8_0 = new Class35.Delegate8(Class62.smethod_0);

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  protected static ulong UInt64_0 => Class50.ulong_0;

  public static void Initialise() => Class35.Attach();

  public static void Attach()
  {
    if (Class35.bool_0)
      return;
    Class37.smethod_8(Class37.Types.UNIT_DIED, new Class37.Delegate11(Class35.smethod_1));
    Class37.smethod_8(Class37.Types.UNIT_DESTROYED, new Class37.Delegate11(Class35.smethod_1));
    Class35.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class35.bool_0)
      return;
    Class37.smethod_9(Class37.Types.UNIT_DIED, new Class37.Delegate11(Class35.smethod_1));
    Class37.smethod_9(Class37.Types.UNIT_DESTROYED, new Class37.Delegate11(Class35.smethod_1));
    Class35.bool_0 = false;
  }

  public static void Shutdown() => Class35.smethod_0();

  private static void smethod_1(EventArgs0 eventArgs0_0)
  {
    if (eventArgs0_0.lazy_4.Value != 0UL && (long) eventArgs0_0.lazy_4.Value == (long) Class49.ulong_0 && Class51.smethod_4("cooldown_137619"))
      Class51.smethod_3("cooldown_137619");
    if (eventArgs0_0.lazy_0.Value != Class37.Types.UNIT_DESTROYED || Class141.dictionary_0.Count <= 0)
      return;
    WoWUnit woWunit = eventArgs0_0.lazy_5.Value;
    Totems key;
    if (!woWunit.IsTotem || !Class141.dictionary_4.TryGetValue((int) woWunit.CreatedBySpellId, out key) || !Class141.dictionary_0.ContainsKey(key))
      return;
    Class141.dictionary_0.Remove(key);
  }

  private delegate void Delegate8(params object[] args);
}
