﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class89
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using JetBrains.Annotations;
using Styx;
using Styx.TreeSharp;

#nullable disable
namespace ns1;

[UsedImplicitly]
internal class Class89(params Composite[] composite_0) : PrioritySelector(composite_0)
{
  public virtual RunStatus Tick(object context)
  {
    using (StyxWoW.Memory.AcquireFrame())
      return ((Composite) this).Tick(context);
  }
}
