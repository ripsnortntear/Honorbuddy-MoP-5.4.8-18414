﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class50
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.CommonBot;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Linq;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class50
{
  private static bool bool_0;
  private static Class50.Delegate23 delegate23_0 = new Class50.Delegate23(Class62.smethod_0);
  public static WoWUnit woWUnit_0;
  public static WoWUnit woWUnit_1;
  public static WoWUnit woWUnit_2;
  public static ulong ulong_0;
  public static ulong ulong_1;
  public static DateTime dateTime_0 = DateTime.MinValue;
  public static DateTime dateTime_1 = DateTime.MinValue;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  public static void Initialise()
  {
    Class144.Event_0 += (Class144.Delegate42) ((sender, e) =>
    {
      if (WoWObject.op_Inequality((WoWObject) Class50.woWUnit_0, (WoWObject) null) && !((WoWObject) Class50.woWUnit_0).IsValid)
        Class50.smethod_2();
      if (!WoWObject.op_Inequality((WoWObject) Class50.woWUnit_1, (WoWObject) null) || ((WoWObject) Class50.woWUnit_1).IsValid)
        return;
      Class50.smethod_3();
    });
    // ISSUE: reference to a compiler-generated field
    if (Class50.onBotStartDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class50.onBotStartDelegate_0 = new BotEvents.OnBotStartDelegate((object) null, __methodptr(smethod_11));
    }
    // ISSUE: reference to a compiler-generated field
    BotEvents.OnBotStarted += Class50.onBotStartDelegate_0;
    Class50.Attach();
  }

  public static void Attach()
  {
    if (Class50.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.PLAYER_TARGET_CHANGED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_4)));
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.PLAYER_FOCUS_CHANGED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_5)));
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.PLAYER_DEAD, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_6)));
    Class50.bool_0 = true;
    Class50.woWUnit_0 = ((WoWUnit) Class50.LocalPlayer_0).CurrentTarget;
    Class50.woWUnit_1 = Class50.LocalPlayer_0.FocusedUnit;
  }

  public static void smethod_0()
  {
    if (!Class50.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.PLAYER_TARGET_CHANGED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_4)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.PLAYER_FOCUS_CHANGED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_5)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.PLAYER_DEAD, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_6)));
    Class50.bool_0 = false;
  }

  public static void Shutdown() => Class50.smethod_0();

  public static void smethod_1()
  {
    Class50.woWUnit_0 = (WoWUnit) null;
    Class50.woWUnit_1 = (WoWUnit) null;
    Class50.woWUnit_2 = (WoWUnit) null;
    Class50.ulong_0 = 0UL;
    Class50.ulong_1 = 0UL;
  }

  private static void smethod_2()
  {
    Class50.woWUnit_2 = Class50.woWUnit_0;
    Class50.woWUnit_0 = ((WoWUnit) Class50.LocalPlayer_0).CurrentTarget;
    Class50.ulong_0 = WoWObject.op_Inequality((WoWObject) Class50.woWUnit_0, (WoWObject) null) ? ((WoWObject) Class50.woWUnit_0).Guid : 0UL;
    Class50.dateTime_0 = DateTime.UtcNow;
    if (!WoWObject.op_Inequality((WoWObject) Class50.woWUnit_0, (WoWObject) null))
      return;
    WoWUnit woWunit0 = Class50.woWUnit_0;
    // ISSUE: reference to a compiler-generated field
    if (Class50.objectInvalidateDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class50.objectInvalidateDelegate_0 = new ObjectInvalidateDelegate((object) null, __methodptr(smethod_12));
    }
    // ISSUE: reference to a compiler-generated field
    ObjectInvalidateDelegate invalidateDelegate0 = Class50.objectInvalidateDelegate_0;
    ((WoWObject) woWunit0).OnInvalidate += invalidateDelegate0;
  }

  private static void smethod_3()
  {
    Class50.woWUnit_1 = Class50.LocalPlayer_0.FocusedUnit;
    Class50.ulong_1 = WoWObject.op_Inequality((WoWObject) Class50.woWUnit_1, (WoWObject) null) ? ((WoWObject) Class50.woWUnit_1).Guid : 0UL;
    Class50.dateTime_1 = DateTime.UtcNow;
    if (!WoWObject.op_Inequality((WoWObject) Class50.woWUnit_1, (WoWObject) null))
      return;
    WoWUnit woWunit1 = Class50.woWUnit_1;
    // ISSUE: reference to a compiler-generated field
    if (Class50.objectInvalidateDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class50.objectInvalidateDelegate_1 = new ObjectInvalidateDelegate((object) null, __methodptr(smethod_13));
    }
    // ISSUE: reference to a compiler-generated field
    ObjectInvalidateDelegate invalidateDelegate1 = Class50.objectInvalidateDelegate_1;
    ((WoWObject) woWunit1).OnInvalidate += invalidateDelegate1;
  }

  private static void smethod_4(object sender, LuaEventArgs e)
  {
    Class50.smethod_2();
    Class50.smethod_7();
    Class50.smethod_8();
    Class50.smethod_9();
    Class49.woWSpell_0 = (WoWSpell) null;
    Class49.woWSpell_1 = (WoWSpell) null;
    Class49.woWSpell_2 = (WoWSpell) null;
  }

  private static void smethod_5(object sender, LuaEventArgs e) => Class50.smethod_3();

  private static void smethod_6(object sender, LuaEventArgs e) => Class50.smethod_1();

  private static void smethod_7()
  {
    using (StyxWoW.Memory.AcquireFrame())
    {
      if (!Class50.LocalPlayer_0.smethod_0(Class50.woWUnit_0) || !((WoWUnit) Class50.LocalPlayer_0).smethod_4() && !Class53.smethod_3((WoWUnit) Class50.LocalPlayer_0, 51713) || Class50.woWUnit_0.Combat || !Class50.woWUnit_0.smethod_4() || Class53.smethod_3(Class50.woWUnit_0, 6770) || Class70.smethod_2(Class50.woWUnit_0) >= 12.0)
        return;
      SpellManager.Cast(6770);
      Class140.smethod_7("Sapping " + ((WoWObject) Class50.woWUnit_0).Name, Class140.struct24_6);
    }
  }

  private static void smethod_8()
  {
    if (!((WoWUnit) Class50.LocalPlayer_0).Combat || Class50.LocalPlayer_0.smethod_22())
      return;
    double num1 = Class65.smethod_1(5171);
    double num2 = Class65.smethod_1(73651);
    int rawComboPoints = Class50.LocalPlayer_0.RawComboPoints;
    if (rawComboPoints > 1 && (Class134.Class134_0.lazy_7.Value < 80.0 || rawComboPoints > 3 && num1 > 10.0) && (WoWObject.op_Equality((WoWObject) Class50.woWUnit_0, (WoWObject) null) || num1 > 0.0 || Class134.Class134_0.lazy_7.Value < 30.0) && (WoWObject.op_Equality((WoWObject) Class50.woWUnit_0, (WoWObject) null) || rawComboPoints < 4 || Class59.smethod_0(73981)) && num2 < 2.5)
    {
      SpellManager.Cast(73651);
      Class62.smethod_2("Recuperate (Target Switch)", (WoWUnit) Class50.LocalPlayer_0);
    }
    else
    {
      if (rawComboPoints <= 0 || !WoWObject.op_Equality((WoWObject) Class50.woWUnit_0, (WoWObject) null) && rawComboPoints >= 4 && !Class59.smethod_0(73981) || (double) (6 + rawComboPoints * 6 - 2) <= num1 || Class41.bool_1 && rawComboPoints <= 3 && !WoWObject.op_Equality((WoWObject) Class134.Class134_0.lazy_5.Value, (WoWObject) null) || ((WoWUnit) Class50.LocalPlayer_0).smethod_4() && rawComboPoints <= 4 && num1 >= 4.0)
        return;
      SpellManager.Cast(5171);
      Class62.smethod_2("Slice and Dice (Target Switch)", (WoWUnit) Class50.LocalPlayer_0);
    }
  }

  private static void smethod_9()
  {
    if (!VitalicSettings.Instance.AutoTarget || !WoWObject.op_Equality((WoWObject) Class50.woWUnit_0, (WoWObject) null) || Class50.LocalPlayer_0.smethod_22() || !((WoWUnit) Class50.LocalPlayer_0).Combat || ((WoWUnit) Class50.LocalPlayer_0).smethod_4())
      return;
    WoWUnit woWunit = Class63.IEnumerable_0.Where<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_3 =>
    {
      if (!((WoWObject) woWUnit_3).IsValid || woWUnit_3.IsDead || woWUnit_3.IsTotem)
        return false;
      if (woWUnit_3.IsPlayer)
        return true;
      return !Class41.bool_1 && !Class41.bool_2;
    })).OrderBy<WoWUnit, double>((Func<WoWUnit, double>) (woWUnit_3 => Class70.smethod_2(woWUnit_3))).FirstOrDefault<WoWUnit>();
    if (!WoWObject.op_Inequality((WoWObject) woWunit, (WoWObject) null))
      return;
    woWunit.Target();
  }

  private delegate void Delegate23(params object[] args);
}
