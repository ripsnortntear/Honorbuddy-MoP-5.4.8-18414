﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class141
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.Helpers;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Windows.Media;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class141
{
  private static bool bool_0;
  private static Class141.Delegate40 delegate40_0 = new Class141.Delegate40(Class62.smethod_0);
  private static Class141.Delegate40 delegate40_1 = new Class141.Delegate40(Class62.smethod_1);
  private static bool bool_1 = true;
  public static HashSet<int> hashSet_0 = new HashSet<int>();
  public static Dictionary<Totems, DateTime> dictionary_0 = new Dictionary<Totems, DateTime>();
  private static Dictionary<int, bool> dictionary_1 = new Dictionary<int, bool>();
  private static bool bool_2;
  private static bool bool_3;
  private static bool bool_4;
  private static bool bool_5;
  public static WoWUnit woWUnit_0;
  private static DateTime dateTime_0;
  public static ulong ulong_0;
  private static WoWUnit woWUnit_1;
  private static DateTime dateTime_1;
  private static WoWUnit woWUnit_2;
  public static bool bool_6;
  public static DateTime dateTime_2;
  public static DateTime dateTime_3;
  private static Stopwatch stopwatch_0 = new Stopwatch();
  private static readonly Dictionary<int, Class141.Delegate39> dictionary_2 = new Dictionary<int, Class141.Delegate39>()
  {
    {
      8122,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => !WoWObject.op_Equality((WoWObject) woWUnit_3, (WoWObject) Class141.WoWUnit_0) ? Class141.bool_3 : Class141.bool_2)
    },
    {
      5484,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => !WoWObject.op_Equality((WoWObject) woWUnit_3, (WoWObject) Class141.WoWUnit_0) ? Class141.bool_3 : Class141.bool_2)
    },
    {
      49576,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => Class134.Class134_0.lazy_18.Value < 40.0)
    }
  };
  private static readonly Dictionary<int, Class141.Delegate39> dictionary_3 = new Dictionary<int, Class141.Delegate39>()
  {
    {
      1966,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => Class141.LocalPlayer_0.smethod_4(9))
    },
    {
      74001,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => Class141.LocalPlayer_0.smethod_4(6))
    },
    {
      8676,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => Class141.LocalPlayer_0.smethod_4(10))
    },
    {
      408,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => Class141.LocalPlayer_0.ComboPoints > 3)
    },
    {
      6770,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => !woWUnit_3.Combat)
    },
    {
      5277,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => !Class53.smethod_3((WoWUnit) Class141.LocalPlayer_0, 5277))
    },
    {
      19503,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => !Class53.smethod_3((WoWUnit) Class141.LocalPlayer_0, 5277))
    },
    {
      51722,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => woWUnit_3.MaxMana < 290000U)
    },
    {
      1776,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) =>
      {
        if (Class141.LocalPlayer_0.smethod_3(56809))
          return true;
        return !WoWObject.op_Equality((WoWObject) woWUnit_3, (WoWObject) Class141.WoWUnit_0) ? Class141.bool_5 : Class141.bool_4;
      })
    },
    {
      36554,
      (Class141.Delegate39) ((ulong_1, woWUnit_3) => (long) ulong_1 == (long) Class141.UInt64_0 && Class141.LocalPlayer_0.smethod_4(11))
    }
  };
  internal static readonly Dictionary<int, Totems> dictionary_4 = new Dictionary<int, Totems>()
  {
    {
      98008,
      Totems.SpiritLink
    },
    {
      51485,
      Totems.Earthgrab
    },
    {
      5394,
      Totems.HealingStream
    },
    {
      108280,
      Totems.HealingTide
    },
    {
      108269,
      Totems.Capacitor
    },
    {
      8177,
      Totems.Grounding
    },
    {
      108273,
      Totems.Windwalk
    }
  };
  private static readonly HashSet<int> hashSet_1 = new HashSet<int>()
  {
    59752,
    42292,
    19574,
    1856,
    102280,
    1953,
    8122,
    5484
  };
  private static readonly HashSet<int> hashSet_2 = new HashSet<int>()
  {
    51490,
    13813,
    61391,
    703,
    1833
  };
  private static readonly HashSet<int> hashSet_3 = new HashSet<int>()
  {
    1966,
    36554,
    76577,
    58984
  };
  private static readonly HashSet<int> hashSet_4 = new HashSet<int>()
  {
    1776,
    51722,
    703,
    1833,
    408,
    5938
  };
  private static readonly HashSet<int> hashSet_5 = new HashSet<int>()
  {
    6770,
    8676
  };
  private static readonly Dictionary<int, double> dictionary_5 = new Dictionary<int, double>()
  {
    {
      2094,
      15.0
    },
    {
      36554,
      25.0
    },
    {
      6770,
      10.0
    }
  };
  private static readonly Dictionary<int, HashSet<int>> dictionary_6 = new Dictionary<int, HashSet<int>>()
  {
    {
      113656,
      new HashSet<int>() { 1776, 51722, 1966 }
    },
    {
      116844,
      new HashSet<int>() { 2094, 1776, 1966 }
    },
    {
      116740,
      new HashSet<int>() { 74001, 1966 }
    },
    {
      123904,
      new HashSet<int>() { 5277, 51722 }
    },
    {
      119381,
      new HashSet<int>() { 1776, 1966 }
    },
    {
      47481,
      new HashSet<int>() { 5277 }
    },
    {
      91797,
      new HashSet<int>() { 5277 }
    },
    {
      49576,
      new HashSet<int>() { 31224 }
    },
    {
      49016,
      new HashSet<int>() { 5938 }
    },
    {
      45524,
      new HashSet<int>() { 1776 }
    },
    {
      49039,
      new HashSet<int>() { 703, 1776 }
    },
    {
      48792,
      new HashSet<int>() { 703, 1776 }
    },
    {
      108194,
      new HashSet<int>() { 51722, 1776, 1966 }
    },
    {
      51271,
      new HashSet<int>() { 5277, 1966 }
    },
    {
      47568,
      new HashSet<int>() { 5277, 1966 }
    },
    {
      5211,
      new HashSet<int>() { 51722, 1776, 1966 }
    },
    {
      33786,
      new HashSet<int>() { 31224 }
    },
    {
      22570,
      new HashSet<int>() { 1776, 1966 }
    },
    {
      9005,
      new HashSet<int>() { 51722, 74001, 1856, 1776, 1966 }
    },
    {
      339,
      new HashSet<int>() { 1776 }
    },
    {
      49376,
      new HashSet<int>() { 36554, 1966 }
    },
    {
      16979,
      new HashSet<int>() { 36554 }
    },
    {
      49377,
      new HashSet<int>() { 36554 }
    },
    {
      5229,
      new HashSet<int>() { 5938 }
    },
    {
      102280,
      new HashSet<int>() { -1, 1833, 408, 8676, -2 }
    },
    {
      106731,
      new HashSet<int>() { 51722, 1776, 1966 }
    },
    {
      61391,
      new HashSet<int>() { -1 }
    },
    {
      5215,
      new HashSet<int>() { 6770 }
    },
    {
      99,
      new HashSet<int>() { 5938 }
    },
    {
      109248,
      new HashSet<int>() { 31224, 1966 }
    },
    {
      19263,
      new HashSet<int>() { 1776, 5938 }
    },
    {
      781,
      new HashSet<int>() { 1776, 51722, 1833, 408, 5938 }
    },
    {
      19503,
      new HashSet<int>() { 1776, 2094, 1966, 5938 }
    },
    {
      53271,
      new HashSet<int>() { 51722, 1776 }
    },
    {
      19574,
      new HashSet<int>() { 1833, 408, 51722 }
    },
    {
      19577,
      new HashSet<int>() { 51722, 1966 }
    },
    {
      3045,
      new HashSet<int>() { 51722, 5277, 1966 }
    },
    {
      121818,
      new HashSet<int>() { 5277, 1966 }
    },
    {
      82939,
      new HashSet<int>() { -1 }
    },
    {
      13813,
      new HashSet<int>() { -1 }
    },
    {
      44572,
      new HashSet<int>() { 1776, 76577, 2094, 31224, 58984, 1966 }
    },
    {
      118271,
      new HashSet<int>() { 1776, 1966 }
    },
    {
      31661,
      new HashSet<int>() { 1776, 2094, 31224, 5938 }
    },
    {
      83047,
      new HashSet<int>() { 31224 }
    },
    {
      118,
      new HashSet<int>() { 31224 }
    },
    {
      122,
      new HashSet<int>() { 1776, 408, 703, 5938 }
    },
    {
      33395,
      new HashSet<int>() { 1776, 408, 703, 5938 }
    },
    {
      1953,
      new HashSet<int>() { -1, 8676, -2 }
    },
    {
      45438,
      new HashSet<int>() { 703, 1776, 5938 }
    },
    {
      84714,
      new HashSet<int>() { 1966 }
    },
    {
      853,
      new HashSet<int>() { 1776, 31224, 51722, 1966 }
    },
    {
      105593,
      new HashSet<int>() { 1776, 31224, 51722, 1966 }
    },
    {
      115750,
      new HashSet<int>() { 703, 31224, 1966 }
    },
    {
      20066,
      new HashSet<int>() { 1776, 31224, 2094 }
    },
    {
      31935,
      new HashSet<int>() { 36554 }
    },
    {
      31884,
      new HashSet<int>() { 703, 51722 }
    },
    {
      31821,
      new HashSet<int>() { 5938, 1776 }
    },
    {
      605,
      new HashSet<int>() { 31224 }
    },
    {
      64044,
      new HashSet<int>() { 1776, 5938, 1966 }
    },
    {
      8122,
      new HashSet<int>() { 31224, 1776, 1966 }
    },
    {
      64058,
      new HashSet<int>() { 1776, 5938, 1966 }
    },
    {
      89485,
      new HashSet<int>() { 5938, 1776 }
    },
    {
      88625,
      new HashSet<int>() { 5938 }
    },
    {
      2094,
      new HashSet<int>() { 58984, 1943, 73651 }
    },
    {
      1833,
      new HashSet<int>() { 51722, 74001, 1856, 1776, 1966 }
    },
    {
      79140,
      new HashSet<int>() { 74001, 5277 }
    },
    {
      1856,
      new HashSet<int>() { 6770, 51722, 1833, 2094, 1776, 1966 }
    },
    {
      58984,
      new HashSet<int>() { 51722 }
    },
    {
      408,
      new HashSet<int>() { 51722, 1776, 74001, 1856, 1966 }
    },
    {
      6770,
      new HashSet<int>() { 6770 }
    },
    {
      51722,
      new HashSet<int>() { 51722 }
    },
    {
      36554,
      new HashSet<int>() { 1776, 51722, 36554 }
    },
    {
      51713,
      new HashSet<int>() { 1776, 51722, 36554, 2094 }
    },
    {
      51690,
      new HashSet<int>() { 74001, 1966 }
    },
    {
      703,
      new HashSet<int>() { 1966 }
    },
    {
      1784,
      new HashSet<int>() { 6770 }
    },
    {
      51514,
      new HashSet<int>() { 31224 }
    },
    {
      51490,
      new HashSet<int>() { -1 }
    },
    {
      2645,
      new HashSet<int>() { 5938 }
    },
    {
      131557,
      new HashSet<int>() { 5938, 1776 }
    },
    {
      51505,
      new HashSet<int>() { 1966 }
    },
    {
      89766,
      new HashSet<int>() { 5277 }
    },
    {
      6789,
      new HashSet<int>() { 1776, 1856, 31224 }
    },
    {
      5782,
      new HashSet<int>() { 31224 }
    },
    {
      5484,
      new HashSet<int>() { 31224, 1966 }
    },
    {
      30283,
      new HashSet<int>() { 1776, 31224, 1966 }
    },
    {
      6358,
      new HashSet<int>() { 31224 }
    },
    {
      48020,
      new HashSet<int>() { -1, 1776 }
    },
    {
      100,
      new HashSet<int>() { 36554, 1966 }
    },
    {
      6544,
      new HashSet<int>() { 76577 }
    },
    {
      20253,
      new HashSet<int>() { 36554 }
    },
    {
      5246,
      new HashSet<int>() { 2094, 1966 }
    },
    {
      46968,
      new HashSet<int>() { 74001, 51722, 1856, 1776, 1966 }
    },
    {
      107570,
      new HashSet<int>() { 74001, 51722, 1856, 1776, 1966 }
    },
    {
      23694,
      new HashSet<int>() { 1776, 51722 }
    },
    {
      46924,
      new HashSet<int>() { 1966 }
    },
    {
      1719,
      new HashSet<int>() { 51722, 5277, 1966 }
    },
    {
      57519,
      new HashSet<int>() { 5938 }
    },
    {
      59752,
      new HashSet<int>() { 6770, 408, 1833, 703 }
    },
    {
      42292,
      new HashSet<int>() { 6770, 408, 1833, 703 }
    }
  };

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static WoWUnit WoWUnit_1 => Class50.woWUnit_1;

  private static WoWUnit WoWUnit_2 => Class50.woWUnit_2;

  private static ulong UInt64_0 => Class50.ulong_0;

  private static ulong UInt64_1 => Class50.ulong_1;

  private static ulong UInt64_2
  {
    get
    {
      return (DateTime.UtcNow - Class50.dateTime_0).TotalSeconds > 1.0 || !WoWObject.op_Inequality((WoWObject) Class141.WoWUnit_2, (WoWObject) null) || !((WoWObject) Class141.WoWUnit_2).IsValid ? 0UL : ((WoWObject) Class141.WoWUnit_2).Guid;
    }
  }

  private static double Double_0
  {
    get
    {
      return Class141.dateTime_0 == DateTime.MinValue ? 0.0 : (DateTime.UtcNow - Class141.dateTime_0).TotalSeconds;
    }
  }

  private static double Double_1
  {
    get
    {
      return Class141.dateTime_1 == DateTime.MinValue ? 0.0 : (DateTime.UtcNow - Class141.dateTime_1).TotalSeconds;
    }
  }

  private static bool Boolean_0
  {
    get
    {
      Class141.woWUnit_2 = ObjectManager.GetObjectsOfTypeFast<WoWUnit>().FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_3 => woWUnit_3.CreatedBySpellId == 108921U));
      return WoWObject.op_Inequality((WoWObject) Class141.woWUnit_2, (WoWObject) null);
    }
  }

  private static bool Boolean_1
  {
    get
    {
      if (Class141.ulong_0 == 0UL)
        return false;
      Class141.woWUnit_1 = (WoWUnit) ObjectManager.GetObjectsOfType<WoWPlayer>(false, false).FirstOrDefault<WoWPlayer>((Func<WoWPlayer, bool>) (woWPlayer_0 => (long) ((WoWObject) woWPlayer_0).Guid == (long) Class141.ulong_0 && !Class53.smethod_3((WoWUnit) woWPlayer_0, 119032) && !Class53.smethod_3((WoWUnit) woWPlayer_0, 58984)));
      return WoWObject.op_Inequality((WoWObject) Class141.woWUnit_1, (WoWObject) null);
    }
  }

  public static Composite Composite_0
  {
    get
    {
      Composite[] compositeArray1 = new Composite[5];
      Composite[] compositeArray2 = compositeArray1;
      if (Class141.canRunDecoratorDelegate_0 == null)
        Class141.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
      CanRunDecoratorDelegate decoratorDelegate0 = Class141.canRunDecoratorDelegate_0;
      if (Class141.actionDelegate_0 == null)
        Class141.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_7));
      Action action1 = new Action(Class141.actionDelegate_0);
      Decorator decorator1 = new Decorator(decoratorDelegate0, (Composite) action1);
      compositeArray2[0] = (Composite) decorator1;
      Composite[] compositeArray3 = compositeArray1;
      if (Class141.actionDelegate_1 == null)
        Class141.actionDelegate_1 = new ActionDelegate((object) null, __methodptr(smethod_8));
      Action action2 = new Action(Class141.actionDelegate_1);
      compositeArray3[1] = (Composite) action2;
      Composite[] compositeArray4 = compositeArray1;
      if (Class141.canRunDecoratorDelegate_1 == null)
        Class141.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
      CanRunDecoratorDelegate decoratorDelegate1 = Class141.canRunDecoratorDelegate_1;
      Composite[] compositeArray5 = new Composite[1];
      Composite[] compositeArray6 = compositeArray5;
      if (Class141.canRunDecoratorDelegate_2 == null)
        Class141.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_10));
      CanRunDecoratorDelegate decoratorDelegate2 = Class141.canRunDecoratorDelegate_2;
      Composite[] compositeArray7 = new Composite[3]
      {
        Class84.smethod_4((Class144.Delegate43) (object_0 => Class141.woWUnit_2)),
        null,
        null
      };
      Composite[] compositeArray8 = compositeArray7;
      if (Class141.actionSucceedDelegate_0 == null)
        Class141.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_12));
      Action action3 = new Action(Class141.actionSucceedDelegate_0);
      compositeArray8[1] = (Composite) action3;
      Composite[] compositeArray9 = compositeArray7;
      if (Class141.canRunDecoratorDelegate_3 == null)
        Class141.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_13));
      CanRunDecoratorDelegate decoratorDelegate3 = Class141.canRunDecoratorDelegate_3;
      if (Class141.actionSucceedDelegate_1 == null)
        Class141.actionSucceedDelegate_1 = new ActionSucceedDelegate((object) null, __methodptr(smethod_14));
      Action action4 = new Action(Class141.actionSucceedDelegate_1);
      Decorator decorator2 = new Decorator(decoratorDelegate3, (Composite) action4);
      compositeArray9[2] = (Composite) decorator2;
      PrioritySelector prioritySelector = new PrioritySelector(compositeArray7);
      Decorator decorator3 = new Decorator(decoratorDelegate2, (Composite) prioritySelector);
      compositeArray6[0] = (Composite) decorator3;
      Sequence sequence1 = new Sequence(compositeArray5);
      Decorator decorator4 = new Decorator(decoratorDelegate1, (Composite) sequence1);
      compositeArray4[2] = (Composite) decorator4;
      Composite[] compositeArray10 = compositeArray1;
      if (Class141.canRunDecoratorDelegate_4 == null)
        Class141.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_15));
      CanRunDecoratorDelegate decoratorDelegate4 = Class141.canRunDecoratorDelegate_4;
      Composite[] compositeArray11 = new Composite[2];
      Composite[] compositeArray12 = compositeArray11;
      if (Class141.actionSucceedDelegate_2 == null)
        Class141.actionSucceedDelegate_2 = new ActionSucceedDelegate((object) null, __methodptr(smethod_16));
      Action action5 = new Action(Class141.actionSucceedDelegate_2);
      compositeArray12[0] = (Composite) action5;
      Composite[] compositeArray13 = compositeArray11;
      if (Class141.canRunDecoratorDelegate_5 == null)
        Class141.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_17));
      CanRunDecoratorDelegate decoratorDelegate5 = Class141.canRunDecoratorDelegate_5;
      if (Class141.actionSucceedDelegate_3 == null)
        Class141.actionSucceedDelegate_3 = new ActionSucceedDelegate((object) null, __methodptr(smethod_18));
      Action action6 = new Action(Class141.actionSucceedDelegate_3);
      Decorator decorator5 = new Decorator(decoratorDelegate5, (Composite) action6);
      compositeArray13[1] = (Composite) decorator5;
      Sequence sequence2 = new Sequence(compositeArray11);
      Decorator decorator6 = new Decorator(decoratorDelegate4, (Composite) sequence2);
      compositeArray10[3] = (Composite) decorator6;
      Composite[] compositeArray14 = compositeArray1;
      if (Class141.canRunDecoratorDelegate_6 == null)
        Class141.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_19));
      CanRunDecoratorDelegate decoratorDelegate6 = Class141.canRunDecoratorDelegate_6;
      Composite[] compositeArray15 = new Composite[2];
      Composite[] compositeArray16 = compositeArray15;
      if (Class141.actionSucceedDelegate_4 == null)
        Class141.actionSucceedDelegate_4 = new ActionSucceedDelegate((object) null, __methodptr(smethod_20));
      Action action7 = new Action(Class141.actionSucceedDelegate_4);
      compositeArray16[0] = (Composite) action7;
      Composite[] compositeArray17 = compositeArray15;
      if (Class141.canRunDecoratorDelegate_7 == null)
        Class141.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_21));
      CanRunDecoratorDelegate decoratorDelegate7 = Class141.canRunDecoratorDelegate_7;
      if (Class141.actionSucceedDelegate_5 == null)
        Class141.actionSucceedDelegate_5 = new ActionSucceedDelegate((object) null, __methodptr(smethod_22));
      Action action8 = new Action(Class141.actionSucceedDelegate_5);
      Decorator decorator7 = new Decorator(decoratorDelegate7, (Composite) action8);
      compositeArray17[1] = (Composite) decorator7;
      Sequence sequence3 = new Sequence(compositeArray15);
      Decorator decorator8 = new Decorator(decoratorDelegate6, (Composite) sequence3);
      compositeArray14[4] = (Composite) decorator8;
      return (Composite) new PrioritySelector(compositeArray1);
    }
  }

  public static void Initialise()
  {
    Class141.Attach();
    // ISSUE: reference to a compiler-generated field
    if (Class141.onBotStopDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class141.onBotStopDelegate_0 = new BotEvents.OnBotStopDelegate((object) null, __methodptr(smethod_23));
    }
    // ISSUE: reference to a compiler-generated field
    BotEvents.OnBotStopped += Class141.onBotStopDelegate_0;
    Class41.Event_0 += (EventHandler) ((sender, e) =>
    {
      if (Class41.bool_3)
        Class141.Detach();
      else
        Class141.Attach();
    });
    Class144.Event_0 += (Class144.Delegate42) ((sender, e) =>
    {
      DictionaryExtensions.RemoveAll<Totems, DateTime>(Class141.dictionary_0, (Func<DateTime, bool>) (dateTime_4 => DateTime.UtcNow - dateTime_4 > TimeSpan.FromSeconds(5.0)));
      if (!Class144.class80_7.method_2())
        return;
      if (Class141.bool_1)
      {
        Class141.bool_1 = false;
        Class140.smethod_9("Events: |cffb73737Disabled");
      }
      else
      {
        Class141.bool_1 = true;
        Class140.smethod_9("Events: |cFF15E61CEnabled");
      }
    });
    if (!string.IsNullOrEmpty(VitalicSettings.Instance.EventBlacklist))
    {
      string eventBlacklist = VitalicSettings.Instance.EventBlacklist;
      char[] chArray = new char[1]{ ',' };
      foreach (int num in ((IEnumerable<string>) eventBlacklist.Split(chArray)).Select<string, int>((Func<string, int>) (string_0 => int.Parse(string_0))).ToList<int>())
      {
        if (!Class141.hashSet_0.Contains(num))
          Class141.hashSet_0.Add(num);
      }
    }
    Logging.Write((LogLevel) 2, Colors.LightSkyBlue, "Event Framework Initialised");
  }

  public static void Attach()
  {
    if (Class141.bool_0 || Class41.bool_3)
      return;
    Class37.smethod_8(Class37.Types.SPELL_CAST_SUCCESS, new Class37.Delegate11(Class141.smethod_3));
    Class37.smethod_8(Class37.Types.SPELL_AURA_APPLIED, new Class37.Delegate11(Class141.smethod_3));
    Class37.smethod_8(Class37.Types.SPELL_AURA_REMOVED, new Class37.Delegate11(Class141.smethod_3));
    Class141.bool_0 = true;
  }

  public static void Detach()
  {
    if (!Class141.bool_0)
      return;
    Class37.smethod_9(Class37.Types.SPELL_CAST_SUCCESS, new Class37.Delegate11(Class141.smethod_3));
    Class37.smethod_9(Class37.Types.SPELL_AURA_APPLIED, new Class37.Delegate11(Class141.smethod_3));
    Class37.smethod_9(Class37.Types.SPELL_AURA_REMOVED, new Class37.Delegate11(Class141.smethod_3));
    Class141.bool_0 = false;
  }

  private static void smethod_0(WoWSpell woWSpell_0, WoWSpell woWSpell_1, WoWUnit woWUnit_3)
  {
    string str1 = $"|cff71d5ff|Hspell:{(object) woWSpell_0.Id}|h[{woWSpell_0.Name}]|h|r";
    string str2 = $"|cff71d5ff|Hspell:{(object) woWSpell_1.Id}|h[{woWSpell_1.Name}]|h|r";
    if (Class140.bool_2)
      Class140.smethod_9($"Casted {str1} in response to {str2}");
    Class140.Struct24 struct24_8 = WoWObject.op_Equality((WoWObject) woWUnit_3, (WoWObject) Class141.WoWUnit_1) ? Class140.struct24_0 : Class140.struct24_2;
    Class140.smethod_6($"{woWSpell_0.Name} {woWSpell_1.Name}", struct24_8, woWSpell_0, true);
  }

  public static Composite smethod_1()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class141.actionDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class141.actionDelegate_2 = new ActionDelegate((object) null, __methodptr(smethod_28));
    }
    // ISSUE: reference to a compiler-generated field
    return (Composite) new Action(Class141.actionDelegate_2);
  }

  public static bool smethod_2(int int_0, WoWUnit woWUnit_3)
  {
    if (Class141.dictionary_1.ContainsKey(int_0))
    {
      if (Class141.dictionary_1[int_0])
        return false;
      if (int_0 == 31224 || int_0 == 74001 || int_0 == 1856 || int_0 == 36554 || int_0 == 1966 || int_0 == 58984)
        return true;
    }
    else if (Class59.smethod_0(int_0))
      return false;
    WoWSpell woWspell = WoWSpell.FromId(int_0);
    if (!Class141.hashSet_3.Contains(int_0))
    {
      if (Class141.hashSet_4.Contains(int_0))
      {
        if (!woWUnit_3.smethod_6(true))
          return false;
      }
      else if (((WoWObject) woWUnit_3).Distance > Class141.dictionary_5[int_0])
        return false;
    }
    return !Class141.hashSet_5.Contains(int_0) || woWspell.CanCast;
  }

  private static void smethod_3(EventArgs0 eventArgs0_0)
  {
    if (!Class141.bool_1 || Class141.LocalPlayer_0.smethod_7())
      return;
    Class141.stopwatch_0.Reset();
    Class141.stopwatch_0.Start();
    int key = eventArgs0_0.lazy_7.Value;
    ulong source = eventArgs0_0.lazy_1.Value;
    ulong num1 = eventArgs0_0.lazy_4.Value;
    if (source == 0UL)
    {
      if (num1 == 0UL)
        return;
    }
    try
    {
      if (eventArgs0_0.lazy_0.Value != Class37.Types.SPELL_CAST_SUCCESS && (eventArgs0_0.lazy_0.Value != Class37.Types.SPELL_AURA_APPLIED || (eventArgs0_0.lazy_6.Value & Enum13.flag_10) == (Enum13) 0 && key != 51490))
      {
        if (eventArgs0_0.lazy_0.Value == Class37.Types.SPELL_AURA_REMOVED)
        {
          if (key != 45438)
          {
            if (key != 19263)
              goto label_32;
          }
        }
        else
          goto label_32;
      }
      if (((long) source != (long) Class141.UInt64_0 || (long) num1 != (long) ((WoWObject) Class141.LocalPlayer_0).Guid && ((long) num1 != (long) Class141.UInt64_0 && num1 != 0UL || (long) Class141.WoWUnit_0.CurrentTargetGuid != (long) ((WoWObject) Class141.LocalPlayer_0).Guid && !WoWObject.op_Equality((WoWObject) Class141.WoWUnit_0.CurrentTarget, (WoWObject) Class141.WoWUnit_0))) && ((long) source != (long) Class141.UInt64_1 || (long) num1 != (long) ((WoWObject) Class141.LocalPlayer_0).Guid && ((long) num1 != (long) Class141.UInt64_1 && num1 != 0UL || (long) Class141.WoWUnit_1.CurrentTargetGuid != (long) ((WoWObject) Class141.LocalPlayer_0).Guid && !WoWObject.op_Equality((WoWObject) Class141.WoWUnit_1.CurrentTarget, (WoWObject) Class141.WoWUnit_1))) && ((long) source != (long) Class141.UInt64_0 && (long) source != (long) Class141.UInt64_1 || !Class141.hashSet_1.Contains(key)))
      {
        if ((long) num1 == (long) ((WoWObject) Class141.LocalPlayer_0).Guid)
        {
          if (!Class141.hashSet_2.Contains(key))
            goto label_32;
        }
        else
          goto label_32;
      }
      if ((key == 45438 || key == 19263) && eventArgs0_0.lazy_0.Value != Class37.Types.SPELL_AURA_REMOVED)
        return;
      HashSet<int> intSet;
      if (Class141.dictionary_6.TryGetValue(eventArgs0_0.lazy_7.Value, out intSet))
      {
        using (StyxWoW.Memory.AcquireFrame())
        {
          WoWUnit woWunit = (long) source == (long) Class141.UInt64_1 ? Class141.WoWUnit_1 : Class141.WoWUnit_0;
          if (Class141.dictionary_2.ContainsKey(key) && !Class141.dictionary_2[key](source, woWunit))
            return;
          foreach (int num2 in intSet)
          {
            if (!Class141.hashSet_0.Contains(num2) && (!Class141.dictionary_3.ContainsKey(num2) || Class141.dictionary_3[num2](source, woWunit)))
            {
              if (num2 < 0)
              {
                if (num2 != -1 || !Class141.LocalPlayer_0.smethod_4(11))
                {
                  if (num2 == -2 && VitalicSettings.Instance.EventAutoFace && (long) source == (long) Class141.UInt64_0)
                  {
                    Class141.woWUnit_0 = eventArgs0_0.lazy_2.Value;
                    Class141.dateTime_0 = DateTime.UtcNow;
                    return;
                  }
                }
                else
                {
                  Class113.dateTime_0 = DateTime.UtcNow;
                  return;
                }
              }
              else if (Class141.smethod_2(num2, woWunit))
              {
                Class141.delegate40_1((object) "[Event Framework] Response time:", (object) (Class141.stopwatch_0.Elapsed.TotalMilliseconds.ToString() + " ms"));
                SpellManager.CastSpellById(num2, woWunit);
                WoWSpell woWSpell_0 = WoWSpell.FromId(num2);
                Class141.smethod_0(woWSpell_0, eventArgs0_0.lazy_8.Value, woWunit);
                Logging.Write((LogLevel) 2, Colors.LightSkyBlue, $"[Event Framework] Casted {woWSpell_0.Name} in response to: {eventArgs0_0.lazy_8.Value.Name}");
                Class140.smethod_8(Enum16.const_2);
                return;
              }
            }
          }
        }
      }
    }
    catch (Exception ex)
    {
      Class141.delegate40_1((object) $"[Event Framework] Exception occurred: {ex.Message}, {(object) eventArgs0_0.lazy_0.Value} {(object) source} {(object) num1} {(object) Class141.UInt64_0} {(object) Class141.UInt64_1} {(object) eventArgs0_0.lazy_7.Value}");
    }
label_32:
    if (eventArgs0_0.lazy_0.Value == Class37.Types.SPELL_CAST_SUCCESS)
    {
      if (key == 108921 && ((long) source == (long) Class141.UInt64_0 || (long) source == (long) Class141.UInt64_1))
      {
        Class141.bool_6 = true;
        Class141.dateTime_1 = DateTime.UtcNow;
        Class140.smethod_5("Casted Psyfiend", Class140.struct24_6, 108921);
      }
      if ((key == 112833 || key == 55342 || key == 58984) && ((long) source == (long) Class141.UInt64_0 || (long) source == (long) Class141.UInt64_2))
      {
        Class141.ulong_0 = eventArgs0_0.lazy_1.Value;
        Class141.dateTime_1 = DateTime.UtcNow;
        Class140.smethod_7("Searching for " + eventArgs0_0.String_0, Class140.struct24_6);
      }
      if ((eventArgs0_0.lazy_3.Value & Enum13.flag_10) != (Enum13) 0)
      {
        if (key == 1499 || key == 60192)
          Class141.dateTime_2 = DateTime.UtcNow;
        if (key == 13813 || key == 82939)
          Class141.dateTime_3 = DateTime.UtcNow;
        if (Class41.bool_1 && key == 19503 && !((WoWUnit) Class141.LocalPlayer_0).IsDead && eventArgs0_0.lazy_5.Value.smethod_17())
        {
          Class140.smethod_5("Healer Scatter Shot", Class140.struct24_7, 19503);
          Class140.smethod_8(Enum16.const_3);
        }
      }
      if (((long) source == (long) Class141.UInt64_0 || (long) source == (long) Class141.UInt64_1) && Class141.dictionary_4.ContainsKey(key))
      {
        if (Class141.dictionary_0.ContainsKey(Class141.dictionary_4[key]))
          Class141.dictionary_0[Class141.dictionary_4[key]] = DateTime.UtcNow;
        else
          Class141.dictionary_0.Add(Class141.dictionary_4[key], DateTime.UtcNow);
      }
      if (Class41.bool_1 && (key == 59752 || key == 42292) && !Class141.hashSet_0.Contains(2094) && !Class141.LocalPlayer_0.smethod_22() && (eventArgs0_0.lazy_3.Value & Enum13.flag_10) != (Enum13) 0)
      {
        WoWUnit woWUnit_0 = eventArgs0_0.lazy_2.Value;
        if (WoWObject.op_Inequality((WoWObject) woWUnit_0, (WoWObject) Class141.WoWUnit_0) && woWUnit_0.smethod_17() && !woWUnit_0.smethod_5(Class68.Enum14.const_1) && Class134.Class134_0.lazy_18.Value < 70.0 && Class77.smethod_7(2094, woWUnit_0, true))
        {
          SpellManager.Cast(2094, woWUnit_0);
          Class62.smethod_4(2094, woWUnit_0);
          Class140.smethod_5("Blind Healer Trinket", Class140.struct24_2, 2094);
          Class140.smethod_8(Enum16.const_2);
        }
      }
    }
    if (!Class41.bool_1 || eventArgs0_0.lazy_0.Value != Class37.Types.SPELL_AURA_APPLIED || key != 115834 && key != 114018 || (eventArgs0_0.lazy_6.Value & Enum13.flag_10) == (Enum13) 0 || Class110.bool_0)
      return;
    Class110.dateTime_0 = DateTime.UtcNow;
    Class140.smethod_9("Enemy Rogue casted Shroud of Concealment!");
  }

  private delegate bool Delegate39(ulong source, WoWUnit target);

  private delegate void Delegate40(params object[] args);
}
