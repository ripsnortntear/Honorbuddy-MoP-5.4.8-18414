﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class49
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class49
{
  private static bool bool_0;
  private static Class49.Delegate22 delegate22_0 = new Class49.Delegate22(Class62.smethod_0);
  public static WoWSpell woWSpell_0;
  public static WoWSpell woWSpell_1;
  public static WoWSpell woWSpell_2;
  public static ulong ulong_0 = 0;

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  protected static ulong UInt64_0 => Class50.ulong_0;

  public static void Initialise() => Class49.Attach();

  public static void Attach()
  {
    if (Class49.bool_0)
      return;
    Class37.smethod_8(Class37.Types.SPELL_CAST_SUCCESS, new Class37.Delegate11(Class49.smethod_1));
    Class37.smethod_8(Class37.Types.SPELL_AURA_APPLIED, new Class37.Delegate11(Class49.smethod_1));
    Class37.smethod_8(Class37.Types.SPELL_AURA_REFRESH, new Class37.Delegate11(Class49.smethod_1));
    Class37.smethod_8(Class37.Types.SPELL_MISSED, new Class37.Delegate11(Class49.smethod_1));
    Class49.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class49.bool_0)
      return;
    Class37.smethod_9(Class37.Types.SPELL_CAST_SUCCESS, new Class37.Delegate11(Class49.smethod_1));
    Class37.smethod_9(Class37.Types.SPELL_AURA_APPLIED, new Class37.Delegate11(Class49.smethod_1));
    Class37.smethod_9(Class37.Types.SPELL_AURA_REFRESH, new Class37.Delegate11(Class49.smethod_1));
    Class37.smethod_9(Class37.Types.SPELL_MISSED, new Class37.Delegate11(Class49.smethod_1));
    Class49.bool_0 = false;
  }

  public static void Shutdown() => Class49.smethod_0();

  private static void smethod_1(EventArgs0 eventArgs0_0)
  {
    if (eventArgs0_0.lazy_0.Value == Class37.Types.SPELL_CAST_SUCCESS && (long) eventArgs0_0.lazy_1.Value == (long) ((WoWObject) Class49.LocalPlayer_0).Guid && eventArgs0_0.lazy_7.Value != 121473 && eventArgs0_0.lazy_7.Value != 121474)
    {
      if ((long) eventArgs0_0.lazy_4.Value == (long) Class49.UInt64_0 && eventArgs0_0.lazy_7.Value != 36554)
        Class49.woWSpell_0 = eventArgs0_0.lazy_8.Value;
      else
        Class49.woWSpell_1 = eventArgs0_0.lazy_8.Value;
      if (eventArgs0_0.lazy_7.Value == 137619)
        Class49.ulong_0 = eventArgs0_0.lazy_4.Value;
      if (WoWSpell.op_Inequality(Class49.woWSpell_0, (WoWSpell) null) && Class49.woWSpell_0.Id == 1856 && (eventArgs0_0.lazy_7.Value == 59752 || eventArgs0_0.lazy_7.Value == 42292))
        Class49.woWSpell_0 = (WoWSpell) null;
    }
    if ((long) eventArgs0_0.lazy_1.Value == (long) ((WoWObject) Class49.LocalPlayer_0).Guid && (long) eventArgs0_0.lazy_4.Value == (long) ((WoWObject) Class49.LocalPlayer_0).Guid)
      Class49.woWSpell_2 = eventArgs0_0.lazy_8.Value;
    if (eventArgs0_0.lazy_0.Value == Class37.Types.SPELL_MISSED && (long) eventArgs0_0.lazy_1.Value == (long) ((WoWObject) Class49.LocalPlayer_0).Guid)
    {
      if (WoWSpell.op_Inequality(Class49.woWSpell_0, (WoWSpell) null) && eventArgs0_0.lazy_7.Value == Class49.woWSpell_0.Id)
        Class49.woWSpell_0 = (WoWSpell) null;
      if (WoWSpell.op_Inequality(Class49.woWSpell_1, (WoWSpell) null) && eventArgs0_0.lazy_7.Value == Class49.woWSpell_1.Id)
        Class49.woWSpell_0 = (WoWSpell) null;
    }
    if (Class41.bool_1 && eventArgs0_0.lazy_0.Value == Class37.Types.SPELL_AURA_APPLIED && eventArgs0_0.lazy_7.Value == 3355 && (eventArgs0_0.lazy_3.Value & Enum13.flag_10) != (Enum13) 0)
    {
      Class62.smethod_1((object) "Reset Freezing Trap");
      Class141.dateTime_2 = DateTime.MinValue;
    }
    if ((long) eventArgs0_0.lazy_1.Value != (long) ((WoWObject) Class49.LocalPlayer_0).Guid)
      return;
    if (Class51.smethod_4("gcd_remaining"))
      Class51.smethod_3("gcd_remaining");
    string string_0_1 = "cooldown_" + (object) eventArgs0_0.lazy_7.Value;
    if (eventArgs0_0.lazy_7.Value == 59628)
      string_0_1 = "cooldown_" + (object) 57934;
    if (Class51.smethod_4(string_0_1))
      Class51.smethod_3(string_0_1);
    if (eventArgs0_0.lazy_7.Value == 14185)
    {
      foreach (int num in Class77.hashSet_0)
      {
        string string_0_2 = "cooldown_" + (object) num;
        if (Class51.smethod_4(string_0_2))
          Class51.smethod_3(string_0_2);
      }
    }
    if (eventArgs0_0.lazy_7.Value != 5171)
      return;
    if (Class144.class81_0.method_2())
      Class144.class81_0.method_3(2.0);
    if (!Class144.class81_1.method_2())
      return;
    Class144.class81_1.method_3(2.0);
  }

  private delegate void Delegate22(params object[] args);
}
