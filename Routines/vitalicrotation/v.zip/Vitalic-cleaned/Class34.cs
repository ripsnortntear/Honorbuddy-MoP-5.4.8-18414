﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class34
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class34
{
  private static bool bool_0;
  private static Class34.Delegate7 delegate7_0 = new Class34.Delegate7(Class62.smethod_0);

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  protected static ulong UInt64_0 => Class50.ulong_0;

  public static void Initialise() => Class34.Attach();

  public static void Attach()
  {
    if (Class34.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.ARENA_OPPONENT_UPDATE, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    Class34.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class34.bool_0)
      return;
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.ARENA_OPPONENT_UPDATE, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    Class34.bool_0 = false;
  }

  public static void Shutdown() => Class34.smethod_0();

  private static void smethod_1(object sender, LuaEventArgs e)
  {
    if (!Class41.bool_1)
      return;
    Class62.smethod_1((object) "ARENA_OPPONENT_UPDATE clear cache");
    if (!Class51.smethod_4("attackable_units"))
      return;
    Class51.smethod_3("attackable_units");
  }

  private delegate void Delegate7(params object[] args);
}
