﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class147
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

#nullable disable
namespace ns1;

[CompilerGenerated]
internal class Class147
{
  internal static Class147.Struct26 struct26_0;
  internal static Dictionary<string, int> dictionary_0;

  [StructLayout(LayoutKind.Explicit, Size = 12, Pack = 1)]
  private struct Struct26
  {
  }
}
