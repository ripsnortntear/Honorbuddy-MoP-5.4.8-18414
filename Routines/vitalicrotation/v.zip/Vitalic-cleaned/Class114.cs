﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class114
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class114 : Class91
{
  private static bool Boolean_21
  {
    get
    {
      return !Class91.Boolean_1 || Class61.list_0.Contains((WoWClass) 3) || Class61.list_0.Contains((WoWClass) 4) || Class91.IEnumerable_2.Count<WoWUnit>() > 0;
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class114.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class114.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class114.canRunDecoratorDelegate_0;
    // ISSUE: reference to a compiler-generated field
    if (Class114.actionSucceedDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class114.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    Action action = new Action(Class114.actionSucceedDelegate_0);
    return (Composite) new Decorator(decoratorDelegate0, (Composite) action);
  }
}
