﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class112
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class112 : Class91
{
  private static WoWItem woWItem_0;

  private static bool Boolean_21
  {
    get
    {
      Class112.woWItem_0 = Class91.LocalPlayer_0.BagItems.FirstOrDefault<WoWItem>((Func<WoWItem, bool>) (woWItem_1 => ((WoWObject) woWItem_1).Entry == 5512U));
      return WoWObject.op_Inequality((WoWObject) Class112.woWItem_0, (WoWObject) null) && !Class59.smethod_1(Class112.woWItem_0);
    }
  }

  private static bool Boolean_22
  {
    get
    {
      if (Class91.LocalPlayer_0.RawComboPoints <= Class91.LocalPlayer_0.ComboPoints || Class91.Double_3 >= 90.0)
        return false;
      if (Class59.smethod_0(73981) || Class91.LocalPlayer_0.RawComboPoints < 5)
        return true;
      return !Class91.Boolean_12 && Class91.Double_0 > 2.0;
    }
  }

  private static bool Boolean_23
  {
    get => Class71.CurrentSpec == 259 && Class91.Boolean_10 && !Class91.WoWUnit_0.smethod_14();
  }

  private static bool Boolean_24
  {
    get
    {
      return (Class91.LocalPlayer_0.RawComboPoints > 2 || Class65.Boolean_0) && Class91.Boolean_16 && (Class91.Boolean_10 || Class91.Double_3 > 30.0) && ((WoWObject) Class91.WoWUnit_0).Distance < 15.0;
    }
  }

  private static bool Boolean_25
  {
    get
    {
      if (Class91.Double_4 >= 30.0)
        return false;
      return Class91.Boolean_10 || Class91.Double_3 > 20.0 || (double) Class91.WoWUnit_0.CurrentHealth < Class91.Double_6;
    }
  }

  private static int Int32_4 => Class91.Double_3 <= 30.0 ? 1 : 2;

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[2];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class112.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class112.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite = Class77.smethod_2(73651, Class112.canRunDecoratorDelegate_0, "Recuperate");
    compositeArray2[0] = composite;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class112.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class112.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class112.canRunDecoratorDelegate_1;
    // ISSUE: reference to a compiler-generated field
    if (Class112.actionSucceedDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class112.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    Action action = new Action(Class112.actionSucceedDelegate_0);
    Decorator decorator = new Decorator(decoratorDelegate1, (Composite) action);
    compositeArray3[1] = (Composite) decorator;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
