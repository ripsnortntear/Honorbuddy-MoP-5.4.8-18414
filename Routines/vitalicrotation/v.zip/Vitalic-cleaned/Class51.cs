﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class51
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;

#nullable disable
namespace ns1;

internal class Class51
{
  private static readonly ObjectCache objectCache_0 = (ObjectCache) MemoryCache.Default;

  public static T smethod_0<T>(string string_0) where T : class
  {
    try
    {
      return (T) Class51.objectCache_0[string_0];
    }
    catch
    {
      return default (T);
    }
  }

  public static void smethod_1<T>(T gparam_0, string string_0, int int_0) where T : class
  {
    if ((object) gparam_0 == null)
      return;
    Class51.objectCache_0.Add(string_0, (object) gparam_0, (DateTimeOffset) DateTime.UtcNow.AddMilliseconds((double) int_0));
  }

  public static void smethod_2(object object_0, string string_0, int int_0)
  {
    if (object_0 == null)
      return;
    Class51.objectCache_0.Add(string_0, object_0, (DateTimeOffset) DateTime.UtcNow.AddMilliseconds((double) int_0));
  }

  public static void smethod_3(string string_0) => Class51.objectCache_0.Remove(string_0);

  public static bool smethod_4(string string_0) => Class51.objectCache_0.Get(string_0) != null;

  public static List<string> smethod_5()
  {
    return Class51.objectCache_0.Select<KeyValuePair<string, object>, string>((Func<KeyValuePair<string, object>, string>) (keyValuePair_0 => keyValuePair_0.Key)).ToList<string>();
  }

  internal class Class52<T> where T : struct
  {
    public T Value { get; set; }
  }
}
