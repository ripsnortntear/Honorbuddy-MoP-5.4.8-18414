﻿using ns1;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: AssemblyInfo("")]
[assembly: AssemblyFileVersion("2.0.3.0")]
[assembly: ComVisible(false)]
[assembly: AssemblyTitle("Vitalic Elite Rogue PvP Routine (Release)")]
[assembly: AssemblyCopyright("Copyright © Vitalic 2014")]
[assembly: AssemblyProduct("Vitalic")]
[assembly: Guid("9ce2aebd-510f-4413-884f-d9fd530d56c5")]
[assembly: AssemblyTrademark("")]
[assembly: Extension]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyVersion("2.0.3.0")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
