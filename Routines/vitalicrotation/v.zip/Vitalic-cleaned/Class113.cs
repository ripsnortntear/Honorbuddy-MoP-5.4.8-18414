﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class113
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx.Pathing;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class113 : Class91
{
  public static DateTime dateTime_0;
  private static WoWPlayer woWPlayer_0;
  private static WoWGameObject woWGameObject_0;
  private static bool bool_0;

  private static bool Boolean_21
  {
    get
    {
      return ((WoWUnit) Class91.LocalPlayer_0).MovementInfo.MovingForward && (double) ((WoWUnit) Class91.LocalPlayer_0).MovementInfo.TimeMoved > 0.5 && !((WoWUnit) Class91.LocalPlayer_0).MovementInfo.IsStrafing && ((WoWObject) Class91.LocalPlayer_0).IsSafelyFacing((WoWObject) Class91.WoWUnit_0);
    }
  }

  private static bool Boolean_22
  {
    get
    {
      Class113.woWPlayer_0 = Class91.LocalPlayer_0.PartyMembers.FirstOrDefault<WoWPlayer>((Func<WoWPlayer, bool>) (woWPlayer_1 => ((WoWUnit) woWPlayer_1).IsPlayer && WoWObject.op_Inequality((WoWObject) woWPlayer_1, (WoWObject) Class91.LocalPlayer_0) && (Class91.LocalPlayer_0.GroupInfo.PartySize == 2U || ((WoWUnit) woWPlayer_1).smethod_17()) && ((WoWUnit) woWPlayer_1).smethod_0(Class68.Enum15.const_8) && !Class53.smethod_3((WoWUnit) woWPlayer_1, 60192)));
      return WoWObject.op_Inequality((WoWObject) Class113.woWPlayer_0, (WoWObject) null);
    }
  }

  private static bool Boolean_23
  {
    get
    {
      if (Class141.dateTime_2 == DateTime.MinValue || !((WoWUnit) Class113.woWPlayer_0).smethod_0(Class68.Enum15.const_8))
        return false;
      Class113.woWGameObject_0 = ObjectManager.GetObjectsOfTypeFast<WoWGameObject>().Where<WoWGameObject>((Func<WoWGameObject, bool>) (woWGameObject_1 => ((WoWObject) woWGameObject_1).Entry == 2561U)).OrderBy<WoWGameObject, double>((Func<WoWGameObject, double>) (woWGameObject_1 => ((WoWObject) woWGameObject_1).Distance)).FirstOrDefault<WoWGameObject>();
      if (!WoWObject.op_Inequality((WoWObject) Class113.woWGameObject_0, (WoWObject) null) || !((WoWUnit) Class91.LocalPlayer_0).smethod_0(Class68.Enum15.const_5))
        return WoWObject.op_Inequality((WoWObject) Class113.woWGameObject_0, (WoWObject) null);
      if ((Class91.Boolean_18 || Class53.smethod_3((WoWUnit) Class91.LocalPlayer_0, 51713)) && ((WoWObject) Class113.woWGameObject_0).WithinInteractRange)
        ((WoWObject) Class113.woWGameObject_0).Interact();
      return false;
    }
  }

  private static bool Boolean_24
  {
    get
    {
      if (Navigator.NavigationProvider.StuckHandler.IsStuck())
      {
        Class141.dateTime_2 = DateTime.MinValue;
        return false;
      }
      Lua.DoString("MouselookStop(); StrafeLeftStop(); StrafeRightStop();", "WoW.lua");
      Navigator.MoveTo(((WoWObject) Class113.woWGameObject_0).Location);
      if (!((WoWObject) Class91.LocalPlayer_0).IsSafelyFacing((WoWObject) Class113.woWGameObject_0))
        Class91.LocalPlayer_0.SetFacing(Class113.woWGameObject_0);
      Class91.delegate34_1((object) "MoveToTrap", (object) DateTime.UtcNow.Millisecond);
      return false;
    }
  }

  private static Composite Composite_0
  {
    get
    {
      if (Class113.actionDelegate_0 == null)
        Class113.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_8));
      return (Composite) new Action(Class113.actionDelegate_0);
    }
  }

  private static bool Boolean_25
  {
    get
    {
      if (!Class113.bool_0)
      {
        Navigator.GeneratePath(((WoWObject) Class91.LocalPlayer_0).Location, ((WoWObject) Class113.woWPlayer_0).Location);
        Class113.bool_0 = true;
      }
      return true;
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[3]
    {
      Class113.Composite_0,
      null,
      null
    };
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class113.canRunDecoratorDelegate_0;
    // ISSUE: reference to a compiler-generated field
    if (Class113.retrieveSwitchParameterDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.retrieveSwitchParameterDelegate_0 = new RetrieveSwitchParameterDelegate<bool>((object) null, __methodptr(smethod_10));
    }
    // ISSUE: reference to a compiler-generated field
    RetrieveSwitchParameterDelegate<bool> parameterDelegate0 = Class113.retrieveSwitchParameterDelegate_0;
    SwitchArgument<bool>[] switchArgumentArray1 = new SwitchArgument<bool>[2];
    SwitchArgument<bool>[] switchArgumentArray2 = switchArgumentArray1;
    Composite[] compositeArray3 = new Composite[3];
    Composite[] compositeArray4 = compositeArray3;
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_11));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class113.canRunDecoratorDelegate_1;
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_12));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite1 = Class77.smethod_2(31224, Class113.canRunDecoratorDelegate_2, "Cloak of Shadows");
    DecoratorContinue decoratorContinue1 = new DecoratorContinue(decoratorDelegate1, composite1);
    compositeArray4[0] = (Composite) decoratorContinue1;
    Composite[] compositeArray5 = compositeArray3;
    Class144.Delegate43 delegate43_4 = (Class144.Delegate43) (object_0 => (WoWUnit) Class113.woWPlayer_0);
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_14));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate3 = Class113.canRunDecoratorDelegate_3;
    Action action_0 = (Action) (() =>
    {
      Class140.smethod_5("Shadowstep Trap: " + ((WoWObject) Class113.woWPlayer_0).Name, Class140.struct24_0, 1499);
      Class140.smethod_8(Enum16.const_2);
    });
    Composite composite2 = Class77.smethod_0(36554, delegate43_4, decoratorDelegate3, "Shadowstep", action_0, true);
    compositeArray5[1] = composite2;
    Composite[] compositeArray6 = compositeArray3;
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_16));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate4 = Class113.canRunDecoratorDelegate_4;
    TimeSpan timeSpan1 = TimeSpan.FromSeconds(3.0);
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_5 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_17));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate5 = Class113.canRunDecoratorDelegate_5;
    ActionAlwaysSucceed actionAlwaysSucceed1 = new ActionAlwaysSucceed();
    Wait wait1 = new Wait(timeSpan1, decoratorDelegate5, (Composite) actionAlwaysSucceed1);
    DecoratorContinue decoratorContinue2 = new DecoratorContinue(decoratorDelegate4, (Composite) wait1);
    compositeArray6[2] = (Composite) decoratorContinue2;
    SwitchArgument<bool> switchArgument1 = new SwitchArgument<bool>(true, (Composite) new Sequence(compositeArray3));
    switchArgumentArray2[0] = switchArgument1;
    SwitchArgument<bool>[] switchArgumentArray3 = switchArgumentArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_6 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_18));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate6 = Class113.canRunDecoratorDelegate_6;
    Composite[] compositeArray7 = new Composite[2];
    Composite[] compositeArray8 = compositeArray7;
    TimeSpan timeSpan2 = TimeSpan.FromSeconds(3.0);
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_7 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_19));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate7 = Class113.canRunDecoratorDelegate_7;
    ActionAlwaysSucceed actionAlwaysSucceed2 = new ActionAlwaysSucceed();
    Wait wait2 = new Wait(timeSpan2, decoratorDelegate7, (Composite) actionAlwaysSucceed2);
    compositeArray8[0] = (Composite) wait2;
    Composite[] compositeArray9 = compositeArray7;
    // ISSUE: reference to a compiler-generated field
    if (Class113.actionSucceedDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_20));
    }
    // ISSUE: reference to a compiler-generated field
    Action action = new Action(Class113.actionSucceedDelegate_0);
    compositeArray9[1] = (Composite) action;
    Sequence sequence = new Sequence(compositeArray7);
    SwitchArgument<bool> switchArgument2 = new SwitchArgument<bool>(false, (Composite) new Decorator(decoratorDelegate6, (Composite) sequence));
    switchArgumentArray3[1] = switchArgument2;
    SwitchArgument<bool>[] switchArgumentArray4 = switchArgumentArray1;
    Switch<bool> @switch = new Switch<bool>(parameterDelegate0, switchArgumentArray4);
    Decorator decorator1 = new Decorator(decoratorDelegate0, (Composite) @switch);
    compositeArray2[1] = (Composite) decorator1;
    Composite[] compositeArray10 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_8 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_8 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_21));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate8 = Class113.canRunDecoratorDelegate_8;
    Composite[] compositeArray11 = new Composite[3];
    Composite[] compositeArray12 = compositeArray11;
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_9 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_9 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_22));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite3 = Class77.smethod_6(36554, Class113.canRunDecoratorDelegate_9, "Shadowstep", (Action) (() =>
    {
      Class140.smethod_7("Shadowstep (Explosive Trap)", Class140.struct24_0);
      Class140.smethod_8(Enum16.const_2);
      Class113.dateTime_0 = DateTime.MinValue;
    }));
    compositeArray12[0] = composite3;
    Composite[] compositeArray13 = compositeArray11;
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_10 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_10 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_24));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite4 = Class77.smethod_6(36554, Class113.canRunDecoratorDelegate_10, "Shadowstep", (Action) (() =>
    {
      Class140.smethod_7("Shadowstep", Class140.struct24_0);
      Class140.smethod_8(Enum16.const_2);
      Class113.dateTime_0 = DateTime.MinValue;
    }));
    compositeArray13[1] = composite4;
    Composite[] compositeArray14 = compositeArray11;
    // ISSUE: reference to a compiler-generated field
    if (Class113.canRunDecoratorDelegate_11 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class113.canRunDecoratorDelegate_11 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_26));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite5 = Class77.smethod_6(36554, Class113.canRunDecoratorDelegate_11, "Shadowstep", (Action) (() =>
    {
      Class140.smethod_7("Shadowstep (Auto) " + ((WoWObject) Class91.WoWUnit_0).Name, Class140.struct24_0);
      Class140.smethod_8(Enum16.const_2);
    }));
    compositeArray14[2] = composite5;
    PrioritySelector prioritySelector = new PrioritySelector(compositeArray11);
    Decorator decorator2 = new Decorator(decoratorDelegate8, (Composite) prioritySelector);
    compositeArray10[2] = (Composite) decorator2;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
