﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class47
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;

#nullable disable
namespace ns1;

[Attribute0]
internal class Class47
{
  private static bool bool_0;
  private static Class47.Delegate20 delegate20_0 = new Class47.Delegate20(Class62.smethod_0);
  public static DateTime dateTime_0;
  public static readonly HashSet<int> hashSet_0 = new HashSet<int>()
  {
    5171,
    73651,
    1966,
    76577,
    139546,
    112947,
    79136,
    127802,
    73981,
    113742,
    36554,
    51699,
    120032,
    104423,
    104509,
    104510
  };

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  protected static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  public static void Initialise() => Class47.Attach();

  public static void Attach()
  {
    if (Class47.bool_0)
      return;
    Class37.smethod_8(Class37.Types.SWING_DAMAGE, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_8(Class37.Types.SWING_MISSED, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_8(Class37.Types.RANGE_DAMAGE, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_8(Class37.Types.RANGE_MISSED, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_8(Class37.Types.SPELL_DAMAGE, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_8(Class37.Types.SPELL_MISSED, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_8(Class37.Types.SPELL_CAST_SUCCESS, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_8(Class37.Types.SPELL_AURA_APPLIED, new Class37.Delegate11(Class47.smethod_3));
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.PLAYER_REGEN_ENABLED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    // ISSUE: method pointer
    Class37.smethod_5(Class37.WoWEvents.PLAYER_REGEN_DISABLED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_2)));
    Class47.bool_0 = true;
  }

  public static void smethod_0()
  {
    if (!Class47.bool_0)
      return;
    Class37.smethod_9(Class37.Types.SWING_DAMAGE, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_9(Class37.Types.SWING_MISSED, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_9(Class37.Types.RANGE_DAMAGE, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_9(Class37.Types.RANGE_MISSED, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_9(Class37.Types.SPELL_DAMAGE, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_9(Class37.Types.SPELL_MISSED, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_9(Class37.Types.SPELL_CAST_SUCCESS, new Class37.Delegate11(Class47.smethod_3));
    Class37.smethod_9(Class37.Types.SPELL_AURA_APPLIED, new Class37.Delegate11(Class47.smethod_3));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.PLAYER_REGEN_ENABLED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_1)));
    // ISSUE: method pointer
    Class37.smethod_6(Class37.WoWEvents.PLAYER_REGEN_DISABLED, new LuaEventHandlerDelegate((object) null, __methodptr(smethod_2)));
    Class47.bool_0 = false;
  }

  public static void Shutdown() => Class47.smethod_0();

  private static void smethod_1(object sender, LuaEventArgs e)
  {
    Class47.dateTime_0 = DateTime.MinValue;
    Class62.smethod_1((object) "[Event] Left Combat");
  }

  private static void smethod_2(object sender, LuaEventArgs e)
  {
    Class47.dateTime_0 = DateTime.UtcNow;
    Class62.smethod_1((object) "[Event] Entered Combat");
  }

  private static void smethod_3(EventArgs0 eventArgs0_0)
  {
    bool flag1 = (eventArgs0_0.lazy_6.Value & Enum13.flag_13) != (Enum13) 0;
    bool flag2 = (eventArgs0_0.lazy_6.Value & Enum13.flag_10) != (Enum13) 0;
    bool flag3 = (eventArgs0_0.lazy_3.Value & Enum13.flag_13) != (Enum13) 0;
    bool flag4 = (eventArgs0_0.lazy_3.Value & Enum13.flag_9) != (Enum13) 0;
    if (flag3 && eventArgs0_0.lazy_7.Value == 5938 && Class51.smethod_4("cooldown_5938"))
      Class51.smethod_3("cooldown_5938");
    if (!flag1 && !flag3 || eventArgs0_0.lazy_0.Value == Class37.Types.SPELL_CAST_SUCCESS && (!flag2 && !flag2 || flag1 && flag4) || flag1 && flag3 || eventArgs0_0.lazy_0.Value == Class37.Types.SPELL_AURA_APPLIED && flag1 && flag4 || Class47.hashSet_0.Contains(eventArgs0_0.lazy_7.Value))
      return;
    if ((Class137.smethod_5(Class137.Macro.Restealth) || Class46.bool_2) && flag3 && flag2 && eventArgs0_0.lazy_0.Value == Class37.Types.SWING_DAMAGE)
    {
      Class137.smethod_8(Class137.Macro.Restealth);
      Class46.bool_2 = false;
      Class140.smethod_9("Restealth: |cffb73737Disabled");
    }
    Class47.dateTime_0 = DateTime.UtcNow;
  }

  private delegate void Delegate20(params object[] args);
}
