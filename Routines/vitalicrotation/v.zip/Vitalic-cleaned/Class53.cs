﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class53
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

internal static class Class53
{
  public static readonly List<int> list_0 = new List<int>()
  {
    35774,
    35775,
    32724,
    32725,
    134735,
    74410
  };
  private static Func<WoWAura, bool> func_0 = (Func<WoWAura, bool>) (woWAura_0 =>
  {
    if ((byte) (woWAura_0.Flags & 4) == (byte) 0 && (byte) (woWAura_0.Flags & 8) == (byte) 0 && (byte) (woWAura_0.Flags & 2) == (byte) 0)
      return false;
    return !Class41.bool_1 || !Class53.list_0.Contains(woWAura_0.SpellId);
  });
  private static IEnumerable<WoWAura> ienumerable_0;
  private static IEnumerable<WoWAura> ienumerable_1;
  private static IEnumerable<WoWAura> ienumerable_2;
  private static IEnumerable<WoWAura> ienumerable_3;
  private static IEnumerable<WoWAura> ienumerable_4;
  private static IEnumerable<WoWAura> ienumerable_5;
  private static IEnumerable<WoWAura> ienumerable_6;
  private static IEnumerable<WoWAura> ienumerable_7;
  private static IEnumerable<WoWAura> ienumerable_8;
  private static Class53.Delegate24 delegate24_0 = new Class53.Delegate24(Class62.smethod_0);

  private static LocalPlayer LocalPlayer_0 => StyxWoW.Me;

  private static WoWUnit WoWUnit_0 => Class50.woWUnit_0;

  private static WoWUnit WoWUnit_1 => Class50.woWUnit_1;

  private static ulong UInt64_0 => Class50.ulong_0;

  private static ulong UInt64_1 => Class50.ulong_1;

  public static IEnumerable<WoWAura> smethod_0(this WoWUnit woWUnit_0)
  {
    ulong guid = ((WoWObject) woWUnit_0).Guid;
    if ((long) guid == (long) ((WoWObject) Class53.LocalPlayer_0).Guid && Class53.ienumerable_2 != null)
      return Class53.ienumerable_2;
    if ((long) guid == (long) Class53.UInt64_0 && Class53.ienumerable_0 != null)
      return Class53.ienumerable_0;
    return (long) guid == (long) Class53.UInt64_1 && Class53.ienumerable_1 != null ? Class53.ienumerable_1 : (IEnumerable<WoWAura>) woWUnit_0.GetAllAuras();
  }

  public static IEnumerable<WoWAura> smethod_1(this WoWUnit woWUnit_0)
  {
    ulong guid = ((WoWObject) woWUnit_0).Guid;
    if ((long) guid == (long) ((WoWObject) Class53.LocalPlayer_0).Guid && Class53.ienumerable_5 != null)
      return Class53.ienumerable_5;
    if ((long) guid == (long) Class53.UInt64_0 && Class53.ienumerable_3 != null)
      return Class53.ienumerable_3;
    return (long) guid == (long) Class53.UInt64_1 && Class53.ienumerable_4 != null ? Class53.ienumerable_4 : woWUnit_0.smethod_0().Where<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => woWAura_0.IsActive && !woWAura_0.IsHarmful));
  }

  public static IEnumerable<WoWAura> smethod_2(this WoWUnit woWUnit_0)
  {
    ulong guid = ((WoWObject) woWUnit_0).Guid;
    if ((long) guid == (long) ((WoWObject) Class53.LocalPlayer_0).Guid && Class53.ienumerable_8 != null)
      return Class53.ienumerable_8;
    if ((long) guid == (long) Class53.UInt64_0 && Class53.ienumerable_6 != null)
      return Class53.ienumerable_6;
    return (long) guid == (long) Class53.UInt64_1 && Class53.ienumerable_7 != null ? Class53.ienumerable_7 : woWUnit_0.smethod_0().Where<WoWAura>((Func<WoWAura, bool>) (woWAura_0 => woWAura_0.IsActive && woWAura_0.IsHarmful));
  }

  public static bool smethod_3(this WoWUnit woWUnit_0, int int_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: reference to a compiler-generated method
    return woWUnit_0.smethod_0().Any<WoWAura>(new Func<WoWAura, bool>(new Class53.Class54()
    {
      int_0 = int_0
    }.method_0));
  }

  public static bool smethod_4(this WoWUnit woWUnit_0, params WoWSpellMechanic[] woWSpellMechanic_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: reference to a compiler-generated method
    return woWUnit_0.smethod_0().Any<WoWAura>(new Func<WoWAura, bool>(new Class53.Class55()
    {
      woWSpellMechanic_0 = woWSpellMechanic_0
    }.method_0));
  }

  public static bool smethod_5(this WoWUnit woWUnit_0, int int_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: reference to a compiler-generated method
    return woWUnit_0.smethod_0().Any<WoWAura>(new Func<WoWAura, bool>(new Class53.Class56()
    {
      int_0 = int_0
    }.method_0));
  }

  public static bool smethod_6(this WoWUnit woWUnit_0, params int[] int_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: reference to a compiler-generated method
    return woWUnit_0.smethod_0().Any<WoWAura>(new Func<WoWAura, bool>(new Class53.Class57()
    {
      hashSet_0 = new HashSet<int>((IEnumerable<int>) int_0)
    }.method_0));
  }

  public static bool smethod_7(this WoWUnit woWUnit_0, params int[] int_0)
  {
    // ISSUE: object of a compiler-generated type is created
    // ISSUE: reference to a compiler-generated method
    return woWUnit_0.smethod_0().Any<WoWAura>(new Func<WoWAura, bool>(new Class53.Class58()
    {
      hashSet_0 = new HashSet<int>((IEnumerable<int>) int_0)
    }.method_0));
  }

  public static Composite smethod_8()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class53.actionDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class53.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_11));
    }
    // ISSUE: reference to a compiler-generated field
    return (Composite) new Action(Class53.actionDelegate_0);
  }

  private delegate void Delegate24(params object[] args);
}
