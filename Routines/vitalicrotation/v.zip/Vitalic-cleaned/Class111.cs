﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class111
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class111 : Class91
{
  private static WoWUnit woWUnit_0;
  private static WoWAura woWAura_0;
  private static WoWUnit woWUnit_1;
  private static HashSet<int> hashSet_0 = new HashSet<int>()
  {
    51713,
    121471,
    1719,
    106952,
    126679,
    126690,
    126683,
    49016,
    106731,
    3045,
    113860,
    113861,
    113858,
    114049,
    31884,
    12472,
    107574,
    51271,
    34692,
    48505,
    115834,
    51753,
    5215,
    1784,
    32612
  };
  private static HashSet<int> hashSet_1 = new HashSet<int>()
  {
    10060,
    108294
  };

  private static bool Boolean_21
  {
    get => Class91.Boolean_4 && Class53.smethod_3(Class91.WoWUnit_0, 1833) && Class65.Boolean_0;
  }

  private static bool Boolean_22
  {
    get
    {
      if (!Class111.woWUnit_0.smethod_4())
        return true;
      return Class111.woWUnit_0.smethod_7(32612, 51753);
    }
  }

  private static bool Boolean_23
  {
    get
    {
      foreach (WoWUnit partyMember in Class91.LocalPlayer_0.PartyMembers)
      {
        Class111.Class132 class132 = new Class111.Class132();
        if (!((WoWObject) partyMember).IsMe && !partyMember.IsDead && !partyMember.smethod_8() && !partyMember.Mounted)
        {
          class132.ienumerable_0 = partyMember.smethod_17() ? (IEnumerable<int>) Class111.hashSet_1 : (IEnumerable<int>) Class111.hashSet_0;
          Class111.woWAura_0 = ((IEnumerable<WoWAura>) partyMember.GetAllAuras()).FirstOrDefault<WoWAura>(new Func<WoWAura, bool>(class132.method_0));
          if (WoWAura.op_Inequality(Class111.woWAura_0, (WoWAura) null))
          {
            Class111.woWUnit_0 = partyMember;
            return true;
          }
        }
      }
      return false;
    }
  }

  private static bool Boolean_24
  {
    get
    {
      Class111.woWUnit_0 = (WoWUnit) Class91.LocalPlayer_0.PartyMembers.FirstOrDefault<WoWPlayer>((Func<WoWPlayer, bool>) (woWPlayer_0 => !((WoWObject) woWPlayer_0).IsMe && !((WoWUnit) woWPlayer_0).IsDead && !((WoWUnit) woWPlayer_0).Mounted && !((WoWUnit) woWPlayer_0).smethod_17() && !((WoWUnit) woWPlayer_0).smethod_8() && ((WoWUnit) woWPlayer_0).HealthPercent > 40.0));
      return WoWObject.op_Inequality((WoWObject) Class111.woWUnit_0, (WoWObject) null);
    }
  }

  private static bool Boolean_25
  {
    get
    {
      Class111.woWUnit_1 = (WoWUnit) (Class91.LocalPlayer_0.GroupInfo.IsInRaid ? (IEnumerable<WoWPlayer>) Class91.LocalPlayer_0.RaidMembers : (IEnumerable<WoWPlayer>) Class91.LocalPlayer_0.PartyMembers).FirstOrDefault<WoWPlayer>((Func<WoWPlayer, bool>) (woWPlayer_0 => ((WoWObject) woWPlayer_0).Name == VitalicSettings.Instance.TricksTarget && !((WoWUnit) woWPlayer_0).IsDead && !((WoWUnit) woWPlayer_0).Mounted && ((WoWUnit) woWPlayer_0).HealthPercent > 40.0));
      return WoWObject.op_Inequality((WoWObject) Class111.woWUnit_1, (WoWObject) null);
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[3];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class111.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class111.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class111.canRunDecoratorDelegate_0;
    Class144.Delegate43 delegate43_4_1 = (Class144.Delegate43) (object_0 => Class111.woWUnit_0);
    // ISSUE: reference to a compiler-generated field
    if (Class111.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class111.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class111.canRunDecoratorDelegate_1;
    Action action_0_1 = (Action) (() => Class140.smethod_7($"Tricks of the Trade: {((WoWObject) Class111.woWUnit_0).Name} ({Class111.woWAura_0.Name})", Class140.struct24_2));
    Composite composite1 = Class77.smethod_0(57934, delegate43_4_1, decoratorDelegate1, "Tricks", action_0_1, true);
    Decorator decorator1 = new Decorator(decoratorDelegate0, composite1);
    compositeArray2[0] = (Composite) decorator1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class111.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class111.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_11));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate2 = Class111.canRunDecoratorDelegate_2;
    Class144.Delegate43 delegate43_4_2 = (Class144.Delegate43) (object_0 => Class111.woWUnit_0);
    // ISSUE: reference to a compiler-generated field
    if (Class111.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class111.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_13));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate3 = Class111.canRunDecoratorDelegate_3;
    Action action_0_2 = (Action) (() => Class140.smethod_7("Tricks of the Trade: " + ((WoWObject) Class111.woWUnit_0).Name, Class140.struct24_2));
    Composite composite2 = Class77.smethod_0(57934, delegate43_4_2, decoratorDelegate3, "Tricks", action_0_2, true);
    Decorator decorator2 = new Decorator(decoratorDelegate2, composite2);
    compositeArray3[1] = (Composite) decorator2;
    Composite[] compositeArray4 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class111.canRunDecoratorDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class111.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_15));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate4 = Class111.canRunDecoratorDelegate_4;
    Class144.Delegate43 delegate43_4_3 = (Class144.Delegate43) (object_0 => Class111.woWUnit_1);
    // ISSUE: reference to a compiler-generated field
    if (Class111.canRunDecoratorDelegate_5 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class111.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_17));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate5 = Class111.canRunDecoratorDelegate_5;
    Action action_0_3 = (Action) (() => Class140.smethod_7("Tricks of the Trade: " + ((WoWObject) Class111.woWUnit_1).Name, Class140.struct24_2));
    Composite composite3 = Class77.smethod_0(57934, delegate43_4_3, decoratorDelegate5, "Tricks", action_0_3, true);
    Decorator decorator3 = new Decorator(decoratorDelegate4, composite3);
    compositeArray4[2] = (Composite) decorator3;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
