﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class92
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class92 : Class91
{
  private static DateTime dateTime_0;
  private static WoWUnit woWUnit_0;

  private static double Double_9 => (DateTime.UtcNow - Class92.dateTime_0).TotalSeconds;

  private static string String_0
  {
    get
    {
      return !WoWObject.op_Equality((WoWObject) Class91.WoWPlayer_0, (WoWObject) Class91.LocalPlayer_0) ? ((WoWObject) Class91.WoWPlayer_0).Name : "Me";
    }
  }

  private static bool Boolean_21
  {
    get
    {
      Class92.woWUnit_0 = Class91.IEnumerable_1.FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_1 => WoWObject.op_Equality((WoWObject) woWUnit_1.CurrentTarget, (WoWObject) Class91.WoWPlayer_0) && (Class63.smethod_6(woWUnit_1) || Class91.LocalPlayer_0.smethod_4(10) && Class91.Boolean_18 && Class70.smethod_2(woWUnit_1) < 40.0) && !woWUnit_1.smethod_5(Class68.Enum14.const_0, Class91.LocalPlayer_0.smethod_4(5) ? 0.5 : 1.0) && !woWUnit_1.smethod_0(Class68.Enum15.const_11) && !woWUnit_1.smethod_17() && !woWUnit_1.smethod_8(true) && !Class53.smethod_3(woWUnit_1, 112947)));
      return WoWObject.op_Inequality((WoWObject) Class92.woWUnit_0, (WoWObject) null);
    }
  }

  private static bool Boolean_22
  {
    get
    {
      Class92.woWUnit_0 = Class91.IEnumerable_1.FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_1 => WoWObject.op_Equality((WoWObject) woWUnit_1.CurrentTarget, (WoWObject) Class91.WoWPlayer_0) && !woWUnit_1.smethod_17() && woWUnit_1.smethod_15() && (Class63.smethod_6(woWUnit_1) || Class91.LocalPlayer_0.smethod_4(10) && Class91.Boolean_18 && Class70.smethod_2(woWUnit_1) < 40.0) && !woWUnit_1.smethod_5(Class68.Enum14.const_2) && !woWUnit_1.smethod_0(Class68.Enum15.const_11) && !woWUnit_1.smethod_8(true) && !Class53.smethod_3(woWUnit_1, 112947)));
      return WoWObject.op_Inequality((WoWObject) Class92.woWUnit_0, (WoWObject) null);
    }
  }

  private static bool Boolean_23
  {
    get
    {
      Class92.woWUnit_0 = Class91.IEnumerable_2.FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_1 => WoWObject.op_Equality((WoWObject) woWUnit_1.CurrentTarget, (WoWObject) Class91.WoWPlayer_0) && Class63.smethod_6(woWUnit_1) && !woWUnit_1.smethod_5(Class68.Enum14.const_5) && !woWUnit_1.smethod_0(Class68.Enum15.const_11) && !woWUnit_1.smethod_8(true) && !Class53.smethod_3(woWUnit_1, 112947)));
      return WoWObject.op_Inequality((WoWObject) Class92.woWUnit_0, (WoWObject) null);
    }
  }

  private static bool Boolean_24
  {
    get
    {
      Class92.woWUnit_0 = Class91.IEnumerable_2.FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_1 => WoWObject.op_Equality((WoWObject) woWUnit_1.CurrentTarget, (WoWObject) Class91.WoWPlayer_0) && Class63.smethod_6(woWUnit_1) && !woWUnit_1.smethod_5(Class68.Enum14.const_4) && !woWUnit_1.smethod_0(Class68.Enum15.const_11) && (double) woWUnit_1.MovementInfo.CurrentSpeed > 0.0 && !woWUnit_1.smethod_13() && !woWUnit_1.smethod_8(true) && !Class53.smethod_3(woWUnit_1, 112947)));
      return WoWObject.op_Inequality((WoWObject) Class92.woWUnit_0, (WoWObject) null);
    }
  }

  private static Composite Composite_0
  {
    get
    {
      if (Class92.canRunDecoratorDelegate_0 == null)
        Class92.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
      CanRunDecoratorDelegate decoratorDelegate0 = Class92.canRunDecoratorDelegate_0;
      Composite[] compositeArray1 = new Composite[2]
      {
        Class84.Composite_3,
        null
      };
      Composite[] compositeArray2 = compositeArray1;
      Class144.Delegate43 delegate43_4 = (Class144.Delegate43) (object_0 => Class92.woWUnit_0);
      if (Class92.canRunDecoratorDelegate_1 == null)
        Class92.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_11));
      CanRunDecoratorDelegate decoratorDelegate1 = Class92.canRunDecoratorDelegate_1;
      Action action_0 = (Action) (() =>
      {
        Class140.smethod_7($"Cheap Shot: {((WoWObject) Class92.woWUnit_0).Name} low health: {Class92.String_0}", Class140.struct24_0);
        Class92.dateTime_0 = DateTime.UtcNow;
      });
      Composite composite = Class77.smethod_0(1833, delegate43_4, decoratorDelegate1, "Cheap Shot (Peel)", action_0);
      compositeArray2[1] = composite;
      PrioritySelector prioritySelector = new PrioritySelector(compositeArray1);
      return (Composite) new Decorator(decoratorDelegate0, (Composite) prioritySelector);
    }
  }

  private static Composite Composite_1
  {
    get
    {
      if (Class92.canRunDecoratorDelegate_2 == null)
        Class92.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_13));
      CanRunDecoratorDelegate decoratorDelegate2 = Class92.canRunDecoratorDelegate_2;
      Composite[] compositeArray1 = new Composite[2]
      {
        Class84.Composite_3,
        null
      };
      Composite[] compositeArray2 = compositeArray1;
      Class144.Delegate43 delegate43_4 = (Class144.Delegate43) (object_0 => Class92.woWUnit_0);
      if (Class92.canRunDecoratorDelegate_3 == null)
        Class92.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_15));
      CanRunDecoratorDelegate decoratorDelegate3 = Class92.canRunDecoratorDelegate_3;
      Action action_0 = (Action) (() =>
      {
        Class140.smethod_7($"Garrote: {((WoWObject) Class92.woWUnit_0).Name} low health: {Class92.String_0}", Class140.struct24_0);
        Class92.dateTime_0 = DateTime.UtcNow;
      });
      Composite composite = Class77.smethod_0(703, delegate43_4, decoratorDelegate3, "Garrote (Peel)", action_0);
      compositeArray2[1] = composite;
      PrioritySelector prioritySelector = new PrioritySelector(compositeArray1);
      return (Composite) new Decorator(decoratorDelegate2, (Composite) prioritySelector);
    }
  }

  private static Composite Composite_2
  {
    get
    {
      if (Class92.canRunDecoratorDelegate_4 == null)
        Class92.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_17));
      CanRunDecoratorDelegate decoratorDelegate4 = Class92.canRunDecoratorDelegate_4;
      Class144.Delegate43 delegate43_4 = (Class144.Delegate43) (object_0 => Class92.woWUnit_0);
      if (Class92.canRunDecoratorDelegate_5 == null)
        Class92.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_19));
      CanRunDecoratorDelegate decoratorDelegate5 = Class92.canRunDecoratorDelegate_5;
      Action action_0 = (Action) (() =>
      {
        Class140.smethod_7($"Dismantle: {((WoWObject) Class92.woWUnit_0).Name} low health: {Class92.String_0}", Class140.struct24_0);
        Class92.dateTime_0 = DateTime.UtcNow;
      });
      Composite composite = Class77.smethod_0(51722, delegate43_4, decoratorDelegate5, "Dismantle (Peel)", action_0);
      return (Composite) new Decorator(decoratorDelegate4, composite);
    }
  }

  private static Composite Composite_3
  {
    get
    {
      if (Class92.canRunDecoratorDelegate_6 == null)
        Class92.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_21));
      CanRunDecoratorDelegate decoratorDelegate6 = Class92.canRunDecoratorDelegate_6;
      Class144.Delegate43 delegate43_4 = (Class144.Delegate43) (object_0 => Class92.woWUnit_0);
      if (Class92.canRunDecoratorDelegate_7 == null)
        Class92.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_23));
      CanRunDecoratorDelegate decoratorDelegate7 = Class92.canRunDecoratorDelegate_7;
      Action action_0 = (Action) (() =>
      {
        Class140.smethod_7($"Shiv: {((WoWObject) Class92.woWUnit_0).Name} low health: {Class92.String_0}", Class140.struct24_0);
        Class92.dateTime_0 = DateTime.UtcNow;
      });
      Composite composite = Class77.smethod_0(5938, delegate43_4, decoratorDelegate7, "Shiv (Peel)", action_0);
      return (Composite) new Decorator(decoratorDelegate6, composite);
    }
  }

  public static Composite smethod_4()
  {
    // ISSUE: reference to a compiler-generated field
    if (Class92.canRunDecoratorDelegate_8 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class92.canRunDecoratorDelegate_8 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_25));
    }
    // ISSUE: reference to a compiler-generated field
    return (Composite) new Decorator(Class92.canRunDecoratorDelegate_8, (Composite) new PrioritySelector(new Composite[4]
    {
      Class92.Composite_0,
      Class92.Composite_1,
      Class92.Composite_2,
      Class92.Composite_3
    }));
  }
}
