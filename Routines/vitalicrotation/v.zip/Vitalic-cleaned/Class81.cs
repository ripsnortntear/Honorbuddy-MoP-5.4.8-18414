﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class81
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using System;

#nullable disable
namespace ns1;

internal class Class81 : Class80
{
  public Class81(double double_1 = 0.0)
    : base(true, true)
  {
    if (double_1 <= 0.0)
      return;
    this.double_0 = double_1;
  }

  public void method_3(double double_1)
  {
    this.dateTime_0 = this.dateTime_0.Add(TimeSpan.FromSeconds(double_1));
  }

  public void method_4(double double_1)
  {
    this.dateTime_0 = DateTime.UtcNow + TimeSpan.FromSeconds(double_1);
  }
}
