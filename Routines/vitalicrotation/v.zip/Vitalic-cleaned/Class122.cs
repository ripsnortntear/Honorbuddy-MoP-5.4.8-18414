﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class122
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx.TreeSharp;
using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Linq;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class122 : Class91
{
  public static Class137.MacroTargets macroTargets_0;
  private static WoWSpell woWSpell_0 = WoWSpell.FromId(1776);
  private static WoWUnit woWUnit_0;

  private static bool Boolean_21 => Class91.LocalPlayer_0.smethod_4(15);

  private static double Double_9
  {
    get => VitalicSettings.Instance.GougeDelay + Class144.double_0 / 1000.0;
  }

  private static int Int32_4 => VitalicSettings.Instance.GougeNoKickHP;

  private static WoWUnit WoWUnit_2
  {
    get
    {
      if (!Class144.class82_0.method_6(Enum18.const_3))
        return Class91.WoWUnit_0;
      Class144.class82_0.method_5(0.1, Enum18.const_3);
      return Class91.WoWUnit_1;
    }
  }

  private static WoWUnit WoWUnit_3
  {
    get
    {
      switch (Class122.macroTargets_0)
      {
        case Class137.MacroTargets.None:
          return Class122.WoWUnit_2;
        case Class137.MacroTargets.Target:
          return Class91.WoWUnit_0;
        case Class137.MacroTargets.Focus:
          return Class91.WoWUnit_1;
        default:
          return Class137.woWUnit_0;
      }
    }
  }

  private static bool smethod_4(WoWUnit woWUnit_1)
  {
    if (DateTime.UtcNow - Class118.dateTime_0 < TimeSpan.FromSeconds(0.5))
      return false;
    return Class59.smethod_0(1766) && (Class91.Double_4 < (double) Class122.Int32_4 || Class91.Boolean_8) || woWUnit_1.smethod_12();
  }

  private static bool Boolean_22
  {
    get
    {
      if (!Class91.Boolean_1)
        return false;
      Class122.woWUnit_0 = Class91.IEnumerable_1.OrderBy<WoWUnit, double>((Func<WoWUnit, double>) (woWUnit_1 => woWUnit_1.CurrentCastTimeLeft.TotalSeconds)).FirstOrDefault<WoWUnit>((Func<WoWUnit, bool>) (woWUnit_1 => woWUnit_1.IsCasting && WoWObject.op_Inequality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_0) && WoWObject.op_Inequality((WoWObject) woWUnit_1, (WoWObject) Class91.WoWUnit_1) && !Class118.hashSet_0.Contains(woWUnit_1.CastingSpellId) && Class118.dictionary_0.ContainsKey(woWUnit_1.CastingSpellId) && woWUnit_1.CurrentCastTimeLeft.TotalSeconds >= 0.2 && Class63.smethod_6(woWUnit_1) && !woWUnit_1.smethod_8() && !woWUnit_1.smethod_12() && DateTime.Now - woWUnit_1.CurrentCastStartTime > TimeSpan.FromSeconds(VitalicSettings.Instance.InterruptMinimum)));
      return WoWObject.op_Inequality((WoWObject) Class122.woWUnit_0, (WoWObject) null);
    }
  }

  public static Composite smethod_5()
  {
    Composite[] compositeArray1 = new Composite[2];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class122.canRunDecoratorDelegate_0;
    Composite[] compositeArray3 = new Composite[3];
    Composite[] compositeArray4 = compositeArray3;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_9));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class122.canRunDecoratorDelegate_1;
    // ISSUE: reference to a compiler-generated field
    if (Class122.actionDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_10));
    }
    // ISSUE: reference to a compiler-generated field
    Action action1 = new Action(Class122.actionDelegate_0);
    Decorator decorator1 = new Decorator(decoratorDelegate1, (Composite) action1);
    compositeArray4[0] = (Composite) decorator1;
    Composite[] compositeArray5 = compositeArray3;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_11));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate2 = Class122.canRunDecoratorDelegate_2;
    // ISSUE: reference to a compiler-generated field
    if (Class122.actionSucceedDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.actionSucceedDelegate_0 = new ActionSucceedDelegate((object) null, __methodptr(smethod_12));
    }
    // ISSUE: reference to a compiler-generated field
    Action action2 = new Action(Class122.actionSucceedDelegate_0);
    Decorator decorator2 = new Decorator(decoratorDelegate2, (Composite) action2);
    compositeArray5[1] = (Composite) decorator2;
    Composite[] compositeArray6 = compositeArray3;
    Class144.Delegate43 delegate43_4_1 = (Class144.Delegate43) (object_0 => Class122.WoWUnit_3);
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_14));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate3 = Class122.canRunDecoratorDelegate_3;
    Action action_0_1 = (Action) (() =>
    {
      if (Class122.macroTargets_0 == Class137.MacroTargets.None)
        return;
      Class91.delegate34_1((object) ("[Macro] Casted spell: Gouge on " + Class122.macroTargets_0.ToString()));
    });
    Composite composite1 = Class77.smethod_0(1776, delegate43_4_1, decoratorDelegate3, "Gouge (Manual)", action_0_1);
    compositeArray6[2] = composite1;
    PrioritySelector prioritySelector1 = new PrioritySelector(compositeArray3);
    Decorator decorator3 = new Decorator(decoratorDelegate0, (Composite) prioritySelector1);
    compositeArray2[0] = (Composite) decorator3;
    Composite[] compositeArray7 = compositeArray1;
    Composite[] compositeArray8 = new Composite[5];
    Composite[] compositeArray9 = compositeArray8;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_4 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_4 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_16));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate4 = Class122.canRunDecoratorDelegate_4;
    Composite[] compositeArray10 = new Composite[2];
    Composite[] compositeArray11 = compositeArray10;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_5 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_5 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_17));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator4 = new Decorator(Class122.canRunDecoratorDelegate_5, (Composite) new ActionAlwaysSucceed());
    compositeArray11[0] = (Composite) decorator4;
    Composite[] compositeArray12 = compositeArray10;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_6 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_6 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_18));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite2 = Class77.smethod_1(1776, Class122.canRunDecoratorDelegate_6, "Gouge", (Action) (() => Class140.smethod_7("Gouging: " + Class91.WoWUnit_0.CastingSpell.Name, Class140.struct24_3)));
    compositeArray12[1] = composite2;
    PrioritySelector prioritySelector2 = new PrioritySelector(compositeArray10);
    Decorator decorator5 = new Decorator(decoratorDelegate4, (Composite) prioritySelector2);
    compositeArray9[0] = (Composite) decorator5;
    Composite[] compositeArray13 = compositeArray8;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_7 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_7 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_20));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate7 = Class122.canRunDecoratorDelegate_7;
    Composite[] compositeArray14 = new Composite[2];
    Composite[] compositeArray15 = compositeArray14;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_8 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_8 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_21));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator6 = new Decorator(Class122.canRunDecoratorDelegate_8, (Composite) new ActionAlwaysSucceed());
    compositeArray15[0] = (Composite) decorator6;
    Composite[] compositeArray16 = compositeArray14;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_9 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_9 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_22));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite3 = Class77.smethod_1(1776, Class122.canRunDecoratorDelegate_9, "Gouge", (Action) (() => Class140.smethod_7("Gouging: " + Class91.WoWUnit_0.ChanneledSpell.Name, Class140.struct24_3)));
    compositeArray16[1] = composite3;
    PrioritySelector prioritySelector3 = new PrioritySelector(compositeArray14);
    Decorator decorator7 = new Decorator(decoratorDelegate7, (Composite) prioritySelector3);
    compositeArray13[1] = (Composite) decorator7;
    Composite[] compositeArray17 = compositeArray8;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_10 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_10 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_24));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate10 = Class122.canRunDecoratorDelegate_10;
    Composite[] compositeArray18 = new Composite[2];
    Composite[] compositeArray19 = compositeArray18;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_11 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_11 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_25));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator8 = new Decorator(Class122.canRunDecoratorDelegate_11, (Composite) new ActionAlwaysSucceed());
    compositeArray19[0] = (Composite) decorator8;
    Composite[] compositeArray20 = compositeArray18;
    Class144.Delegate43 delegate43_4_2 = (Class144.Delegate43) (object_0 => Class91.WoWUnit_1);
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_12 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_12 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_27));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate12 = Class122.canRunDecoratorDelegate_12;
    Action action_0_2 = (Action) (() => Class140.smethod_7("Focus Gouging: " + Class91.WoWUnit_1.CastingSpell.Name, Class140.struct24_3));
    Composite composite4 = Class77.smethod_0(1776, delegate43_4_2, decoratorDelegate12, "Gouge", action_0_2);
    compositeArray20[1] = composite4;
    PrioritySelector prioritySelector4 = new PrioritySelector(compositeArray18);
    Decorator decorator9 = new Decorator(decoratorDelegate10, (Composite) prioritySelector4);
    compositeArray17[2] = (Composite) decorator9;
    Composite[] compositeArray21 = compositeArray8;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_13 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_13 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_29));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate13 = Class122.canRunDecoratorDelegate_13;
    Composite[] compositeArray22 = new Composite[2];
    Composite[] compositeArray23 = compositeArray22;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_14 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_14 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_30));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator10 = new Decorator(Class122.canRunDecoratorDelegate_14, (Composite) new ActionAlwaysSucceed());
    compositeArray23[0] = (Composite) decorator10;
    Composite[] compositeArray24 = compositeArray22;
    Class144.Delegate43 delegate43_4_3 = (Class144.Delegate43) (object_0 => Class91.WoWUnit_1);
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_15 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_15 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_32));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate15 = Class122.canRunDecoratorDelegate_15;
    Action action_0_3 = (Action) (() => Class140.smethod_7("Focus Gouging: " + Class91.WoWUnit_1.ChanneledSpell.Name, Class140.struct24_5));
    Composite composite5 = Class77.smethod_0(1776, delegate43_4_3, decoratorDelegate15, "Gouge", action_0_3);
    compositeArray24[1] = composite5;
    PrioritySelector prioritySelector5 = new PrioritySelector(compositeArray22);
    Decorator decorator11 = new Decorator(decoratorDelegate13, (Composite) prioritySelector5);
    compositeArray21[3] = (Composite) decorator11;
    Composite[] compositeArray25 = compositeArray8;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_16 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_16 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_34));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate16 = Class122.canRunDecoratorDelegate_16;
    Composite[] compositeArray26 = new Composite[2];
    Composite[] compositeArray27 = compositeArray26;
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_17 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_17 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_35));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator12 = new Decorator(Class122.canRunDecoratorDelegate_17, (Composite) new ActionAlwaysSucceed());
    compositeArray27[0] = (Composite) decorator12;
    Composite[] compositeArray28 = compositeArray26;
    Class144.Delegate43 delegate43_4_4 = (Class144.Delegate43) (object_0 => Class122.woWUnit_0);
    // ISSUE: reference to a compiler-generated field
    if (Class122.canRunDecoratorDelegate_18 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class122.canRunDecoratorDelegate_18 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_37));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate18 = Class122.canRunDecoratorDelegate_18;
    Action action_0_4 = (Action) (() => Class140.smethod_7("Off Gouging: " + Class122.woWUnit_0.CastingSpell.Name, Class140.struct24_5));
    Composite composite6 = Class77.smethod_0(1776, delegate43_4_4, decoratorDelegate18, "Gouge", action_0_4);
    compositeArray28[1] = composite6;
    PrioritySelector prioritySelector6 = new PrioritySelector(compositeArray26);
    Decorator decorator13 = new Decorator(decoratorDelegate16, (Composite) prioritySelector6);
    compositeArray25[4] = (Composite) decorator13;
    PrioritySelector prioritySelector7 = new PrioritySelector(compositeArray8);
    compositeArray7[1] = (Composite) prioritySelector7;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
