﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class127
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using CommonBehaviors.Actions;
using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class127 : Class91
{
  private static bool Boolean_21
  {
    get
    {
      return VitalicSettings.Instance.AutoKidney && Class91.Boolean_16 && Class91.Double_4 > 20.0 && Class91.Double_2 <= (double) (((WoWUnit) Class91.LocalPlayer_0).MaxEnergy - 10U) && (!Class91.Boolean_6 || Class91.Double_2 + Class91.Double_7 * Class91.Double_5 <= (double) (((WoWUnit) Class91.LocalPlayer_0).MaxEnergy - 10U));
    }
  }

  private static int Int32_4 => !Class91.LocalPlayer_0.smethod_4(18) ? 3 : 4;

  private static double Double_9 => Class91.Double_2 + Class91.Double_7 * 1.5;

  private static bool Boolean_22
  {
    get
    {
      double num = Class65.smethod_1(5171);
      return num > 1.0 && num < 3.0;
    }
  }

  private static bool Boolean_23
  {
    get
    {
      double num = Class74.smethod_2(1943, true);
      return num != 0.0 && (!Class91.LocalPlayer_0.smethod_4(18) || Class91.UInt32_0 >= 4U) && (num < 5.0 && num > 3.0 && !Class91.WoWUnit_0.smethod_0(Class68.Enum15.const_0) && Class91.Double_2 + Class91.Double_7 * (num - 2.0) + 25.0 < 110.0 || num <= 3.0);
    }
  }

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[4];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class127.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class127.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite1 = Class77.smethod_1(32645, Class127.canRunDecoratorDelegate_0, "Envenom (Marked for Death)");
    compositeArray2[0] = composite1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class127.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class127.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite2 = Class77.smethod_1(32645, Class127.canRunDecoratorDelegate_1, "Envenom (Slice and Dice)");
    compositeArray3[1] = composite2;
    Composite[] compositeArray4 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class127.canRunDecoratorDelegate_2 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class127.canRunDecoratorDelegate_2 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    Decorator decorator = new Decorator(Class127.canRunDecoratorDelegate_2, (Composite) new ActionAlwaysSucceed());
    compositeArray4[2] = (Composite) decorator;
    Composite[] compositeArray5 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class127.canRunDecoratorDelegate_3 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class127.canRunDecoratorDelegate_3 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    Composite composite3 = Class77.smethod_1(32645, Class127.canRunDecoratorDelegate_3, "Envenom");
    compositeArray5[3] = composite3;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
