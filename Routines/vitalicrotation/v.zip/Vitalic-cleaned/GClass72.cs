﻿// Decompiled with JetBrains decompiler
// Type: ns1.GClass72
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using System;
using System.Collections.Generic;

#nullable disable
namespace ns1;

public class GClass72 : Decorator
{
  private DateTime dateTime_0;
  private int int_0;
  private RunStatus runStatus_0;

  public GClass72(int int_2, TimeSpan timeSpan_1, RunStatus runStatus_1, Composite composite_0)
    : base(composite_0)
  {
    this.TimeFrame = timeSpan_1;
    this.Limit = int_2;
    this.dateTime_0 = DateTime.MinValue;
    this.int_0 = 0;
    this.runStatus_0 = runStatus_1;
  }

  public GClass72(TimeSpan timeSpan_1, Composite composite_0)
    : this(1, timeSpan_1, (RunStatus) 0, composite_0)
  {
  }

  public GClass72(int int_2, int int_3, Composite composite_0)
    : this(int_2, TimeSpan.FromSeconds((double) int_3), (RunStatus) 0, composite_0)
  {
  }

  public GClass72(int int_2, TimeSpan timeSpan_1, Composite composite_0)
    : this(int_2, timeSpan_1, (RunStatus) 0, composite_0)
  {
  }

  public GClass72(int int_2, Composite composite_0)
    : this(1, TimeSpan.FromSeconds((double) int_2), (RunStatus) 0, composite_0)
  {
  }

  public TimeSpan TimeFrame { get; set; }

  public int Limit { get; set; }

  public virtual void Start(object context) => base.Start(context);

  public virtual void Stop(object context) => ((Composite) this).Stop(context);

  protected virtual IEnumerable<RunStatus> Execute(object context)
  {
    if (DateTime.Now < this.dateTime_0 && this.int_0 >= this.Limit)
    {
      yield return this.runStatus_0;
    }
    else
    {
      this.DecoratedChild.Start(context);
      while (this.DecoratedChild.Tick(context) == 1)
        yield return (RunStatus) 1;
      this.DecoratedChild.Stop(context);
      if (DateTime.Now > this.dateTime_0)
      {
        this.int_0 = 0;
        this.dateTime_0 = DateTime.Now + this.TimeFrame;
      }
      ++this.int_0;
      RunStatus? lastStatus = this.DecoratedChild.LastStatus;
      if ((lastStatus.GetValueOrDefault() != null ? 0 : (lastStatus.HasValue ? 1 : 0)) != 0)
        yield return (RunStatus) 0;
      else
        yield return (RunStatus) 2;
    }
  }
}
