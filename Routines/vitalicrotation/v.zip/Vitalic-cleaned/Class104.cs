﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class104
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.TreeSharp;
using Styx.WoWInternals.WoWObjects;
using VitalicEliteRogue;

#nullable disable
namespace ns1;

internal class Class104 : Class91
{
  private static int Int32_4
  {
    get
    {
      return ((WoWUnit) Class91.LocalPlayer_0).smethod_5() ? VitalicSettings.Instance.BurstEnergyOpener : VitalicSettings.Instance.BurstEnergy;
    }
  }

  private static bool Boolean_21
  {
    get
    {
      int comboPoints = Class91.LocalPlayer_0.ComboPoints;
      return comboPoints > 2 && comboPoints < 5 && Class91.Double_5 > 5.0 && Class121.smethod_5() && VitalicSettings.Instance.AutoKidney;
    }
  }

  private static bool Boolean_22
  {
    get
    {
      Class68.Struct22 struct22 = Class91.WoWUnit_0.smethod_6(Class68.Enum14.const_0, VitalicSettings.Instance.BurstStunDR);
      return struct22.bool_0 && (double) struct22.timeSpan_0.Seconds > Class91.Double_5;
    }
  }

  private static bool Boolean_23 => Class71.CurrentSpec != 260 || Class59.smethod_0(51690);

  public static Composite smethod_4()
  {
    Composite[] compositeArray1 = new Composite[2];
    Composite[] compositeArray2 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class104.canRunDecoratorDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class104.canRunDecoratorDelegate_0 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_5));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate0 = Class104.canRunDecoratorDelegate_0;
    // ISSUE: reference to a compiler-generated field
    if (Class104.actionDelegate_0 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class104.actionDelegate_0 = new ActionDelegate((object) null, __methodptr(smethod_6));
    }
    // ISSUE: reference to a compiler-generated field
    Action action1 = new Action(Class104.actionDelegate_0);
    Decorator decorator1 = new Decorator(decoratorDelegate0, (Composite) action1);
    compositeArray2[0] = (Composite) decorator1;
    Composite[] compositeArray3 = compositeArray1;
    // ISSUE: reference to a compiler-generated field
    if (Class104.canRunDecoratorDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class104.canRunDecoratorDelegate_1 = new CanRunDecoratorDelegate((object) null, __methodptr(smethod_7));
    }
    // ISSUE: reference to a compiler-generated field
    CanRunDecoratorDelegate decoratorDelegate1 = Class104.canRunDecoratorDelegate_1;
    // ISSUE: reference to a compiler-generated field
    if (Class104.actionDelegate_1 == null)
    {
      // ISSUE: reference to a compiler-generated field
      // ISSUE: method pointer
      Class104.actionDelegate_1 = new ActionDelegate((object) null, __methodptr(smethod_8));
    }
    // ISSUE: reference to a compiler-generated field
    Action action2 = new Action(Class104.actionDelegate_1);
    Decorator decorator2 = new Decorator(decoratorDelegate1, (Composite) action2);
    compositeArray3[1] = (Composite) decorator2;
    return (Composite) new PrioritySelector(compositeArray1);
  }
}
