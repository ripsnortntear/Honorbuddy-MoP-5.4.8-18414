﻿// Decompiled with JetBrains decompiler
// Type: ns1.Class59
// Assembly: Vitalic, Version=2.0.3.0, Culture=neutral, PublicKeyToken=6a93f04b22df8534
// MVID: 66A64FBB-8F6D-4A78-84F2-D8EB05F9FE60
// Assembly location: C:\Users\Texy6\Desktop\Vitalic-cleaned.dll

using Styx.WoWInternals;
using Styx.WoWInternals.WoWObjects;
using System;
using System.Collections.Generic;
using System.Linq;

#nullable disable
namespace ns1;

internal class Class59
{
  private static Class59.Delegate25 delegate25_0 = new Class59.Delegate25(Class62.smethod_0);
  private static Class59.Delegate25 delegate25_1 = new Class59.Delegate25(Class62.smethod_1);
  private static HashSet<string> hashSet_0 = new HashSet<string>();

  static Class59()
  {
    Class41.Event_0 += (EventHandler) ((sender, e) =>
    {
      foreach (string string_0 in Class59.hashSet_0)
      {
        if (Class51.smethod_4(string_0))
          Class51.smethod_3(string_0);
      }
      Class59.hashSet_0.Clear();
    });
  }

  private static double Double_0 => Math.Max(50.0, Class144.double_0);

  public static bool smethod_0(int int_0, bool bool_0 = true)
  {
    string string_0 = "cooldown_" + (object) int_0;
    Class59.Class60 class60 = Class51.smethod_0<Class59.Class60>(string_0);
    if (class60 != null)
      return class60.bool_0;
    TimeSpan timeSpan = WoWSpell.FromId(int_0).CooldownTimeLeft - TimeSpan.FromMilliseconds(Class59.Double_0);
    Class59.Class60 gparam_0;
    if (timeSpan.TotalMilliseconds > 0.0)
    {
      gparam_0 = new Class59.Class60(DateTime.UtcNow + timeSpan, true);
      Class51.smethod_1<Class59.Class60>(gparam_0, string_0, (int) timeSpan.TotalMilliseconds);
      if (!Class59.hashSet_0.Contains(string_0))
        Class59.hashSet_0.Add(string_0);
    }
    else
    {
      if (!bool_0)
        return false;
      gparam_0 = new Class59.Class60(DateTime.MinValue, false);
      Class51.smethod_1<Class59.Class60>(gparam_0, string_0, 120000);
      if (!Class59.hashSet_0.Contains(string_0))
        Class59.hashSet_0.Add(string_0);
    }
    return gparam_0.bool_0;
  }

  public static bool smethod_1(WoWItem woWItem_0)
  {
    string string_0 = "cooldown_" + (object) (woWItem_0.ItemSpells.Count > 0 ? woWItem_0.ItemSpells.First<WoWItem.WoWItemSpell>().Id : (int) ((WoWObject) woWItem_0).Entry);
    Class59.Class60 class60 = Class51.smethod_0<Class59.Class60>(string_0);
    if (class60 != null)
      return class60.bool_0;
    TimeSpan timeSpan = woWItem_0.CooldownTimeLeft - TimeSpan.FromMilliseconds(Class59.Double_0);
    Class59.Class60 gparam_0;
    if (timeSpan.TotalMilliseconds > 0.0)
    {
      gparam_0 = new Class59.Class60(DateTime.UtcNow + timeSpan, true);
      Class51.smethod_1<Class59.Class60>(gparam_0, string_0, (int) timeSpan.TotalMilliseconds);
      if (!Class59.hashSet_0.Contains(string_0))
        Class59.hashSet_0.Add(string_0);
    }
    else
    {
      gparam_0 = new Class59.Class60(DateTime.MinValue, false);
      Class51.smethod_1<Class59.Class60>(gparam_0, string_0, 30000);
      if (!Class59.hashSet_0.Contains(string_0))
        Class59.hashSet_0.Add(string_0);
    }
    return gparam_0.bool_0;
  }

  public static double smethod_2(int int_0)
  {
    string string_0 = "cooldown_" + (object) int_0;
    Class59.Class60 class60 = Class51.smethod_0<Class59.Class60>(string_0);
    if (class60 != null)
      return !class60.bool_0 ? 0.0 : (class60.dateTime_0 - DateTime.UtcNow).TotalSeconds;
    TimeSpan timeSpan = WoWSpell.FromId(int_0).CooldownTimeLeft - TimeSpan.FromMilliseconds(Class59.Double_0);
    if (timeSpan.TotalMilliseconds > 0.0)
    {
      Class51.smethod_1<Class59.Class60>(new Class59.Class60(DateTime.UtcNow + timeSpan, true), string_0, (int) timeSpan.TotalMilliseconds);
      if (!Class59.hashSet_0.Contains(string_0))
        Class59.hashSet_0.Add(string_0);
      return timeSpan.TotalSeconds;
    }
    Class51.smethod_1<Class59.Class60>(new Class59.Class60(DateTime.MinValue, false), string_0, 30000);
    if (!Class59.hashSet_0.Contains(string_0))
      Class59.hashSet_0.Add(string_0);
    return 0.0;
  }

  private delegate void Delegate25(params object[] args);

  private class Class60
  {
    public DateTime dateTime_0;
    public bool bool_0;

    public Class60(DateTime dateTime_1, bool bool_1)
    {
      this.dateTime_0 = dateTime_1;
      this.bool_0 = bool_1;
    }
  }
}
