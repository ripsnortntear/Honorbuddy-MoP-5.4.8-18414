﻿using System;
using System.IO;
using System.Net;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Windows.Media;
using Styx.Common;

namespace ns0
{
	// Token: 0x02000004 RID: 4
	public class GClass1
	{
		// Token: 0x06000006 RID: 6 RVA: 0x00007840 File Offset: 0x00005A40
		public static bool smethod_0()
		{
			string path = Utilities.AssemblyDirectory + "\\Routines\\VitalicEliteRogue\\keyfile";
			if (!File.Exists(path))
			{
				Logging.Write(Colors.DarkRed, "Error occurred initialising routine, keyfile missing");
				return false;
			}
			using (StreamReader streamReader = new StreamReader(path, Encoding.UTF8))
			{
				GClass1.string_1 = streamReader.ReadToEnd();
			}
			return !string.IsNullOrEmpty(GClass1.string_1);
		}

		// Token: 0x06000007 RID: 7 RVA: 0x000078B8 File Offset: 0x00005AB8
		public static bool smethod_1()
		{
			string address = "http://vitalic.azurewebsites.net/info/" + GClass1.string_1.Trim();
			bool result;
			using (WebClient webClient = new WebClient())
			{
				string text = string.Empty;
				try
				{
					text = webClient.DownloadString(address);
				}
				catch (Exception)
				{
					return false;
				}
				if (!string.IsNullOrEmpty(text))
				{
					MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(text));
					DataContractJsonSerializer dataContractJsonSerializer = new DataContractJsonSerializer(typeof(GClass1.Response));
					GClass1.Response response = (GClass1.Response)dataContractJsonSerializer.ReadObject(stream);
					if (response.ChangeLog == string.Empty)
					{
						result = false;
					}
					else if (response.LoaderVersion != Assembly.GetExecutingAssembly().GetName().Version.ToString())
					{
						Logging.Write(Colors.DarkOrange, "Error occurred initialising routine, please install the latest version");
						result = false;
					}
					else
					{
						GClass1.string_2 = response.UserName;
						GClass1.string_4 = response.ChangeLog;
						GClass1.string_3 = response.RotationNotes;
						GClass1.string_5 = response.Name;
						result = true;
					}
				}
				else
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x04000005 RID: 5
		public const string string_0 = "http://vitalic.azurewebsites.net/";

		// Token: 0x04000006 RID: 6
		public static string string_1;

		// Token: 0x04000007 RID: 7
		public static string string_2;

		// Token: 0x04000008 RID: 8
		public static string string_3;

		// Token: 0x04000009 RID: 9
		public static string string_4;

		// Token: 0x0400000A RID: 10
		public static string string_5;

		// Token: 0x02000005 RID: 5
		[DataContract]
		private class Response
		{
			// Token: 0x17000001 RID: 1
			// (get) Token: 0x06000009 RID: 9 RVA: 0x00002107 File Offset: 0x00000307
			// (set) Token: 0x0600000A RID: 10 RVA: 0x0000210F File Offset: 0x0000030F
			[DataMember(Name = "username")]
			public string UserName { get; set; }

			// Token: 0x17000002 RID: 2
			// (get) Token: 0x0600000B RID: 11 RVA: 0x00002118 File Offset: 0x00000318
			// (set) Token: 0x0600000C RID: 12 RVA: 0x00002120 File Offset: 0x00000320
			[DataMember(Name = "rotation_notes")]
			public string RotationNotes { get; set; }

			// Token: 0x17000003 RID: 3
			// (get) Token: 0x0600000D RID: 13 RVA: 0x00002129 File Offset: 0x00000329
			// (set) Token: 0x0600000E RID: 14 RVA: 0x00002131 File Offset: 0x00000331
			[DataMember(Name = "changelog")]
			public string ChangeLog { get; set; }

			// Token: 0x17000004 RID: 4
			// (get) Token: 0x0600000F RID: 15 RVA: 0x0000213A File Offset: 0x0000033A
			// (set) Token: 0x06000010 RID: 16 RVA: 0x00002142 File Offset: 0x00000342
			[DataMember(Name = "loader_version")]
			public string LoaderVersion { get; set; }

			// Token: 0x17000005 RID: 5
			// (get) Token: 0x06000011 RID: 17 RVA: 0x0000214B File Offset: 0x0000034B
			// (set) Token: 0x06000012 RID: 18 RVA: 0x00002153 File Offset: 0x00000353
			[DataMember(Name = "name")]
			public string Name { get; set; }

			// Token: 0x0400000B RID: 11
			[CompilerGenerated]
			private string string_0;

			// Token: 0x0400000C RID: 12
			[CompilerGenerated]
			private string string_1;

			// Token: 0x0400000D RID: 13
			[CompilerGenerated]
			private string string_2;

			// Token: 0x0400000E RID: 14
			[CompilerGenerated]
			private string string_3;

			// Token: 0x0400000F RID: 15
			[CompilerGenerated]
			private string string_4;
		}
	}
}
