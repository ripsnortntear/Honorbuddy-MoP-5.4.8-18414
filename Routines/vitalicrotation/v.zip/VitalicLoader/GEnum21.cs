﻿using System;

namespace ns0
{
	// Token: 0x0200009D RID: 157
	public enum GEnum21
	{
		// Token: 0x04000479 RID: 1145
		const_0,
		// Token: 0x0400047A RID: 1146
		const_1,
		// Token: 0x0400047B RID: 1147
		const_2
	}
}
