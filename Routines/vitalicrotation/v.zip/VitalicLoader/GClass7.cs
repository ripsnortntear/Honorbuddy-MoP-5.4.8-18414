﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200001A RID: 26
	[ProvideProperty("ApplyMetroTheme", typeof(Control))]
	public sealed class GClass7 : Component, IExtenderProvider, GInterface0
	{
		// Token: 0x06000094 RID: 148 RVA: 0x00002444 File Offset: 0x00000644
		public GClass7()
		{
		}

		// Token: 0x06000095 RID: 149 RVA: 0x00002457 File Offset: 0x00000657
		public GClass7(IContainer icontainer_0) : this()
		{
			if (icontainer_0 != null)
			{
				icontainer_0.Add(this);
			}
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000096 RID: 150 RVA: 0x00002469 File Offset: 0x00000669
		// (set) Token: 0x06000097 RID: 151 RVA: 0x00002470 File Offset: 0x00000670
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public GEnum10 GEnum10_0
		{
			get
			{
				throw new NotSupportedException();
			}
			set
			{
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x06000098 RID: 152 RVA: 0x00008EE4 File Offset: 0x000070E4
		// (set) Token: 0x06000099 RID: 153 RVA: 0x00002472 File Offset: 0x00000672
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
				this.method_0();
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x0600009A RID: 154 RVA: 0x00002481 File Offset: 0x00000681
		// (set) Token: 0x0600009B RID: 155 RVA: 0x00002489 File Offset: 0x00000689
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
				this.method_0();
			}
		}

		// Token: 0x0600009C RID: 156 RVA: 0x00008F3C File Offset: 0x0000713C
		private void method_0()
		{
			Color backColor = GClass39.GClass46.smethod_0(this.GEnum29_0);
			Color foreColor = GClass39.GClass56.GClass60.smethod_0(this.GEnum29_0);
			foreach (Control control in this.list_0)
			{
				if (control != null)
				{
					try
					{
						control.BackColor = backColor;
					}
					catch
					{
					}
					try
					{
						control.ForeColor = foreColor;
					}
					catch
					{
					}
				}
			}
		}

		// Token: 0x0600009D RID: 157 RVA: 0x00002498 File Offset: 0x00000698
		bool IExtenderProvider.CanExtend(object extendee)
		{
			return extendee is Control && !(extendee is GInterface2) && !(extendee is GInterface1);
		}

		// Token: 0x0600009E RID: 158 RVA: 0x000024BA File Offset: 0x000006BA
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		[Description("Apply Metro Theme BackColor and ForeColor.")]
		public bool method_1(Control control_0)
		{
			return control_0 != null && this.list_0.Contains(control_0);
		}

		// Token: 0x0600009F RID: 159 RVA: 0x000024CD File Offset: 0x000006CD
		public void method_2(Control control_0, bool bool_0)
		{
			if (control_0 == null)
			{
				return;
			}
			if (this.list_0.Contains(control_0))
			{
				if (!bool_0)
				{
					this.list_0.Remove(control_0);
					return;
				}
			}
			else if (bool_0)
			{
				this.list_0.Add(control_0);
			}
		}

		// Token: 0x04000045 RID: 69
		private GEnum29 genum29_0;

		// Token: 0x04000046 RID: 70
		private GClass8 gclass8_0;

		// Token: 0x04000047 RID: 71
		private readonly List<Control> list_0 = new List<Control>();
	}
}
