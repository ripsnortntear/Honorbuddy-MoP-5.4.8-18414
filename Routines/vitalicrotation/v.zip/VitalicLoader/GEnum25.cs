﻿using System;

namespace ns0
{
	// Token: 0x020000A1 RID: 161
	public enum GEnum25
	{
		// Token: 0x04000489 RID: 1161
		const_0,
		// Token: 0x0400048A RID: 1162
		const_1,
		// Token: 0x0400048B RID: 1163
		const_2
	}
}
