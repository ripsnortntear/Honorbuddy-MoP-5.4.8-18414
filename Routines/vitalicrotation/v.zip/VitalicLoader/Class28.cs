﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Security;

namespace ns0
{
	// Token: 0x020000BB RID: 187
	internal class Class28
	{
		// Token: 0x06000877 RID: 2167 RVA: 0x0001DCD8 File Offset: 0x0001BED8
		[SecuritySafeCritical]
		public Class28()
		{
			IntPtr intptr_ = Class29.FindWindow("Shell_TrayWnd", null);
			Class29.Struct17 @struct = default(Class29.Struct17);
			@struct.uint_0 = (uint)Marshal.SizeOf(typeof(Class29.Struct17));
			@struct.intptr_0 = intptr_;
			IntPtr value = Class29.SHAppBarMessage(Class29.Enum6.const_5, ref @struct);
			if (value == IntPtr.Zero)
			{
				throw new InvalidOperationException();
			}
			this.GEnum30_0 = (GEnum30)@struct.enum7_0;
			this.Rectangle_0 = Rectangle.FromLTRB(@struct.struct14_0.int_0, @struct.struct14_0.int_1, @struct.struct14_0.int_2, @struct.struct14_0.int_3);
			@struct.uint_0 = (uint)Marshal.SizeOf(typeof(Class29.Struct17));
			int num = Class29.SHAppBarMessage(Class29.Enum6.const_4, ref @struct).ToInt32();
			this.Boolean_0 = ((num & 2) == 2);
			this.Boolean_1 = ((num & 1) == 1);
		}

		// Token: 0x17000259 RID: 601
		// (get) Token: 0x06000878 RID: 2168 RVA: 0x00007778 File Offset: 0x00005978
		// (set) Token: 0x06000879 RID: 2169 RVA: 0x00007780 File Offset: 0x00005980
		public Rectangle Rectangle_0
		{
			get
			{
				return this.rectangle_0;
			}
			private set
			{
				this.rectangle_0 = value;
			}
		}

		// Token: 0x1700025A RID: 602
		// (get) Token: 0x0600087A RID: 2170 RVA: 0x00007789 File Offset: 0x00005989
		// (set) Token: 0x0600087B RID: 2171 RVA: 0x00007791 File Offset: 0x00005991
		public GEnum30 GEnum30_0
		{
			get
			{
				return this.genum30_0;
			}
			private set
			{
				this.genum30_0 = value;
			}
		}

		// Token: 0x1700025B RID: 603
		// (get) Token: 0x0600087C RID: 2172 RVA: 0x0001DDD4 File Offset: 0x0001BFD4
		public Point Point_0
		{
			get
			{
				return this.Rectangle_0.Location;
			}
		}

		// Token: 0x1700025C RID: 604
		// (get) Token: 0x0600087D RID: 2173 RVA: 0x0001DDF0 File Offset: 0x0001BFF0
		public Size Size_0
		{
			get
			{
				return this.Rectangle_0.Size;
			}
		}

		// Token: 0x1700025D RID: 605
		// (get) Token: 0x0600087E RID: 2174 RVA: 0x0000779A File Offset: 0x0000599A
		// (set) Token: 0x0600087F RID: 2175 RVA: 0x000077A2 File Offset: 0x000059A2
		public bool Boolean_0
		{
			get
			{
				return this.bool_0;
			}
			private set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x1700025E RID: 606
		// (get) Token: 0x06000880 RID: 2176 RVA: 0x000077AB File Offset: 0x000059AB
		// (set) Token: 0x06000881 RID: 2177 RVA: 0x000077B3 File Offset: 0x000059B3
		public bool Boolean_1
		{
			get
			{
				return this.bool_1;
			}
			private set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x04000500 RID: 1280
		private const string string_0 = "Shell_TrayWnd";

		// Token: 0x04000501 RID: 1281
		private Rectangle rectangle_0 = Rectangle.Empty;

		// Token: 0x04000502 RID: 1282
		private GEnum30 genum30_0 = GEnum30.const_0;

		// Token: 0x04000503 RID: 1283
		private bool bool_0;

		// Token: 0x04000504 RID: 1284
		private bool bool_1;
	}
}
