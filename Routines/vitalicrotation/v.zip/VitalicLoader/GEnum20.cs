﻿using System;

namespace ns0
{
	// Token: 0x0200009C RID: 156
	public enum GEnum20
	{
		// Token: 0x04000475 RID: 1141
		const_0,
		// Token: 0x04000476 RID: 1142
		const_1,
		// Token: 0x04000477 RID: 1143
		const_2
	}
}
