﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace ns0
{
	// Token: 0x0200005E RID: 94
	internal class Class16
	{
		// Token: 0x06000704 RID: 1796 RVA: 0x000068B3 File Offset: 0x00004AB3
		private Class16()
		{
			this.list_0 = new List<GClass23>();
			this.list_1 = new List<GClass23>();
			this.list_2 = new List<GClass23>();
		}

		// Token: 0x06000705 RID: 1797 RVA: 0x0001988C File Offset: 0x00017A8C
		public Class16(GClass23 gclass23_4, Graphics graphics_0) : this()
		{
			if (!(gclass23_4.String_47 == "table") && !(gclass23_4.String_47 == "inline-table"))
			{
				throw new ArgumentException("Box is not a table", "tableBox");
			}
			this.gclass23_0 = gclass23_4;
			this.method_7(gclass23_4, graphics_0);
			this.method_0(graphics_0);
		}

		// Token: 0x17000203 RID: 515
		// (get) Token: 0x06000706 RID: 1798 RVA: 0x000068DC File Offset: 0x00004ADC
		public bool Boolean_0
		{
			get
			{
				return this.bool_0;
			}
		}

		// Token: 0x17000204 RID: 516
		// (get) Token: 0x06000707 RID: 1799 RVA: 0x000068E4 File Offset: 0x00004AE4
		public List<GClass23> List_0
		{
			get
			{
				return this.list_2;
			}
		}

		// Token: 0x17000205 RID: 517
		// (get) Token: 0x06000708 RID: 1800 RVA: 0x000068EC File Offset: 0x00004AEC
		public GClass23 GClass23_0
		{
			get
			{
				return this.gclass23_1;
			}
		}

		// Token: 0x17000206 RID: 518
		// (get) Token: 0x06000709 RID: 1801 RVA: 0x000068F4 File Offset: 0x00004AF4
		public int Int32_0
		{
			get
			{
				return this.int_1;
			}
		}

		// Token: 0x17000207 RID: 519
		// (get) Token: 0x0600070A RID: 1802 RVA: 0x000198EC File Offset: 0x00017AEC
		public float[] Single_0
		{
			get
			{
				if (this.float_1 == null)
				{
					this.float_1 = new float[this.Single_1.Length];
					foreach (GClass23 gclass in this.List_0)
					{
						foreach (GClass23 gclass2 in gclass.List_0)
						{
							int num = this.method_4(gclass2);
							int num2 = this.method_2(gclass, gclass2);
							int num3 = num2 + num - 1;
							float num4 = this.method_1(gclass, gclass2, num2, num) + (float)(num - 1) * this.Single_2;
							this.float_1[num3] = Math.Max(this.float_1[num3], gclass2.method_9() - num4);
						}
					}
				}
				return this.float_1;
			}
		}

		// Token: 0x17000208 RID: 520
		// (get) Token: 0x0600070B RID: 1803 RVA: 0x000068FC File Offset: 0x00004AFC
		public List<GClass23> List_1
		{
			get
			{
				return this.list_1;
			}
		}

		// Token: 0x17000209 RID: 521
		// (get) Token: 0x0600070C RID: 1804 RVA: 0x00006904 File Offset: 0x00004B04
		public float[] Single_1
		{
			get
			{
				return this.float_0;
			}
		}

		// Token: 0x1700020A RID: 522
		// (get) Token: 0x0600070D RID: 1805 RVA: 0x0000690C File Offset: 0x00004B0C
		public List<GClass23> List_2
		{
			get
			{
				return this.list_0;
			}
		}

		// Token: 0x1700020B RID: 523
		// (get) Token: 0x0600070E RID: 1806 RVA: 0x00006914 File Offset: 0x00004B14
		public GClass23 GClass23_1
		{
			get
			{
				return this.gclass23_3;
			}
		}

		// Token: 0x1700020C RID: 524
		// (get) Token: 0x0600070F RID: 1807 RVA: 0x0000691C File Offset: 0x00004B1C
		public GClass23 GClass23_2
		{
			get
			{
				return this.gclass23_2;
			}
		}

		// Token: 0x1700020D RID: 525
		// (get) Token: 0x06000710 RID: 1808 RVA: 0x00006924 File Offset: 0x00004B24
		public float Single_2
		{
			get
			{
				if (this.GClass23_3.String_21 == "collapse")
				{
					return -1f;
				}
				return this.GClass23_3.Single_19;
			}
		}

		// Token: 0x1700020E RID: 526
		// (get) Token: 0x06000711 RID: 1809 RVA: 0x0000694E File Offset: 0x00004B4E
		public float Single_3
		{
			get
			{
				if (this.GClass23_3.String_21 == "collapse")
				{
					return -1f;
				}
				return this.GClass23_3.Single_20;
			}
		}

		// Token: 0x1700020F RID: 527
		// (get) Token: 0x06000712 RID: 1810 RVA: 0x00006978 File Offset: 0x00004B78
		public int Int32_1
		{
			get
			{
				return this.int_0;
			}
		}

		// Token: 0x17000210 RID: 528
		// (get) Token: 0x06000713 RID: 1811 RVA: 0x00006980 File Offset: 0x00004B80
		public GClass23 GClass23_3
		{
			get
			{
				return this.gclass23_0;
			}
		}

		// Token: 0x06000714 RID: 1812 RVA: 0x000199F8 File Offset: 0x00017BF8
		private void method_0(Graphics graphics_0)
		{
			this.method_11();
			float num = float.NaN;
			foreach (GClass23 gclass in this.GClass23_3.List_0)
			{
				gclass.method_30();
				string string_;
				if ((string_ = gclass.String_47) != null)
				{
					if (Class31.dictionary_3 == null)
					{
						Class31.dictionary_3 = new Dictionary<string, int>(7)
						{
							{
								"table-caption",
								0
							},
							{
								"table-column",
								1
							},
							{
								"table-column-group",
								2
							},
							{
								"table-footer-group",
								3
							},
							{
								"table-header-group",
								4
							},
							{
								"table-row",
								5
							},
							{
								"table-row-group",
								6
							}
						};
					}
					int num2;
					if (Class31.dictionary_3.TryGetValue(string_, out num2))
					{
						switch (num2)
						{
						case 0:
							this.gclass23_1 = gclass;
							continue;
						case 1:
							for (int i = 0; i < this.method_14(gclass); i++)
							{
								this.List_1.Add(this.method_15(gclass));
							}
							continue;
						case 2:
							if (gclass.List_0.Count == 0)
							{
								int num3 = this.method_14(gclass);
								for (int j = 0; j < num3; j++)
								{
									this.List_1.Add(this.method_15(gclass));
								}
								continue;
							}
							using (List<GClass23>.Enumerator enumerator2 = gclass.List_0.GetEnumerator())
							{
								while (enumerator2.MoveNext())
								{
									GClass23 gclass23_ = enumerator2.Current;
									int num4 = this.method_14(gclass23_);
									for (int k = 0; k < num4; k++)
									{
										this.List_1.Add(this.method_15(gclass23_));
									}
								}
								continue;
							}
							break;
						case 3:
							break;
						case 4:
							if (this.GClass23_2 != null)
							{
								this.List_2.Add(gclass);
								continue;
							}
							this.gclass23_2 = gclass;
							continue;
						case 5:
							this.List_2.Add(gclass);
							continue;
						case 6:
							foreach (GClass23 gclass2 in gclass.List_0)
							{
								if (gclass.String_47 == "table-row")
								{
									this.List_2.Add(gclass);
								}
							}
							continue;
						default:
							continue;
						}
						if (this.GClass23_1 != null)
						{
							this.List_2.Add(gclass);
						}
						else
						{
							this.gclass23_3 = gclass;
						}
					}
				}
			}
			if (this.GClass23_2 != null)
			{
				this.list_2.AddRange(this.GClass23_2.List_0);
			}
			this.list_2.AddRange(this.List_2);
			if (this.GClass23_1 != null)
			{
				this.list_2.AddRange(this.GClass23_1.List_0);
			}
			if (!this.GClass23_3.bool_0)
			{
				int num5 = 0;
				List<GClass23> list = this.List_2;
				foreach (GClass23 gclass3 in list)
				{
					gclass3.method_30();
					int num6 = 0;
					for (int l = 0; l < gclass3.List_0.Count; l++)
					{
						GClass23 gclass4 = gclass3.List_0[l];
						int num7 = this.method_5(gclass4);
						int num8 = this.method_2(gclass3, gclass4);
						int m = num5 + 1;
						IL_3BF:
						while (m < num5 + num7)
						{
							int num9 = 0;
							for (int n = 0; n <= list[m].List_0.Count; n++)
							{
								if (num9 == num8)
								{
									list[m].List_0.Insert(num9, new Class16.Class10(this.GClass23_3, ref gclass4, num5));
									IL_3B9:
									m++;
									goto IL_3BF;
								}
								num9++;
								num8 -= this.method_4(list[m].List_0[n]) - 1;
							}
							goto IL_3B9;
						}
						num6++;
					}
					num5++;
				}
				this.GClass23_3.bool_0 = true;
			}
			this.int_0 = this.List_2.Count + ((this.GClass23_2 != null) ? this.GClass23_2.List_0.Count : 0) + ((this.GClass23_1 != null) ? this.GClass23_1.List_0.Count : 0);
			if (this.List_1.Count > 0)
			{
				this.int_1 = this.List_1.Count;
			}
			else
			{
				foreach (GClass23 gclass5 in this.List_0)
				{
					this.int_1 = Math.Max(this.int_1, gclass5.List_0.Count);
				}
			}
			this.float_0 = new float[this.int_1];
			for (int num10 = 0; num10 < this.float_0.Length; num10++)
			{
				this.float_0[num10] = float.NaN;
			}
			num = this.method_12();
			if (this.List_1.Count > 0)
			{
				for (int num11 = 0; num11 < this.List_1.Count; num11++)
				{
					GClass33 gclass6 = new GClass33(this.List_1[num11].String_39);
					if (gclass6.Single_0 > 0f)
					{
						if (gclass6.Boolean_1)
						{
							this.Single_1[num11] = GClass34.smethod_0(this.List_1[num11].String_39, num);
						}
						else if (gclass6.GEnum4_0 == GClass33.GEnum4.const_2 || gclass6.GEnum4_0 == GClass33.GEnum4.const_0)
						{
							this.Single_1[num11] = gclass6.Single_0;
						}
					}
				}
			}
			else
			{
				foreach (GClass23 gclass7 in this.List_0)
				{
					for (int num12 = 0; num12 < this.int_1; num12++)
					{
						if (float.IsNaN(this.Single_1[num12]) && num12 < gclass7.List_0.Count && gclass7.List_0[num12].String_47 == "table-cell")
						{
							GClass33 gclass8 = new GClass33(gclass7.List_0[num12].String_39);
							if (gclass8.Single_0 > 0f)
							{
								int num13 = this.method_4(gclass7.List_0[num12]);
								float num14 = 0f;
								if (gclass8.Boolean_1)
								{
									num14 = GClass34.smethod_0(gclass7.List_0[num12].String_39, num);
								}
								else if (gclass8.GEnum4_0 == GClass33.GEnum4.const_2 || gclass8.GEnum4_0 == GClass33.GEnum4.const_0)
								{
									num14 = gclass8.Single_0;
								}
								num14 /= Convert.ToSingle(num13);
								for (int num15 = num12; num15 < num12 + num13; num15++)
								{
									this.Single_1[num15] = num14;
								}
							}
						}
					}
				}
			}
			if (this.Boolean_0)
			{
				int num16 = 0;
				float num17 = 0f;
				for (int num18 = 0; num18 < this.Single_1.Length; num18++)
				{
					if (float.IsNaN(this.Single_1[num18]))
					{
						num16++;
					}
					else
					{
						num17 += this.Single_1[num18];
					}
				}
				float num19 = (num - num17) / Convert.ToSingle(num16);
				for (int num20 = 0; num20 < this.Single_1.Length; num20++)
				{
					if (float.IsNaN(this.Single_1[num20]))
					{
						this.Single_1[num20] = num19;
					}
				}
			}
			else
			{
				float[] array = new float[this.Single_1.Length];
				foreach (GClass23 gclass9 in this.List_0)
				{
					for (int num21 = 0; num21 < gclass9.List_0.Count; num21++)
					{
						int num22 = this.method_2(gclass9, gclass9.List_0[num21]);
						if (float.IsNaN(this.Single_1[num22]) && num21 < gclass9.List_0.Count && this.method_4(gclass9.List_0[num21]) == 1)
						{
							array[num22] = Math.Max(array[num22], gclass9.List_0[num21].method_13(graphics_0));
						}
					}
				}
				for (int num23 = 0; num23 < this.Single_1.Length; num23++)
				{
					if (float.IsNaN(this.Single_1[num23]))
					{
						this.Single_1[num23] = array[num23];
					}
				}
			}
			int num24 = 0;
			float num25 = 1f;
			while (this.method_13() > this.method_11())
			{
				if (!this.method_9())
				{
					break;
				}
				while (!this.method_10(num24))
				{
					num24++;
				}
				this.Single_1[num24] -= num25;
				num24++;
				if (num24 >= this.Single_1.Length)
				{
					num24 = 0;
				}
			}
			foreach (GClass23 gclass10 in this.List_0)
			{
				foreach (GClass23 gclass11 in gclass10.List_0)
				{
					int num26 = this.method_4(gclass11);
					int num27 = this.method_2(gclass10, gclass11);
					int num28 = num27 + num26 - 1;
					if (this.Single_1[num27] < this.Single_0[num27])
					{
						float num29 = this.Single_0[num27] - this.Single_1[num27];
						this.Single_1[num28] = this.Single_0[num28];
						if (num27 < this.Single_1.Length - 1)
						{
							this.Single_1[num27 + 1] -= num29;
						}
					}
				}
			}
			this.GClass23_3.String_32 = "0";
			float num30 = this.GClass23_3.Single_23 + this.Single_2;
			float num31 = this.GClass23_3.Single_24 + this.Single_3;
			float y = num31;
			float num32 = num30;
			float num33 = 0f;
			int num34 = 0;
			foreach (GClass23 gclass12 in this.List_0)
			{
				if (!(gclass12 is GClass25) && !(gclass12 is GClass27))
				{
					float x = num30;
					num24 = 0;
					foreach (GClass23 gclass13 in gclass12.List_0)
					{
						if (num24 >= this.Single_1.Length)
						{
							break;
						}
						int num35 = this.method_5(gclass13);
						float width = this.method_3(this.method_2(gclass12, gclass13), gclass13);
						gclass13.PointF_0 = new PointF(x, y);
						gclass13.SizeF_0 = new SizeF(width, 0f);
						gclass13.vmethod_0(graphics_0);
						Class16.Class10 @class = gclass13 as Class16.Class10;
						if (@class != null)
						{
							if (@class.Int32_1 == num34)
							{
								num33 = Math.Max(num33, @class.gclass23_3.Single_22);
							}
						}
						else if (num35 == 1)
						{
							num33 = Math.Max(num33, gclass13.Single_22);
						}
						num32 = Math.Max(num32, gclass13.Single_30);
						num24++;
						x = gclass13.Single_30 + this.Single_2;
					}
					foreach (GClass23 gclass14 in gclass12.List_0)
					{
						Class16.Class10 class2 = gclass14 as Class16.Class10;
						if (class2 == null && this.method_5(gclass14) == 1)
						{
							gclass14.Single_22 = num33;
							Class14.smethod_10(graphics_0, gclass14);
						}
						else if (class2 != null && class2.Int32_1 == num34)
						{
							class2.gclass23_3.Single_22 = num33;
							Class14.smethod_10(graphics_0, class2.gclass23_3);
						}
					}
					y = num33 + this.Single_3;
					num34++;
				}
			}
			this.GClass23_3.Single_30 = num32 + this.Single_2 + this.GClass23_3.Single_11;
			this.GClass23_3.Single_22 = num33 + this.Single_3 + this.GClass23_3.Single_10;
		}

		// Token: 0x06000715 RID: 1813 RVA: 0x0001A794 File Offset: 0x00018994
		private float method_1(GClass23 gclass23_4, GClass23 gclass23_5, int int_2, int int_3)
		{
			float num = 0f;
			int num2 = int_2;
			while (num2 < gclass23_4.List_0.Count || num2 < int_2 + int_3 - 1)
			{
				num += this.Single_0[num2];
				num2++;
			}
			return num;
		}

		// Token: 0x06000716 RID: 1814 RVA: 0x0001A7D8 File Offset: 0x000189D8
		private int method_2(GClass23 gclass23_4, GClass23 gclass23_5)
		{
			int num = 0;
			foreach (GClass23 gclass in gclass23_4.List_0)
			{
				if (gclass.Equals(gclass23_5))
				{
					break;
				}
				num += this.method_4(gclass);
			}
			return num;
		}

		// Token: 0x06000717 RID: 1815 RVA: 0x0001A83C File Offset: 0x00018A3C
		private float method_3(int int_2, GClass23 gclass23_4)
		{
			float num = Convert.ToSingle(this.method_4(gclass23_4));
			float num2 = 0f;
			int num3 = int_2;
			while ((float)num3 < (float)int_2 + num && int_2 < this.Single_1.Length && this.Single_1.Length > num3)
			{
				num2 += this.Single_1[num3];
				num3++;
			}
			return num2 + (num - 1f) * this.Single_2;
		}

		// Token: 0x06000718 RID: 1816 RVA: 0x0001A8A0 File Offset: 0x00018AA0
		private int method_4(GClass23 gclass23_4)
		{
			string s = gclass23_4.method_6("colspan", "1");
			int result;
			if (!int.TryParse(s, out result))
			{
				return 1;
			}
			return result;
		}

		// Token: 0x06000719 RID: 1817 RVA: 0x0001A8CC File Offset: 0x00018ACC
		private int method_5(GClass23 gclass23_4)
		{
			string s = gclass23_4.method_6("rowspan", "1");
			int result;
			if (!int.TryParse(s, out result))
			{
				return 1;
			}
			return result;
		}

		// Token: 0x0600071A RID: 1818 RVA: 0x0001A8F8 File Offset: 0x00018AF8
		private void method_6(GClass23 gclass23_4, Graphics graphics_0)
		{
			if (gclass23_4 == null)
			{
				return;
			}
			foreach (GClass23 gclass in gclass23_4.List_0)
			{
				gclass.vmethod_0(graphics_0);
				this.method_6(gclass, graphics_0);
			}
		}

		// Token: 0x0600071B RID: 1819 RVA: 0x0001A958 File Offset: 0x00018B58
		private void method_7(GClass23 gclass23_4, Graphics graphics_0)
		{
			if (gclass23_4 == null)
			{
				return;
			}
			foreach (GClass23 gclass in gclass23_4.List_0)
			{
				gclass.method_21(graphics_0);
				this.method_7(gclass, graphics_0);
			}
		}

		// Token: 0x0600071C RID: 1820 RVA: 0x0001A9B8 File Offset: 0x00018BB8
		private int method_8()
		{
			int num = 0;
			for (int i = 0; i < this.Single_1.Length; i++)
			{
				if (this.method_10(i))
				{
					num++;
				}
			}
			return num;
		}

		// Token: 0x0600071D RID: 1821 RVA: 0x0001A9E8 File Offset: 0x00018BE8
		private bool method_9()
		{
			for (int i = 0; i < this.Single_1.Length; i++)
			{
				if (this.method_10(i))
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600071E RID: 1822 RVA: 0x00006988 File Offset: 0x00004B88
		private bool method_10(int int_2)
		{
			return this.Single_1.Length < int_2 && this.Single_0.Length < int_2 && this.Single_1[int_2] > this.Single_0[int_2];
		}

		// Token: 0x0600071F RID: 1823 RVA: 0x0001AA14 File Offset: 0x00018C14
		private float method_11()
		{
			GClass33 gclass = new GClass33(this.GClass23_3.String_39);
			if (gclass.Single_0 <= 0f)
			{
				return this.GClass23_3.GClass23_2.Single_21;
			}
			this.bool_0 = true;
			if (gclass.Boolean_1)
			{
				return GClass34.smethod_0(gclass.String_0, this.GClass23_3.GClass23_2.Single_21);
			}
			return gclass.Single_0;
		}

		// Token: 0x06000720 RID: 1824 RVA: 0x000069B4 File Offset: 0x00004BB4
		private float method_12()
		{
			return this.method_11() - this.Single_2 * (float)(this.Int32_0 + 1) - this.GClass23_3.Single_9 - this.GClass23_3.Single_11;
		}

		// Token: 0x06000721 RID: 1825 RVA: 0x0001AA84 File Offset: 0x00018C84
		private float method_13()
		{
			float num = 0f;
			for (int i = 0; i < this.Single_1.Length; i++)
			{
				if (float.IsNaN(this.Single_1[i]))
				{
					throw new Exception("CssTable Algorithm error: There's a NaN in column widths");
				}
				num += this.Single_1[i];
			}
			num += this.Single_2 * (float)(this.Single_1.Length + 1);
			return num + (this.GClass23_3.Single_9 + this.GClass23_3.Single_11);
		}

		// Token: 0x06000722 RID: 1826 RVA: 0x0001AB04 File Offset: 0x00018D04
		private int method_14(GClass23 gclass23_4)
		{
			float value = GClass34.smethod_0(gclass23_4.method_5("span"), 1f);
			return Math.Max(1, Convert.ToInt32(value));
		}

		// Token: 0x06000723 RID: 1827 RVA: 0x00002E64 File Offset: 0x00001064
		private GClass23 method_15(GClass23 gclass23_4)
		{
			return gclass23_4;
		}

		// Token: 0x04000300 RID: 768
		private GClass23 gclass23_0;

		// Token: 0x04000301 RID: 769
		private int int_0;

		// Token: 0x04000302 RID: 770
		private int int_1;

		// Token: 0x04000303 RID: 771
		private List<GClass23> list_0;

		// Token: 0x04000304 RID: 772
		private GClass23 gclass23_1;

		// Token: 0x04000305 RID: 773
		private List<GClass23> list_1;

		// Token: 0x04000306 RID: 774
		private GClass23 gclass23_2;

		// Token: 0x04000307 RID: 775
		private GClass23 gclass23_3;

		// Token: 0x04000308 RID: 776
		private List<GClass23> list_2;

		// Token: 0x04000309 RID: 777
		private float[] float_0;

		// Token: 0x0400030A RID: 778
		private bool bool_0;

		// Token: 0x0400030B RID: 779
		private float[] float_1;

		// Token: 0x0200005F RID: 95
		public class Class10 : GClass23
		{
			// Token: 0x06000724 RID: 1828 RVA: 0x0001AB34 File Offset: 0x00018D34
			public Class10(GClass23 gclass23_4, ref GClass23 gclass23_5, int int_2) : base(gclass23_4, new GClass37("<none colspan=" + gclass23_5.method_6("colspan", "1") + ">"))
			{
				this.gclass23_3 = gclass23_5;
				base.String_47 = "none";
				this.int_0 = int_2;
				this.int_1 = int_2 + int.Parse(gclass23_5.method_6("rowspan", "1")) - 1;
			}

			// Token: 0x17000211 RID: 529
			// (get) Token: 0x06000725 RID: 1829 RVA: 0x000069E5 File Offset: 0x00004BE5
			public int Int32_0
			{
				get
				{
					return this.int_0;
				}
			}

			// Token: 0x17000212 RID: 530
			// (get) Token: 0x06000726 RID: 1830 RVA: 0x000069ED File Offset: 0x00004BED
			public int Int32_1
			{
				get
				{
					return this.int_1;
				}
			}

			// Token: 0x0400030C RID: 780
			public readonly GClass23 gclass23_3;

			// Token: 0x0400030D RID: 781
			private int int_0;

			// Token: 0x0400030E RID: 782
			private int int_1;
		}
	}
}
