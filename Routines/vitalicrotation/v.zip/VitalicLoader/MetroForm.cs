﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200001D RID: 29
	public partial class MetroForm : Form, IDisposable, GInterface1
	{
		// Token: 0x060000B7 RID: 183 RVA: 0x00009228 File Offset: 0x00007428
		public MetroForm()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.FormBorderStyle_0 = FormBorderStyle.None;
			base.Name = "MetroForm";
			base.StartPosition = FormStartPosition.CenterScreen;
			base.TransparencyKey = Color.Lavender;
			this.Cursor.Tag = GEnum9.const_0;
			if (this.dictionary_0 == null)
			{
				this.dictionary_0 = new Dictionary<GEnum9, Cursor>();
			}
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x060000B8 RID: 184 RVA: 0x000025CB File Offset: 0x000007CB
		// (set) Token: 0x060000B9 RID: 185 RVA: 0x000025E7 File Offset: 0x000007E7
		[Category("Metro Appearance")]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (this.GClass8_0 != null)
				{
					return this.GClass8_0.GEnum10_0;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x060000BA RID: 186 RVA: 0x000025F0 File Offset: 0x000007F0
		// (set) Token: 0x060000BB RID: 187 RVA: 0x0000260C File Offset: 0x0000080C
		[Category("Metro Appearance")]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (this.GClass8_0 != null)
				{
					return this.GClass8_0.GEnum29_0;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000BC RID: 188 RVA: 0x00002615 File Offset: 0x00000815
		// (set) Token: 0x060000BD RID: 189 RVA: 0x0000261D File Offset: 0x0000081D
		[Browsable(false)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000BE RID: 190 RVA: 0x00002626 File Offset: 0x00000826
		// (set) Token: 0x060000BF RID: 191 RVA: 0x0000262E File Offset: 0x0000082E
		[Category("Metro Appearance")]
		[Browsable(true)]
		public GEnum5 GEnum5_0
		{
			get
			{
				return this.genum5_0;
			}
			set
			{
				this.genum5_0 = value;
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060000C0 RID: 192 RVA: 0x00002637 File Offset: 0x00000837
		[Browsable(false)]
		public override Color BackColor
		{
			get
			{
				return GClass39.GClass46.smethod_0(this.GEnum29_0);
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060000C1 RID: 193 RVA: 0x00002644 File Offset: 0x00000844
		// (set) Token: 0x060000C2 RID: 194 RVA: 0x0000264C File Offset: 0x0000084C
		[Category("Metro Appearance")]
		[Browsable(true)]
		[DefaultValue(GEnum7.const_0)]
		public GEnum7 GEnum7_0
		{
			get
			{
				return this.genum7_0;
			}
			set
			{
				this.genum7_0 = value;
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000C3 RID: 195 RVA: 0x00002655 File Offset: 0x00000855
		// (set) Token: 0x060000C4 RID: 196 RVA: 0x0000265D File Offset: 0x0000085D
		[Category("Metro Appearance")]
		public bool Boolean_0
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000C5 RID: 197 RVA: 0x00002666 File Offset: 0x00000866
		// (set) Token: 0x060000C6 RID: 198 RVA: 0x0000266E File Offset: 0x0000086E
		public Padding Padding_0
		{
			get
			{
				return base.Padding;
			}
			set
			{
				value.Top = Math.Max(value.Top, this.Boolean_1 ? 60 : 0);
				base.Padding = value;
			}
		}

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000C7 RID: 199 RVA: 0x00002697 File Offset: 0x00000897
		protected override Padding DefaultPadding
		{
			get
			{
				return new Padding(20, this.Boolean_1 ? 60 : 20, 20, 20);
			}
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060000C8 RID: 200 RVA: 0x000026B2 File Offset: 0x000008B2
		// (set) Token: 0x060000C9 RID: 201 RVA: 0x000092C0 File Offset: 0x000074C0
		[DefaultValue(true)]
		[Category("Metro Appearance")]
		public bool Boolean_1
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				if (value != this.bool_1)
				{
					Padding padding = base.Padding;
					padding.Top += (value ? 30 : -30);
					base.Padding = padding;
				}
				this.bool_1 = value;
			}
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060000CA RID: 202 RVA: 0x000026BA File Offset: 0x000008BA
		// (set) Token: 0x060000CB RID: 203 RVA: 0x000026C2 File Offset: 0x000008C2
		[Category("Metro Appearance")]
		public bool Boolean_2
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060000CC RID: 204 RVA: 0x000026CB File Offset: 0x000008CB
		// (set) Token: 0x060000CD RID: 205 RVA: 0x000026DD File Offset: 0x000008DD
		[Category("Metro Appearance")]
		[DefaultValue(GEnum6.const_1)]
		public GEnum6 GEnum6_0
		{
			get
			{
				if (!base.IsMdiChild)
				{
					return this.genum6_0;
				}
				return GEnum6.const_0;
			}
			set
			{
				this.genum6_0 = value;
			}
		}

		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060000CE RID: 206 RVA: 0x000026E6 File Offset: 0x000008E6
		// (set) Token: 0x060000CF RID: 207 RVA: 0x000026EE File Offset: 0x000008EE
		[Browsable(false)]
		public FormBorderStyle FormBorderStyle_0
		{
			get
			{
				return base.FormBorderStyle;
			}
			set
			{
				base.FormBorderStyle = value;
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060000D0 RID: 208 RVA: 0x000026F7 File Offset: 0x000008F7
		// (set) Token: 0x060000D1 RID: 209 RVA: 0x000026FF File Offset: 0x000008FF
		public Form Form_0
		{
			get
			{
				return base.MdiParent;
			}
			set
			{
				if (value != null)
				{
					this.method_13();
					this.genum6_0 = GEnum6.const_0;
				}
				base.MdiParent = value;
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060000D2 RID: 210 RVA: 0x00002718 File Offset: 0x00000918
		// (set) Token: 0x060000D3 RID: 211 RVA: 0x00002720 File Offset: 0x00000920
		[DefaultValue(5)]
		[Category("Metro Appearance")]
		public int Int32_0
		{
			get
			{
				return this.int_2;
			}
			set
			{
				this.int_2 = value;
				this.Refresh();
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060000D4 RID: 212 RVA: 0x0000272F File Offset: 0x0000092F
		// (set) Token: 0x060000D5 RID: 213 RVA: 0x00002737 File Offset: 0x00000937
		[Category("Metro Appearance")]
		[DefaultValue(null)]
		public Image Image_0
		{
			get
			{
				return this.image_0;
			}
			set
			{
				this.image_0 = value;
				this.Refresh();
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x060000D6 RID: 214 RVA: 0x00002746 File Offset: 0x00000946
		// (set) Token: 0x060000D7 RID: 215 RVA: 0x0000274E File Offset: 0x0000094E
		[Category("Metro Appearance")]
		public Padding Padding_1
		{
			get
			{
				return this.padding_0;
			}
			set
			{
				this.padding_0 = value;
				this.Refresh();
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x060000D8 RID: 216 RVA: 0x0000275D File Offset: 0x0000095D
		// (set) Token: 0x060000D9 RID: 217 RVA: 0x00002765 File Offset: 0x00000965
		[Category("Metro Appearance")]
		public int Int32_1
		{
			get
			{
				return this.int_3;
			}
			set
			{
				this.int_3 = value;
				this.Refresh();
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x060000DA RID: 218 RVA: 0x00002774 File Offset: 0x00000974
		// (set) Token: 0x060000DB RID: 219 RVA: 0x0000277C File Offset: 0x0000097C
		[DefaultValue(GEnum8.const_0)]
		[Category("Metro Appearance")]
		public GEnum8 GEnum8_0
		{
			get
			{
				return this.genum8_0;
			}
			set
			{
				this.genum8_0 = value;
				this.Refresh();
			}
		}

		// Token: 0x060000DD RID: 221 RVA: 0x00009304 File Offset: 0x00007504
		protected void method_0(GEnum9 genum9_0, Bitmap bitmap_0, int int_4, int int_5)
		{
			Cursor cursor = this.method_2(bitmap_0, int_4, int_5);
			cursor.Tag = genum9_0;
			this.dictionary_0.Add(genum9_0, cursor);
		}

		// Token: 0x060000DE RID: 222 RVA: 0x0000279D File Offset: 0x0000099D
		public void method_1(GEnum9 genum9_0)
		{
			if (this.dictionary_0.ContainsKey(genum9_0))
			{
				this.Cursor = this.dictionary_0[genum9_0];
			}
		}

		// Token: 0x060000DF RID: 223
		[DllImport("user32.dll")]
		[return: MarshalAs(UnmanagedType.Bool)]
		private static extern bool GetIconInfo(IntPtr intptr_0, ref MetroForm.Struct0 struct0_0);

		// Token: 0x060000E0 RID: 224
		[DllImport("user32.dll")]
		private static extern IntPtr CreateIconIndirect(ref MetroForm.Struct0 struct0_0);

		// Token: 0x060000E1 RID: 225 RVA: 0x00009338 File Offset: 0x00007538
		private Cursor method_2(Bitmap bitmap_0, int int_4, int int_5)
		{
			IntPtr intPtr = bitmap_0.GetHicon();
			MetroForm.Struct0 @struct = default(MetroForm.Struct0);
			MetroForm.GetIconInfo(intPtr, ref @struct);
			@struct.int_0 = int_4;
			@struct.int_1 = int_5;
			@struct.bool_0 = false;
			intPtr = MetroForm.CreateIconIndirect(ref @struct);
			return new Cursor(intPtr);
		}

		// Token: 0x060000E2 RID: 226
		[DllImport("user32.dll")]
		private static extern IntPtr GetForegroundWindow();

		// Token: 0x060000E3 RID: 227 RVA: 0x00009384 File Offset: 0x00007584
		public bool method_3()
		{
			IntPtr foregroundWindow = MetroForm.GetForegroundWindow();
			return foregroundWindow == base.Handle;
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x000093A4 File Offset: 0x000075A4
		protected override void OnPaint(PaintEventArgs e)
		{
			Color color = GClass39.GClass46.smethod_0(this.GEnum29_0);
			GClass39.GClass56.smethod_0(this.GEnum29_0);
			e.Graphics.Clear(color);
			using (SolidBrush solidBrush = GClass39.smethod_1(this.GEnum10_0))
			{
				Rectangle rect = new Rectangle(0, 0, base.Width, this.int_2);
				e.Graphics.FillRectangle(solidBrush, rect);
			}
			if (this.GEnum7_0 != GEnum7.const_0)
			{
				Color color2 = GClass39.GClass40.smethod_0(this.GEnum29_0);
				using (Pen pen = new Pen(color2))
				{
					e.Graphics.DrawLines(pen, new Point[]
					{
						new Point(0, this.int_2),
						new Point(0, base.Height - 1),
						new Point(base.Width - 1, base.Height - 1),
						new Point(base.Width - 1, this.int_2)
					});
				}
			}
			if (this.image_0 != null && this.int_3 != 0)
			{
				Image image = Class25.smethod_0(this.image_0, new Rectangle(0, 0, this.int_3, this.int_3));
				switch (this.genum8_0)
				{
				case GEnum8.const_0:
					e.Graphics.DrawImage(image, this.padding_0.Left, this.padding_0.Top);
					break;
				case GEnum8.const_1:
					e.Graphics.DrawImage(image, base.ClientRectangle.Right - (this.padding_0.Right + image.Width), this.padding_0.Top);
					break;
				case GEnum8.const_2:
					e.Graphics.DrawImage(image, this.padding_0.Left, base.ClientRectangle.Bottom - (image.Height + this.padding_0.Bottom));
					break;
				case GEnum8.const_3:
					e.Graphics.DrawImage(image, base.ClientRectangle.Right - (this.padding_0.Right + image.Width), base.ClientRectangle.Bottom - (image.Height + this.padding_0.Bottom));
					break;
				}
			}
			if (this.Boolean_2 && (base.SizeGripStyle == SizeGripStyle.Auto || base.SizeGripStyle == SizeGripStyle.Show))
			{
				using (SolidBrush solidBrush2 = new SolidBrush(GClass39.GClass56.GClass57.smethod_3(this.GEnum29_0)))
				{
					Size size = new Size(2, 2);
					e.Graphics.FillRectangles(solidBrush2, new Rectangle[]
					{
						new Rectangle(new Point(base.ClientRectangle.Width - 6, base.ClientRectangle.Height - 6), size),
						new Rectangle(new Point(base.ClientRectangle.Width - 10, base.ClientRectangle.Height - 10), size),
						new Rectangle(new Point(base.ClientRectangle.Width - 10, base.ClientRectangle.Height - 6), size),
						new Rectangle(new Point(base.ClientRectangle.Width - 6, base.ClientRectangle.Height - 10), size),
						new Rectangle(new Point(base.ClientRectangle.Width - 14, base.ClientRectangle.Height - 6), size),
						new Rectangle(new Point(base.ClientRectangle.Width - 6, base.ClientRectangle.Height - 14), size)
					});
				}
			}
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x00009830 File Offset: 0x00007A30
		private TextFormatFlags method_4()
		{
			switch (this.GEnum5_0)
			{
			case GEnum5.const_0:
				return TextFormatFlags.Default;
			case GEnum5.const_1:
				return TextFormatFlags.HorizontalCenter;
			case GEnum5.const_2:
				return TextFormatFlags.Right;
			default:
				throw new InvalidOperationException();
			}
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x000027BF File Offset: 0x000009BF
		protected override void OnClosing(CancelEventArgs e)
		{
			if (!(this is GForm1))
			{
				GForm1.smethod_8();
			}
			base.OnClosing(e);
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x000027D5 File Offset: 0x000009D5
		protected override void OnClosed(EventArgs e)
		{
			this.method_13();
			base.OnClosed(e);
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x000027E4 File Offset: 0x000009E4
		[SecuritySafeCritical]
		public bool method_5()
		{
			return Class29.SetForegroundWindow(base.Handle);
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x00009864 File Offset: 0x00007A64
		protected override void OnLoad(EventArgs e)
		{
			base.OnLoad(e);
			if (base.DesignMode)
			{
				return;
			}
			FormStartPosition startPosition = base.StartPosition;
			if (startPosition != FormStartPosition.CenterScreen)
			{
				if (startPosition == FormStartPosition.CenterParent)
				{
					base.CenterToParent();
				}
			}
			else if (base.IsMdiChild)
			{
				base.CenterToParent();
			}
			else
			{
				base.CenterToScreen();
			}
			this.method_14();
			if (base.ControlBox)
			{
				this.method_9(MetroForm.Enum0.const_2);
				if (base.MaximizeBox)
				{
					this.method_9(MetroForm.Enum0.const_1);
				}
				if (base.MinimizeBox)
				{
					this.method_9(MetroForm.Enum0.const_0);
				}
				this.method_11();
			}
			this.method_12();
		}

		// Token: 0x060000EA RID: 234 RVA: 0x000098F0 File Offset: 0x00007AF0
		protected override void OnActivated(EventArgs e)
		{
			base.OnActivated(e);
			if (this.genum6_0 == GEnum6.const_4 && MetroForm.smethod_0() && MetroForm.smethod_1())
			{
				int num = 2;
				Class26.DwmSetWindowAttribute_1(base.Handle, 2, ref num, 4);
				Class26.Struct7 @struct = new Class26.Struct7
				{
					int_3 = 1,
					int_0 = 0,
					int_1 = 0,
					int_2 = 0
				};
				Class26.DwmExtendFrameIntoClientArea(base.Handle, ref @struct);
			}
		}

		// Token: 0x060000EB RID: 235 RVA: 0x000027F1 File Offset: 0x000009F1
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x060000EC RID: 236 RVA: 0x00002800 File Offset: 0x00000A00
		protected override void OnResizeEnd(EventArgs e)
		{
			base.OnResizeEnd(e);
			this.method_11();
		}

		// Token: 0x060000ED RID: 237 RVA: 0x00009968 File Offset: 0x00007B68
		protected override void WndProc(ref Message m)
		{
			if (base.DesignMode)
			{
				base.WndProc(ref m);
				return;
			}
			int msg = m.Msg;
			if (msg <= 163)
			{
				if (msg != 32)
				{
					if (msg != 132)
					{
						if (msg != 163)
						{
							goto IL_11C;
						}
					}
					else
					{
						Class29.Enum9 @enum = this.method_7(m.HWnd, m.WParam, m.LParam);
						if (@enum != Class29.Enum9.const_1)
						{
							m.Result = (IntPtr)((long)@enum);
							return;
						}
						if ((GEnum9)this.Cursor.Tag == GEnum9.const_1)
						{
							this.method_1(GEnum9.const_0);
							goto IL_11C;
						}
						goto IL_11C;
					}
				}
				else
				{
					int num = m.LParam.ToInt32() << 16 >> 16;
					if (num == 2)
					{
						this.method_1(GEnum9.const_1);
						m.Result = (IntPtr)1;
						return;
					}
					goto IL_11C;
				}
			}
			else if (msg != 274)
			{
				if (msg != 515)
				{
					if (msg != 798)
					{
						goto IL_11C;
					}
					goto IL_11C;
				}
			}
			else
			{
				int num2 = m.WParam.ToInt32() & 65520;
				int num3 = num2;
				if (num3 != 61456)
				{
					if (num3 != 61488 && num3 != 61728)
					{
						goto IL_11C;
					}
					goto IL_11C;
				}
				else
				{
					if (!this.Boolean_0)
					{
						return;
					}
					goto IL_11C;
				}
			}
			if (!base.MaximizeBox)
			{
				return;
			}
			IL_11C:
			base.WndProc(ref m);
			int msg2 = m.Msg;
			if (msg2 != 36)
			{
				return;
			}
			this.method_6(m.HWnd, m.LParam);
		}

		// Token: 0x060000EE RID: 238 RVA: 0x00009ABC File Offset: 0x00007CBC
		[SecuritySafeCritical]
		private unsafe void method_6(IntPtr intptr_0, IntPtr intptr_1)
		{
			Class29.Struct16* ptr = (Class29.Struct16*)((void*)intptr_1);
			Screen screen = Screen.FromHandle(intptr_0);
			ptr->struct9_1.int_0 = screen.WorkingArea.Width;
			ptr->struct9_1.int_1 = screen.WorkingArea.Height;
			ptr->struct9_2.int_0 = Math.Abs(screen.WorkingArea.Left - screen.Bounds.Left);
			ptr->struct9_2.int_1 = Math.Abs(screen.WorkingArea.Top - screen.Bounds.Top);
		}

		// Token: 0x060000EF RID: 239 RVA: 0x00009B68 File Offset: 0x00007D68
		private Class29.Enum9 method_7(IntPtr intptr_0, IntPtr intptr_1, IntPtr intptr_2)
		{
			Point pt = new Point((int)((short)((int)intptr_2)), (int)((short)((int)intptr_2 >> 16)));
			int num = Math.Max(this.Padding_0.Right, this.Padding_0.Bottom);
			if (this.Boolean_2 && base.RectangleToScreen(new Rectangle(base.ClientRectangle.Width - num, base.ClientRectangle.Height - num, num, num)).Contains(pt))
			{
				return Class29.Enum9.const_14;
			}
			if (base.RectangleToScreen(new Rectangle(this.int_2, this.int_2, base.ClientRectangle.Width - 2 * this.int_2, 50)).Contains(pt))
			{
				return Class29.Enum9.const_2;
			}
			return Class29.Enum9.const_1;
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x00009C38 File Offset: 0x00007E38
		protected override void OnMouseDown(MouseEventArgs e)
		{
			base.OnMouseDown(e);
			if (e.Button == MouseButtons.Left && this.Boolean_0)
			{
				if (base.WindowState == FormWindowState.Maximized)
				{
					return;
				}
				if (base.Width - this.int_2 > e.Location.X && e.Location.X > this.int_2 && e.Location.Y > this.int_2)
				{
					this.method_8();
				}
			}
		}

		// Token: 0x060000F1 RID: 241 RVA: 0x0000280F File Offset: 0x00000A0F
		[SecuritySafeCritical]
		private void method_8()
		{
			Class29.ReleaseCapture();
			Class29.SendMessage(base.Handle, 161, 2, 0);
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x00009CBC File Offset: 0x00007EBC
		[SecuritySafeCritical]
		private static bool smethod_0()
		{
			if (Environment.OSVersion.Version.Major <= 5)
			{
				return false;
			}
			bool result;
			Class26.DwmIsCompositionEnabled_1(out result);
			return result;
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x0000282A File Offset: 0x00000A2A
		private static bool smethod_1()
		{
			return Environment.OSVersion.Version.Major > 5 && SystemInformation.IsDropShadowEnabled;
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x00009CE8 File Offset: 0x00007EE8
		private void method_9(MetroForm.Enum0 enum0_0)
		{
			if (this.dictionary_1 == null)
			{
				this.dictionary_1 = new Dictionary<MetroForm.Enum0, MetroForm.Class7>();
			}
			if (this.dictionary_1.ContainsKey(enum0_0))
			{
				return;
			}
			MetroForm.Class7 @class = new MetroForm.Class7(this);
			if (enum0_0 == MetroForm.Enum0.const_2)
			{
				@class.Text = "r";
			}
			else if (enum0_0 == MetroForm.Enum0.const_0)
			{
				@class.Text = "0";
			}
			else if (enum0_0 == MetroForm.Enum0.const_1)
			{
				if (base.WindowState == FormWindowState.Normal)
				{
					@class.Text = "1";
				}
				else
				{
					@class.Text = "2";
				}
			}
			@class.GEnum10_0 = this.GEnum10_0;
			@class.GEnum29_0 = this.GEnum29_0;
			@class.Tag = enum0_0;
			@class.Size = new Size(25, 20);
			@class.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
			@class.Click += this.method_10;
			base.Controls.Add(@class);
			this.dictionary_1.Add(enum0_0, @class);
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x00009DCC File Offset: 0x00007FCC
		private void method_10(object sender, EventArgs e)
		{
			MetroForm.Class7 @class = sender as MetroForm.Class7;
			if (@class != null)
			{
				MetroForm.Enum0 @enum = (MetroForm.Enum0)@class.Tag;
				if (@enum == MetroForm.Enum0.const_2)
				{
					base.Close();
					return;
				}
				if (@enum == MetroForm.Enum0.const_0)
				{
					base.WindowState = FormWindowState.Minimized;
					return;
				}
				if (@enum == MetroForm.Enum0.const_1)
				{
					if (base.WindowState == FormWindowState.Normal)
					{
						base.WindowState = FormWindowState.Maximized;
						@class.Text = "2";
						return;
					}
					base.WindowState = FormWindowState.Normal;
					@class.Text = "1";
				}
			}
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x00009E38 File Offset: 0x00008038
		private void method_11()
		{
			if (!base.ControlBox)
			{
				return;
			}
			Dictionary<int, MetroForm.Enum0> dictionary = new Dictionary<int, MetroForm.Enum0>(3)
			{
				{
					0,
					MetroForm.Enum0.const_2
				},
				{
					1,
					MetroForm.Enum0.const_1
				},
				{
					2,
					MetroForm.Enum0.const_0
				}
			};
			Point location = new Point(base.ClientRectangle.Width - this.int_2 - 25, this.int_2);
			int num = location.X - 25;
			MetroForm.Class7 @class = null;
			if (this.dictionary_1.Count == 1)
			{
				using (Dictionary<MetroForm.Enum0, MetroForm.Class7>.Enumerator enumerator = this.dictionary_1.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						KeyValuePair<MetroForm.Enum0, MetroForm.Class7> keyValuePair = enumerator.Current;
						keyValuePair.Value.Location = location;
					}
					goto IL_148;
				}
			}
			foreach (KeyValuePair<int, MetroForm.Enum0> keyValuePair2 in dictionary)
			{
				bool flag = this.dictionary_1.ContainsKey(keyValuePair2.Value);
				if (@class == null && flag)
				{
					@class = this.dictionary_1[keyValuePair2.Value];
					@class.Location = location;
				}
				else if (@class != null && flag)
				{
					this.dictionary_1[keyValuePair2.Value].Location = new Point(num, this.int_2);
					num -= 25;
				}
			}
			IL_148:
			this.Refresh();
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x060000F7 RID: 247 RVA: 0x00009FB0 File Offset: 0x000081B0
		protected override CreateParams CreateParams
		{
			get
			{
				CreateParams createParams = base.CreateParams;
				createParams.Style |= 131072;
				if (this.GEnum6_0 == GEnum6.const_3)
				{
					createParams.ClassStyle |= 131072;
				}
				return createParams;
			}
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x00009FF4 File Offset: 0x000081F4
		private void method_12()
		{
			switch (this.GEnum6_0)
			{
			case GEnum6.const_1:
				this.form_0 = new MetroForm.GForm4(this);
				return;
			case GEnum6.const_2:
				this.form_0 = new MetroForm.GForm5(this);
				return;
			default:
				return;
			}
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x0000A034 File Offset: 0x00008234
		private void method_13()
		{
			if (this.form_0 != null && !this.form_0.IsDisposed)
			{
				this.form_0.Visible = false;
				base.Owner = this.form_0.Owner;
				this.form_0.Owner = null;
				this.form_0.Dispose();
				this.form_0 = null;
				return;
			}
		}

		// Token: 0x060000FA RID: 250 RVA: 0x0000A094 File Offset: 0x00008294
		[SecuritySafeCritical]
		public void method_14()
		{
			IntPtr systemMenu = Class29.GetSystemMenu(base.Handle, false);
			if (systemMenu == IntPtr.Zero)
			{
				return;
			}
			int menuItemCount = Class29.GetMenuItemCount(systemMenu);
			if (menuItemCount <= 0)
			{
				return;
			}
			Class29.RemoveMenu(systemMenu, (uint)(menuItemCount - 1), 5120U);
			Class29.RemoveMenu(systemMenu, (uint)(menuItemCount - 2), 5120U);
			Class29.DrawMenuBar(base.Handle);
		}

		// Token: 0x060000FB RID: 251 RVA: 0x0000A0F4 File Offset: 0x000082F4
		private Rectangle method_15(Graphics graphics_0, Rectangle rectangle_0, Font font_0, string string_0, TextFormatFlags textFormatFlags_0)
		{
			Size proposedSize = new Size(int.MaxValue, int.MinValue);
			Size size = TextRenderer.MeasureText(graphics_0, string_0, font_0, proposedSize, textFormatFlags_0);
			return new Rectangle(rectangle_0.X, rectangle_0.Y, size.Width, size.Height);
		}

		// Token: 0x0400004D RID: 77
		private const int int_0 = 131072;

		// Token: 0x0400004E RID: 78
		private const int int_1 = 131072;

		// Token: 0x0400004F RID: 79
		private GEnum10 genum10_0 = GEnum10.const_3;

		// Token: 0x04000050 RID: 80
		private GEnum29 genum29_0 = GEnum29.const_1;

		// Token: 0x04000051 RID: 81
		private GClass8 gclass8_0;

		// Token: 0x04000052 RID: 82
		private GEnum5 genum5_0;

		// Token: 0x04000053 RID: 83
		private GEnum7 genum7_0;

		// Token: 0x04000054 RID: 84
		private bool bool_0 = true;

		// Token: 0x04000055 RID: 85
		private bool bool_1 = true;

		// Token: 0x04000056 RID: 86
		private bool bool_2 = true;

		// Token: 0x04000057 RID: 87
		private GEnum6 genum6_0 = GEnum6.const_1;

		// Token: 0x04000058 RID: 88
		private int int_2 = 5;

		// Token: 0x04000059 RID: 89
		private Image image_0;

		// Token: 0x0400005A RID: 90
		private Padding padding_0;

		// Token: 0x0400005B RID: 91
		private int int_3;

		// Token: 0x0400005C RID: 92
		private GEnum8 genum8_0;

		// Token: 0x0400005D RID: 93
		private Dictionary<GEnum9, Cursor> dictionary_0;

		// Token: 0x0400005E RID: 94
		private Dictionary<MetroForm.Enum0, MetroForm.Class7> dictionary_1;

		// Token: 0x0400005F RID: 95
		private Form form_0;

		// Token: 0x0200001E RID: 30
		private struct Struct0
		{
			// Token: 0x04000060 RID: 96
			public bool bool_0;

			// Token: 0x04000061 RID: 97
			public int int_0;

			// Token: 0x04000062 RID: 98
			public int int_1;

			// Token: 0x04000063 RID: 99
			public IntPtr intptr_0;

			// Token: 0x04000064 RID: 100
			public IntPtr intptr_1;
		}

		// Token: 0x0200001F RID: 31
		private enum Enum0
		{
			// Token: 0x04000066 RID: 102
			const_0,
			// Token: 0x04000067 RID: 103
			const_1,
			// Token: 0x04000068 RID: 104
			const_2
		}

		// Token: 0x02000020 RID: 32
		private class Class7 : Button, GInterface2
		{
			// Token: 0x060000FC RID: 252 RVA: 0x00002845 File Offset: 0x00000A45
			public Class7(MetroForm metroForm_1)
			{
				base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
				this.metroForm_0 = metroForm_1;
			}

			// Token: 0x14000002 RID: 2
			// (add) Token: 0x060000FD RID: 253 RVA: 0x0000A140 File Offset: 0x00008340
			// (remove) Token: 0x060000FE RID: 254 RVA: 0x0000A178 File Offset: 0x00008378
			[Category("Metro Appearance")]
			public event EventHandler<GEventArgs3> Event_2
			{
				add
				{
					EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
					EventHandler<GEventArgs3> eventHandler2;
					do
					{
						eventHandler2 = eventHandler;
						EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
						eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
					}
					while (eventHandler != eventHandler2);
				}
				remove
				{
					EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
					EventHandler<GEventArgs3> eventHandler2;
					do
					{
						eventHandler2 = eventHandler;
						EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
						eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
					}
					while (eventHandler != eventHandler2);
				}
			}

			// Token: 0x060000FF RID: 255 RVA: 0x00002860 File Offset: 0x00000A60
			protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
			{
				if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
				{
					this.eventHandler_0(this, geventArgs3_0);
				}
			}

			// Token: 0x14000003 RID: 3
			// (add) Token: 0x06000100 RID: 256 RVA: 0x0000A1B0 File Offset: 0x000083B0
			// (remove) Token: 0x06000101 RID: 257 RVA: 0x0000A1E8 File Offset: 0x000083E8
			[Category("Metro Appearance")]
			public event EventHandler<GEventArgs3> Event_3
			{
				add
				{
					EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
					EventHandler<GEventArgs3> eventHandler2;
					do
					{
						eventHandler2 = eventHandler;
						EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
						eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
					}
					while (eventHandler != eventHandler2);
				}
				remove
				{
					EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
					EventHandler<GEventArgs3> eventHandler2;
					do
					{
						eventHandler2 = eventHandler;
						EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
						eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
					}
					while (eventHandler != eventHandler2);
				}
			}

			// Token: 0x06000102 RID: 258 RVA: 0x00002880 File Offset: 0x00000A80
			protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
			{
				if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
				{
					this.eventHandler_1(this, geventArgs3_0);
				}
			}

			// Token: 0x14000004 RID: 4
			// (add) Token: 0x06000103 RID: 259 RVA: 0x0000A220 File Offset: 0x00008420
			// (remove) Token: 0x06000104 RID: 260 RVA: 0x0000A258 File Offset: 0x00008458
			[Category("Metro Appearance")]
			public event EventHandler<GEventArgs3> Event_4
			{
				add
				{
					EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
					EventHandler<GEventArgs3> eventHandler2;
					do
					{
						eventHandler2 = eventHandler;
						EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
						eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
					}
					while (eventHandler != eventHandler2);
				}
				remove
				{
					EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
					EventHandler<GEventArgs3> eventHandler2;
					do
					{
						eventHandler2 = eventHandler;
						EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
						eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
					}
					while (eventHandler != eventHandler2);
				}
			}

			// Token: 0x06000105 RID: 261 RVA: 0x000028A0 File Offset: 0x00000AA0
			protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
			{
				if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
				{
					this.eventHandler_2(this, geventArgs3_0);
				}
			}

			// Token: 0x17000031 RID: 49
			// (get) Token: 0x06000106 RID: 262 RVA: 0x0000A290 File Offset: 0x00008490
			// (set) Token: 0x06000107 RID: 263 RVA: 0x000028C0 File Offset: 0x00000AC0
			[Category("Metro Appearance")]
			[DefaultValue(GEnum10.const_0)]
			public GEnum10 GEnum10_0
			{
				get
				{
					if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
					{
						return this.genum10_0;
					}
					if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
					{
						return this.GClass8_0.GEnum10_0;
					}
					if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
					{
						return GEnum10.const_3;
					}
					return this.genum10_0;
				}
				set
				{
					this.genum10_0 = value;
				}
			}

			// Token: 0x17000032 RID: 50
			// (get) Token: 0x06000108 RID: 264 RVA: 0x0000A2E8 File Offset: 0x000084E8
			// (set) Token: 0x06000109 RID: 265 RVA: 0x000028C9 File Offset: 0x00000AC9
			[Category("Metro Appearance")]
			[DefaultValue(GEnum29.const_0)]
			public GEnum29 GEnum29_0
			{
				get
				{
					if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
					{
						return this.genum29_0;
					}
					if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
					{
						return this.GClass8_0.GEnum29_0;
					}
					if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
					{
						return GEnum29.const_1;
					}
					return this.genum29_0;
				}
				set
				{
					this.genum29_0 = value;
				}
			}

			// Token: 0x17000033 RID: 51
			// (get) Token: 0x0600010A RID: 266 RVA: 0x000028D2 File Offset: 0x00000AD2
			// (set) Token: 0x0600010B RID: 267 RVA: 0x000028DA File Offset: 0x00000ADA
			[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
			[Browsable(false)]
			public GClass8 GClass8_0
			{
				get
				{
					return this.gclass8_0;
				}
				set
				{
					this.gclass8_0 = value;
				}
			}

			// Token: 0x17000034 RID: 52
			// (get) Token: 0x0600010C RID: 268 RVA: 0x000028E3 File Offset: 0x00000AE3
			// (set) Token: 0x0600010D RID: 269 RVA: 0x000028EB File Offset: 0x00000AEB
			[DefaultValue(false)]
			[Category("Metro Appearance")]
			public bool Boolean_8
			{
				get
				{
					return this.bool_0;
				}
				set
				{
					this.bool_0 = value;
				}
			}

			// Token: 0x17000035 RID: 53
			// (get) Token: 0x0600010E RID: 270 RVA: 0x000028F4 File Offset: 0x00000AF4
			// (set) Token: 0x0600010F RID: 271 RVA: 0x000028FC File Offset: 0x00000AFC
			[DefaultValue(false)]
			[Category("Metro Appearance")]
			public bool Boolean_9
			{
				get
				{
					return this.bool_1;
				}
				set
				{
					this.bool_1 = value;
				}
			}

			// Token: 0x17000036 RID: 54
			// (get) Token: 0x06000110 RID: 272 RVA: 0x00002905 File Offset: 0x00000B05
			// (set) Token: 0x06000111 RID: 273 RVA: 0x0000290D File Offset: 0x00000B0D
			[DefaultValue(false)]
			[Category("Metro Appearance")]
			public bool Boolean_10
			{
				get
				{
					return this.bool_2;
				}
				set
				{
					this.bool_2 = value;
				}
			}

			// Token: 0x17000037 RID: 55
			// (get) Token: 0x06000112 RID: 274 RVA: 0x00002916 File Offset: 0x00000B16
			// (set) Token: 0x06000113 RID: 275 RVA: 0x00002923 File Offset: 0x00000B23
			[Category("Metro Behaviour")]
			[DefaultValue(false)]
			[Browsable(false)]
			public bool Boolean_11
			{
				get
				{
					return base.GetStyle(ControlStyles.Selectable);
				}
				set
				{
					base.SetStyle(ControlStyles.Selectable, value);
				}
			}

			// Token: 0x06000114 RID: 276 RVA: 0x0000A340 File Offset: 0x00008540
			protected override void OnPaint(PaintEventArgs e)
			{
				GEnum29 genum = this.GEnum29_0;
				Color color;
				if (this.metroForm_0 != null)
				{
					if (this.metroForm_0 != null)
					{
						genum = ((GInterface1)this.metroForm_0).GEnum29_0;
						color = GClass39.GClass46.smethod_0(genum);
					}
					else if (this.metroForm_0 is GInterface2)
					{
						color = GClass39.smethod_0(this.GEnum10_0);
					}
					else
					{
						color = this.metroForm_0.BackColor;
					}
				}
				else
				{
					color = GClass39.GClass46.smethod_0(genum);
				}
				Color foreColor;
				if (this.bool_3 && !this.bool_4 && base.Enabled)
				{
					foreColor = GClass39.GClass56.GClass57.smethod_0(genum);
					color = GClass39.GClass46.GClass47.smethod_0(genum);
				}
				else if (this.bool_3 && this.bool_4 && base.Enabled)
				{
					foreColor = GClass39.GClass56.GClass57.smethod_2(genum);
					color = GClass39.smethod_0(this.GEnum10_0);
				}
				else if (!base.Enabled)
				{
					foreColor = GClass39.GClass56.GClass57.smethod_3(genum);
					color = GClass39.GClass46.GClass47.smethod_3(genum);
				}
				else
				{
					foreColor = GClass39.GClass56.GClass57.smethod_0(genum);
				}
				e.Graphics.Clear(color);
				Font font = new Font("Webdings", 9.25f);
				TextRenderer.DrawText(e.Graphics, this.Text, font, base.ClientRectangle, foreColor, color, TextFormatFlags.EndEllipsis | TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
			}

			// Token: 0x06000115 RID: 277 RVA: 0x00002931 File Offset: 0x00000B31
			protected override void OnMouseEnter(EventArgs e)
			{
				this.bool_3 = true;
				base.Invalidate();
				this.metroForm_0.method_1(GEnum9.const_0);
				base.OnMouseEnter(e);
			}

			// Token: 0x06000116 RID: 278 RVA: 0x00002953 File Offset: 0x00000B53
			protected override void OnMouseDown(MouseEventArgs e)
			{
				if (e.Button == MouseButtons.Left)
				{
					this.bool_4 = true;
					base.Invalidate();
				}
				base.OnMouseDown(e);
			}

			// Token: 0x06000117 RID: 279 RVA: 0x00002976 File Offset: 0x00000B76
			protected override void OnMouseUp(MouseEventArgs e)
			{
				this.bool_4 = false;
				base.Invalidate();
				base.OnMouseUp(e);
			}

			// Token: 0x06000118 RID: 280 RVA: 0x0000298C File Offset: 0x00000B8C
			protected override void OnMouseLeave(EventArgs e)
			{
				this.bool_3 = false;
				base.Invalidate();
				base.OnMouseLeave(e);
			}

			// Token: 0x04000069 RID: 105
			private EventHandler<GEventArgs3> eventHandler_0;

			// Token: 0x0400006A RID: 106
			private EventHandler<GEventArgs3> eventHandler_1;

			// Token: 0x0400006B RID: 107
			private EventHandler<GEventArgs3> eventHandler_2;

			// Token: 0x0400006C RID: 108
			private GEnum10 genum10_0;

			// Token: 0x0400006D RID: 109
			private GEnum29 genum29_0;

			// Token: 0x0400006E RID: 110
			private GClass8 gclass8_0;

			// Token: 0x0400006F RID: 111
			private bool bool_0;

			// Token: 0x04000070 RID: 112
			private bool bool_1;

			// Token: 0x04000071 RID: 113
			private bool bool_2;

			// Token: 0x04000072 RID: 114
			private bool bool_3;

			// Token: 0x04000073 RID: 115
			private bool bool_4;

			// Token: 0x04000074 RID: 116
			protected MetroForm metroForm_0;
		}

		// Token: 0x02000021 RID: 33
		protected abstract class GForm2 : Form
		{
			// Token: 0x06000119 RID: 281 RVA: 0x0000A458 File Offset: 0x00008658
			protected GForm2(Form form_1, int int_6, int int_7)
			{
				this.TargetForm = form_1;
				this.int_4 = int_6;
				this.int_5 = int_7;
				this.TargetForm.Activated += this.method_1;
				this.TargetForm.ResizeBegin += this.method_3;
				this.TargetForm.ResizeEnd += this.method_7;
				this.TargetForm.VisibleChanged += this.method_2;
				this.TargetForm.SizeChanged += this.method_6;
				this.TargetForm.Move += this.method_4;
				this.TargetForm.Resize += this.method_5;
				if (this.TargetForm.Owner != null)
				{
					base.Owner = this.TargetForm.Owner;
				}
				this.TargetForm.Owner = this;
				base.MaximizeBox = false;
				base.MinimizeBox = false;
				base.ShowInTaskbar = false;
				base.ShowIcon = false;
				base.FormBorderStyle = FormBorderStyle.None;
				base.Bounds = this.method_0();
			}

			// Token: 0x17000038 RID: 56
			// (get) Token: 0x0600011A RID: 282 RVA: 0x000029A2 File Offset: 0x00000BA2
			// (set) Token: 0x0600011B RID: 283 RVA: 0x000029AA File Offset: 0x00000BAA
			private protected Form TargetForm { protected get; private set; }

			// Token: 0x17000039 RID: 57
			// (get) Token: 0x0600011C RID: 284 RVA: 0x0000A57C File Offset: 0x0000877C
			protected override CreateParams CreateParams
			{
				get
				{
					CreateParams createParams = base.CreateParams;
					createParams.ExStyle |= this.int_5;
					return createParams;
				}
			}

			// Token: 0x0600011D RID: 285 RVA: 0x0000A5A4 File Offset: 0x000087A4
			private Rectangle method_0()
			{
				Rectangle bounds = this.TargetForm.Bounds;
				bounds.Inflate(this.int_4, this.int_4);
				return bounds;
			}

			// Token: 0x0600011E RID: 286
			protected abstract void vmethod_0();

			// Token: 0x0600011F RID: 287
			protected abstract void vmethod_1();

			// Token: 0x06000120 RID: 288 RVA: 0x000029B3 File Offset: 0x00000BB3
			protected override void OnDeactivate(EventArgs e)
			{
				base.OnDeactivate(e);
				this.bool_0 = true;
			}

			// Token: 0x06000121 RID: 289 RVA: 0x000029C3 File Offset: 0x00000BC3
			private void method_1(object sender, EventArgs e)
			{
				if (base.Visible)
				{
					base.Update();
				}
				if (this.bool_0)
				{
					base.Visible = true;
					this.bool_0 = false;
					return;
				}
				base.BringToFront();
			}

			// Token: 0x06000122 RID: 290 RVA: 0x000029F0 File Offset: 0x00000BF0
			private void method_2(object sender, EventArgs e)
			{
				base.Visible = (this.TargetForm.Visible && this.TargetForm.WindowState != FormWindowState.Minimized);
				base.Update();
			}

			// Token: 0x1700003A RID: 58
			// (get) Token: 0x06000123 RID: 291 RVA: 0x00002A1F File Offset: 0x00000C1F
			private bool Boolean_0
			{
				get
				{
					return this.long_1 > 0L;
				}
			}

			// Token: 0x06000124 RID: 292 RVA: 0x0000A5D4 File Offset: 0x000087D4
			private void method_3(object sender, EventArgs e)
			{
				this.long_1 = DateTime.UtcNow.Ticks;
			}

			// Token: 0x06000125 RID: 293 RVA: 0x00002A32 File Offset: 0x00000C32
			private void method_4(object sender, EventArgs e)
			{
				if (this.TargetForm.Visible && this.TargetForm.WindowState == FormWindowState.Normal)
				{
					base.Bounds = this.method_0();
					return;
				}
				base.Visible = false;
			}

			// Token: 0x06000126 RID: 294 RVA: 0x00002A62 File Offset: 0x00000C62
			private void method_5(object sender, EventArgs e)
			{
				this.vmethod_1();
			}

			// Token: 0x06000127 RID: 295 RVA: 0x00002A6A File Offset: 0x00000C6A
			private void method_6(object sender, EventArgs e)
			{
				base.Bounds = this.method_0();
				if (this.Boolean_0)
				{
					return;
				}
				this.method_8();
			}

			// Token: 0x06000128 RID: 296 RVA: 0x00002A87 File Offset: 0x00000C87
			private void method_7(object sender, EventArgs e)
			{
				this.long_1 = 0L;
				this.method_8();
			}

			// Token: 0x06000129 RID: 297 RVA: 0x00002A9E File Offset: 0x00000C9E
			private void method_8()
			{
				if (this.TargetForm.Visible && this.TargetForm.WindowState != FormWindowState.Minimized)
				{
					this.vmethod_0();
				}
			}

			// Token: 0x04000075 RID: 117
			protected const int int_0 = 32;

			// Token: 0x04000076 RID: 118
			protected const int int_1 = 524288;

			// Token: 0x04000077 RID: 119
			protected const int int_2 = 134217728;

			// Token: 0x04000078 RID: 120
			private const int int_3 = 10000;

			// Token: 0x04000079 RID: 121
			private const long long_0 = 10000000L;

			// Token: 0x0400007A RID: 122
			private readonly int int_4;

			// Token: 0x0400007B RID: 123
			private readonly int int_5;

			// Token: 0x0400007C RID: 124
			private bool bool_0;

			// Token: 0x0400007D RID: 125
			private long long_1;

			// Token: 0x0400007E RID: 126
			[CompilerGenerated]
			private Form form_0;
		}

		// Token: 0x02000022 RID: 34
		protected class GForm3 : MetroForm.GForm2
		{
			// Token: 0x0600012A RID: 298 RVA: 0x00002AC1 File Offset: 0x00000CC1
			public GForm3(Form form_1) : base(form_1, 0, 134217760)
			{
				base.FormBorderStyle = FormBorderStyle.SizableToolWindow;
			}

			// Token: 0x0600012B RID: 299 RVA: 0x00002AD7 File Offset: 0x00000CD7
			protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
			{
				if (specified == BoundsSpecified.Size)
				{
					return;
				}
				base.SetBoundsCore(x, y, width, height, specified);
			}

			// Token: 0x0600012C RID: 300 RVA: 0x00002AED File Offset: 0x00000CED
			protected override void vmethod_0()
			{
				base.Visible = true;
			}

			// Token: 0x0600012D RID: 301 RVA: 0x00002470 File Offset: 0x00000670
			protected override void vmethod_1()
			{
			}
		}

		// Token: 0x02000023 RID: 35
		protected class GForm4 : MetroForm.GForm2
		{
			// Token: 0x0600012E RID: 302 RVA: 0x00002AF6 File Offset: 0x00000CF6
			public GForm4(Form form_1) : base(form_1, 6, 134742048)
			{
			}

			// Token: 0x0600012F RID: 303 RVA: 0x00002B14 File Offset: 0x00000D14
			protected override void OnLoad(EventArgs e)
			{
				base.OnLoad(e);
				this.vmethod_0();
			}

			// Token: 0x06000130 RID: 304 RVA: 0x00002B23 File Offset: 0x00000D23
			protected override void OnPaint(PaintEventArgs e)
			{
				base.Visible = true;
				this.vmethod_0();
			}

			// Token: 0x06000131 RID: 305 RVA: 0x0000A5F4 File Offset: 0x000087F4
			protected override void vmethod_0()
			{
				using (Bitmap bitmap = this.method_10())
				{
					this.method_9(bitmap, byte.MaxValue);
				}
			}

			// Token: 0x06000132 RID: 306 RVA: 0x0000A630 File Offset: 0x00008830
			protected override void vmethod_1()
			{
				Bitmap bitmap = new Bitmap(base.Width, base.Height, PixelFormat.Format32bppArgb);
				Graphics graphics = Graphics.FromImage(bitmap);
				graphics.Clear(Color.Transparent);
				graphics.Flush();
				graphics.Dispose();
				this.method_9(bitmap, byte.MaxValue);
				bitmap.Dispose();
			}

			// Token: 0x06000133 RID: 307 RVA: 0x0000A684 File Offset: 0x00008884
			[SecuritySafeCritical]
			private void method_9(Bitmap bitmap_0, byte byte_0)
			{
				if (bitmap_0.PixelFormat != PixelFormat.Format32bppArgb)
				{
					throw new ApplicationException("The bitmap must be 32ppp with alpha-channel.");
				}
				IntPtr dc = Class29.GetDC(IntPtr.Zero);
				IntPtr intPtr = Class29.CreateCompatibleDC(dc);
				IntPtr intPtr2 = IntPtr.Zero;
				IntPtr intptr_ = IntPtr.Zero;
				try
				{
					intPtr2 = bitmap_0.GetHbitmap(Color.FromArgb(0));
					intptr_ = Class29.SelectObject(intPtr, intPtr2);
					Class29.Struct10 @struct = new Class29.Struct10(bitmap_0.Width, bitmap_0.Height);
					Class29.Struct9 struct2 = new Class29.Struct9(0, 0);
					Class29.Struct9 struct3 = new Class29.Struct9(base.Left, base.Top);
					Class29.Struct12 struct4 = default(Class29.Struct12);
					struct4.byte_0 = 0;
					struct4.byte_1 = 0;
					struct4.byte_2 = byte_0;
					struct4.byte_3 = 1;
					Class29.UpdateLayeredWindow(base.Handle, dc, ref struct3, ref @struct, intPtr, ref struct2, 0, ref struct4, 2);
				}
				finally
				{
					Class29.ReleaseDC(IntPtr.Zero, dc);
					if (intPtr2 != IntPtr.Zero)
					{
						Class29.SelectObject(intPtr, intptr_);
						Class29.DeleteObject(intPtr2);
					}
					Class29.DeleteDC(intPtr);
				}
			}

			// Token: 0x06000134 RID: 308 RVA: 0x0000A79C File Offset: 0x0000899C
			private Bitmap method_10()
			{
				return (Bitmap)this.method_11(Color.Black, new Rectangle(0, 0, base.ClientRectangle.Width, base.ClientRectangle.Height));
			}

			// Token: 0x06000135 RID: 309 RVA: 0x0000A7DC File Offset: 0x000089DC
			private Image method_11(Color color_0, Rectangle rectangle_0)
			{
				Rectangle rect = rectangle_0;
				Rectangle rect2 = new Rectangle(rectangle_0.X + (-this.point_0.X - 1), rectangle_0.Y + (-this.point_0.Y - 1), rectangle_0.Width - (-this.point_0.X * 2 - 1), rectangle_0.Height - (-this.point_0.Y * 2 - 1));
				Bitmap bitmap = new Bitmap(rect.Width, rect.Height, PixelFormat.Format32bppArgb);
				Graphics graphics = Graphics.FromImage(bitmap);
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
				using (Brush brush = new SolidBrush(Color.FromArgb(30, Color.Black)))
				{
					graphics.FillRectangle(brush, rect);
				}
				using (Brush brush2 = new SolidBrush(Color.FromArgb(60, Color.Black)))
				{
					graphics.FillRectangle(brush2, rect2);
				}
				graphics.Flush();
				graphics.Dispose();
				return bitmap;
			}

			// Token: 0x0400007F RID: 127
			private Point point_0 = new Point(-6, -6);
		}

		// Token: 0x02000024 RID: 36
		protected class GForm5 : MetroForm.GForm2
		{
			// Token: 0x06000136 RID: 310 RVA: 0x00002B32 File Offset: 0x00000D32
			public GForm5(Form form_1) : base(form_1, 15, 134742048)
			{
			}

			// Token: 0x06000137 RID: 311 RVA: 0x00002B14 File Offset: 0x00000D14
			protected override void OnLoad(EventArgs e)
			{
				base.OnLoad(e);
				this.vmethod_0();
			}

			// Token: 0x06000138 RID: 312 RVA: 0x00002B23 File Offset: 0x00000D23
			protected override void OnPaint(PaintEventArgs e)
			{
				base.Visible = true;
				this.vmethod_0();
			}

			// Token: 0x06000139 RID: 313 RVA: 0x0000A8FC File Offset: 0x00008AFC
			protected override void vmethod_0()
			{
				using (Bitmap bitmap = this.method_10())
				{
					this.method_9(bitmap, byte.MaxValue);
				}
			}

			// Token: 0x0600013A RID: 314 RVA: 0x0000A938 File Offset: 0x00008B38
			protected override void vmethod_1()
			{
				Bitmap bitmap = new Bitmap(base.Width, base.Height, PixelFormat.Format32bppArgb);
				Graphics graphics = Graphics.FromImage(bitmap);
				graphics.Clear(Color.Transparent);
				graphics.Flush();
				graphics.Dispose();
				this.method_9(bitmap, byte.MaxValue);
				bitmap.Dispose();
			}

			// Token: 0x0600013B RID: 315 RVA: 0x0000A98C File Offset: 0x00008B8C
			[SecuritySafeCritical]
			private void method_9(Bitmap bitmap_0, byte byte_0)
			{
				if (bitmap_0.PixelFormat != PixelFormat.Format32bppArgb)
				{
					throw new ApplicationException("The bitmap must be 32ppp with alpha-channel.");
				}
				IntPtr dc = Class29.GetDC(IntPtr.Zero);
				IntPtr intPtr = Class29.CreateCompatibleDC(dc);
				IntPtr intPtr2 = IntPtr.Zero;
				IntPtr intptr_ = IntPtr.Zero;
				try
				{
					intPtr2 = bitmap_0.GetHbitmap(Color.FromArgb(0));
					intptr_ = Class29.SelectObject(intPtr, intPtr2);
					Class29.Struct10 @struct = new Class29.Struct10(bitmap_0.Width, bitmap_0.Height);
					Class29.Struct9 struct2 = new Class29.Struct9(0, 0);
					Class29.Struct9 struct3 = new Class29.Struct9(base.Left, base.Top);
					Class29.Struct12 struct4 = new Class29.Struct12
					{
						byte_0 = 0,
						byte_1 = 0,
						byte_2 = byte_0,
						byte_3 = 1
					};
					Class29.UpdateLayeredWindow(base.Handle, dc, ref struct3, ref @struct, intPtr, ref struct2, 0, ref struct4, 2);
				}
				finally
				{
					Class29.ReleaseDC(IntPtr.Zero, dc);
					if (intPtr2 != IntPtr.Zero)
					{
						Class29.SelectObject(intPtr, intptr_);
						Class29.DeleteObject(intPtr2);
					}
					Class29.DeleteDC(intPtr);
				}
			}

			// Token: 0x0600013C RID: 316 RVA: 0x0000AAA8 File Offset: 0x00008CA8
			private Bitmap method_10()
			{
				return (Bitmap)this.method_11(0, 0, 40, 1, Color.Black, new Rectangle(1, 1, base.ClientRectangle.Width, base.ClientRectangle.Height));
			}

			// Token: 0x0600013D RID: 317 RVA: 0x0000AAF0 File Offset: 0x00008CF0
			private Image method_11(int int_6, int int_7, int int_8, int int_9, Color color_0, Rectangle rectangle_0)
			{
				Rectangle rectangle = rectangle_0;
				Rectangle rectangle2 = rectangle_0;
				rectangle2.Offset(int_6, int_7);
				rectangle2.Inflate(-int_8, -int_8);
				rectangle.Inflate(int_9, int_9);
				rectangle.Offset(int_6, int_7);
				Rectangle rectangle3 = rectangle;
				Bitmap bitmap = new Bitmap(rectangle3.Width, rectangle3.Height, PixelFormat.Format32bppArgb);
				Graphics graphics = Graphics.FromImage(bitmap);
				graphics.SmoothingMode = SmoothingMode.AntiAlias;
				graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
				int int_10 = 0;
				do
				{
					double num = (double)(rectangle.Height - rectangle2.Height) / (double)(int_8 * 2 + int_9 * 2);
					Color color_ = Color.FromArgb((int)(200.0 * (num * num)), color_0);
					Rectangle rectangle_ = rectangle2;
					rectangle_.Offset(-rectangle3.Left, -rectangle3.Top);
					this.method_12(graphics, rectangle_, int_10, Pens.Transparent, color_);
					rectangle2.Inflate(1, 1);
					int_10 = (int)((double)int_8 * (1.0 - num * num));
				}
				while (rectangle.Contains(rectangle2));
				graphics.Flush();
				graphics.Dispose();
				return bitmap;
			}

			// Token: 0x0600013E RID: 318 RVA: 0x0000AC00 File Offset: 0x00008E00
			private void method_12(Graphics graphics_0, Rectangle rectangle_0, int int_6, Pen pen_0, Color color_0)
			{
				int num = Convert.ToInt32(Math.Ceiling((double)pen_0.Width));
				rectangle_0 = Rectangle.Inflate(rectangle_0, -num, -num);
				GraphicsPath graphicsPath = new GraphicsPath();
				if (int_6 > 0)
				{
					graphicsPath.AddArc(rectangle_0.X, rectangle_0.Y, int_6, int_6, 180f, 90f);
					graphicsPath.AddArc(rectangle_0.X + rectangle_0.Width - int_6, rectangle_0.Y, int_6, int_6, 270f, 90f);
					graphicsPath.AddArc(rectangle_0.X + rectangle_0.Width - int_6, rectangle_0.Y + rectangle_0.Height - int_6, int_6, int_6, 0f, 90f);
					graphicsPath.AddArc(rectangle_0.X, rectangle_0.Y + rectangle_0.Height - int_6, int_6, int_6, 90f, 90f);
				}
				else
				{
					graphicsPath.AddRectangle(rectangle_0);
				}
				graphicsPath.CloseAllFigures();
				if (int_6 > 5)
				{
					using (SolidBrush solidBrush = new SolidBrush(color_0))
					{
						graphics_0.FillPath(solidBrush, graphicsPath);
					}
				}
				if (pen_0 != Pens.Transparent)
				{
					using (Pen pen = new Pen(pen_0.Color))
					{
						Pen pen2 = pen;
						pen.StartCap = LineCap.Round;
						pen2.EndCap = LineCap.Round;
						graphics_0.DrawPath(pen, graphicsPath);
					}
				}
			}
		}
	}
}
