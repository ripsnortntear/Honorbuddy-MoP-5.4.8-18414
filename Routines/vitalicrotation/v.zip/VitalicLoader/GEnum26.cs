﻿using System;

namespace ns0
{
	// Token: 0x020000A2 RID: 162
	public enum GEnum26
	{
		// Token: 0x0400048D RID: 1165
		const_0,
		// Token: 0x0400048E RID: 1166
		const_1,
		// Token: 0x0400048F RID: 1167
		const_2
	}
}
