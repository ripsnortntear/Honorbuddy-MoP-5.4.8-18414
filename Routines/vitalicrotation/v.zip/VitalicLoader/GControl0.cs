﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200003D RID: 61
	[ToolboxBitmap(typeof(ProgressBar))]
	[Designer("MetroFramework.Design.Controls.MetroProgressSpinnerDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	public class GControl0 : Control, GInterface2
	{
		// Token: 0x06000333 RID: 819 RVA: 0x0000EB7C File Offset: 0x0000CD7C
		public GControl0()
		{
			this.timer_0 = new System.Windows.Forms.Timer();
			this.timer_0.Interval = 20;
			this.timer_0.Tick += this.timer_0_Tick;
			this.timer_0.Enabled = true;
			base.Width = 16;
			base.Height = 16;
			this.float_1 = 1f;
			this.DoubleBuffered = true;
		}

		// Token: 0x14000021 RID: 33
		// (add) Token: 0x06000334 RID: 820 RVA: 0x0000EC08 File Offset: 0x0000CE08
		// (remove) Token: 0x06000335 RID: 821 RVA: 0x0000EC40 File Offset: 0x0000CE40
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000336 RID: 822 RVA: 0x00003FE7 File Offset: 0x000021E7
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000022 RID: 34
		// (add) Token: 0x06000337 RID: 823 RVA: 0x0000EC78 File Offset: 0x0000CE78
		// (remove) Token: 0x06000338 RID: 824 RVA: 0x0000ECB0 File Offset: 0x0000CEB0
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000339 RID: 825 RVA: 0x00004007 File Offset: 0x00002207
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000023 RID: 35
		// (add) Token: 0x0600033A RID: 826 RVA: 0x0000ECE8 File Offset: 0x0000CEE8
		// (remove) Token: 0x0600033B RID: 827 RVA: 0x0000ED20 File Offset: 0x0000CF20
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x0600033C RID: 828 RVA: 0x00004027 File Offset: 0x00002227
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x170000BD RID: 189
		// (get) Token: 0x0600033D RID: 829 RVA: 0x0000ED58 File Offset: 0x0000CF58
		// (set) Token: 0x0600033E RID: 830 RVA: 0x00004047 File Offset: 0x00002247
		[Category("Metro Appearance")]
		[DefaultValue(GEnum10.const_0)]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x170000BE RID: 190
		// (get) Token: 0x0600033F RID: 831 RVA: 0x0000EDB0 File Offset: 0x0000CFB0
		// (set) Token: 0x06000340 RID: 832 RVA: 0x00004050 File Offset: 0x00002250
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x170000BF RID: 191
		// (get) Token: 0x06000341 RID: 833 RVA: 0x00004059 File Offset: 0x00002259
		// (set) Token: 0x06000342 RID: 834 RVA: 0x00004061 File Offset: 0x00002261
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x170000C0 RID: 192
		// (get) Token: 0x06000343 RID: 835 RVA: 0x0000406A File Offset: 0x0000226A
		// (set) Token: 0x06000344 RID: 836 RVA: 0x00004072 File Offset: 0x00002272
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x170000C1 RID: 193
		// (get) Token: 0x06000345 RID: 837 RVA: 0x0000407B File Offset: 0x0000227B
		// (set) Token: 0x06000346 RID: 838 RVA: 0x00004083 File Offset: 0x00002283
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x170000C2 RID: 194
		// (get) Token: 0x06000347 RID: 839 RVA: 0x0000408C File Offset: 0x0000228C
		// (set) Token: 0x06000348 RID: 840 RVA: 0x00004094 File Offset: 0x00002294
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x170000C3 RID: 195
		// (get) Token: 0x06000349 RID: 841 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x0600034A RID: 842 RVA: 0x00002923 File Offset: 0x00000B23
		[Browsable(false)]
		[DefaultValue(false)]
		[Category("Metro Behaviour")]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x170000C4 RID: 196
		// (get) Token: 0x0600034B RID: 843 RVA: 0x0000409D File Offset: 0x0000229D
		// (set) Token: 0x0600034C RID: 844 RVA: 0x000040AA File Offset: 0x000022AA
		[Category("Metro Behaviour")]
		[DefaultValue(true)]
		public bool Boolean_0
		{
			get
			{
				return this.timer_0.Enabled;
			}
			set
			{
				this.timer_0.Enabled = value;
			}
		}

		// Token: 0x170000C5 RID: 197
		// (get) Token: 0x0600034D RID: 845 RVA: 0x000040B8 File Offset: 0x000022B8
		// (set) Token: 0x0600034E RID: 846 RVA: 0x000040C0 File Offset: 0x000022C0
		[DefaultValue(0)]
		[Category("Metro Appearance")]
		public int Int32_0
		{
			get
			{
				return this.int_0;
			}
			set
			{
				if (value != -1 && (value < this.int_1 || value > this.int_2))
				{
					throw new ArgumentOutOfRangeException("Progress value must be -1 or between Minimum and Maximum.", null);
				}
				this.int_0 = value;
				this.Refresh();
			}
		}

		// Token: 0x170000C6 RID: 198
		// (get) Token: 0x0600034F RID: 847 RVA: 0x000040F1 File Offset: 0x000022F1
		// (set) Token: 0x06000350 RID: 848 RVA: 0x0000EE08 File Offset: 0x0000D008
		[DefaultValue(0)]
		[Category("Metro Appearance")]
		public int Int32_1
		{
			get
			{
				return this.int_1;
			}
			set
			{
				if (value < 0)
				{
					throw new ArgumentOutOfRangeException("Minimum value must be >= 0.", null);
				}
				if (value >= this.int_2)
				{
					throw new ArgumentOutOfRangeException("Minimum value must be < Maximum.", null);
				}
				this.int_1 = value;
				if (this.int_0 != -1 && this.int_0 < this.int_1)
				{
					this.int_0 = this.int_1;
				}
				this.Refresh();
			}
		}

		// Token: 0x170000C7 RID: 199
		// (get) Token: 0x06000351 RID: 849 RVA: 0x000040F9 File Offset: 0x000022F9
		// (set) Token: 0x06000352 RID: 850 RVA: 0x00004101 File Offset: 0x00002301
		[DefaultValue(0)]
		[Category("Metro Appearance")]
		public int Int32_2
		{
			get
			{
				return this.int_2;
			}
			set
			{
				if (value <= this.int_1)
				{
					throw new ArgumentOutOfRangeException("Maximum value must be > Minimum.", null);
				}
				this.int_2 = value;
				if (this.int_0 > this.int_2)
				{
					this.int_0 = this.int_2;
				}
				this.Refresh();
			}
		}

		// Token: 0x170000C8 RID: 200
		// (get) Token: 0x06000353 RID: 851 RVA: 0x0000413F File Offset: 0x0000233F
		// (set) Token: 0x06000354 RID: 852 RVA: 0x00004147 File Offset: 0x00002347
		[DefaultValue(true)]
		[Category("Metro Appearance")]
		public bool Boolean_1
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
				this.Refresh();
			}
		}

		// Token: 0x170000C9 RID: 201
		// (get) Token: 0x06000355 RID: 853 RVA: 0x00004156 File Offset: 0x00002356
		// (set) Token: 0x06000356 RID: 854 RVA: 0x0000415E File Offset: 0x0000235E
		[Category("Metro Behaviour")]
		[DefaultValue(1f)]
		public float Single_0
		{
			get
			{
				return this.float_1;
			}
			set
			{
				if (value <= 0f || value > 10f)
				{
					throw new ArgumentOutOfRangeException("Speed value must be > 0 and <= 10.", null);
				}
				this.float_1 = value;
			}
		}

		// Token: 0x170000CA RID: 202
		// (get) Token: 0x06000357 RID: 855 RVA: 0x00004183 File Offset: 0x00002383
		// (set) Token: 0x06000358 RID: 856 RVA: 0x0000418B File Offset: 0x0000238B
		[Category("Metro Behaviour")]
		[DefaultValue(false)]
		public bool Boolean_2
		{
			get
			{
				return this.bool_4;
			}
			set
			{
				this.bool_4 = value;
				this.Refresh();
			}
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x06000359 RID: 857 RVA: 0x0000419A File Offset: 0x0000239A
		// (set) Token: 0x0600035A RID: 858 RVA: 0x000041A2 File Offset: 0x000023A2
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_3
		{
			get
			{
				return this.bool_5;
			}
			set
			{
				this.bool_5 = value;
			}
		}

		// Token: 0x0600035B RID: 859 RVA: 0x000041AB File Offset: 0x000023AB
		public void method_0()
		{
			this.int_0 = this.int_1;
			this.float_0 = 270f;
			this.Refresh();
		}

		// Token: 0x0600035C RID: 860 RVA: 0x000041CA File Offset: 0x000023CA
		private void timer_0_Tick(object sender, EventArgs e)
		{
			if (!base.DesignMode)
			{
				this.float_0 += 6f * this.float_1 * (float)(this.bool_4 ? -1 : 1);
				this.Refresh();
			}
		}

		// Token: 0x0600035D RID: 861 RVA: 0x0000EE6C File Offset: 0x0000D06C
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					if (base.Parent is GClass22)
					{
						color = GClass39.smethod_0(this.GEnum10_0);
					}
					else
					{
						color = GClass39.GClass46.smethod_0(this.GEnum29_0);
					}
				}
				if (color.A == 255)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600035E RID: 862 RVA: 0x0000EF04 File Offset: 0x0000D104
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600035F RID: 863 RVA: 0x0000EF64 File Offset: 0x0000D164
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color color;
			if (this.bool_5)
			{
				color = GClass39.smethod_0(this.GEnum10_0);
			}
			else if (base.Parent is GClass22)
			{
				color = GClass39.GClass56.GClass58.smethod_0(this.GEnum29_0);
			}
			else
			{
				color = GClass39.smethod_0(this.GEnum10_0);
			}
			using (Pen pen = new Pen(color, (float)base.Width / 5f))
			{
				int num = (int)Math.Ceiling((double)((float)base.Width / 10f));
				paintEventArgs_0.Graphics.SmoothingMode = SmoothingMode.HighQuality;
				if (this.int_0 != -1)
				{
					float num2 = (float)(this.int_0 - this.int_1) / (float)(this.int_2 - this.int_1);
					float num3;
					if (this.bool_3)
					{
						num3 = 30f + 300f * num2;
					}
					else
					{
						num3 = 360f * num2;
					}
					if (this.bool_4)
					{
						num3 = -num3;
					}
					paintEventArgs_0.Graphics.DrawArc(pen, (float)num, (float)num, (float)(base.Width - 2 * num - 1), (float)(base.Height - 2 * num - 1), this.float_0, num3);
				}
				else
				{
					for (int i = 0; i <= 180; i += 15)
					{
						int num4 = 290 - i * 290 / 180;
						if (num4 > 255)
						{
							num4 = 255;
						}
						if (num4 < 0)
						{
							num4 = 0;
						}
						Color color2 = Color.FromArgb(num4, pen.Color);
						using (Pen pen2 = new Pen(color2, pen.Width))
						{
							float startAngle = this.float_0 + (float)((i - (this.bool_3 ? 30 : 0)) * (this.bool_4 ? 1 : -1));
							float sweepAngle = (float)(15 * (this.bool_4 ? 1 : -1));
							paintEventArgs_0.Graphics.DrawArc(pen2, (float)num, (float)num, (float)(base.Width - 2 * num - 1), (float)(base.Height - 2 * num - 1), startAngle, sweepAngle);
						}
					}
				}
			}
			this.vmethod_2(new GEventArgs3(Color.Empty, color, paintEventArgs_0.Graphics));
		}

		// Token: 0x0400012D RID: 301
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x0400012E RID: 302
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x0400012F RID: 303
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x04000130 RID: 304
		private GEnum10 genum10_0;

		// Token: 0x04000131 RID: 305
		private GEnum29 genum29_0;

		// Token: 0x04000132 RID: 306
		private GClass8 gclass8_0;

		// Token: 0x04000133 RID: 307
		private bool bool_0;

		// Token: 0x04000134 RID: 308
		private bool bool_1;

		// Token: 0x04000135 RID: 309
		private bool bool_2;

		// Token: 0x04000136 RID: 310
		private System.Windows.Forms.Timer timer_0;

		// Token: 0x04000137 RID: 311
		private int int_0;

		// Token: 0x04000138 RID: 312
		private float float_0 = 270f;

		// Token: 0x04000139 RID: 313
		private int int_1;

		// Token: 0x0400013A RID: 314
		private int int_2 = 100;

		// Token: 0x0400013B RID: 315
		private bool bool_3 = true;

		// Token: 0x0400013C RID: 316
		private float float_1;

		// Token: 0x0400013D RID: 317
		private bool bool_4;

		// Token: 0x0400013E RID: 318
		private bool bool_5;
	}
}
