﻿using System;

namespace ns0
{
	// Token: 0x02000007 RID: 7
	// (Invoke) Token: 0x0600001F RID: 31
	public delegate void GDelegate0();
}
