﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200003E RID: 62
	[Designer("MetroFramework.Design.Controls.MetroRadioButtonDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	[ToolboxBitmap(typeof(RadioButton))]
	public class GClass19 : RadioButton, GInterface2
	{
		// Token: 0x06000360 RID: 864 RVA: 0x00004201 File Offset: 0x00002401
		public GClass19()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x14000024 RID: 36
		// (add) Token: 0x06000361 RID: 865 RVA: 0x0000F1A8 File Offset: 0x0000D3A8
		// (remove) Token: 0x06000362 RID: 866 RVA: 0x0000F1E0 File Offset: 0x0000D3E0
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000363 RID: 867 RVA: 0x0000421C File Offset: 0x0000241C
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000025 RID: 37
		// (add) Token: 0x06000364 RID: 868 RVA: 0x0000F218 File Offset: 0x0000D418
		// (remove) Token: 0x06000365 RID: 869 RVA: 0x0000F250 File Offset: 0x0000D450
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000366 RID: 870 RVA: 0x0000423C File Offset: 0x0000243C
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000026 RID: 38
		// (add) Token: 0x06000367 RID: 871 RVA: 0x0000F288 File Offset: 0x0000D488
		// (remove) Token: 0x06000368 RID: 872 RVA: 0x0000F2C0 File Offset: 0x0000D4C0
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000369 RID: 873 RVA: 0x0000425C File Offset: 0x0000245C
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x170000CC RID: 204
		// (get) Token: 0x0600036A RID: 874 RVA: 0x0000F2F8 File Offset: 0x0000D4F8
		// (set) Token: 0x0600036B RID: 875 RVA: 0x0000427C File Offset: 0x0000247C
		[DefaultValue(GEnum10.const_0)]
		[Category("Metro Appearance")]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x170000CD RID: 205
		// (get) Token: 0x0600036C RID: 876 RVA: 0x0000F350 File Offset: 0x0000D550
		// (set) Token: 0x0600036D RID: 877 RVA: 0x00004285 File Offset: 0x00002485
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x170000CE RID: 206
		// (get) Token: 0x0600036E RID: 878 RVA: 0x0000428E File Offset: 0x0000248E
		// (set) Token: 0x0600036F RID: 879 RVA: 0x00004296 File Offset: 0x00002496
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x170000CF RID: 207
		// (get) Token: 0x06000370 RID: 880 RVA: 0x0000429F File Offset: 0x0000249F
		// (set) Token: 0x06000371 RID: 881 RVA: 0x000042A7 File Offset: 0x000024A7
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x170000D0 RID: 208
		// (get) Token: 0x06000372 RID: 882 RVA: 0x000042B0 File Offset: 0x000024B0
		// (set) Token: 0x06000373 RID: 883 RVA: 0x000042B8 File Offset: 0x000024B8
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x170000D1 RID: 209
		// (get) Token: 0x06000374 RID: 884 RVA: 0x000042C1 File Offset: 0x000024C1
		// (set) Token: 0x06000375 RID: 885 RVA: 0x000042C9 File Offset: 0x000024C9
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x170000D2 RID: 210
		// (get) Token: 0x06000376 RID: 886 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x06000377 RID: 887 RVA: 0x00002923 File Offset: 0x00000B23
		[DefaultValue(false)]
		[Category("Metro Behaviour")]
		[Browsable(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x170000D3 RID: 211
		// (get) Token: 0x06000378 RID: 888 RVA: 0x000042D2 File Offset: 0x000024D2
		// (set) Token: 0x06000379 RID: 889 RVA: 0x000042DA File Offset: 0x000024DA
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x170000D4 RID: 212
		// (get) Token: 0x0600037A RID: 890 RVA: 0x000042E3 File Offset: 0x000024E3
		// (set) Token: 0x0600037B RID: 891 RVA: 0x000042EB File Offset: 0x000024EB
		[DefaultValue(GEnum25.const_0)]
		[Category("Metro Appearance")]
		public GEnum25 GEnum25_0
		{
			get
			{
				return this.genum25_0;
			}
			set
			{
				this.genum25_0 = value;
			}
		}

		// Token: 0x170000D5 RID: 213
		// (get) Token: 0x0600037C RID: 892 RVA: 0x000042F4 File Offset: 0x000024F4
		// (set) Token: 0x0600037D RID: 893 RVA: 0x000042FC File Offset: 0x000024FC
		[Category("Metro Appearance")]
		[DefaultValue(GEnum26.const_1)]
		public GEnum26 GEnum26_0
		{
			get
			{
				return this.genum26_0;
			}
			set
			{
				this.genum26_0 = value;
			}
		}

		// Token: 0x170000D6 RID: 214
		// (get) Token: 0x0600037E RID: 894 RVA: 0x000033C1 File Offset: 0x000015C1
		// (set) Token: 0x0600037F RID: 895 RVA: 0x000033C9 File Offset: 0x000015C9
		[Browsable(false)]
		public override Font Font
		{
			get
			{
				return base.Font;
			}
			set
			{
				base.Font = value;
			}
		}

		// Token: 0x06000380 RID: 896 RVA: 0x0000F3A8 File Offset: 0x0000D5A8
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
					if (base.Parent is GClass22)
					{
						color = GClass39.smethod_0(this.GEnum10_0);
					}
				}
				if (color.A == 255)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x06000381 RID: 897 RVA: 0x0000F440 File Offset: 0x0000D640
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x06000382 RID: 898 RVA: 0x0000F4A0 File Offset: 0x0000D6A0
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color color;
			Color color2;
			if (this.bool_1)
			{
				color = this.ForeColor;
				if (this.bool_4 && !this.bool_5 && base.Enabled)
				{
					color2 = GClass39.GClass40.GClass42.smethod_1(this.GEnum29_0);
				}
				else if (this.bool_4 && this.bool_5 && base.Enabled)
				{
					color2 = GClass39.GClass40.GClass42.smethod_2(this.GEnum29_0);
				}
				else if (!base.Enabled)
				{
					color2 = GClass39.GClass40.GClass42.smethod_3(this.GEnum29_0);
				}
				else
				{
					color2 = GClass39.GClass40.GClass42.smethod_0(this.GEnum29_0);
				}
			}
			else if (this.bool_4 && !this.bool_5 && base.Enabled)
			{
				color = GClass39.GClass56.GClass61.smethod_1(this.GEnum29_0);
				color2 = GClass39.GClass40.GClass42.smethod_1(this.GEnum29_0);
			}
			else if (this.bool_4 && this.bool_5 && base.Enabled)
			{
				color = GClass39.GClass56.GClass61.smethod_2(this.GEnum29_0);
				color2 = GClass39.GClass40.GClass42.smethod_2(this.GEnum29_0);
			}
			else if (!base.Enabled)
			{
				color = GClass39.GClass56.GClass61.smethod_3(this.GEnum29_0);
				color2 = GClass39.GClass40.GClass42.smethod_3(this.GEnum29_0);
			}
			else
			{
				color = ((!this.bool_2) ? GClass39.GClass56.GClass61.smethod_0(this.GEnum29_0) : GClass39.smethod_0(this.GEnum10_0));
				color2 = GClass39.GClass40.GClass42.smethod_0(this.GEnum29_0);
			}
			paintEventArgs_0.Graphics.SmoothingMode = SmoothingMode.HighQuality;
			using (Pen pen = new Pen(color2))
			{
				Rectangle rect = new Rectangle(0, base.Height / 2 - 6, 12, 12);
				paintEventArgs_0.Graphics.DrawEllipse(pen, rect);
			}
			if (base.Checked)
			{
				Color color3 = GClass39.smethod_0(this.GEnum10_0);
				using (SolidBrush solidBrush = new SolidBrush(color3))
				{
					Rectangle rect2 = new Rectangle(3, base.Height / 2 - 3, 6, 6);
					paintEventArgs_0.Graphics.FillEllipse(solidBrush, rect2);
				}
			}
			paintEventArgs_0.Graphics.SmoothingMode = SmoothingMode.Default;
			Rectangle bounds = new Rectangle(16, 0, base.Width - 16, base.Height);
			TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Text, GClass67.smethod_11(this.genum25_0, this.genum26_0), bounds, color, GClass39.smethod_4(this.TextAlign));
			this.vmethod_2(new GEventArgs3(Color.Empty, color, paintEventArgs_0.Graphics));
			if (this.bool_3 && this.bool_6)
			{
				ControlPaint.DrawFocusRectangle(paintEventArgs_0.Graphics, base.ClientRectangle);
			}
		}

		// Token: 0x06000383 RID: 899 RVA: 0x00004305 File Offset: 0x00002505
		protected override void OnGotFocus(EventArgs e)
		{
			this.bool_6 = true;
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x06000384 RID: 900 RVA: 0x0000431B File Offset: 0x0000251B
		protected override void OnLostFocus(EventArgs e)
		{
			this.bool_6 = false;
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		// Token: 0x06000385 RID: 901 RVA: 0x0000433F File Offset: 0x0000253F
		protected override void OnEnter(EventArgs e)
		{
			this.bool_6 = true;
			base.Invalidate();
			base.OnEnter(e);
		}

		// Token: 0x06000386 RID: 902 RVA: 0x00004355 File Offset: 0x00002555
		protected override void OnLeave(EventArgs e)
		{
			this.bool_6 = false;
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnLeave(e);
		}

		// Token: 0x06000387 RID: 903 RVA: 0x00004379 File Offset: 0x00002579
		protected override void OnKeyDown(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Space)
			{
				this.bool_4 = true;
				this.bool_5 = true;
				base.Invalidate();
			}
			base.OnKeyDown(e);
		}

		// Token: 0x06000388 RID: 904 RVA: 0x000043A0 File Offset: 0x000025A0
		protected override void OnKeyUp(KeyEventArgs e)
		{
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnKeyUp(e);
		}

		// Token: 0x06000389 RID: 905 RVA: 0x000043BD File Offset: 0x000025BD
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_4 = true;
			base.Invalidate();
			base.OnMouseEnter(e);
		}

		// Token: 0x0600038A RID: 906 RVA: 0x000043D3 File Offset: 0x000025D3
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.bool_5 = true;
				base.Invalidate();
			}
			base.OnMouseDown(e);
		}

		// Token: 0x0600038B RID: 907 RVA: 0x000043F6 File Offset: 0x000025F6
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this.bool_5 = false;
			base.Invalidate();
			base.OnMouseUp(e);
		}

		// Token: 0x0600038C RID: 908 RVA: 0x0000440C File Offset: 0x0000260C
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_4 = false;
			base.Invalidate();
			base.OnMouseLeave(e);
		}

		// Token: 0x0600038D RID: 909 RVA: 0x0000311B File Offset: 0x0000131B
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x0600038E RID: 910 RVA: 0x00004422 File Offset: 0x00002622
		protected override void OnCheckedChanged(EventArgs e)
		{
			base.OnCheckedChanged(e);
			base.Invalidate();
		}

		// Token: 0x0600038F RID: 911 RVA: 0x0000F72C File Offset: 0x0000D92C
		public override Size GetPreferredSize(Size proposedSize)
		{
			base.GetPreferredSize(proposedSize);
			Size result;
			using (Graphics graphics = base.CreateGraphics())
			{
				proposedSize = new Size(int.MaxValue, int.MaxValue);
				result = TextRenderer.MeasureText(graphics, this.Text, GClass67.smethod_11(this.genum25_0, this.genum26_0), proposedSize, GClass39.smethod_4(this.TextAlign));
				result.Width += 16;
			}
			return result;
		}

		// Token: 0x0400013F RID: 319
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x04000140 RID: 320
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x04000141 RID: 321
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x04000142 RID: 322
		private GEnum10 genum10_0;

		// Token: 0x04000143 RID: 323
		private GEnum29 genum29_0;

		// Token: 0x04000144 RID: 324
		private GClass8 gclass8_0;

		// Token: 0x04000145 RID: 325
		private bool bool_0;

		// Token: 0x04000146 RID: 326
		private bool bool_1;

		// Token: 0x04000147 RID: 327
		private bool bool_2;

		// Token: 0x04000148 RID: 328
		private bool bool_3;

		// Token: 0x04000149 RID: 329
		private GEnum25 genum25_0;

		// Token: 0x0400014A RID: 330
		private GEnum26 genum26_0 = GEnum26.const_1;

		// Token: 0x0400014B RID: 331
		private bool bool_4;

		// Token: 0x0400014C RID: 332
		private bool bool_5;

		// Token: 0x0400014D RID: 333
		private bool bool_6;
	}
}
