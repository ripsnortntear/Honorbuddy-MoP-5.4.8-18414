﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000016 RID: 22
	public sealed class GClass6 : GClass3
	{
		// Token: 0x06000089 RID: 137 RVA: 0x00008DEC File Offset: 0x00006FEC
		public void method_6(Control control_1, Point point_0, GEnum0 genum0_1, int int_3)
		{
			GClass6.Class6 @class = new GClass6.Class6();
			@class.control_0 = control_1;
			@class.point_0 = point_0;
			@class.gclass6_0 = this;
			base.method_3(@class.control_0, genum0_1, int_3, new GDelegate0(@class.method_0), new GDelegate1(@class.method_1));
		}

		// Token: 0x0600008A RID: 138 RVA: 0x00008D14 File Offset: 0x00006F14
		private int method_7(int int_3, int int_4)
		{
			float float_ = (float)this.int_0 - (float)this.int_1;
			float float_2 = (float)int_3;
			float float_3 = (float)int_4 - (float)int_3;
			float float_4 = (float)this.int_2 - (float)this.int_1;
			return base.method_5(float_, float_2, float_4, float_3);
		}

		// Token: 0x02000017 RID: 23
		[CompilerGenerated]
		private sealed class Class6
		{
			// Token: 0x0600008C RID: 140 RVA: 0x00008E3C File Offset: 0x0000703C
			public void method_0()
			{
				int x = this.gclass6_0.method_7(this.control_0.Location.X, this.point_0.X);
				int y = this.gclass6_0.method_7(this.control_0.Location.Y, this.point_0.Y);
				this.control_0.Location = new Point(x, y);
			}

			// Token: 0x0600008D RID: 141 RVA: 0x00008EB0 File Offset: 0x000070B0
			public bool method_1()
			{
				return this.control_0.Location.Equals(this.point_0);
			}

			// Token: 0x04000036 RID: 54
			public GClass6 gclass6_0;

			// Token: 0x04000037 RID: 55
			public Control control_0;

			// Token: 0x04000038 RID: 56
			public Point point_0;
		}
	}
}
