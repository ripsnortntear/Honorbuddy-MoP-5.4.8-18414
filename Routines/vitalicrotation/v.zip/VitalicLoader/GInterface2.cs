﻿using System;

namespace ns0
{
	// Token: 0x02000025 RID: 37
	public interface GInterface2
	{
		// Token: 0x14000005 RID: 5
		// (add) Token: 0x0600013F RID: 319
		// (remove) Token: 0x06000140 RID: 320
		event EventHandler<GEventArgs3> Event_2;

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x06000141 RID: 321
		// (remove) Token: 0x06000142 RID: 322
		event EventHandler<GEventArgs3> Event_3;

		// Token: 0x14000007 RID: 7
		// (add) Token: 0x06000143 RID: 323
		// (remove) Token: 0x06000144 RID: 324
		event EventHandler<GEventArgs3> Event_4;

		// Token: 0x1700003B RID: 59
		// (get) Token: 0x06000145 RID: 325
		// (set) Token: 0x06000146 RID: 326
		GEnum10 GEnum10_0 { get; set; }

		// Token: 0x1700003C RID: 60
		// (get) Token: 0x06000147 RID: 327
		// (set) Token: 0x06000148 RID: 328
		GEnum29 GEnum29_0 { get; set; }

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x06000149 RID: 329
		// (set) Token: 0x0600014A RID: 330
		GClass8 GClass8_0 { get; set; }

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x0600014B RID: 331
		// (set) Token: 0x0600014C RID: 332
		bool Boolean_8 { get; set; }

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x0600014D RID: 333
		// (set) Token: 0x0600014E RID: 334
		bool Boolean_9 { get; set; }

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x0600014F RID: 335
		// (set) Token: 0x06000150 RID: 336
		bool Boolean_10 { get; set; }

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x06000151 RID: 337
		// (set) Token: 0x06000152 RID: 338
		bool Boolean_11 { get; set; }
	}
}
