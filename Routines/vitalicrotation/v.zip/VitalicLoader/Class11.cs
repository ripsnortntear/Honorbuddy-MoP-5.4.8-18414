﻿using System;
using System.Drawing;

namespace ns0
{
	// Token: 0x02000052 RID: 82
	internal class Class11 : GClass30
	{
		// Token: 0x060006B4 RID: 1716 RVA: 0x000065DA File Offset: 0x000047DA
		internal Class11(GClass23 gclass23_1)
		{
			this.gclass23_0 = gclass23_1;
			this.string_0 = string.Empty;
		}

		// Token: 0x060006B5 RID: 1717 RVA: 0x000065F4 File Offset: 0x000047F4
		public Class11(GClass23 gclass23_1, Image image_1) : this(gclass23_1)
		{
			this.Image_0 = image_1;
		}

		// Token: 0x170001EC RID: 492
		// (get) Token: 0x060006B6 RID: 1718 RVA: 0x00006604 File Offset: 0x00004804
		public float Single_6
		{
			get
			{
				return base.Single_2;
			}
		}

		// Token: 0x170001ED RID: 493
		// (get) Token: 0x060006B7 RID: 1719 RVA: 0x0000660C File Offset: 0x0000480C
		// (set) Token: 0x060006B8 RID: 1720 RVA: 0x0001750C File Offset: 0x0001570C
		public Image Image_0
		{
			get
			{
				return this.image_0;
			}
			set
			{
				this.image_0 = value;
				if (value != null)
				{
					GClass33 gclass = new GClass33(this.GClass23_0.String_39);
					GClass33 gclass2 = new GClass33(this.GClass23_0.String_40);
					if (gclass.Single_0 > 0f && gclass.GEnum4_0 == GClass33.GEnum4.const_2)
					{
						base.Single_2 = gclass.Single_0;
					}
					else
					{
						base.Single_2 = (float)value.Width;
					}
					if (gclass2.Single_0 > 0f && gclass2.GEnum4_0 == GClass33.GEnum4.const_2)
					{
						base.Single_3 = gclass2.Single_0;
					}
					else
					{
						base.Single_3 = (float)value.Height;
					}
					base.Single_3 += this.GClass23_0.Single_10 + this.GClass23_0.Single_8 + this.GClass23_0.Single_0 + this.GClass23_0.Single_2;
				}
			}
		}

		// Token: 0x170001EE RID: 494
		// (get) Token: 0x060006B9 RID: 1721 RVA: 0x00006614 File Offset: 0x00004814
		public bool Boolean_0
		{
			get
			{
				return this.Image_0 != null;
			}
		}

		// Token: 0x170001EF RID: 495
		// (get) Token: 0x060006BA RID: 1722 RVA: 0x00006622 File Offset: 0x00004822
		public bool Boolean_1
		{
			get
			{
				return string.IsNullOrEmpty(this.String_0.Trim());
			}
		}

		// Token: 0x170001F0 RID: 496
		// (get) Token: 0x060006BB RID: 1723 RVA: 0x00006634 File Offset: 0x00004834
		public bool Boolean_2
		{
			get
			{
				return this.String_0 == "\n";
			}
		}

		// Token: 0x170001F1 RID: 497
		// (get) Token: 0x060006BC RID: 1724 RVA: 0x00006646 File Offset: 0x00004846
		public bool Boolean_3
		{
			get
			{
				return this.String_0 == "\t";
			}
		}

		// Token: 0x170001F2 RID: 498
		// (get) Token: 0x060006BD RID: 1725 RVA: 0x00006658 File Offset: 0x00004858
		public GClass23 GClass23_0
		{
			get
			{
				return this.gclass23_0;
			}
		}

		// Token: 0x170001F3 RID: 499
		// (get) Token: 0x060006BE RID: 1726 RVA: 0x00006660 File Offset: 0x00004860
		public string String_0
		{
			get
			{
				return this.string_0;
			}
		}

		// Token: 0x170001F4 RID: 500
		// (get) Token: 0x060006BF RID: 1727 RVA: 0x00006668 File Offset: 0x00004868
		// (set) Token: 0x060006C0 RID: 1728 RVA: 0x00006670 File Offset: 0x00004870
		internal PointF PointF_1
		{
			get
			{
				return this.pointF_0;
			}
			set
			{
				this.pointF_0 = value;
			}
		}

		// Token: 0x060006C1 RID: 1729 RVA: 0x00006679 File Offset: 0x00004879
		internal void method_0()
		{
			this.string_0 = this.string_0.Replace('\n', ' ');
			this.string_0 = this.string_0.Replace('\t', ' ');
		}

		// Token: 0x060006C2 RID: 1730 RVA: 0x000066A5 File Offset: 0x000048A5
		internal void method_1(char char_0)
		{
			this.string_0 += char_0;
		}

		// Token: 0x060006C3 RID: 1731 RVA: 0x000175E8 File Offset: 0x000157E8
		public override string ToString()
		{
			return string.Format("{0} ({1} char{2})", this.String_0.Replace(' ', '-').Replace("\n", "\\n"), this.String_0.Length, (this.String_0.Length != 1) ? "s" : string.Empty);
		}

		// Token: 0x04000277 RID: 631
		private string string_0;

		// Token: 0x04000278 RID: 632
		private PointF pointF_0;

		// Token: 0x04000279 RID: 633
		private GClass23 gclass23_0;

		// Token: 0x0400027A RID: 634
		private Image image_0;
	}
}
