﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;

namespace ns0
{
	// Token: 0x0200006A RID: 106
	public class GEventArgs3 : EventArgs
	{
		// Token: 0x06000778 RID: 1912 RVA: 0x00006CC6 File Offset: 0x00004EC6
		public GEventArgs3(Color color_2, Color color_3, Graphics graphics_1)
		{
			this.BackColor = color_2;
			this.ForeColor = color_3;
			this.Graphics = graphics_1;
		}

		// Token: 0x17000224 RID: 548
		// (get) Token: 0x06000779 RID: 1913 RVA: 0x00006CE3 File Offset: 0x00004EE3
		// (set) Token: 0x0600077A RID: 1914 RVA: 0x00006CEB File Offset: 0x00004EEB
		public Color BackColor { get; private set; }

		// Token: 0x17000225 RID: 549
		// (get) Token: 0x0600077B RID: 1915 RVA: 0x00006CF4 File Offset: 0x00004EF4
		// (set) Token: 0x0600077C RID: 1916 RVA: 0x00006CFC File Offset: 0x00004EFC
		public Color ForeColor { get; private set; }

		// Token: 0x17000226 RID: 550
		// (get) Token: 0x0600077D RID: 1917 RVA: 0x00006D05 File Offset: 0x00004F05
		// (set) Token: 0x0600077E RID: 1918 RVA: 0x00006D0D File Offset: 0x00004F0D
		public Graphics Graphics { get; private set; }

		// Token: 0x0400040A RID: 1034
		[CompilerGenerated]
		private Color color_0;

		// Token: 0x0400040B RID: 1035
		[CompilerGenerated]
		private Color color_1;

		// Token: 0x0400040C RID: 1036
		[CompilerGenerated]
		private Graphics graphics_0;
	}
}
