﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace ns0
{
	// Token: 0x0200002A RID: 42
	public class GEventArgs0 : EventArgs
	{
		// Token: 0x06000181 RID: 385 RVA: 0x00002CA5 File Offset: 0x00000EA5
		public GEventArgs0(Graphics graphics_1, Font font_1, Rectangle rectangle_1, Color color_3, Color color_4, Color color_5, object object_1)
		{
			this.color_1 = color_4;
			this.color_2 = color_5;
			this.graphics_0 = graphics_1;
			this.font_0 = font_1;
			this.rectangle_0 = rectangle_1;
			this.color_0 = color_3;
			this.object_0 = object_1;
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000182 RID: 386 RVA: 0x00002CE2 File Offset: 0x00000EE2
		public Rectangle Rectangle_0
		{
			get
			{
				return this.rectangle_0;
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000183 RID: 387 RVA: 0x00002CEA File Offset: 0x00000EEA
		public Font Font_0
		{
			get
			{
				return this.font_0;
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000184 RID: 388 RVA: 0x00002CF2 File Offset: 0x00000EF2
		public Color Color_0
		{
			get
			{
				return this.color_0;
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000185 RID: 389 RVA: 0x00002CFA File Offset: 0x00000EFA
		public Color Color_1
		{
			get
			{
				return this.color_1;
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x06000186 RID: 390 RVA: 0x00002D02 File Offset: 0x00000F02
		public Color Color_2
		{
			get
			{
				return this.color_2;
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x06000187 RID: 391 RVA: 0x00002D0A File Offset: 0x00000F0A
		public Graphics Graphics_0
		{
			get
			{
				return this.graphics_0;
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000188 RID: 392 RVA: 0x00002D12 File Offset: 0x00000F12
		public object Object_0
		{
			get
			{
				return this.object_0;
			}
		}

		// Token: 0x06000189 RID: 393 RVA: 0x0000B4A8 File Offset: 0x000096A8
		public virtual void vmethod_0()
		{
			LinearGradientBrush brush = new LinearGradientBrush(this.rectangle_0, this.color_1, this.color_2, LinearGradientMode.Vertical);
			GraphicsPath graphicsPath = new GraphicsPath();
			graphicsPath.AddArc(this.rectangle_0.Width - 9, 0, 8, 8, -90f, 90f);
			graphicsPath.AddLine(this.rectangle_0.Width - 1, 4, this.rectangle_0.Width - 1, this.rectangle_0.Height - 13);
			graphicsPath.AddArc(this.rectangle_0.Width - 9, this.rectangle_0.Height - 17, 8, 8, 0f, 90f);
			graphicsPath.AddArc(0, this.rectangle_0.Height - 17, 8, 8, 90f, 90f);
			graphicsPath.AddLine(0, this.rectangle_0.Height - 13, 0, 4);
			graphicsPath.AddArc(0, 0, 8, 8, 180f, 90f);
			graphicsPath.AddLine(4, 0, this.rectangle_0.Width - 5, 0);
			this.graphics_0.FillPath(brush, graphicsPath);
			this.graphics_0.DrawPath(Pens.SteelBlue, graphicsPath);
		}

		// Token: 0x040000A1 RID: 161
		private Graphics graphics_0;

		// Token: 0x040000A2 RID: 162
		private Font font_0;

		// Token: 0x040000A3 RID: 163
		private Rectangle rectangle_0;

		// Token: 0x040000A4 RID: 164
		private Color color_0;

		// Token: 0x040000A5 RID: 165
		private Color color_1;

		// Token: 0x040000A6 RID: 166
		private Color color_2;

		// Token: 0x040000A7 RID: 167
		private object object_0;
	}
}
