﻿using System;

namespace ns0
{
	// Token: 0x0200004C RID: 76
	[CLSCompliant(false)]
	public class GClass24 : GClass23
	{
		// Token: 0x06000694 RID: 1684 RVA: 0x0000643E File Offset: 0x0000463E
		public GClass24(GClass23 gclass23_3) : base(gclass23_3)
		{
			base.String_47 = "block";
		}

		// Token: 0x06000695 RID: 1685 RVA: 0x00017260 File Offset: 0x00015460
		public GClass24(GClass23 gclass23_3, GClass23 gclass23_4) : this(gclass23_3)
		{
			int num = gclass23_3.List_0.IndexOf(gclass23_4);
			if (num < 0)
			{
				throw new Exception("insertBefore box doesn't exist on parent");
			}
			gclass23_3.List_0.Remove(this);
			gclass23_3.List_0.Insert(num, this);
		}
	}
}
