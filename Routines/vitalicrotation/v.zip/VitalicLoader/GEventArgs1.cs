﻿using System;
using System.Drawing;

namespace ns0
{
	// Token: 0x0200002E RID: 46
	public class GEventArgs1 : EventArgs
	{
		// Token: 0x060001A6 RID: 422 RVA: 0x00002E0D File Offset: 0x0000100D
		public GEventArgs1(Font font_1, object object_1, int int_2, int int_3)
		{
			this.font_0 = font_1;
			this.object_0 = object_1;
			this.int_0 = int_2;
			this.int_1 = int_3;
		}

		// Token: 0x17000057 RID: 87
		// (get) Token: 0x060001A7 RID: 423 RVA: 0x00002E32 File Offset: 0x00001032
		public Font Font_0
		{
			get
			{
				return this.font_0;
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x060001A8 RID: 424 RVA: 0x00002E3A File Offset: 0x0000103A
		public object Object_0
		{
			get
			{
				return this.object_0;
			}
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x060001A9 RID: 425 RVA: 0x00002E42 File Offset: 0x00001042
		// (set) Token: 0x060001AA RID: 426 RVA: 0x00002E4A File Offset: 0x0000104A
		public int Int32_0
		{
			get
			{
				return this.int_0;
			}
			set
			{
				this.int_0 = value;
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x060001AB RID: 427 RVA: 0x00002E53 File Offset: 0x00001053
		// (set) Token: 0x060001AC RID: 428 RVA: 0x00002E5B File Offset: 0x0000105B
		public int Int32_1
		{
			get
			{
				return this.int_1;
			}
			set
			{
				this.int_1 = value;
			}
		}

		// Token: 0x040000AF RID: 175
		private object object_0;

		// Token: 0x040000B0 RID: 176
		private int int_0;

		// Token: 0x040000B1 RID: 177
		private int int_1;

		// Token: 0x040000B2 RID: 178
		private Font font_0;
	}
}
