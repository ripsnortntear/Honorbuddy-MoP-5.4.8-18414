﻿using System;

namespace ns0
{
	// Token: 0x02000008 RID: 8
	// (Invoke) Token: 0x06000023 RID: 35
	public delegate bool GDelegate1();
}
