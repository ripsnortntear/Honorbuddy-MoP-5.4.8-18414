﻿namespace ns0
{
	// Token: 0x0200001D RID: 29
	public partial class MetroForm : global::System.Windows.Forms.Form, global::System.IDisposable, global::ns0.GInterface1
	{
		// Token: 0x060000DC RID: 220 RVA: 0x0000278B File Offset: 0x0000098B
		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				this.method_13();
			}
			base.Dispose(disposing);
		}
	}
}
