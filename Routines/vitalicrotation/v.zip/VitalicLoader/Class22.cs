﻿using System;

namespace ns0
{
	// Token: 0x02000091 RID: 145
	internal static class Class22
	{
		// Token: 0x0400044C RID: 1100
		public const GEnum10 genum10_0 = GEnum10.const_3;

		// Token: 0x0400044D RID: 1101
		public const GEnum29 genum29_0 = GEnum29.const_1;

		// Token: 0x02000092 RID: 146
		public static class Class23
		{
			// Token: 0x0400044E RID: 1102
			public const string string_0 = "Metro Appearance";

			// Token: 0x0400044F RID: 1103
			public const string string_1 = "Metro Behaviour";
		}
	}
}
