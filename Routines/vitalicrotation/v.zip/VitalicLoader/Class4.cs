﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;

namespace ns0
{
	// Token: 0x02000012 RID: 18
	internal class Class4<T, U, V> : Class1
	{
		// Token: 0x06000077 RID: 119 RVA: 0x00008B4C File Offset: 0x00006D4C
		public static Class4<T, U, V> smethod_10(Class4<T, U, V>.Delegate3 delegate3_1, T gparam_3, U gparam_4, V gparam_5, int int_0)
		{
			Class4<T, U, V> @class = new Class4<T, U, V>();
			Class1.smethod_4(@class, int_0, false);
			@class.delegate3_0 = delegate3_1;
			@class.gparam_0 = gparam_3;
			@class.gparam_1 = gparam_4;
			@class.gparam_2 = gparam_5;
			return @class;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00008B88 File Offset: 0x00006D88
		public static Class4<T, U, V> smethod_11(Class4<T, U, V>.Delegate3 delegate3_1, T gparam_3, U gparam_4, V gparam_5, int int_0)
		{
			Class4<T, U, V> @class = new Class4<T, U, V>();
			Class1.smethod_4(@class, int_0, true);
			@class.delegate3_0 = delegate3_1;
			@class.gparam_0 = gparam_3;
			@class.gparam_1 = gparam_4;
			@class.gparam_2 = gparam_5;
			return @class;
		}

		// Token: 0x06000079 RID: 121 RVA: 0x00008BC4 File Offset: 0x00006DC4
		public static Class4<T, U, V> smethod_12(Class4<T, U, V>.Delegate3 delegate3_1, T gparam_3, U gparam_4, V gparam_5, int int_0)
		{
			Class4<T, U, V> @class = Class4<T, U, V>.smethod_10(delegate3_1, gparam_3, gparam_4, gparam_5, int_0);
			@class.method_3();
			return @class;
		}

		// Token: 0x0600007A RID: 122 RVA: 0x00008BE4 File Offset: 0x00006DE4
		public static Class4<T, U, V> smethod_13(Class4<T, U, V>.Delegate3 delegate3_1, T gparam_3, U gparam_4, V gparam_5, int int_0)
		{
			Class4<T, U, V> @class = Class4<T, U, V>.smethod_11(delegate3_1, gparam_3, gparam_4, gparam_5, int_0);
			@class.method_3();
			return @class;
		}

		// Token: 0x0600007B RID: 123 RVA: 0x00002422 File Offset: 0x00000622
		protected override void vmethod_1()
		{
			this.synchronizationContext_0.Post(new SendOrPostCallback(this.method_11), null);
		}

		// Token: 0x0600007C RID: 124 RVA: 0x00008C04 File Offset: 0x00006E04
		public void method_10(T gparam_3, U gparam_4, V gparam_5, int int_0)
		{
			lock (this.object_0)
			{
				base.method_4();
				this.gparam_0 = gparam_3;
				this.gparam_1 = gparam_4;
				this.gparam_2 = gparam_5;
				base.Int32_1 = int_0;
				base.method_3();
			}
		}

		// Token: 0x0600007D RID: 125 RVA: 0x00008C60 File Offset: 0x00006E60
		[CompilerGenerated]
		private void method_11(object object_2)
		{
			lock (this.object_0)
			{
				if (this.bool_0)
				{
					return;
				}
			}
			if (this.delegate3_0 != null)
			{
				this.delegate3_0(this.gparam_0, this.gparam_1, this.gparam_2);
			}
		}

		// Token: 0x0400002F RID: 47
		private Class4<T, U, V>.Delegate3 delegate3_0;

		// Token: 0x04000030 RID: 48
		private T gparam_0;

		// Token: 0x04000031 RID: 49
		private U gparam_1;

		// Token: 0x04000032 RID: 50
		private V gparam_2;

		// Token: 0x02000013 RID: 19
		// (Invoke) Token: 0x0600007F RID: 127
		public delegate void Delegate3(T data1, U data2, V data3);
	}
}
