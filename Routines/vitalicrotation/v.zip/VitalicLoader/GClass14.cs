﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000036 RID: 54
	[ToolboxBitmap(typeof(ComboBox))]
	public class GClass14 : ComboBox, GInterface2
	{
		// Token: 0x06000233 RID: 563 RVA: 0x0000C890 File Offset: 0x0000AA90
		public GClass14()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer, true);
			base.DrawMode = DrawMode.OwnerDrawFixed;
			base.DropDownStyle = ComboBoxStyle.DropDownList;
			this.bool_4 = (this.SelectedIndex == -1);
		}

		// Token: 0x14000012 RID: 18
		// (add) Token: 0x06000234 RID: 564 RVA: 0x0000C8E8 File Offset: 0x0000AAE8
		// (remove) Token: 0x06000235 RID: 565 RVA: 0x0000C920 File Offset: 0x0000AB20
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000236 RID: 566 RVA: 0x000034FE File Offset: 0x000016FE
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000013 RID: 19
		// (add) Token: 0x06000237 RID: 567 RVA: 0x0000C958 File Offset: 0x0000AB58
		// (remove) Token: 0x06000238 RID: 568 RVA: 0x0000C990 File Offset: 0x0000AB90
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000239 RID: 569 RVA: 0x0000351E File Offset: 0x0000171E
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000014 RID: 20
		// (add) Token: 0x0600023A RID: 570 RVA: 0x0000C9C8 File Offset: 0x0000ABC8
		// (remove) Token: 0x0600023B RID: 571 RVA: 0x0000CA00 File Offset: 0x0000AC00
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x0600023C RID: 572 RVA: 0x0000353E File Offset: 0x0000173E
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x0600023D RID: 573 RVA: 0x0000CA38 File Offset: 0x0000AC38
		// (set) Token: 0x0600023E RID: 574 RVA: 0x0000355E File Offset: 0x0000175E
		[Category("Metro Appearance")]
		[DefaultValue(GEnum10.const_0)]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x0600023F RID: 575 RVA: 0x0000CA90 File Offset: 0x0000AC90
		// (set) Token: 0x06000240 RID: 576 RVA: 0x00003567 File Offset: 0x00001767
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06000241 RID: 577 RVA: 0x00003570 File Offset: 0x00001770
		// (set) Token: 0x06000242 RID: 578 RVA: 0x00003578 File Offset: 0x00001778
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06000243 RID: 579 RVA: 0x00003581 File Offset: 0x00001781
		// (set) Token: 0x06000244 RID: 580 RVA: 0x00003589 File Offset: 0x00001789
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06000245 RID: 581 RVA: 0x00003592 File Offset: 0x00001792
		// (set) Token: 0x06000246 RID: 582 RVA: 0x0000359A File Offset: 0x0000179A
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x06000247 RID: 583 RVA: 0x000035A3 File Offset: 0x000017A3
		// (set) Token: 0x06000248 RID: 584 RVA: 0x000035AB File Offset: 0x000017AB
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x1700007C RID: 124
		// (get) Token: 0x06000249 RID: 585 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x0600024A RID: 586 RVA: 0x00002923 File Offset: 0x00000B23
		[Category("Metro Behaviour")]
		[Browsable(false)]
		[DefaultValue(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x1700007D RID: 125
		// (get) Token: 0x0600024B RID: 587 RVA: 0x000035B4 File Offset: 0x000017B4
		// (set) Token: 0x0600024C RID: 588 RVA: 0x000035BC File Offset: 0x000017BC
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x0600024D RID: 589 RVA: 0x00002243 File Offset: 0x00000443
		// (set) Token: 0x0600024E RID: 590 RVA: 0x000035C5 File Offset: 0x000017C5
		[DefaultValue(DrawMode.OwnerDrawFixed)]
		[Browsable(false)]
		public DrawMode DrawMode_0
		{
			get
			{
				return DrawMode.OwnerDrawFixed;
			}
			set
			{
				base.DrawMode = DrawMode.OwnerDrawFixed;
			}
		}

		// Token: 0x1700007F RID: 127
		// (get) Token: 0x0600024F RID: 591 RVA: 0x000035CE File Offset: 0x000017CE
		// (set) Token: 0x06000250 RID: 592 RVA: 0x000035D1 File Offset: 0x000017D1
		[Browsable(false)]
		[DefaultValue(ComboBoxStyle.DropDownList)]
		public ComboBoxStyle ComboBoxStyle_0
		{
			get
			{
				return ComboBoxStyle.DropDownList;
			}
			set
			{
				base.DropDownStyle = ComboBoxStyle.DropDownList;
			}
		}

		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000251 RID: 593 RVA: 0x000035DA File Offset: 0x000017DA
		// (set) Token: 0x06000252 RID: 594 RVA: 0x000035E2 File Offset: 0x000017E2
		[Category("Metro Appearance")]
		[DefaultValue(GEnum17.const_1)]
		public GEnum17 GEnum17_0
		{
			get
			{
				return this.genum17_0;
			}
			set
			{
				this.genum17_0 = value;
			}
		}

		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000253 RID: 595 RVA: 0x000035EB File Offset: 0x000017EB
		// (set) Token: 0x06000254 RID: 596 RVA: 0x000035F3 File Offset: 0x000017F3
		[Category("Metro Appearance")]
		[DefaultValue(GEnum18.const_1)]
		public GEnum18 GEnum18_0
		{
			get
			{
				return this.genum18_0;
			}
			set
			{
				this.genum18_0 = value;
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06000255 RID: 597 RVA: 0x000035FC File Offset: 0x000017FC
		// (set) Token: 0x06000256 RID: 598 RVA: 0x00003604 File Offset: 0x00001804
		[Browsable(true)]
		[EditorBrowsable(EditorBrowsableState.Always)]
		[DefaultValue("")]
		[Category("Metro Appearance")]
		public string String_0
		{
			get
			{
				return this.string_0;
			}
			set
			{
				this.string_0 = value.Trim();
				base.Invalidate();
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x06000257 RID: 599 RVA: 0x000033C1 File Offset: 0x000015C1
		// (set) Token: 0x06000258 RID: 600 RVA: 0x000033C9 File Offset: 0x000015C9
		[Browsable(false)]
		public override Font Font
		{
			get
			{
				return base.Font;
			}
			set
			{
				base.Font = value;
			}
		}

		// Token: 0x06000259 RID: 601 RVA: 0x0000CAE8 File Offset: 0x0000ACE8
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
				}
				if (color.A == 255 && this.BackgroundImage == null)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600025A RID: 602 RVA: 0x0000CB70 File Offset: 0x0000AD70
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600025B RID: 603 RVA: 0x0000CBD0 File Offset: 0x0000ADD0
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			base.ItemHeight = this.GetPreferredSize(Size.Empty).Height;
			Color color;
			Color color2;
			if (this.bool_5 && !this.bool_6 && base.Enabled)
			{
				color = GClass39.GClass56.GClass62.smethod_1(this.GEnum29_0);
				color2 = GClass39.GClass40.GClass43.smethod_1(this.GEnum29_0);
			}
			else if (this.bool_5 && this.bool_6 && base.Enabled)
			{
				color = GClass39.GClass56.GClass62.smethod_2(this.GEnum29_0);
				color2 = GClass39.GClass40.GClass43.smethod_2(this.GEnum29_0);
			}
			else if (!base.Enabled)
			{
				color = GClass39.GClass56.GClass62.smethod_3(this.GEnum29_0);
				color2 = GClass39.GClass40.GClass43.smethod_3(this.GEnum29_0);
			}
			else
			{
				color = GClass39.GClass56.GClass62.smethod_0(this.GEnum29_0);
				color2 = GClass39.GClass40.GClass43.smethod_0(this.GEnum29_0);
			}
			using (Pen pen = new Pen(color2))
			{
				Rectangle rect = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
				paintEventArgs_0.Graphics.DrawRectangle(pen, rect);
			}
			using (SolidBrush solidBrush = new SolidBrush(color))
			{
				paintEventArgs_0.Graphics.FillPolygon(solidBrush, new Point[]
				{
					new Point(base.Width - 20, base.Height / 2 - 2),
					new Point(base.Width - 9, base.Height / 2 - 2),
					new Point(base.Width - 15, base.Height / 2 + 4)
				});
			}
			Rectangle bounds = new Rectangle(2, 2, base.Width - 20, base.Height - 4);
			TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Text, GClass67.smethod_6(this.genum17_0, this.genum18_0), bounds, color, TextFormatFlags.VerticalCenter);
			this.vmethod_2(new GEventArgs3(Color.Empty, color, paintEventArgs_0.Graphics));
			if (this.bool_3 && this.bool_7)
			{
				ControlPaint.DrawFocusRectangle(paintEventArgs_0.Graphics, base.ClientRectangle);
			}
			if (this.bool_4)
			{
				this.method_1(paintEventArgs_0.Graphics);
			}
		}

		// Token: 0x0600025C RID: 604 RVA: 0x0000CE14 File Offset: 0x0000B014
		protected override void OnDrawItem(DrawItemEventArgs e)
		{
			if (e.Index >= 0)
			{
				Color foreColor;
				if (e.State != (DrawItemState.NoAccelerator | DrawItemState.NoFocusRect) && e.State != DrawItemState.None)
				{
					using (SolidBrush solidBrush = new SolidBrush(GClass39.smethod_0(this.GEnum10_0)))
					{
						e.Graphics.FillRectangle(solidBrush, new Rectangle(e.Bounds.Left, e.Bounds.Top, e.Bounds.Width, e.Bounds.Height));
					}
					foreColor = GClass39.GClass56.GClass58.smethod_0(this.GEnum29_0);
				}
				else
				{
					using (SolidBrush solidBrush2 = new SolidBrush(this.BackColor))
					{
						e.Graphics.FillRectangle(solidBrush2, new Rectangle(e.Bounds.Left, e.Bounds.Top, e.Bounds.Width, e.Bounds.Height));
					}
					foreColor = GClass39.GClass56.GClass59.smethod_0(this.GEnum29_0);
				}
				Rectangle bounds = new Rectangle(0, e.Bounds.Top, e.Bounds.Width, e.Bounds.Height);
				TextRenderer.DrawText(e.Graphics, base.GetItemText(base.Items[e.Index]), GClass67.smethod_6(this.genum17_0, this.genum18_0), bounds, foreColor, TextFormatFlags.VerticalCenter);
				return;
			}
			base.OnDrawItem(e);
		}

		// Token: 0x0600025D RID: 605 RVA: 0x0000CFC4 File Offset: 0x0000B1C4
		private void method_0()
		{
			using (Graphics graphics = base.CreateGraphics())
			{
				this.method_1(graphics);
			}
		}

		// Token: 0x0600025E RID: 606 RVA: 0x0000CFFC File Offset: 0x0000B1FC
		private void method_1(Graphics graphics_0)
		{
			Color backColor = this.BackColor;
			if (!this.bool_0)
			{
				backColor = GClass39.GClass46.smethod_0(this.GEnum29_0);
			}
			Rectangle bounds = new Rectangle(2, 2, base.Width - 20, base.Height - 4);
			TextRenderer.DrawText(graphics_0, this.string_0, GClass67.smethod_6(this.genum17_0, this.genum18_0), bounds, SystemColors.GrayText, backColor, TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter);
		}

		// Token: 0x0600025F RID: 607 RVA: 0x00003618 File Offset: 0x00001818
		protected override void OnGotFocus(EventArgs e)
		{
			this.bool_7 = true;
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x06000260 RID: 608 RVA: 0x0000362E File Offset: 0x0000182E
		protected override void OnLostFocus(EventArgs e)
		{
			base.Enabled = false;
			base.Enabled = true;
			this.bool_7 = false;
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		// Token: 0x06000261 RID: 609 RVA: 0x00003660 File Offset: 0x00001860
		protected override void OnEnter(EventArgs e)
		{
			this.bool_7 = true;
			base.Invalidate();
			base.OnEnter(e);
		}

		// Token: 0x06000262 RID: 610 RVA: 0x00003676 File Offset: 0x00001876
		protected override void OnLeave(EventArgs e)
		{
			this.bool_7 = false;
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnLeave(e);
		}

		// Token: 0x06000263 RID: 611 RVA: 0x0000369A File Offset: 0x0000189A
		protected override void OnKeyDown(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Space)
			{
				this.bool_5 = true;
				this.bool_6 = true;
				base.Invalidate();
			}
			base.OnKeyDown(e);
		}

		// Token: 0x06000264 RID: 612 RVA: 0x000036C1 File Offset: 0x000018C1
		protected override void OnKeyUp(KeyEventArgs e)
		{
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnKeyUp(e);
		}

		// Token: 0x06000265 RID: 613 RVA: 0x000036DE File Offset: 0x000018DE
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_5 = true;
			if (!base.DroppedDown)
			{
				base.Invalidate();
			}
			base.OnMouseEnter(e);
		}

		// Token: 0x06000266 RID: 614 RVA: 0x000036FC File Offset: 0x000018FC
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.bool_6 = true;
				base.Invalidate();
			}
			base.OnMouseDown(e);
		}

		// Token: 0x06000267 RID: 615 RVA: 0x0000371F File Offset: 0x0000191F
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this.bool_6 = false;
			if (!base.DroppedDown)
			{
				base.Invalidate();
			}
			base.OnMouseUp(e);
		}

		// Token: 0x06000268 RID: 616 RVA: 0x0000373D File Offset: 0x0000193D
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_5 = false;
			if (!base.DroppedDown)
			{
				base.Invalidate();
			}
			base.OnMouseLeave(e);
		}

		// Token: 0x06000269 RID: 617 RVA: 0x0000D068 File Offset: 0x0000B268
		public override Size GetPreferredSize(Size proposedSize)
		{
			base.GetPreferredSize(proposedSize);
			Size result;
			using (Graphics graphics = base.CreateGraphics())
			{
				string text = (this.Text.Length > 0) ? this.Text : "MeasureText";
				proposedSize = new Size(int.MaxValue, int.MaxValue);
				result = TextRenderer.MeasureText(graphics, text, GClass67.smethod_6(this.genum17_0, this.genum18_0), proposedSize, TextFormatFlags.VerticalCenter | TextFormatFlags.LeftAndRightPadding);
				result.Height += 4;
			}
			return result;
		}

		// Token: 0x0600026A RID: 618 RVA: 0x0000375B File Offset: 0x0000195B
		protected override void OnSelectedIndexChanged(EventArgs e)
		{
			base.OnSelectedIndexChanged(e);
			this.bool_4 = (this.SelectedIndex == -1);
			base.Invalidate();
		}

		// Token: 0x0600026B RID: 619 RVA: 0x00003779 File Offset: 0x00001979
		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			if ((m.Msg == 15 || m.Msg == 8465) && this.bool_4)
			{
				this.method_0();
			}
		}

		// Token: 0x040000DA RID: 218
		private const int int_0 = 8465;

		// Token: 0x040000DB RID: 219
		private const int int_1 = 15;

		// Token: 0x040000DC RID: 220
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x040000DD RID: 221
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x040000DE RID: 222
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x040000DF RID: 223
		private GEnum10 genum10_0;

		// Token: 0x040000E0 RID: 224
		private GEnum29 genum29_0;

		// Token: 0x040000E1 RID: 225
		private GClass8 gclass8_0;

		// Token: 0x040000E2 RID: 226
		private bool bool_0;

		// Token: 0x040000E3 RID: 227
		private bool bool_1;

		// Token: 0x040000E4 RID: 228
		private bool bool_2;

		// Token: 0x040000E5 RID: 229
		private bool bool_3;

		// Token: 0x040000E6 RID: 230
		private GEnum17 genum17_0 = GEnum17.const_1;

		// Token: 0x040000E7 RID: 231
		private GEnum18 genum18_0 = GEnum18.const_1;

		// Token: 0x040000E8 RID: 232
		private string string_0 = "";

		// Token: 0x040000E9 RID: 233
		private bool bool_4;

		// Token: 0x040000EA RID: 234
		private bool bool_5;

		// Token: 0x040000EB RID: 235
		private bool bool_6;

		// Token: 0x040000EC RID: 236
		private bool bool_7;
	}
}
