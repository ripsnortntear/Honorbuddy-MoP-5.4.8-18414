﻿using System;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200002D RID: 45
	public interface GInterface4
	{
		// Token: 0x060001A1 RID: 417
		object imethod_0(string string_0);

		// Token: 0x060001A2 RID: 418
		void imethod_1(string string_0, Control control_0);

		// Token: 0x060001A3 RID: 419
		void imethod_2(Control control_0);

		// Token: 0x1400000A RID: 10
		// (add) Token: 0x060001A4 RID: 420
		// (remove) Token: 0x060001A5 RID: 421
		event GDelegate4 Event_0;
	}
}
