﻿using System;

namespace ns0
{
	// Token: 0x02000061 RID: 97
	[CLSCompliant(false)]
	public class GClass35
	{
		// Token: 0x0400030F RID: 783
		public const string string_0 = "A";

		// Token: 0x04000310 RID: 784
		public const string string_1 = "ABBR";

		// Token: 0x04000311 RID: 785
		public const string string_2 = "ACRONYM";

		// Token: 0x04000312 RID: 786
		public const string string_3 = "ADDRESS";

		// Token: 0x04000313 RID: 787
		public const string string_4 = "APPLET";

		// Token: 0x04000314 RID: 788
		public const string string_5 = "AREA";

		// Token: 0x04000315 RID: 789
		public const string string_6 = "B";

		// Token: 0x04000316 RID: 790
		public const string string_7 = "BASE";

		// Token: 0x04000317 RID: 791
		public const string string_8 = "BASEFONT";

		// Token: 0x04000318 RID: 792
		public const string string_9 = "BDO";

		// Token: 0x04000319 RID: 793
		public const string string_10 = "BIG";

		// Token: 0x0400031A RID: 794
		public const string string_11 = "BLOCKQUOTE";

		// Token: 0x0400031B RID: 795
		public const string string_12 = "BODY";

		// Token: 0x0400031C RID: 796
		public const string string_13 = "BR";

		// Token: 0x0400031D RID: 797
		public const string string_14 = "BUTTON";

		// Token: 0x0400031E RID: 798
		public const string string_15 = "CAPTION";

		// Token: 0x0400031F RID: 799
		public const string string_16 = "CENTER";

		// Token: 0x04000320 RID: 800
		public const string string_17 = "CITE";

		// Token: 0x04000321 RID: 801
		public const string string_18 = "CODE";

		// Token: 0x04000322 RID: 802
		public const string string_19 = "COL";

		// Token: 0x04000323 RID: 803
		public const string string_20 = "COLGROUP";

		// Token: 0x04000324 RID: 804
		public const string string_21 = "DD";

		// Token: 0x04000325 RID: 805
		public const string string_22 = "DEL";

		// Token: 0x04000326 RID: 806
		public const string string_23 = "DFN";

		// Token: 0x04000327 RID: 807
		public const string string_24 = "DIR";

		// Token: 0x04000328 RID: 808
		public const string string_25 = "DIV";

		// Token: 0x04000329 RID: 809
		public const string string_26 = "DL";

		// Token: 0x0400032A RID: 810
		public const string string_27 = "DT";

		// Token: 0x0400032B RID: 811
		public const string string_28 = "EM";

		// Token: 0x0400032C RID: 812
		public const string string_29 = "FIELDSET";

		// Token: 0x0400032D RID: 813
		public const string string_30 = "FONT";

		// Token: 0x0400032E RID: 814
		public const string string_31 = "FORM";

		// Token: 0x0400032F RID: 815
		public const string string_32 = "FRAME";

		// Token: 0x04000330 RID: 816
		public const string string_33 = "FRAMESET";

		// Token: 0x04000331 RID: 817
		public const string string_34 = "H1";

		// Token: 0x04000332 RID: 818
		public const string string_35 = "H2";

		// Token: 0x04000333 RID: 819
		public const string string_36 = "H3";

		// Token: 0x04000334 RID: 820
		public const string string_37 = "H4";

		// Token: 0x04000335 RID: 821
		public const string string_38 = "H5";

		// Token: 0x04000336 RID: 822
		public const string string_39 = "H6";

		// Token: 0x04000337 RID: 823
		public const string string_40 = "HEAD";

		// Token: 0x04000338 RID: 824
		public const string string_41 = "HR";

		// Token: 0x04000339 RID: 825
		public const string string_42 = "HTML";

		// Token: 0x0400033A RID: 826
		public const string string_43 = "I";

		// Token: 0x0400033B RID: 827
		public const string string_44 = "IFRAME";

		// Token: 0x0400033C RID: 828
		public const string string_45 = "IMG";

		// Token: 0x0400033D RID: 829
		public const string string_46 = "INPUT";

		// Token: 0x0400033E RID: 830
		public const string string_47 = "INS";

		// Token: 0x0400033F RID: 831
		public const string string_48 = "ISINDEX";

		// Token: 0x04000340 RID: 832
		public const string string_49 = "KBD";

		// Token: 0x04000341 RID: 833
		public const string string_50 = "LABEL";

		// Token: 0x04000342 RID: 834
		public const string string_51 = "LEGEND";

		// Token: 0x04000343 RID: 835
		public const string string_52 = "LI";

		// Token: 0x04000344 RID: 836
		public const string string_53 = "LINK";

		// Token: 0x04000345 RID: 837
		public const string string_54 = "MAP";

		// Token: 0x04000346 RID: 838
		public const string string_55 = "MENU";

		// Token: 0x04000347 RID: 839
		public const string string_56 = "META";

		// Token: 0x04000348 RID: 840
		public const string string_57 = "NOFRAMES";

		// Token: 0x04000349 RID: 841
		public const string string_58 = "NOSCRIPT";

		// Token: 0x0400034A RID: 842
		public const string string_59 = "OBJECT";

		// Token: 0x0400034B RID: 843
		public const string string_60 = "OL";

		// Token: 0x0400034C RID: 844
		public const string string_61 = "OPTGROUP";

		// Token: 0x0400034D RID: 845
		public const string string_62 = "OPTION";

		// Token: 0x0400034E RID: 846
		public const string string_63 = "P";

		// Token: 0x0400034F RID: 847
		public const string string_64 = "PARAM";

		// Token: 0x04000350 RID: 848
		public const string string_65 = "PRE";

		// Token: 0x04000351 RID: 849
		public const string string_66 = "Q";

		// Token: 0x04000352 RID: 850
		public const string string_67 = "S";

		// Token: 0x04000353 RID: 851
		public const string string_68 = "SAMP";

		// Token: 0x04000354 RID: 852
		public const string string_69 = "SCRIPT";

		// Token: 0x04000355 RID: 853
		public const string string_70 = "SELECT";

		// Token: 0x04000356 RID: 854
		public const string string_71 = "SMALL";

		// Token: 0x04000357 RID: 855
		public const string string_72 = "SPAN";

		// Token: 0x04000358 RID: 856
		public const string string_73 = "STRIKE";

		// Token: 0x04000359 RID: 857
		public const string string_74 = "STRONG";

		// Token: 0x0400035A RID: 858
		public const string string_75 = "STYLE";

		// Token: 0x0400035B RID: 859
		public const string string_76 = "SUB";

		// Token: 0x0400035C RID: 860
		public const string string_77 = "SUP";

		// Token: 0x0400035D RID: 861
		public const string string_78 = "TABLE";

		// Token: 0x0400035E RID: 862
		public const string string_79 = "TBODY";

		// Token: 0x0400035F RID: 863
		public const string string_80 = "TD";

		// Token: 0x04000360 RID: 864
		public const string string_81 = "TEXTAREA";

		// Token: 0x04000361 RID: 865
		public const string string_82 = "TFOOT";

		// Token: 0x04000362 RID: 866
		public const string string_83 = "TH";

		// Token: 0x04000363 RID: 867
		public const string string_84 = "THEAD";

		// Token: 0x04000364 RID: 868
		public const string string_85 = "TITLE";

		// Token: 0x04000365 RID: 869
		public const string string_86 = "TR";

		// Token: 0x04000366 RID: 870
		public const string string_87 = "TT";

		// Token: 0x04000367 RID: 871
		public const string string_88 = "U";

		// Token: 0x04000368 RID: 872
		public const string string_89 = "UL";

		// Token: 0x04000369 RID: 873
		public const string string_90 = "VAR";

		// Token: 0x0400036A RID: 874
		public const string string_91 = "abbr";

		// Token: 0x0400036B RID: 875
		public const string string_92 = "accept";

		// Token: 0x0400036C RID: 876
		public const string string_93 = "accesskey";

		// Token: 0x0400036D RID: 877
		public const string string_94 = "action";

		// Token: 0x0400036E RID: 878
		public const string string_95 = "align";

		// Token: 0x0400036F RID: 879
		public const string string_96 = "alink";

		// Token: 0x04000370 RID: 880
		public const string string_97 = "alt";

		// Token: 0x04000371 RID: 881
		public const string string_98 = "archive";

		// Token: 0x04000372 RID: 882
		public const string string_99 = "axis";

		// Token: 0x04000373 RID: 883
		public const string string_100 = "background";

		// Token: 0x04000374 RID: 884
		public const string string_101 = "bgcolor";

		// Token: 0x04000375 RID: 885
		public const string string_102 = "border";

		// Token: 0x04000376 RID: 886
		public const string string_103 = "bordercolor";

		// Token: 0x04000377 RID: 887
		public const string string_104 = "cellpadding";

		// Token: 0x04000378 RID: 888
		public const string string_105 = "cellspacing";

		// Token: 0x04000379 RID: 889
		public const string string_106 = "char";

		// Token: 0x0400037A RID: 890
		public const string string_107 = "charoff";

		// Token: 0x0400037B RID: 891
		public const string string_108 = "charset";

		// Token: 0x0400037C RID: 892
		public const string string_109 = "checked";

		// Token: 0x0400037D RID: 893
		public const string string_110 = "cite";

		// Token: 0x0400037E RID: 894
		public const string string_111 = "class";

		// Token: 0x0400037F RID: 895
		public const string string_112 = "classid";

		// Token: 0x04000380 RID: 896
		public const string string_113 = "clear";

		// Token: 0x04000381 RID: 897
		public const string string_114 = "code";

		// Token: 0x04000382 RID: 898
		public const string string_115 = "codebase";

		// Token: 0x04000383 RID: 899
		public const string string_116 = "codetype";

		// Token: 0x04000384 RID: 900
		public const string string_117 = "color";

		// Token: 0x04000385 RID: 901
		public const string string_118 = "cols";

		// Token: 0x04000386 RID: 902
		public const string string_119 = "colspan";

		// Token: 0x04000387 RID: 903
		public const string string_120 = "compact";

		// Token: 0x04000388 RID: 904
		public const string string_121 = "content";

		// Token: 0x04000389 RID: 905
		public const string string_122 = "coords";

		// Token: 0x0400038A RID: 906
		public const string string_123 = "data";

		// Token: 0x0400038B RID: 907
		public const string string_124 = "datetime";

		// Token: 0x0400038C RID: 908
		public const string string_125 = "declare";

		// Token: 0x0400038D RID: 909
		public const string string_126 = "defer";

		// Token: 0x0400038E RID: 910
		public const string string_127 = "dir";

		// Token: 0x0400038F RID: 911
		public const string string_128 = "disabled";

		// Token: 0x04000390 RID: 912
		public const string string_129 = "enctype";

		// Token: 0x04000391 RID: 913
		public const string string_130 = "face";

		// Token: 0x04000392 RID: 914
		public const string string_131 = "for";

		// Token: 0x04000393 RID: 915
		public const string string_132 = "frame";

		// Token: 0x04000394 RID: 916
		public const string string_133 = "frameborder";

		// Token: 0x04000395 RID: 917
		public const string string_134 = "headers";

		// Token: 0x04000396 RID: 918
		public const string string_135 = "height";

		// Token: 0x04000397 RID: 919
		public const string string_136 = "href";

		// Token: 0x04000398 RID: 920
		public const string string_137 = "hreflang";

		// Token: 0x04000399 RID: 921
		public const string string_138 = "hspace";

		// Token: 0x0400039A RID: 922
		public const string string_139 = "http-equiv";

		// Token: 0x0400039B RID: 923
		public const string string_140 = "id";

		// Token: 0x0400039C RID: 924
		public const string string_141 = "ismap";

		// Token: 0x0400039D RID: 925
		public const string string_142 = "label";

		// Token: 0x0400039E RID: 926
		public const string string_143 = "lang";

		// Token: 0x0400039F RID: 927
		public const string string_144 = "language";

		// Token: 0x040003A0 RID: 928
		public const string string_145 = "link";

		// Token: 0x040003A1 RID: 929
		public const string string_146 = "longdesc";

		// Token: 0x040003A2 RID: 930
		public const string string_147 = "marginheight";

		// Token: 0x040003A3 RID: 931
		public const string string_148 = "marginwidth";

		// Token: 0x040003A4 RID: 932
		public const string string_149 = "maxlength";

		// Token: 0x040003A5 RID: 933
		public const string string_150 = "media";

		// Token: 0x040003A6 RID: 934
		public const string string_151 = "method";

		// Token: 0x040003A7 RID: 935
		public const string string_152 = "multiple";

		// Token: 0x040003A8 RID: 936
		public const string string_153 = "name";

		// Token: 0x040003A9 RID: 937
		public const string string_154 = "nohref";

		// Token: 0x040003AA RID: 938
		public const string string_155 = "noresize";

		// Token: 0x040003AB RID: 939
		public const string string_156 = "noshade";

		// Token: 0x040003AC RID: 940
		public const string string_157 = "nowrap";

		// Token: 0x040003AD RID: 941
		public const string string_158 = "object";

		// Token: 0x040003AE RID: 942
		public const string string_159 = "onblur";

		// Token: 0x040003AF RID: 943
		public const string string_160 = "onchange";

		// Token: 0x040003B0 RID: 944
		public const string string_161 = "onclick";

		// Token: 0x040003B1 RID: 945
		public const string string_162 = "ondblclick";

		// Token: 0x040003B2 RID: 946
		public const string string_163 = "onfocus";

		// Token: 0x040003B3 RID: 947
		public const string string_164 = "onkeydown";

		// Token: 0x040003B4 RID: 948
		public const string string_165 = "onkeypress";

		// Token: 0x040003B5 RID: 949
		public const string string_166 = "onkeyup";

		// Token: 0x040003B6 RID: 950
		public const string string_167 = "onload";

		// Token: 0x040003B7 RID: 951
		public const string string_168 = "onmousedown";

		// Token: 0x040003B8 RID: 952
		public const string string_169 = "onmousemove";

		// Token: 0x040003B9 RID: 953
		public const string string_170 = "onmouseout";

		// Token: 0x040003BA RID: 954
		public const string string_171 = "onmouseover";

		// Token: 0x040003BB RID: 955
		public const string string_172 = "onmouseup";

		// Token: 0x040003BC RID: 956
		public const string string_173 = "onreset";

		// Token: 0x040003BD RID: 957
		public const string string_174 = "onselect";

		// Token: 0x040003BE RID: 958
		public const string string_175 = "onsubmit";

		// Token: 0x040003BF RID: 959
		public const string string_176 = "onunload";

		// Token: 0x040003C0 RID: 960
		public const string string_177 = "profile";

		// Token: 0x040003C1 RID: 961
		public const string string_178 = "prompt";

		// Token: 0x040003C2 RID: 962
		public const string string_179 = "readonly";

		// Token: 0x040003C3 RID: 963
		public const string string_180 = "rel";

		// Token: 0x040003C4 RID: 964
		public const string string_181 = "rev";

		// Token: 0x040003C5 RID: 965
		public const string string_182 = "rows";

		// Token: 0x040003C6 RID: 966
		public const string string_183 = "rowspan";

		// Token: 0x040003C7 RID: 967
		public const string string_184 = "rules";

		// Token: 0x040003C8 RID: 968
		public const string string_185 = "scheme";

		// Token: 0x040003C9 RID: 969
		public const string string_186 = "scope";

		// Token: 0x040003CA RID: 970
		public const string string_187 = "scrolling";

		// Token: 0x040003CB RID: 971
		public const string string_188 = "selected";

		// Token: 0x040003CC RID: 972
		public const string string_189 = "shape";

		// Token: 0x040003CD RID: 973
		public const string string_190 = "size";

		// Token: 0x040003CE RID: 974
		public const string string_191 = "span";

		// Token: 0x040003CF RID: 975
		public const string string_192 = "src";

		// Token: 0x040003D0 RID: 976
		public const string string_193 = "standby";

		// Token: 0x040003D1 RID: 977
		public const string string_194 = "start";

		// Token: 0x040003D2 RID: 978
		public const string string_195 = "style";

		// Token: 0x040003D3 RID: 979
		public const string string_196 = "summary";

		// Token: 0x040003D4 RID: 980
		public const string string_197 = "tabindex";

		// Token: 0x040003D5 RID: 981
		public const string string_198 = "target";

		// Token: 0x040003D6 RID: 982
		public const string string_199 = "text";

		// Token: 0x040003D7 RID: 983
		public const string string_200 = "title";

		// Token: 0x040003D8 RID: 984
		public const string string_201 = "type";

		// Token: 0x040003D9 RID: 985
		public const string string_202 = "usemap";

		// Token: 0x040003DA RID: 986
		public const string string_203 = "valign";

		// Token: 0x040003DB RID: 987
		public const string string_204 = "value";

		// Token: 0x040003DC RID: 988
		public const string string_205 = "valuetype";

		// Token: 0x040003DD RID: 989
		public const string string_206 = "version";

		// Token: 0x040003DE RID: 990
		public const string string_207 = "vlink";

		// Token: 0x040003DF RID: 991
		public const string string_208 = "vspace";

		// Token: 0x040003E0 RID: 992
		public const string string_209 = "width";

		// Token: 0x040003E1 RID: 993
		public const string string_210 = "left";

		// Token: 0x040003E2 RID: 994
		public const string string_211 = "right";

		// Token: 0x040003E3 RID: 995
		public const string string_212 = "top";

		// Token: 0x040003E4 RID: 996
		public const string string_213 = "center";

		// Token: 0x040003E5 RID: 997
		public const string string_214 = "middle";

		// Token: 0x040003E6 RID: 998
		public const string string_215 = "bottom";

		// Token: 0x040003E7 RID: 999
		public const string string_216 = "justify";
	}
}
