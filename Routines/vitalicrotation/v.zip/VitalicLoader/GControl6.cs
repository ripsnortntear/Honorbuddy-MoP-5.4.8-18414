﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200004A RID: 74
	public class GControl6 : UserControl, GInterface2
	{
		// Token: 0x14000040 RID: 64
		// (add) Token: 0x06000580 RID: 1408 RVA: 0x00013E44 File Offset: 0x00012044
		// (remove) Token: 0x06000581 RID: 1409 RVA: 0x00013E7C File Offset: 0x0001207C
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000582 RID: 1410 RVA: 0x000059EE File Offset: 0x00003BEE
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000041 RID: 65
		// (add) Token: 0x06000583 RID: 1411 RVA: 0x00013EB4 File Offset: 0x000120B4
		// (remove) Token: 0x06000584 RID: 1412 RVA: 0x00013EEC File Offset: 0x000120EC
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000585 RID: 1413 RVA: 0x00005A0E File Offset: 0x00003C0E
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000042 RID: 66
		// (add) Token: 0x06000586 RID: 1414 RVA: 0x00013F24 File Offset: 0x00012124
		// (remove) Token: 0x06000587 RID: 1415 RVA: 0x00013F5C File Offset: 0x0001215C
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000588 RID: 1416 RVA: 0x00005A2E File Offset: 0x00003C2E
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x17000156 RID: 342
		// (get) Token: 0x06000589 RID: 1417 RVA: 0x00013F94 File Offset: 0x00012194
		// (set) Token: 0x0600058A RID: 1418 RVA: 0x00005A4E File Offset: 0x00003C4E
		[Category("Metro Appearance")]
		[DefaultValue(GEnum10.const_0)]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x17000157 RID: 343
		// (get) Token: 0x0600058B RID: 1419 RVA: 0x00013FEC File Offset: 0x000121EC
		// (set) Token: 0x0600058C RID: 1420 RVA: 0x00005A57 File Offset: 0x00003C57
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x17000158 RID: 344
		// (get) Token: 0x0600058D RID: 1421 RVA: 0x00005A60 File Offset: 0x00003C60
		// (set) Token: 0x0600058E RID: 1422 RVA: 0x00005A68 File Offset: 0x00003C68
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x17000159 RID: 345
		// (get) Token: 0x0600058F RID: 1423 RVA: 0x00005A71 File Offset: 0x00003C71
		// (set) Token: 0x06000590 RID: 1424 RVA: 0x00005A79 File Offset: 0x00003C79
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x1700015A RID: 346
		// (get) Token: 0x06000591 RID: 1425 RVA: 0x00005A82 File Offset: 0x00003C82
		// (set) Token: 0x06000592 RID: 1426 RVA: 0x00005A8A File Offset: 0x00003C8A
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x1700015B RID: 347
		// (get) Token: 0x06000593 RID: 1427 RVA: 0x00005A93 File Offset: 0x00003C93
		// (set) Token: 0x06000594 RID: 1428 RVA: 0x00005A9B File Offset: 0x00003C9B
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x1700015C RID: 348
		// (get) Token: 0x06000595 RID: 1429 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x06000596 RID: 1430 RVA: 0x00002923 File Offset: 0x00000B23
		[Browsable(false)]
		[Category("Metro Behaviour")]
		[DefaultValue(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x06000597 RID: 1431 RVA: 0x00014044 File Offset: 0x00012244
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
				}
				if (color.A == 255 && this.BackgroundImage == null)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x06000598 RID: 1432 RVA: 0x000140CC File Offset: 0x000122CC
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x06000599 RID: 1433 RVA: 0x00005AA4 File Offset: 0x00003CA4
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			this.vmethod_2(new GEventArgs3(Color.Empty, Color.Empty, paintEventArgs_0.Graphics));
		}

		// Token: 0x0600059A RID: 1434 RVA: 0x0000472B File Offset: 0x0000292B
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x040001ED RID: 493
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x040001EE RID: 494
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x040001EF RID: 495
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x040001F0 RID: 496
		private GEnum10 genum10_0;

		// Token: 0x040001F1 RID: 497
		private GEnum29 genum29_0;

		// Token: 0x040001F2 RID: 498
		private GClass8 gclass8_0;

		// Token: 0x040001F3 RID: 499
		private bool bool_0;

		// Token: 0x040001F4 RID: 500
		private bool bool_1;

		// Token: 0x040001F5 RID: 501
		private bool bool_2;
	}
}
