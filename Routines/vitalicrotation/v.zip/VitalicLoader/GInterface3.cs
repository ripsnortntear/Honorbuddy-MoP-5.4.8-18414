﻿using System;
using System.Drawing;

namespace ns0
{
	// Token: 0x02000027 RID: 39
	public interface GInterface3 : GInterface1
	{
		// Token: 0x06000156 RID: 342
		void imethod_0(Point point_0, Size size_0);

		// Token: 0x06000157 RID: 343
		void imethod_1();

		// Token: 0x06000158 RID: 344
		void imethod_2(string string_0);

		// Token: 0x06000159 RID: 345
		void imethod_3(object object_0);

		// Token: 0x0600015A RID: 346
		void imethod_4(Exception exception_0);
	}
}
