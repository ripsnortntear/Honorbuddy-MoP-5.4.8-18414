﻿using System;

namespace ns0
{
	// Token: 0x0200005C RID: 92
	public class GAttribute0 : Attribute
	{
		// Token: 0x06000700 RID: 1792 RVA: 0x00006893 File Offset: 0x00004A93
		public GAttribute0(string string_0)
		{
			this.Name = string_0;
		}

		// Token: 0x17000202 RID: 514
		// (get) Token: 0x06000701 RID: 1793 RVA: 0x000068A2 File Offset: 0x00004AA2
		// (set) Token: 0x06000702 RID: 1794 RVA: 0x000068AA File Offset: 0x00004AAA
		public string Name
		{
			get
			{
				return this._name;
			}
			set
			{
				this._name = value;
			}
		}

		// Token: 0x040002FF RID: 767
		private string _name;
	}
}
