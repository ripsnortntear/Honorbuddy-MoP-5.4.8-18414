﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Reflection;

namespace ns0
{
	// Token: 0x02000064 RID: 100
	public static class GClass36
	{
		// Token: 0x06000749 RID: 1865 RVA: 0x00006AE6 File Offset: 0x00004CE6
		static GClass36()
		{
			GClass36.List_0.Add(Assembly.GetExecutingAssembly());
		}

		// Token: 0x17000218 RID: 536
		// (get) Token: 0x0600074A RID: 1866 RVA: 0x00006B01 File Offset: 0x00004D01
		public static List<Assembly> List_0
		{
			get
			{
				return GClass36.list_0;
			}
		}

		// Token: 0x0600074B RID: 1867 RVA: 0x00006B08 File Offset: 0x00004D08
		internal static void smethod_0(Assembly assembly_0)
		{
			if (!GClass36.List_0.Contains(assembly_0))
			{
				GClass36.List_0.Add(assembly_0);
			}
		}

		// Token: 0x0600074C RID: 1868 RVA: 0x00006B22 File Offset: 0x00004D22
		public static void smethod_1(Graphics graphics_0, string string_0, PointF pointF_0, float float_0)
		{
			GClass36.smethod_2(graphics_0, string_0, new RectangleF(pointF_0, new SizeF(float_0, 0f)), false);
		}

		// Token: 0x0600074D RID: 1869 RVA: 0x0001B94C File Offset: 0x00019B4C
		public static void smethod_2(Graphics graphics_0, string string_0, RectangleF rectangleF_0, bool bool_0)
		{
			GClass28 gclass = new GClass28(string_0);
			Region clip = graphics_0.Clip;
			if (bool_0)
			{
				graphics_0.SetClip(rectangleF_0);
			}
			gclass.method_32(rectangleF_0);
			gclass.vmethod_0(graphics_0);
			gclass.method_24(graphics_0);
			if (bool_0)
			{
				graphics_0.SetClip(clip, CombineMode.Replace);
			}
		}

		// Token: 0x040003E9 RID: 1001
		private static List<Assembly> list_0 = new List<Assembly>();
	}
}
