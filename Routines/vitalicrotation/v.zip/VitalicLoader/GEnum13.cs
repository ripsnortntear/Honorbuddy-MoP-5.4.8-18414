﻿using System;

namespace ns0
{
	// Token: 0x02000095 RID: 149
	public enum GEnum13
	{
		// Token: 0x04000459 RID: 1113
		const_0,
		// Token: 0x0400045A RID: 1114
		const_1,
		// Token: 0x0400045B RID: 1115
		const_2
	}
}
