﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;

namespace ns0
{
	// Token: 0x02000010 RID: 16
	internal class Class3<T, U> : Class1
	{
		// Token: 0x0600006B RID: 107 RVA: 0x000089F4 File Offset: 0x00006BF4
		public static Class3<T, U> smethod_10(Class3<T, U>.Delegate2 delegate2_1, T gparam_2, U gparam_3, int int_0)
		{
			Class3<T, U> @class = new Class3<T, U>();
			Class1.smethod_4(@class, int_0, false);
			@class.delegate2_0 = delegate2_1;
			@class.gparam_0 = gparam_2;
			@class.gparam_1 = gparam_3;
			return @class;
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00008A28 File Offset: 0x00006C28
		public static Class3<T, U> smethod_11(Class3<T, U>.Delegate2 delegate2_1, T gparam_2, U gparam_3, int int_0)
		{
			Class3<T, U> @class = new Class3<T, U>();
			Class1.smethod_4(@class, int_0, true);
			@class.delegate2_0 = delegate2_1;
			@class.gparam_0 = gparam_2;
			@class.gparam_1 = gparam_3;
			return @class;
		}

		// Token: 0x0600006D RID: 109 RVA: 0x00008A5C File Offset: 0x00006C5C
		public static Class3<T, U> smethod_12(Class3<T, U>.Delegate2 delegate2_1, T gparam_2, U gparam_3, int int_0)
		{
			Class3<T, U> @class = Class3<T, U>.smethod_10(delegate2_1, gparam_2, gparam_3, int_0);
			@class.method_3();
			return @class;
		}

		// Token: 0x0600006E RID: 110 RVA: 0x00008A7C File Offset: 0x00006C7C
		public static Class3<T, U> smethod_13(Class3<T, U>.Delegate2 delegate2_1, T gparam_2, U gparam_3, int int_0)
		{
			Class3<T, U> @class = Class3<T, U>.smethod_11(delegate2_1, gparam_2, gparam_3, int_0);
			@class.method_3();
			return @class;
		}

		// Token: 0x0600006F RID: 111 RVA: 0x00002408 File Offset: 0x00000608
		protected override void vmethod_1()
		{
			this.synchronizationContext_0.Post(new SendOrPostCallback(this.method_11), null);
		}

		// Token: 0x06000070 RID: 112 RVA: 0x00008A9C File Offset: 0x00006C9C
		public void method_10(T gparam_2, U gparam_3, int int_0)
		{
			lock (this.object_0)
			{
				base.method_4();
				this.gparam_0 = gparam_2;
				this.gparam_1 = gparam_3;
				base.Int32_1 = int_0;
				base.method_3();
			}
		}

		// Token: 0x06000071 RID: 113 RVA: 0x00008AF0 File Offset: 0x00006CF0
		[CompilerGenerated]
		private void method_11(object object_2)
		{
			lock (this.object_0)
			{
				if (this.bool_0)
				{
					return;
				}
			}
			if (this.delegate2_0 != null)
			{
				this.delegate2_0(this.gparam_0, this.gparam_1);
			}
		}

		// Token: 0x0400002C RID: 44
		private Class3<T, U>.Delegate2 delegate2_0;

		// Token: 0x0400002D RID: 45
		private T gparam_0;

		// Token: 0x0400002E RID: 46
		private U gparam_1;

		// Token: 0x02000011 RID: 17
		// (Invoke) Token: 0x06000073 RID: 115
		public delegate void Delegate2(T data1, U data2);
	}
}
