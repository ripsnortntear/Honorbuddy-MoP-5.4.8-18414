﻿using System;

namespace ns0
{
	// Token: 0x02000087 RID: 135
	public enum GEnum7
	{
		// Token: 0x04000418 RID: 1048
		const_0,
		// Token: 0x04000419 RID: 1049
		const_1
	}
}
