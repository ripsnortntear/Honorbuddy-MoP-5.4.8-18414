﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Security;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200003B RID: 59
	[ToolboxBitmap(typeof(Panel))]
	public class GClass17 : Panel, GInterface2
	{
		// Token: 0x060002CC RID: 716 RVA: 0x0000DDF4 File Offset: 0x0000BFF4
		public GClass17()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.Controls.Add(this.gcontrol1_0);
			base.Controls.Add(this.gcontrol1_1);
			this.gcontrol1_0.Boolean_0 = true;
			this.gcontrol1_1.Boolean_0 = true;
			this.gcontrol1_0.Visible = false;
			this.gcontrol1_1.Visible = false;
			this.gcontrol1_0.Event_0 += this.method_1;
			this.gcontrol1_1.Event_0 += this.method_0;
		}

		// Token: 0x1400001B RID: 27
		// (add) Token: 0x060002CD RID: 717 RVA: 0x0000DEAC File Offset: 0x0000C0AC
		// (remove) Token: 0x060002CE RID: 718 RVA: 0x0000DEE4 File Offset: 0x0000C0E4
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060002CF RID: 719 RVA: 0x00003BAD File Offset: 0x00001DAD
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x1400001C RID: 28
		// (add) Token: 0x060002D0 RID: 720 RVA: 0x0000DF1C File Offset: 0x0000C11C
		// (remove) Token: 0x060002D1 RID: 721 RVA: 0x0000DF54 File Offset: 0x0000C154
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x00003BCD File Offset: 0x00001DCD
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x1400001D RID: 29
		// (add) Token: 0x060002D3 RID: 723 RVA: 0x0000DF8C File Offset: 0x0000C18C
		// (remove) Token: 0x060002D4 RID: 724 RVA: 0x0000DFC4 File Offset: 0x0000C1C4
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x00003BED File Offset: 0x00001DED
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x1700009A RID: 154
		// (get) Token: 0x060002D6 RID: 726 RVA: 0x0000DFFC File Offset: 0x0000C1FC
		// (set) Token: 0x060002D7 RID: 727 RVA: 0x00003C0D File Offset: 0x00001E0D
		[DefaultValue(GEnum10.const_0)]
		[Category("Metro Appearance")]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x060002D8 RID: 728 RVA: 0x0000E054 File Offset: 0x0000C254
		// (set) Token: 0x060002D9 RID: 729 RVA: 0x00003C16 File Offset: 0x00001E16
		[DefaultValue(GEnum29.const_0)]
		[Category("Metro Appearance")]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x060002DA RID: 730 RVA: 0x00003C1F File Offset: 0x00001E1F
		// (set) Token: 0x060002DB RID: 731 RVA: 0x00003C27 File Offset: 0x00001E27
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x060002DC RID: 732 RVA: 0x00003C30 File Offset: 0x00001E30
		// (set) Token: 0x060002DD RID: 733 RVA: 0x00003C38 File Offset: 0x00001E38
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x060002DE RID: 734 RVA: 0x00003C41 File Offset: 0x00001E41
		// (set) Token: 0x060002DF RID: 735 RVA: 0x00003C49 File Offset: 0x00001E49
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x1700009F RID: 159
		// (get) Token: 0x060002E0 RID: 736 RVA: 0x00003C52 File Offset: 0x00001E52
		// (set) Token: 0x060002E1 RID: 737 RVA: 0x00003C5A File Offset: 0x00001E5A
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x060002E2 RID: 738 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x060002E3 RID: 739 RVA: 0x00002923 File Offset: 0x00000B23
		[Category("Metro Behaviour")]
		[Browsable(false)]
		[DefaultValue(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x060002E4 RID: 740 RVA: 0x00003C63 File Offset: 0x00001E63
		// (set) Token: 0x060002E5 RID: 741 RVA: 0x00003C6B File Offset: 0x00001E6B
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x060002E6 RID: 742 RVA: 0x00003C74 File Offset: 0x00001E74
		// (set) Token: 0x060002E7 RID: 743 RVA: 0x00003C7C File Offset: 0x00001E7C
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_1
		{
			get
			{
				return this.bool_4;
			}
			set
			{
				this.bool_4 = value;
			}
		}

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x060002E8 RID: 744 RVA: 0x00003C85 File Offset: 0x00001E85
		// (set) Token: 0x060002E9 RID: 745 RVA: 0x00003C92 File Offset: 0x00001E92
		[Category("Metro Appearance")]
		public int Int32_0
		{
			get
			{
				return this.gcontrol1_1.Int32_1;
			}
			set
			{
				this.gcontrol1_1.Int32_1 = value;
			}
		}

		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x060002EA RID: 746 RVA: 0x00003CA0 File Offset: 0x00001EA0
		// (set) Token: 0x060002EB RID: 747 RVA: 0x00003CAD File Offset: 0x00001EAD
		[Category("Metro Appearance")]
		public bool Boolean_2
		{
			get
			{
				return this.gcontrol1_1.Boolean_0;
			}
			set
			{
				this.gcontrol1_1.Boolean_0 = value;
			}
		}

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x060002EC RID: 748 RVA: 0x00003CBB File Offset: 0x00001EBB
		// (set) Token: 0x060002ED RID: 749 RVA: 0x00003CC8 File Offset: 0x00001EC8
		[Category("Metro Appearance")]
		public bool Boolean_3
		{
			get
			{
				return this.gcontrol1_1.Boolean_1;
			}
			set
			{
				this.gcontrol1_1.Boolean_1 = value;
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x060002EE RID: 750 RVA: 0x00003CD6 File Offset: 0x00001ED6
		// (set) Token: 0x060002EF RID: 751 RVA: 0x00003CDE File Offset: 0x00001EDE
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_4
		{
			get
			{
				return this.bool_5;
			}
			set
			{
				this.bool_5 = value;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x060002F0 RID: 752 RVA: 0x00003CE7 File Offset: 0x00001EE7
		// (set) Token: 0x060002F1 RID: 753 RVA: 0x00003CF4 File Offset: 0x00001EF4
		[Category("Metro Appearance")]
		public int Int32_1
		{
			get
			{
				return this.gcontrol1_0.Int32_1;
			}
			set
			{
				this.gcontrol1_0.Int32_1 = value;
			}
		}

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x060002F2 RID: 754 RVA: 0x00003D02 File Offset: 0x00001F02
		// (set) Token: 0x060002F3 RID: 755 RVA: 0x00003D0F File Offset: 0x00001F0F
		[Category("Metro Appearance")]
		public bool Boolean_5
		{
			get
			{
				return this.gcontrol1_0.Boolean_0;
			}
			set
			{
				this.gcontrol1_0.Boolean_0 = value;
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x060002F4 RID: 756 RVA: 0x00003D1D File Offset: 0x00001F1D
		// (set) Token: 0x060002F5 RID: 757 RVA: 0x00003D2A File Offset: 0x00001F2A
		[Category("Metro Appearance")]
		public bool Boolean_6
		{
			get
			{
				return this.gcontrol1_0.Boolean_1;
			}
			set
			{
				this.gcontrol1_0.Boolean_1 = value;
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x060002F6 RID: 758 RVA: 0x00003D38 File Offset: 0x00001F38
		// (set) Token: 0x060002F7 RID: 759 RVA: 0x00003D40 File Offset: 0x00001F40
		[Category("Metro Appearance")]
		public bool Boolean_7
		{
			get
			{
				return base.AutoScroll;
			}
			set
			{
				this.bool_3 = value;
				this.bool_5 = value;
				base.AutoScroll = value;
			}
		}

		// Token: 0x060002F8 RID: 760 RVA: 0x00003D57 File Offset: 0x00001F57
		private void method_0(object sender, ScrollEventArgs e)
		{
			base.AutoScrollPosition = new Point(e.NewValue, this.gcontrol1_0.Int32_6);
			this.method_2();
		}

		// Token: 0x060002F9 RID: 761 RVA: 0x00003D7B File Offset: 0x00001F7B
		private void method_1(object sender, ScrollEventArgs e)
		{
			base.AutoScrollPosition = new Point(this.gcontrol1_1.Int32_6, e.NewValue);
			this.method_2();
		}

		// Token: 0x060002FA RID: 762 RVA: 0x0000E0AC File Offset: 0x0000C2AC
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
				}
				if (color.A == 255 && this.BackgroundImage == null)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060002FB RID: 763 RVA: 0x0000E134 File Offset: 0x0000C334
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				base.Height = base.Parent.Height - 19;
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060002FC RID: 764 RVA: 0x0000E1A8 File Offset: 0x0000C3A8
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			if (base.DesignMode)
			{
				this.gcontrol1_1.Visible = false;
				this.gcontrol1_0.Visible = false;
				return;
			}
			this.method_2();
			if (this.Boolean_0)
			{
				this.gcontrol1_1.Visible = base.HorizontalScroll.Visible;
			}
			if (base.HorizontalScroll.Visible)
			{
				this.gcontrol1_1.Int32_2 = base.HorizontalScroll.Minimum;
				this.gcontrol1_1.Int32_3 = base.HorizontalScroll.Maximum;
				this.gcontrol1_1.Int32_4 = base.HorizontalScroll.SmallChange;
				this.gcontrol1_1.Int32_5 = base.HorizontalScroll.LargeChange;
			}
			if (this.Boolean_4)
			{
				this.gcontrol1_0.Visible = base.VerticalScroll.Visible;
			}
			if (base.VerticalScroll.Visible)
			{
				this.gcontrol1_0.Int32_2 = base.VerticalScroll.Minimum;
				this.gcontrol1_0.Int32_3 = base.VerticalScroll.Maximum;
				this.gcontrol1_0.Int32_4 = base.VerticalScroll.SmallChange;
				this.gcontrol1_0.Int32_5 = base.VerticalScroll.LargeChange;
			}
			if (this.bool_4 && !this.gcontrol1_0.Visible && !this.gcontrol1_1.Visible)
			{
				Color color = GClass39.GClass40.GClass41.smethod_0(this.GEnum29_0);
				if (this.bool_2)
				{
					color = GClass39.smethod_0(this.GEnum10_0);
				}
				using (Pen pen = new Pen(color))
				{
					Rectangle clientRectangle = base.ClientRectangle;
					new Point(clientRectangle.Left, clientRectangle.Top);
					Point pt = new Point(clientRectangle.Right - 1, clientRectangle.Top);
					new Point(clientRectangle.Left, clientRectangle.Bottom - 1);
					Point pt2 = new Point(clientRectangle.Right - 1, clientRectangle.Bottom - 1);
					paintEventArgs_0.Graphics.DrawLine(pen, pt, pt2);
				}
			}
			this.vmethod_2(new GEventArgs3(Color.Empty, Color.Empty, paintEventArgs_0.Graphics));
		}

		// Token: 0x060002FD RID: 765 RVA: 0x00003D9F File Offset: 0x00001F9F
		protected override void OnMouseWheel(MouseEventArgs e)
		{
			base.OnMouseWheel(e);
			this.gcontrol1_0.Int32_6 = Math.Abs(base.VerticalScroll.Value);
			this.gcontrol1_1.Int32_6 = Math.Abs(base.HorizontalScroll.Value);
		}

		// Token: 0x060002FE RID: 766 RVA: 0x00003DDE File Offset: 0x00001FDE
		[SecuritySafeCritical]
		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			if (!base.DesignMode)
			{
				Class29.ShowScrollBar(base.Handle, 3, 0);
			}
		}

		// Token: 0x060002FF RID: 767 RVA: 0x0000E3DC File Offset: 0x0000C5DC
		private void method_2()
		{
			if (base.DesignMode)
			{
				return;
			}
			if (!this.Boolean_7)
			{
				this.gcontrol1_0.Visible = false;
				this.gcontrol1_1.Visible = false;
				return;
			}
			this.gcontrol1_0.Location = new Point(base.ClientRectangle.Width - this.gcontrol1_0.Width, base.ClientRectangle.Y);
			this.gcontrol1_0.Height = base.ClientRectangle.Height - this.gcontrol1_1.Height;
			if (!this.Boolean_4)
			{
				this.gcontrol1_0.Visible = false;
			}
			this.gcontrol1_1.Location = new Point(base.ClientRectangle.X, base.ClientRectangle.Height - this.gcontrol1_1.Height);
			this.gcontrol1_1.Width = base.ClientRectangle.Width - this.gcontrol1_0.Width;
			if (!this.Boolean_0)
			{
				this.gcontrol1_1.Visible = false;
			}
		}

		// Token: 0x0400010E RID: 270
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x0400010F RID: 271
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x04000110 RID: 272
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x04000111 RID: 273
		private GEnum10 genum10_0;

		// Token: 0x04000112 RID: 274
		private GEnum29 genum29_0;

		// Token: 0x04000113 RID: 275
		private GClass8 gclass8_0;

		// Token: 0x04000114 RID: 276
		private bool bool_0;

		// Token: 0x04000115 RID: 277
		private bool bool_1;

		// Token: 0x04000116 RID: 278
		private bool bool_2;

		// Token: 0x04000117 RID: 279
		private GControl1 gcontrol1_0 = new GControl1(GEnum3.const_1);

		// Token: 0x04000118 RID: 280
		private GControl1 gcontrol1_1 = new GControl1(GEnum3.const_0);

		// Token: 0x04000119 RID: 281
		private bool bool_3;

		// Token: 0x0400011A RID: 282
		private bool bool_4;

		// Token: 0x0400011B RID: 283
		private bool bool_5;
	}
}
