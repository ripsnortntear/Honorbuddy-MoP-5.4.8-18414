﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace ns0
{
	// Token: 0x020000A9 RID: 169
	public sealed class GClass68
	{
		// Token: 0x06000835 RID: 2101 RVA: 0x0001DBFC File Offset: 0x0001BDFC
		private static Pen smethod_0(string string_0, Color color_0)
		{
			Pen result;
			lock (GClass68.dictionary_0)
			{
				if (!GClass68.dictionary_0.ContainsKey(string_0))
				{
					GClass68.dictionary_0.Add(string_0, new Pen(color_0, 1f));
				}
				result = (GClass68.dictionary_0[string_0].Clone() as Pen);
			}
			return result;
		}

		// Token: 0x17000247 RID: 583
		// (get) Token: 0x06000836 RID: 2102 RVA: 0x00007477 File Offset: 0x00005677
		public static Pen Pen_0
		{
			get
			{
				return GClass68.smethod_0("Black", GClass66.Color_0);
			}
		}

		// Token: 0x17000248 RID: 584
		// (get) Token: 0x06000837 RID: 2103 RVA: 0x00007488 File Offset: 0x00005688
		public static Pen Pen_1
		{
			get
			{
				return GClass68.smethod_0("White", GClass66.Color_1);
			}
		}

		// Token: 0x17000249 RID: 585
		// (get) Token: 0x06000838 RID: 2104 RVA: 0x00007499 File Offset: 0x00005699
		public static Pen Pen_2
		{
			get
			{
				return GClass68.smethod_0("Silver", GClass66.Color_2);
			}
		}

		// Token: 0x1700024A RID: 586
		// (get) Token: 0x06000839 RID: 2105 RVA: 0x000074AA File Offset: 0x000056AA
		public static Pen Pen_3
		{
			get
			{
				return GClass68.smethod_0("Blue", GClass66.Color_3);
			}
		}

		// Token: 0x1700024B RID: 587
		// (get) Token: 0x0600083A RID: 2106 RVA: 0x000074BB File Offset: 0x000056BB
		public static Pen Pen_4
		{
			get
			{
				return GClass68.smethod_0("Green", GClass66.Color_4);
			}
		}

		// Token: 0x1700024C RID: 588
		// (get) Token: 0x0600083B RID: 2107 RVA: 0x000074CC File Offset: 0x000056CC
		public static Pen Pen_5
		{
			get
			{
				return GClass68.smethod_0("Lime", GClass66.Color_5);
			}
		}

		// Token: 0x1700024D RID: 589
		// (get) Token: 0x0600083C RID: 2108 RVA: 0x000074DD File Offset: 0x000056DD
		public static Pen Pen_6
		{
			get
			{
				return GClass68.smethod_0("Teal", GClass66.Color_6);
			}
		}

		// Token: 0x1700024E RID: 590
		// (get) Token: 0x0600083D RID: 2109 RVA: 0x000074EE File Offset: 0x000056EE
		public static Pen Pen_7
		{
			get
			{
				return GClass68.smethod_0("Orange", GClass66.Color_7);
			}
		}

		// Token: 0x1700024F RID: 591
		// (get) Token: 0x0600083E RID: 2110 RVA: 0x000074FF File Offset: 0x000056FF
		public static Pen Pen_8
		{
			get
			{
				return GClass68.smethod_0("Brown", GClass66.Color_8);
			}
		}

		// Token: 0x17000250 RID: 592
		// (get) Token: 0x0600083F RID: 2111 RVA: 0x00007510 File Offset: 0x00005710
		public static Pen Pen_9
		{
			get
			{
				return GClass68.smethod_0("Pink", GClass66.Color_9);
			}
		}

		// Token: 0x17000251 RID: 593
		// (get) Token: 0x06000840 RID: 2112 RVA: 0x00007521 File Offset: 0x00005721
		public static Pen Pen_10
		{
			get
			{
				return GClass68.smethod_0("Magenta", GClass66.Color_10);
			}
		}

		// Token: 0x17000252 RID: 594
		// (get) Token: 0x06000841 RID: 2113 RVA: 0x00007532 File Offset: 0x00005732
		public static Pen Pen_11
		{
			get
			{
				return GClass68.smethod_0("Purple", GClass66.Color_11);
			}
		}

		// Token: 0x17000253 RID: 595
		// (get) Token: 0x06000842 RID: 2114 RVA: 0x00007543 File Offset: 0x00005743
		public static Pen Pen_12
		{
			get
			{
				return GClass68.smethod_0("Red", GClass66.Color_12);
			}
		}

		// Token: 0x17000254 RID: 596
		// (get) Token: 0x06000843 RID: 2115 RVA: 0x00007554 File Offset: 0x00005754
		public static Pen Pen_13
		{
			get
			{
				return GClass68.smethod_0("Yellow", GClass66.Color_13);
			}
		}

		// Token: 0x04000499 RID: 1177
		private static Dictionary<string, Pen> dictionary_0 = new Dictionary<string, Pen>();
	}
}
