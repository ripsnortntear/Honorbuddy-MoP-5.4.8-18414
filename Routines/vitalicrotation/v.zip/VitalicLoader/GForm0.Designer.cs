﻿namespace ns0
{
	// Token: 0x02000026 RID: 38
	public partial class GForm0 : global::ns0.MetroForm
	{
	}
}
