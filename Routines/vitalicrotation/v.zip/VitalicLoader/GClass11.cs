﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000033 RID: 51
	[Designer("MetroFramework.Design.Controls.MetroButtonDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	[ToolboxBitmap(typeof(Button))]
	[DefaultEvent("Click")]
	public class GClass11 : Button, GInterface2
	{
		// Token: 0x060001C3 RID: 451 RVA: 0x00002EE9 File Offset: 0x000010E9
		public GClass11()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x1400000C RID: 12
		// (add) Token: 0x060001C4 RID: 452 RVA: 0x0000BA04 File Offset: 0x00009C04
		// (remove) Token: 0x060001C5 RID: 453 RVA: 0x0000BA3C File Offset: 0x00009C3C
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060001C6 RID: 454 RVA: 0x00002F04 File Offset: 0x00001104
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x1400000D RID: 13
		// (add) Token: 0x060001C7 RID: 455 RVA: 0x0000BA74 File Offset: 0x00009C74
		// (remove) Token: 0x060001C8 RID: 456 RVA: 0x0000BAAC File Offset: 0x00009CAC
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x00002F24 File Offset: 0x00001124
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x1400000E RID: 14
		// (add) Token: 0x060001CA RID: 458 RVA: 0x0000BAE4 File Offset: 0x00009CE4
		// (remove) Token: 0x060001CB RID: 459 RVA: 0x0000BB1C File Offset: 0x00009D1C
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060001CC RID: 460 RVA: 0x00002F44 File Offset: 0x00001144
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x060001CD RID: 461 RVA: 0x0000BB54 File Offset: 0x00009D54
		// (set) Token: 0x060001CE RID: 462 RVA: 0x00002F64 File Offset: 0x00001164
		[Category("Metro Appearance")]
		[DefaultValue(GEnum10.const_0)]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x060001CF RID: 463 RVA: 0x0000BBAC File Offset: 0x00009DAC
		// (set) Token: 0x060001D0 RID: 464 RVA: 0x00002F6D File Offset: 0x0000116D
		[DefaultValue(GEnum29.const_0)]
		[Category("Metro Appearance")]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x060001D1 RID: 465 RVA: 0x00002F76 File Offset: 0x00001176
		// (set) Token: 0x060001D2 RID: 466 RVA: 0x00002F7E File Offset: 0x0000117E
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x060001D3 RID: 467 RVA: 0x00002F87 File Offset: 0x00001187
		// (set) Token: 0x060001D4 RID: 468 RVA: 0x00002F8F File Offset: 0x0000118F
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x060001D5 RID: 469 RVA: 0x00002F98 File Offset: 0x00001198
		// (set) Token: 0x060001D6 RID: 470 RVA: 0x00002FA0 File Offset: 0x000011A0
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x060001D7 RID: 471 RVA: 0x00002FA9 File Offset: 0x000011A9
		// (set) Token: 0x060001D8 RID: 472 RVA: 0x00002FB1 File Offset: 0x000011B1
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x060001D9 RID: 473 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x060001DA RID: 474 RVA: 0x00002923 File Offset: 0x00000B23
		[Browsable(false)]
		[Category("Metro Behaviour")]
		[DefaultValue(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x060001DB RID: 475 RVA: 0x00002FBA File Offset: 0x000011BA
		// (set) Token: 0x060001DC RID: 476 RVA: 0x00002FC2 File Offset: 0x000011C2
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x060001DD RID: 477 RVA: 0x00002FCB File Offset: 0x000011CB
		// (set) Token: 0x060001DE RID: 478 RVA: 0x00002FD3 File Offset: 0x000011D3
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_1
		{
			get
			{
				return this.bool_4;
			}
			set
			{
				this.bool_4 = value;
			}
		}

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x060001DF RID: 479 RVA: 0x00002FDC File Offset: 0x000011DC
		// (set) Token: 0x060001E0 RID: 480 RVA: 0x00002FE4 File Offset: 0x000011E4
		[DefaultValue(GEnum27.const_0)]
		[Category("Metro Appearance")]
		public GEnum27 GEnum27_0
		{
			get
			{
				return this.genum27_0;
			}
			set
			{
				this.genum27_0 = value;
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x060001E1 RID: 481 RVA: 0x00002FED File Offset: 0x000011ED
		// (set) Token: 0x060001E2 RID: 482 RVA: 0x00002FF5 File Offset: 0x000011F5
		[DefaultValue(GEnum28.const_2)]
		[Category("Metro Appearance")]
		public GEnum28 GEnum28_0
		{
			get
			{
				return this.genum28_0;
			}
			set
			{
				this.genum28_0 = value;
			}
		}

		// Token: 0x060001E3 RID: 483 RVA: 0x0000BC04 File Offset: 0x00009E04
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (this.bool_5 && !this.bool_6 && base.Enabled)
				{
					color = GClass39.GClass46.GClass47.smethod_1(this.GEnum29_0);
				}
				else if (this.bool_5 && this.bool_6 && base.Enabled)
				{
					color = GClass39.GClass46.GClass47.smethod_2(this.GEnum29_0);
				}
				else if (!base.Enabled)
				{
					color = GClass39.GClass46.GClass47.smethod_3(this.GEnum29_0);
				}
				else if (!this.bool_0)
				{
					color = GClass39.GClass46.GClass47.smethod_0(this.GEnum29_0);
				}
				if (color.A == 255 && this.BackgroundImage == null)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060001E4 RID: 484 RVA: 0x0000BCEC File Offset: 0x00009EEC
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x0000BD4C File Offset: 0x00009F4C
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color color;
			Color color2;
			if (this.bool_5 && !this.bool_6 && base.Enabled)
			{
				color = GClass39.GClass40.GClass41.smethod_1(this.GEnum29_0);
				color2 = GClass39.GClass56.GClass57.smethod_1(this.GEnum29_0);
			}
			else if (this.bool_5 && this.bool_6 && base.Enabled)
			{
				color = GClass39.GClass40.GClass41.smethod_2(this.GEnum29_0);
				color2 = GClass39.GClass56.GClass57.smethod_2(this.GEnum29_0);
			}
			else if (!base.Enabled)
			{
				color = GClass39.GClass40.GClass41.smethod_3(this.GEnum29_0);
				color2 = GClass39.GClass56.GClass57.smethod_3(this.GEnum29_0);
			}
			else
			{
				color = GClass39.GClass40.GClass41.smethod_0(this.GEnum29_0);
				if (this.bool_1)
				{
					color2 = this.ForeColor;
				}
				else if (this.bool_2)
				{
					color2 = GClass39.smethod_0(this.GEnum10_0);
				}
				else
				{
					color2 = GClass39.GClass56.GClass57.smethod_0(this.GEnum29_0);
				}
			}
			using (Pen pen = new Pen(color))
			{
				Rectangle rect = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
				paintEventArgs_0.Graphics.DrawRectangle(pen, rect);
			}
			if (this.Boolean_1 && !this.bool_5 && !this.bool_6 && base.Enabled)
			{
				using (Pen pen2 = GClass39.smethod_2(this.GEnum10_0))
				{
					Rectangle rect2 = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
					paintEventArgs_0.Graphics.DrawRectangle(pen2, rect2);
					rect2 = new Rectangle(1, 1, base.Width - 3, base.Height - 3);
					paintEventArgs_0.Graphics.DrawRectangle(pen2, rect2);
				}
			}
			TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Text, GClass67.smethod_12(this.genum27_0, this.genum28_0), base.ClientRectangle, color2, GClass39.smethod_4(this.TextAlign));
			this.vmethod_2(new GEventArgs3(Color.Empty, color2, paintEventArgs_0.Graphics));
			if (this.bool_3 && this.bool_7)
			{
				ControlPaint.DrawFocusRectangle(paintEventArgs_0.Graphics, base.ClientRectangle);
			}
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x00002FFE File Offset: 0x000011FE
		protected override void OnGotFocus(EventArgs e)
		{
			this.bool_7 = true;
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x00003014 File Offset: 0x00001214
		protected override void OnLostFocus(EventArgs e)
		{
			this.bool_7 = false;
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x00003038 File Offset: 0x00001238
		protected override void OnEnter(EventArgs e)
		{
			this.bool_7 = true;
			base.Invalidate();
			base.OnEnter(e);
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x0000304E File Offset: 0x0000124E
		protected override void OnLeave(EventArgs e)
		{
			this.bool_7 = false;
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnLeave(e);
		}

		// Token: 0x060001EA RID: 490 RVA: 0x00003072 File Offset: 0x00001272
		protected override void OnKeyDown(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Space)
			{
				this.bool_5 = true;
				this.bool_6 = true;
				base.Invalidate();
			}
			base.OnKeyDown(e);
		}

		// Token: 0x060001EB RID: 491 RVA: 0x00003099 File Offset: 0x00001299
		protected override void OnKeyUp(KeyEventArgs e)
		{
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnKeyUp(e);
		}

		// Token: 0x060001EC RID: 492 RVA: 0x000030B6 File Offset: 0x000012B6
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_5 = true;
			base.Invalidate();
			base.OnMouseEnter(e);
		}

		// Token: 0x060001ED RID: 493 RVA: 0x000030CC File Offset: 0x000012CC
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.bool_6 = true;
				base.Invalidate();
			}
			base.OnMouseDown(e);
		}

		// Token: 0x060001EE RID: 494 RVA: 0x000030EF File Offset: 0x000012EF
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this.bool_6 = false;
			base.Invalidate();
			base.OnMouseUp(e);
		}

		// Token: 0x060001EF RID: 495 RVA: 0x00003105 File Offset: 0x00001305
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_5 = false;
			base.Invalidate();
			base.OnMouseLeave(e);
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x0000311B File Offset: 0x0000131B
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x040000B7 RID: 183
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x040000B8 RID: 184
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x040000B9 RID: 185
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x040000BA RID: 186
		private GEnum10 genum10_0;

		// Token: 0x040000BB RID: 187
		private GEnum29 genum29_0;

		// Token: 0x040000BC RID: 188
		private GClass8 gclass8_0;

		// Token: 0x040000BD RID: 189
		private bool bool_0;

		// Token: 0x040000BE RID: 190
		private bool bool_1;

		// Token: 0x040000BF RID: 191
		private bool bool_2;

		// Token: 0x040000C0 RID: 192
		private bool bool_3;

		// Token: 0x040000C1 RID: 193
		private bool bool_4;

		// Token: 0x040000C2 RID: 194
		private GEnum27 genum27_0;

		// Token: 0x040000C3 RID: 195
		private GEnum28 genum28_0 = GEnum28.const_2;

		// Token: 0x040000C4 RID: 196
		private bool bool_5;

		// Token: 0x040000C5 RID: 197
		private bool bool_6;

		// Token: 0x040000C6 RID: 198
		private bool bool_7;
	}
}
