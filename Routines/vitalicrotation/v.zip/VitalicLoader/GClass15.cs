﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Security;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000038 RID: 56
	[ToolboxBitmap(typeof(Label))]
	[Designer("MetroFramework.Design.Controls.MetroLabelDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	public class GClass15 : Label, GInterface2
	{
		// Token: 0x0600026C RID: 620 RVA: 0x0000D100 File Offset: 0x0000B300
		public GClass15()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer, true);
			this.class8_0 = new GClass15.Class8();
			this.class8_0.Visible = false;
			base.Controls.Add(this.class8_0);
		}

		// Token: 0x14000015 RID: 21
		// (add) Token: 0x0600026D RID: 621 RVA: 0x0000D158 File Offset: 0x0000B358
		// (remove) Token: 0x0600026E RID: 622 RVA: 0x0000D190 File Offset: 0x0000B390
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x0600026F RID: 623 RVA: 0x000037A7 File Offset: 0x000019A7
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000016 RID: 22
		// (add) Token: 0x06000270 RID: 624 RVA: 0x0000D1C8 File Offset: 0x0000B3C8
		// (remove) Token: 0x06000271 RID: 625 RVA: 0x0000D200 File Offset: 0x0000B400
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000272 RID: 626 RVA: 0x000037C7 File Offset: 0x000019C7
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000017 RID: 23
		// (add) Token: 0x06000273 RID: 627 RVA: 0x0000D238 File Offset: 0x0000B438
		// (remove) Token: 0x06000274 RID: 628 RVA: 0x0000D270 File Offset: 0x0000B470
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000275 RID: 629 RVA: 0x000037E7 File Offset: 0x000019E7
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x17000084 RID: 132
		// (get) Token: 0x06000276 RID: 630 RVA: 0x0000D2A8 File Offset: 0x0000B4A8
		// (set) Token: 0x06000277 RID: 631 RVA: 0x00003807 File Offset: 0x00001A07
		[DefaultValue(GEnum10.const_0)]
		[Category("Metro Appearance")]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x06000278 RID: 632 RVA: 0x0000D300 File Offset: 0x0000B500
		// (set) Token: 0x06000279 RID: 633 RVA: 0x00003810 File Offset: 0x00001A10
		[DefaultValue(GEnum29.const_0)]
		[Category("Metro Appearance")]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x0600027A RID: 634 RVA: 0x00003819 File Offset: 0x00001A19
		// (set) Token: 0x0600027B RID: 635 RVA: 0x00003821 File Offset: 0x00001A21
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x0600027C RID: 636 RVA: 0x0000382A File Offset: 0x00001A2A
		// (set) Token: 0x0600027D RID: 637 RVA: 0x00003832 File Offset: 0x00001A32
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x0600027E RID: 638 RVA: 0x0000383B File Offset: 0x00001A3B
		// (set) Token: 0x0600027F RID: 639 RVA: 0x00003843 File Offset: 0x00001A43
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x06000280 RID: 640 RVA: 0x0000384C File Offset: 0x00001A4C
		// (set) Token: 0x06000281 RID: 641 RVA: 0x00003854 File Offset: 0x00001A54
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000282 RID: 642 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x06000283 RID: 643 RVA: 0x00002923 File Offset: 0x00000B23
		[Browsable(false)]
		[Category("Metro Behaviour")]
		[DefaultValue(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000284 RID: 644 RVA: 0x0000385D File Offset: 0x00001A5D
		// (set) Token: 0x06000285 RID: 645 RVA: 0x00003865 File Offset: 0x00001A65
		[DefaultValue(GEnum11.const_1)]
		[Category("Metro Appearance")]
		public GEnum11 GEnum11_0
		{
			get
			{
				return this.genum11_0;
			}
			set
			{
				this.genum11_0 = value;
				this.Refresh();
			}
		}

		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000286 RID: 646 RVA: 0x00003874 File Offset: 0x00001A74
		// (set) Token: 0x06000287 RID: 647 RVA: 0x0000387C File Offset: 0x00001A7C
		[DefaultValue(GEnum12.const_0)]
		[Category("Metro Appearance")]
		public GEnum12 GEnum12_0
		{
			get
			{
				return this.genum12_0;
			}
			set
			{
				this.genum12_0 = value;
				this.Refresh();
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000288 RID: 648 RVA: 0x0000388B File Offset: 0x00001A8B
		// (set) Token: 0x06000289 RID: 649 RVA: 0x00003893 File Offset: 0x00001A93
		[DefaultValue(GEnum2.const_0)]
		[Category("Metro Appearance")]
		public GEnum2 GEnum2_0
		{
			get
			{
				return this.genum2_0;
			}
			set
			{
				this.genum2_0 = value;
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x0600028A RID: 650 RVA: 0x0000389C File Offset: 0x00001A9C
		// (set) Token: 0x0600028B RID: 651 RVA: 0x000038A4 File Offset: 0x00001AA4
		[Category("Metro Behaviour")]
		[DefaultValue(false)]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
				this.Refresh();
			}
		}

		// Token: 0x0600028C RID: 652 RVA: 0x0000D358 File Offset: 0x0000B558
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
					if (base.Parent is GClass22)
					{
						color = GClass39.smethod_0(this.GEnum10_0);
					}
				}
				if (color.A == 255 && this.BackgroundImage == null)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600028D RID: 653 RVA: 0x0000D3F8 File Offset: 0x0000B5F8
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600028E RID: 654 RVA: 0x0000D458 File Offset: 0x0000B658
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color color;
			if (this.bool_1)
			{
				color = this.ForeColor;
			}
			else if (!base.Enabled)
			{
				if (base.Parent != null)
				{
					if (base.Parent is GClass22)
					{
						color = GClass39.GClass56.GClass58.smethod_3(this.GEnum29_0);
					}
					else
					{
						color = GClass39.GClass56.GClass60.smethod_0(this.GEnum29_0);
					}
				}
				else
				{
					color = GClass39.GClass56.GClass60.smethod_1(this.GEnum29_0);
				}
			}
			else if (base.Parent != null)
			{
				if (base.Parent is GClass22)
				{
					color = GClass39.GClass56.GClass58.smethod_0(this.GEnum29_0);
				}
				else if (this.bool_2)
				{
					color = GClass39.smethod_0(this.GEnum10_0);
				}
				else
				{
					color = GClass39.GClass56.GClass60.smethod_0(this.GEnum29_0);
				}
			}
			else if (this.bool_2)
			{
				color = GClass39.smethod_0(this.GEnum10_0);
			}
			else
			{
				color = GClass39.GClass56.GClass60.smethod_0(this.GEnum29_0);
			}
			if (this.GEnum2_0 == GEnum2.const_1)
			{
				this.method_0();
				this.method_4();
				if (!this.class8_0.Visible)
				{
					TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Text, GClass67.smethod_7(this.genum11_0, this.genum12_0), base.ClientRectangle, color, GClass39.smethod_4(this.TextAlign));
					return;
				}
			}
			else
			{
				this.method_3();
				TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Text, GClass67.smethod_7(this.genum11_0, this.genum12_0), base.ClientRectangle, color, GClass39.smethod_5(this.TextAlign, this.bool_3));
				this.vmethod_2(new GEventArgs3(Color.Empty, color, paintEventArgs_0.Graphics));
			}
		}

		// Token: 0x0600028F RID: 655 RVA: 0x000038B3 File Offset: 0x00001AB3
		public override void Refresh()
		{
			if (this.GEnum2_0 == GEnum2.const_1)
			{
				this.method_4();
			}
			base.Refresh();
		}

		// Token: 0x06000290 RID: 656 RVA: 0x0000D5E0 File Offset: 0x0000B7E0
		public override Size GetPreferredSize(Size proposedSize)
		{
			base.GetPreferredSize(proposedSize);
			Size result;
			using (Graphics graphics = base.CreateGraphics())
			{
				proposedSize = new Size(int.MaxValue, int.MaxValue);
				result = TextRenderer.MeasureText(graphics, this.Text, GClass67.smethod_7(this.genum11_0, this.genum12_0), proposedSize, GClass39.smethod_4(this.TextAlign));
			}
			return result;
		}

		// Token: 0x06000291 RID: 657 RVA: 0x000038CA File Offset: 0x00001ACA
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x06000292 RID: 658 RVA: 0x000038D9 File Offset: 0x00001AD9
		protected override void OnResize(EventArgs e)
		{
			if (this.GEnum2_0 == GEnum2.const_1)
			{
				this.method_5();
			}
			base.OnResize(e);
		}

		// Token: 0x06000293 RID: 659 RVA: 0x000038F1 File Offset: 0x00001AF1
		protected override void OnSizeChanged(EventArgs e)
		{
			base.OnSizeChanged(e);
			if (this.GEnum2_0 == GEnum2.const_1)
			{
				this.method_6();
			}
		}

		// Token: 0x06000294 RID: 660 RVA: 0x0000D658 File Offset: 0x0000B858
		private void method_0()
		{
			if (this.class8_0.Visible && !this.bool_4)
			{
				return;
			}
			if (!this.bool_4)
			{
				return;
			}
			this.bool_4 = false;
			if (!base.DesignMode)
			{
				Form form = base.FindForm();
				if (form != null)
				{
					form.ResizeBegin += this.method_2;
					form.ResizeEnd += this.method_1;
				}
			}
			this.class8_0.BackColor = Color.Transparent;
			this.class8_0.Visible = true;
			this.class8_0.BorderStyle = BorderStyle.None;
			this.class8_0.Font = GClass67.smethod_7(this.genum11_0, this.genum12_0);
			this.class8_0.Location = new Point(1, 0);
			this.class8_0.Text = this.Text;
			this.class8_0.ReadOnly = true;
			this.class8_0.Size = this.GetPreferredSize(Size.Empty);
			this.class8_0.Multiline = true;
			this.class8_0.DoubleClick += this.class8_0_DoubleClick;
			this.class8_0.Click += this.class8_0_Click;
			base.Controls.Add(this.class8_0);
		}

		// Token: 0x06000295 RID: 661 RVA: 0x00003909 File Offset: 0x00001B09
		private void method_1(object sender, EventArgs e)
		{
			if (this.GEnum2_0 == GEnum2.const_1)
			{
				this.method_6();
			}
		}

		// Token: 0x06000296 RID: 662 RVA: 0x0000391A File Offset: 0x00001B1A
		private void method_2(object sender, EventArgs e)
		{
			if (this.GEnum2_0 == GEnum2.const_1)
			{
				this.method_5();
			}
		}

		// Token: 0x06000297 RID: 663 RVA: 0x0000D798 File Offset: 0x0000B998
		private void method_3()
		{
			if (!this.class8_0.Visible)
			{
				return;
			}
			this.class8_0.DoubleClick -= this.class8_0_DoubleClick;
			this.class8_0.Click -= this.class8_0_Click;
			this.class8_0.Visible = false;
		}

		// Token: 0x06000298 RID: 664 RVA: 0x0000D7F0 File Offset: 0x0000B9F0
		private void method_4()
		{
			if (!this.class8_0.Visible)
			{
				return;
			}
			base.SuspendLayout();
			this.class8_0.SuspendLayout();
			if (this.bool_0)
			{
				this.class8_0.BackColor = this.BackColor;
			}
			else
			{
				this.class8_0.BackColor = GClass39.GClass46.smethod_0(this.GEnum29_0);
			}
			if (!base.Enabled)
			{
				if (base.Parent != null)
				{
					if (base.Parent is GClass22)
					{
						this.class8_0.ForeColor = GClass39.GClass56.GClass58.smethod_3(this.GEnum29_0);
					}
					else if (this.bool_2)
					{
						this.class8_0.ForeColor = GClass39.smethod_0(this.GEnum10_0);
					}
					else
					{
						this.class8_0.ForeColor = GClass39.GClass56.GClass60.smethod_1(this.GEnum29_0);
					}
				}
				else if (this.bool_2)
				{
					this.class8_0.ForeColor = GClass39.smethod_0(this.GEnum10_0);
				}
				else
				{
					this.class8_0.ForeColor = GClass39.GClass56.GClass60.smethod_1(this.GEnum29_0);
				}
			}
			else if (base.Parent != null)
			{
				if (base.Parent is GClass22)
				{
					this.class8_0.ForeColor = GClass39.GClass56.GClass58.smethod_0(this.GEnum29_0);
				}
				else if (this.bool_2)
				{
					this.class8_0.ForeColor = GClass39.smethod_0(this.GEnum10_0);
				}
				else
				{
					this.class8_0.ForeColor = GClass39.GClass56.GClass60.smethod_0(this.GEnum29_0);
				}
			}
			else if (this.bool_2)
			{
				this.class8_0.ForeColor = GClass39.smethod_0(this.GEnum10_0);
			}
			else
			{
				this.class8_0.ForeColor = GClass39.GClass56.GClass60.smethod_0(this.GEnum29_0);
			}
			this.class8_0.Font = GClass67.smethod_7(this.genum11_0, this.genum12_0);
			this.class8_0.Text = this.Text;
			this.class8_0.BorderStyle = BorderStyle.None;
			base.Size = this.GetPreferredSize(Size.Empty);
			this.class8_0.ResumeLayout();
			base.ResumeLayout();
		}

		// Token: 0x06000299 RID: 665 RVA: 0x0000392B File Offset: 0x00001B2B
		private void method_5()
		{
			this.class8_0.Visible = false;
		}

		// Token: 0x0600029A RID: 666 RVA: 0x00003939 File Offset: 0x00001B39
		private void method_6()
		{
			this.class8_0.Visible = true;
		}

		// Token: 0x0600029B RID: 667 RVA: 0x00003947 File Offset: 0x00001B47
		[SecuritySafeCritical]
		private void class8_0_Click(object sender, EventArgs e)
		{
			Class30.HideCaret(this.class8_0.Handle);
		}

		// Token: 0x0600029C RID: 668 RVA: 0x0000395A File Offset: 0x00001B5A
		[SecuritySafeCritical]
		private void class8_0_DoubleClick(object sender, EventArgs e)
		{
			this.class8_0.SelectAll();
			Class30.HideCaret(this.class8_0.Handle);
		}

		// Token: 0x040000F0 RID: 240
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x040000F1 RID: 241
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x040000F2 RID: 242
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x040000F3 RID: 243
		private GEnum10 genum10_0;

		// Token: 0x040000F4 RID: 244
		private GEnum29 genum29_0;

		// Token: 0x040000F5 RID: 245
		private GClass8 gclass8_0;

		// Token: 0x040000F6 RID: 246
		private bool bool_0;

		// Token: 0x040000F7 RID: 247
		private bool bool_1;

		// Token: 0x040000F8 RID: 248
		private bool bool_2;

		// Token: 0x040000F9 RID: 249
		private GClass15.Class8 class8_0;

		// Token: 0x040000FA RID: 250
		private GEnum11 genum11_0 = GEnum11.const_1;

		// Token: 0x040000FB RID: 251
		private GEnum12 genum12_0;

		// Token: 0x040000FC RID: 252
		private GEnum2 genum2_0;

		// Token: 0x040000FD RID: 253
		private bool bool_3;

		// Token: 0x040000FE RID: 254
		private bool bool_4 = true;

		// Token: 0x02000039 RID: 57
		private class Class8 : TextBox
		{
			// Token: 0x0600029D RID: 669 RVA: 0x00003978 File Offset: 0x00001B78
			public Class8()
			{
				base.SetStyle(ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer, true);
			}
		}
	}
}
