﻿using System;
using System.IO;
using System.Reflection;

namespace ns0
{
	// Token: 0x02000002 RID: 2
	public class GClass0
	{
		// Token: 0x06000003 RID: 3 RVA: 0x000020E8 File Offset: 0x000002E8
		public static Stream smethod_0(string string_3)
		{
			return GClass0.assembly_0.GetManifestResourceStream("VitalicLoader.Resources." + string_3);
		}

		// Token: 0x04000001 RID: 1
		private static Assembly assembly_0 = Assembly.GetExecutingAssembly();

		// Token: 0x04000002 RID: 2
		public static string string_0;

		// Token: 0x04000003 RID: 3
		public static string string_1;

		// Token: 0x04000004 RID: 4
		public static string string_2;
	}
}
