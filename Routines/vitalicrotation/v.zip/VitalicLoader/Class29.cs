﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Security;

namespace ns0
{
	// Token: 0x020000BC RID: 188
	[SuppressUnmanagedCodeSecurity]
	internal static class Class29
	{
		// Token: 0x06000882 RID: 2178
		[DllImport("user32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern Class29.Enum12 UpdateLayeredWindow(IntPtr intptr_0, IntPtr intptr_1, ref Class29.Struct9 struct9_0, ref Class29.Struct10 struct10_0, IntPtr intptr_2, ref Class29.Struct9 struct9_1, int int_17, ref Class29.Struct12 struct12_0, int int_18);

		// Token: 0x06000883 RID: 2179
		[DllImport("user32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern IntPtr GetDC(IntPtr intptr_0);

		// Token: 0x06000884 RID: 2180
		[DllImport("gdi32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern IntPtr CreateCompatibleDC(IntPtr intptr_0);

		// Token: 0x06000885 RID: 2181
		[DllImport("gdi32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern Class29.Enum12 DeleteDC(IntPtr intptr_0);

		// Token: 0x06000886 RID: 2182
		[DllImport("gdi32.dll", ExactSpelling = true)]
		public static extern IntPtr SelectObject(IntPtr intptr_0, IntPtr intptr_1);

		// Token: 0x06000887 RID: 2183
		[DllImport("gdi32.dll", ExactSpelling = true, SetLastError = true)]
		public static extern Class29.Enum12 DeleteObject(IntPtr intptr_0);

		// Token: 0x06000888 RID: 2184
		[DllImport("user32.dll", SetLastError = true)]
		public static extern uint GetWindowLong(IntPtr intptr_0, int int_17);

		// Token: 0x06000889 RID: 2185
		[DllImport("user32.dll")]
		public static extern int SetWindowLong(IntPtr intptr_0, int int_17, uint uint_0);

		// Token: 0x0600088A RID: 2186
		[DllImport("user32.dll")]
		public static extern IntPtr GetSystemMenu(IntPtr intptr_0, bool bool_0);

		// Token: 0x0600088B RID: 2187
		[DllImport("user32.dll")]
		public static extern int GetMenuItemCount(IntPtr intptr_0);

		// Token: 0x0600088C RID: 2188
		[DllImport("user32.dll")]
		public static extern bool DrawMenuBar(IntPtr intptr_0);

		// Token: 0x0600088D RID: 2189
		[DllImport("user32.dll")]
		public static extern bool RemoveMenu(IntPtr intptr_0, uint uint_0, uint uint_1);

		// Token: 0x0600088E RID: 2190
		[DllImport("user32.dll")]
		public static extern bool ReleaseCapture();

		// Token: 0x0600088F RID: 2191
		[DllImport("user32.dll")]
		public static extern IntPtr SetCapture(IntPtr intptr_0);

		// Token: 0x06000890 RID: 2192
		[DllImport("user32.dll")]
		public static extern int SendMessage(IntPtr intptr_0, int int_17, int int_18, int int_19);

		// Token: 0x06000891 RID: 2193
		[DllImport("user32.dll", EntryPoint = "SendMessage")]
		public static extern int SendMessage_1(IntPtr intptr_0, int int_17, bool bool_0, int int_18);

		// Token: 0x06000892 RID: 2194
		[DllImport("shell32.dll", SetLastError = true)]
		public static extern IntPtr SHAppBarMessage(Class29.Enum6 enum6_0, [In] ref Class29.Struct17 struct17_0);

		// Token: 0x06000893 RID: 2195
		[DllImport("user32.dll", SetLastError = true)]
		public static extern IntPtr FindWindow(string string_0, string string_1);

		// Token: 0x06000894 RID: 2196
		[DllImport("user32.dll")]
		public static extern bool SetForegroundWindow(IntPtr intptr_0);

		// Token: 0x06000895 RID: 2197
		[DllImport("user32.dll")]
		public static extern IntPtr GetDCEx(IntPtr intptr_0, IntPtr intptr_1, uint uint_0);

		// Token: 0x06000896 RID: 2198
		[DllImport("user32.dll")]
		public static extern bool ShowScrollBar(IntPtr intptr_0, int int_17, int int_18);

		// Token: 0x06000897 RID: 2199
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr GetWindowDC(IntPtr intptr_0);

		// Token: 0x06000898 RID: 2200
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr ReleaseDC(IntPtr intptr_0, IntPtr intptr_1);

		// Token: 0x06000899 RID: 2201
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern int GetClassName(IntPtr intptr_0, char[] char_0, int int_17);

		// Token: 0x0600089A RID: 2202
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern IntPtr GetWindow(IntPtr intptr_0, int int_17);

		// Token: 0x0600089B RID: 2203
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		public static extern bool IsWindowVisible(IntPtr intptr_0);

		// Token: 0x0600089C RID: 2204
		[DllImport("user32", CharSet = CharSet.Auto)]
		public static extern int GetClientRect(IntPtr intptr_0, ref Class29.Struct14 struct14_0);

		// Token: 0x0600089D RID: 2205
		[DllImport("user32", CharSet = CharSet.Auto, EntryPoint = "GetClientRect")]
		public static extern int GetClientRect_1(IntPtr intptr_0, [In] [Out] ref Rectangle rectangle_0);

		// Token: 0x0600089E RID: 2206
		[DllImport("user32", CharSet = CharSet.Auto)]
		public static extern bool MoveWindow(IntPtr intptr_0, int int_17, int int_18, int int_19, int int_20, bool bool_0);

		// Token: 0x0600089F RID: 2207
		[DllImport("user32", CharSet = CharSet.Auto)]
		public static extern bool UpdateWindow(IntPtr intptr_0);

		// Token: 0x060008A0 RID: 2208
		[DllImport("user32", CharSet = CharSet.Auto)]
		public static extern bool InvalidateRect(IntPtr intptr_0, ref Rectangle rectangle_0, bool bool_0);

		// Token: 0x060008A1 RID: 2209
		[DllImport("user32", CharSet = CharSet.Auto)]
		public static extern bool ValidateRect(IntPtr intptr_0, ref Rectangle rectangle_0);

		// Token: 0x060008A2 RID: 2210
		[DllImport("user32.dll", CharSet = CharSet.Auto)]
		internal static extern bool GetWindowRect(IntPtr intptr_0, [In] [Out] ref Rectangle rectangle_0);

		// Token: 0x060008A3 RID: 2211 RVA: 0x000077BC File Offset: 0x000059BC
		public static int smethod_0(int int_17)
		{
			return int_17 & 65535;
		}

		// Token: 0x060008A4 RID: 2212 RVA: 0x000077C5 File Offset: 0x000059C5
		public static int smethod_1(int int_17)
		{
			return int_17 >> 16 & 65535;
		}

		// Token: 0x04000505 RID: 1285
		public const int int_0 = 1;

		// Token: 0x04000506 RID: 1286
		public const int int_1 = 2;

		// Token: 0x04000507 RID: 1287
		public const int int_2 = 1024;

		// Token: 0x04000508 RID: 1288
		public const int int_3 = 4096;

		// Token: 0x04000509 RID: 1289
		public const int int_4 = 4883;

		// Token: 0x0400050A RID: 1290
		public const int int_5 = 1;

		// Token: 0x0400050B RID: 1291
		public const int int_6 = 2;

		// Token: 0x0400050C RID: 1292
		public const int int_7 = 4;

		// Token: 0x0400050D RID: 1293
		public const byte byte_0 = 0;

		// Token: 0x0400050E RID: 1294
		public const byte byte_1 = 1;

		// Token: 0x0400050F RID: 1295
		public const int int_8 = 0;

		// Token: 0x04000510 RID: 1296
		public const int int_9 = 1;

		// Token: 0x04000511 RID: 1297
		public const int int_10 = 2;

		// Token: 0x04000512 RID: 1298
		public const int int_11 = 3;

		// Token: 0x04000513 RID: 1299
		public const int int_12 = 4;

		// Token: 0x04000514 RID: 1300
		public const int int_13 = 5;

		// Token: 0x04000515 RID: 1301
		public const int int_14 = 0;

		// Token: 0x04000516 RID: 1302
		public const int int_15 = 4;

		// Token: 0x04000517 RID: 1303
		public const int int_16 = -4;

		// Token: 0x020000BD RID: 189
		public struct Struct9
		{
			// Token: 0x060008A5 RID: 2213 RVA: 0x000077D1 File Offset: 0x000059D1
			public Struct9(int int_2, int int_3)
			{
				this.int_0 = int_2;
				this.int_1 = int_3;
			}

			// Token: 0x04000518 RID: 1304
			public int int_0;

			// Token: 0x04000519 RID: 1305
			public int int_1;
		}

		// Token: 0x020000BE RID: 190
		public struct Struct10
		{
			// Token: 0x060008A6 RID: 2214 RVA: 0x000077E1 File Offset: 0x000059E1
			public Struct10(int int_2, int int_3)
			{
				this.int_0 = int_2;
				this.int_1 = int_3;
			}

			// Token: 0x0400051A RID: 1306
			public int int_0;

			// Token: 0x0400051B RID: 1307
			public int int_1;
		}

		// Token: 0x020000BF RID: 191
		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct Struct11
		{
			// Token: 0x0400051C RID: 1308
			public byte byte_0;

			// Token: 0x0400051D RID: 1309
			public byte byte_1;

			// Token: 0x0400051E RID: 1310
			public byte byte_2;

			// Token: 0x0400051F RID: 1311
			public byte byte_3;
		}

		// Token: 0x020000C0 RID: 192
		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct Struct12
		{
			// Token: 0x04000520 RID: 1312
			public byte byte_0;

			// Token: 0x04000521 RID: 1313
			public byte byte_1;

			// Token: 0x04000522 RID: 1314
			public byte byte_2;

			// Token: 0x04000523 RID: 1315
			public byte byte_3;
		}

		// Token: 0x020000C1 RID: 193
		public struct Struct13
		{
			// Token: 0x04000524 RID: 1316
			public Point point_0;

			// Token: 0x04000525 RID: 1317
			public uint uint_0;
		}

		// Token: 0x020000C2 RID: 194
		public struct Struct14
		{
			// Token: 0x04000526 RID: 1318
			public int int_0;

			// Token: 0x04000527 RID: 1319
			public int int_1;

			// Token: 0x04000528 RID: 1320
			public int int_2;

			// Token: 0x04000529 RID: 1321
			public int int_3;
		}

		// Token: 0x020000C3 RID: 195
		public struct Struct15
		{
			// Token: 0x0400052A RID: 1322
			public Class29.Struct14 struct14_0;

			// Token: 0x0400052B RID: 1323
			public Class29.Struct14 struct14_1;

			// Token: 0x0400052C RID: 1324
			public Class29.Struct14 struct14_2;

			// Token: 0x0400052D RID: 1325
			public IntPtr intptr_0;
		}

		// Token: 0x020000C4 RID: 196
		public struct Struct16
		{
			// Token: 0x0400052E RID: 1326
			public Class29.Struct9 struct9_0;

			// Token: 0x0400052F RID: 1327
			public Class29.Struct9 struct9_1;

			// Token: 0x04000530 RID: 1328
			public Class29.Struct9 struct9_2;

			// Token: 0x04000531 RID: 1329
			public Class29.Struct9 struct9_3;

			// Token: 0x04000532 RID: 1330
			public Class29.Struct9 struct9_4;
		}

		// Token: 0x020000C5 RID: 197
		public struct Struct17
		{
			// Token: 0x04000533 RID: 1331
			public uint uint_0;

			// Token: 0x04000534 RID: 1332
			public IntPtr intptr_0;

			// Token: 0x04000535 RID: 1333
			public uint uint_1;

			// Token: 0x04000536 RID: 1334
			public Class29.Enum7 enum7_0;

			// Token: 0x04000537 RID: 1335
			public Class29.Struct14 struct14_0;

			// Token: 0x04000538 RID: 1336
			public int int_0;
		}

		// Token: 0x020000C6 RID: 198
		public struct Struct18
		{
			// Token: 0x04000539 RID: 1337
			public int int_0;

			// Token: 0x0400053A RID: 1338
			public int int_1;

			// Token: 0x0400053B RID: 1339
			public int int_2;

			// Token: 0x0400053C RID: 1340
			public int int_3;

			// Token: 0x0400053D RID: 1341
			public int int_4;

			// Token: 0x0400053E RID: 1342
			public int int_5;

			// Token: 0x0400053F RID: 1343
			public int int_6;
		}

		// Token: 0x020000C7 RID: 199
		public enum Enum6 : uint
		{
			// Token: 0x04000541 RID: 1345
			const_0,
			// Token: 0x04000542 RID: 1346
			const_1,
			// Token: 0x04000543 RID: 1347
			const_2,
			// Token: 0x04000544 RID: 1348
			const_3,
			// Token: 0x04000545 RID: 1349
			const_4,
			// Token: 0x04000546 RID: 1350
			const_5,
			// Token: 0x04000547 RID: 1351
			const_6,
			// Token: 0x04000548 RID: 1352
			const_7,
			// Token: 0x04000549 RID: 1353
			const_8,
			// Token: 0x0400054A RID: 1354
			const_9,
			// Token: 0x0400054B RID: 1355
			const_10
		}

		// Token: 0x020000C8 RID: 200
		public enum Enum7 : uint
		{
			// Token: 0x0400054D RID: 1357
			const_0,
			// Token: 0x0400054E RID: 1358
			const_1,
			// Token: 0x0400054F RID: 1359
			const_2,
			// Token: 0x04000550 RID: 1360
			const_3
		}

		// Token: 0x020000C9 RID: 201
		public enum Enum8
		{
			// Token: 0x04000552 RID: 1362
			const_0,
			// Token: 0x04000553 RID: 1363
			const_1,
			// Token: 0x04000554 RID: 1364
			const_2,
			// Token: 0x04000555 RID: 1365
			const_3
		}

		// Token: 0x020000CA RID: 202
		public enum Enum9
		{
			// Token: 0x04000557 RID: 1367
			const_0,
			// Token: 0x04000558 RID: 1368
			const_1,
			// Token: 0x04000559 RID: 1369
			const_2,
			// Token: 0x0400055A RID: 1370
			const_3 = 4,
			// Token: 0x0400055B RID: 1371
			const_4 = 4,
			// Token: 0x0400055C RID: 1372
			const_5 = 8,
			// Token: 0x0400055D RID: 1373
			const_6,
			// Token: 0x0400055E RID: 1374
			const_7,
			// Token: 0x0400055F RID: 1375
			const_8,
			// Token: 0x04000560 RID: 1376
			const_9,
			// Token: 0x04000561 RID: 1377
			const_10,
			// Token: 0x04000562 RID: 1378
			const_11,
			// Token: 0x04000563 RID: 1379
			const_12,
			// Token: 0x04000564 RID: 1380
			const_13,
			// Token: 0x04000565 RID: 1381
			const_14,
			// Token: 0x04000566 RID: 1382
			const_15 = 8,
			// Token: 0x04000567 RID: 1383
			const_16,
			// Token: 0x04000568 RID: 1384
			const_17,
			// Token: 0x04000569 RID: 1385
			const_18 = 17,
			// Token: 0x0400056A RID: 1386
			const_19 = -1
		}

		// Token: 0x020000CB RID: 203
		public enum Enum10
		{
			// Token: 0x0400056C RID: 1388
			const_0 = 1
		}

		// Token: 0x020000CC RID: 204
		public enum Enum11 : uint
		{
			// Token: 0x0400056E RID: 1390
			const_0,
			// Token: 0x0400056F RID: 1391
			const_1,
			// Token: 0x04000570 RID: 1392
			const_2,
			// Token: 0x04000571 RID: 1393
			const_3,
			// Token: 0x04000572 RID: 1394
			const_4 = 5U,
			// Token: 0x04000573 RID: 1395
			const_5,
			// Token: 0x04000574 RID: 1396
			const_6,
			// Token: 0x04000575 RID: 1397
			const_7,
			// Token: 0x04000576 RID: 1398
			const_8 = 10U,
			// Token: 0x04000577 RID: 1399
			const_9,
			// Token: 0x04000578 RID: 1400
			const_10,
			// Token: 0x04000579 RID: 1401
			const_11,
			// Token: 0x0400057A RID: 1402
			const_12,
			// Token: 0x0400057B RID: 1403
			const_13,
			// Token: 0x0400057C RID: 1404
			const_14,
			// Token: 0x0400057D RID: 1405
			const_15,
			// Token: 0x0400057E RID: 1406
			const_16 = 19U,
			// Token: 0x0400057F RID: 1407
			const_17 = 22U,
			// Token: 0x04000580 RID: 1408
			const_18 = 18U,
			// Token: 0x04000581 RID: 1409
			const_19 = 20U,
			// Token: 0x04000582 RID: 1410
			const_20,
			// Token: 0x04000583 RID: 1411
			const_21 = 24U,
			// Token: 0x04000584 RID: 1412
			const_22 = 26U,
			// Token: 0x04000585 RID: 1413
			const_23 = 26U,
			// Token: 0x04000586 RID: 1414
			const_24,
			// Token: 0x04000587 RID: 1415
			const_25,
			// Token: 0x04000588 RID: 1416
			const_26,
			// Token: 0x04000589 RID: 1417
			const_27,
			// Token: 0x0400058A RID: 1418
			const_28,
			// Token: 0x0400058B RID: 1419
			const_29,
			// Token: 0x0400058C RID: 1420
			const_30,
			// Token: 0x0400058D RID: 1421
			const_31,
			// Token: 0x0400058E RID: 1422
			const_32,
			// Token: 0x0400058F RID: 1423
			const_33,
			// Token: 0x04000590 RID: 1424
			const_34 = 38U,
			// Token: 0x04000591 RID: 1425
			const_35,
			// Token: 0x04000592 RID: 1426
			const_36,
			// Token: 0x04000593 RID: 1427
			const_37 = 42U,
			// Token: 0x04000594 RID: 1428
			const_38,
			// Token: 0x04000595 RID: 1429
			const_39,
			// Token: 0x04000596 RID: 1430
			const_40,
			// Token: 0x04000597 RID: 1431
			const_41,
			// Token: 0x04000598 RID: 1432
			const_42,
			// Token: 0x04000599 RID: 1433
			const_43,
			// Token: 0x0400059A RID: 1434
			const_44,
			// Token: 0x0400059B RID: 1435
			const_45,
			// Token: 0x0400059C RID: 1436
			const_46,
			// Token: 0x0400059D RID: 1437
			const_47 = 55U,
			// Token: 0x0400059E RID: 1438
			const_48 = 57U,
			// Token: 0x0400059F RID: 1439
			const_49 = 61U,
			// Token: 0x040005A0 RID: 1440
			const_50 = 65U,
			// Token: 0x040005A1 RID: 1441
			const_51 = 68U,
			// Token: 0x040005A2 RID: 1442
			const_52 = 70U,
			// Token: 0x040005A3 RID: 1443
			const_53,
			// Token: 0x040005A4 RID: 1444
			const_54,
			// Token: 0x040005A5 RID: 1445
			const_55 = 74U,
			// Token: 0x040005A6 RID: 1446
			const_56,
			// Token: 0x040005A7 RID: 1447
			const_57 = 78U,
			// Token: 0x040005A8 RID: 1448
			const_58 = 80U,
			// Token: 0x040005A9 RID: 1449
			const_59,
			// Token: 0x040005AA RID: 1450
			const_60,
			// Token: 0x040005AB RID: 1451
			const_61,
			// Token: 0x040005AC RID: 1452
			const_62,
			// Token: 0x040005AD RID: 1453
			const_63,
			// Token: 0x040005AE RID: 1454
			const_64 = 123U,
			// Token: 0x040005AF RID: 1455
			const_65,
			// Token: 0x040005B0 RID: 1456
			const_66,
			// Token: 0x040005B1 RID: 1457
			const_67,
			// Token: 0x040005B2 RID: 1458
			const_68,
			// Token: 0x040005B3 RID: 1459
			const_69,
			// Token: 0x040005B4 RID: 1460
			const_70,
			// Token: 0x040005B5 RID: 1461
			const_71,
			// Token: 0x040005B6 RID: 1462
			const_72,
			// Token: 0x040005B7 RID: 1463
			const_73,
			// Token: 0x040005B8 RID: 1464
			const_74,
			// Token: 0x040005B9 RID: 1465
			const_75,
			// Token: 0x040005BA RID: 1466
			const_76,
			// Token: 0x040005BB RID: 1467
			const_77,
			// Token: 0x040005BC RID: 1468
			const_78 = 160U,
			// Token: 0x040005BD RID: 1469
			const_79,
			// Token: 0x040005BE RID: 1470
			const_80,
			// Token: 0x040005BF RID: 1471
			const_81,
			// Token: 0x040005C0 RID: 1472
			const_82,
			// Token: 0x040005C1 RID: 1473
			const_83,
			// Token: 0x040005C2 RID: 1474
			const_84,
			// Token: 0x040005C3 RID: 1475
			const_85,
			// Token: 0x040005C4 RID: 1476
			const_86,
			// Token: 0x040005C5 RID: 1477
			const_87,
			// Token: 0x040005C6 RID: 1478
			const_88 = 171U,
			// Token: 0x040005C7 RID: 1479
			const_89,
			// Token: 0x040005C8 RID: 1480
			const_90,
			// Token: 0x040005C9 RID: 1481
			const_91 = 255U,
			// Token: 0x040005CA RID: 1482
			const_92,
			// Token: 0x040005CB RID: 1483
			const_93 = 256U,
			// Token: 0x040005CC RID: 1484
			const_94,
			// Token: 0x040005CD RID: 1485
			const_95,
			// Token: 0x040005CE RID: 1486
			const_96,
			// Token: 0x040005CF RID: 1487
			const_97,
			// Token: 0x040005D0 RID: 1488
			const_98,
			// Token: 0x040005D1 RID: 1489
			const_99,
			// Token: 0x040005D2 RID: 1490
			const_100,
			// Token: 0x040005D3 RID: 1491
			const_101 = 265U,
			// Token: 0x040005D4 RID: 1492
			const_102 = 264U,
			// Token: 0x040005D5 RID: 1493
			const_103 = 269U,
			// Token: 0x040005D6 RID: 1494
			const_104,
			// Token: 0x040005D7 RID: 1495
			const_105,
			// Token: 0x040005D8 RID: 1496
			const_106 = 271U,
			// Token: 0x040005D9 RID: 1497
			const_107,
			// Token: 0x040005DA RID: 1498
			const_108,
			// Token: 0x040005DB RID: 1499
			const_109,
			// Token: 0x040005DC RID: 1500
			const_110,
			// Token: 0x040005DD RID: 1501
			const_111,
			// Token: 0x040005DE RID: 1502
			const_112,
			// Token: 0x040005DF RID: 1503
			const_113,
			// Token: 0x040005E0 RID: 1504
			const_114,
			// Token: 0x040005E1 RID: 1505
			const_115 = 287U,
			// Token: 0x040005E2 RID: 1506
			const_116,
			// Token: 0x040005E3 RID: 1507
			const_117,
			// Token: 0x040005E4 RID: 1508
			const_118,
			// Token: 0x040005E5 RID: 1509
			const_119,
			// Token: 0x040005E6 RID: 1510
			const_120,
			// Token: 0x040005E7 RID: 1511
			const_121,
			// Token: 0x040005E8 RID: 1512
			const_122,
			// Token: 0x040005E9 RID: 1513
			const_123,
			// Token: 0x040005EA RID: 1514
			const_124,
			// Token: 0x040005EB RID: 1515
			const_125,
			// Token: 0x040005EC RID: 1516
			const_126 = 25U,
			// Token: 0x040005ED RID: 1517
			const_127 = 306U,
			// Token: 0x040005EE RID: 1518
			const_128,
			// Token: 0x040005EF RID: 1519
			const_129,
			// Token: 0x040005F0 RID: 1520
			const_130,
			// Token: 0x040005F1 RID: 1521
			const_131,
			// Token: 0x040005F2 RID: 1522
			const_132,
			// Token: 0x040005F3 RID: 1523
			const_133,
			// Token: 0x040005F4 RID: 1524
			const_134 = 512U,
			// Token: 0x040005F5 RID: 1525
			const_135 = 512U,
			// Token: 0x040005F6 RID: 1526
			const_136,
			// Token: 0x040005F7 RID: 1527
			const_137,
			// Token: 0x040005F8 RID: 1528
			const_138,
			// Token: 0x040005F9 RID: 1529
			const_139,
			// Token: 0x040005FA RID: 1530
			const_140,
			// Token: 0x040005FB RID: 1531
			const_141,
			// Token: 0x040005FC RID: 1532
			const_142,
			// Token: 0x040005FD RID: 1533
			const_143,
			// Token: 0x040005FE RID: 1534
			const_144,
			// Token: 0x040005FF RID: 1535
			const_145,
			// Token: 0x04000600 RID: 1536
			const_146,
			// Token: 0x04000601 RID: 1537
			const_147,
			// Token: 0x04000602 RID: 1538
			const_148,
			// Token: 0x04000603 RID: 1539
			const_149 = 525U,
			// Token: 0x04000604 RID: 1540
			const_150 = 528U,
			// Token: 0x04000605 RID: 1541
			const_151,
			// Token: 0x04000606 RID: 1542
			const_152,
			// Token: 0x04000607 RID: 1543
			const_153,
			// Token: 0x04000608 RID: 1544
			const_154,
			// Token: 0x04000609 RID: 1545
			const_155,
			// Token: 0x0400060A RID: 1546
			const_156,
			// Token: 0x0400060B RID: 1547
			const_157 = 536U,
			// Token: 0x0400060C RID: 1548
			const_158,
			// Token: 0x0400060D RID: 1549
			const_159 = 544U,
			// Token: 0x0400060E RID: 1550
			const_160,
			// Token: 0x0400060F RID: 1551
			const_161,
			// Token: 0x04000610 RID: 1552
			const_162,
			// Token: 0x04000611 RID: 1553
			const_163,
			// Token: 0x04000612 RID: 1554
			const_164,
			// Token: 0x04000613 RID: 1555
			const_165,
			// Token: 0x04000614 RID: 1556
			const_166,
			// Token: 0x04000615 RID: 1557
			const_167,
			// Token: 0x04000616 RID: 1558
			const_168,
			// Token: 0x04000617 RID: 1559
			const_169 = 560U,
			// Token: 0x04000618 RID: 1560
			const_170,
			// Token: 0x04000619 RID: 1561
			const_171,
			// Token: 0x0400061A RID: 1562
			const_172,
			// Token: 0x0400061B RID: 1563
			const_173,
			// Token: 0x0400061C RID: 1564
			const_174 = 641U,
			// Token: 0x0400061D RID: 1565
			const_175,
			// Token: 0x0400061E RID: 1566
			const_176,
			// Token: 0x0400061F RID: 1567
			const_177,
			// Token: 0x04000620 RID: 1568
			const_178,
			// Token: 0x04000621 RID: 1569
			const_179,
			// Token: 0x04000622 RID: 1570
			const_180 = 648U,
			// Token: 0x04000623 RID: 1571
			const_181 = 656U,
			// Token: 0x04000624 RID: 1572
			const_182,
			// Token: 0x04000625 RID: 1573
			const_183 = 673U,
			// Token: 0x04000626 RID: 1574
			const_184 = 675U,
			// Token: 0x04000627 RID: 1575
			const_185 = 674U,
			// Token: 0x04000628 RID: 1576
			const_186 = 689U,
			// Token: 0x04000629 RID: 1577
			const_187 = 704U,
			// Token: 0x0400062A RID: 1578
			const_188 = 735U,
			// Token: 0x0400062B RID: 1579
			const_189 = 768U,
			// Token: 0x0400062C RID: 1580
			const_190,
			// Token: 0x0400062D RID: 1581
			const_191,
			// Token: 0x0400062E RID: 1582
			const_192,
			// Token: 0x0400062F RID: 1583
			const_193,
			// Token: 0x04000630 RID: 1584
			const_194,
			// Token: 0x04000631 RID: 1585
			const_195,
			// Token: 0x04000632 RID: 1586
			const_196,
			// Token: 0x04000633 RID: 1587
			const_197,
			// Token: 0x04000634 RID: 1588
			const_198,
			// Token: 0x04000635 RID: 1589
			const_199,
			// Token: 0x04000636 RID: 1590
			const_200,
			// Token: 0x04000637 RID: 1591
			const_201,
			// Token: 0x04000638 RID: 1592
			const_202,
			// Token: 0x04000639 RID: 1593
			const_203,
			// Token: 0x0400063A RID: 1594
			const_204,
			// Token: 0x0400063B RID: 1595
			const_205,
			// Token: 0x0400063C RID: 1596
			const_206,
			// Token: 0x0400063D RID: 1597
			const_207,
			// Token: 0x0400063E RID: 1598
			const_208 = 791U,
			// Token: 0x0400063F RID: 1599
			const_209,
			// Token: 0x04000640 RID: 1600
			const_210,
			// Token: 0x04000641 RID: 1601
			const_211,
			// Token: 0x04000642 RID: 1602
			const_212 = 856U,
			// Token: 0x04000643 RID: 1603
			const_213 = 863U,
			// Token: 0x04000644 RID: 1604
			const_214,
			// Token: 0x04000645 RID: 1605
			const_215 = 895U,
			// Token: 0x04000646 RID: 1606
			const_216,
			// Token: 0x04000647 RID: 1607
			const_217 = 911U,
			// Token: 0x04000648 RID: 1608
			const_218 = 1024U,
			// Token: 0x04000649 RID: 1609
			const_219 = 8192U,
			// Token: 0x0400064A RID: 1610
			const_220 = 32768U,
			// Token: 0x0400064B RID: 1611
			const_221 = 798U,
			// Token: 0x0400064C RID: 1612
			const_222 = 61456U,
			// Token: 0x0400064D RID: 1613
			const_223 = 61472U,
			// Token: 0x0400064E RID: 1614
			const_224 = 61488U,
			// Token: 0x0400064F RID: 1615
			const_225 = 61728U
		}

		// Token: 0x020000CD RID: 205
		public enum Enum12
		{
			// Token: 0x04000651 RID: 1617
			const_0,
			// Token: 0x04000652 RID: 1618
			const_1
		}
	}
}
