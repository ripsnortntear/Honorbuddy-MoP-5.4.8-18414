﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.Permissions;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000042 RID: 66
	[Designer("MetroFramework.Design.Controls.MetroTabControlDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	[ToolboxBitmap(typeof(TabControl))]
	public class GControl2 : TabControl, GInterface2
	{
		// Token: 0x060003E4 RID: 996 RVA: 0x000047D1 File Offset: 0x000029D1
		public GControl2()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.Padding = new Point(6, 8);
		}

		// Token: 0x1400002B RID: 43
		// (add) Token: 0x060003E5 RID: 997 RVA: 0x00010A50 File Offset: 0x0000EC50
		// (remove) Token: 0x060003E6 RID: 998 RVA: 0x00010A88 File Offset: 0x0000EC88
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060003E7 RID: 999 RVA: 0x00004801 File Offset: 0x00002A01
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x1400002C RID: 44
		// (add) Token: 0x060003E8 RID: 1000 RVA: 0x00010AC0 File Offset: 0x0000ECC0
		// (remove) Token: 0x060003E9 RID: 1001 RVA: 0x00010AF8 File Offset: 0x0000ECF8
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060003EA RID: 1002 RVA: 0x00004821 File Offset: 0x00002A21
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x1400002D RID: 45
		// (add) Token: 0x060003EB RID: 1003 RVA: 0x00010B30 File Offset: 0x0000ED30
		// (remove) Token: 0x060003EC RID: 1004 RVA: 0x00010B68 File Offset: 0x0000ED68
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060003ED RID: 1005 RVA: 0x00004841 File Offset: 0x00002A41
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x170000E8 RID: 232
		// (get) Token: 0x060003EE RID: 1006 RVA: 0x00010BA0 File Offset: 0x0000EDA0
		// (set) Token: 0x060003EF RID: 1007 RVA: 0x00004861 File Offset: 0x00002A61
		[Category("Metro Appearance")]
		[DefaultValue(GEnum10.const_0)]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x170000E9 RID: 233
		// (get) Token: 0x060003F0 RID: 1008 RVA: 0x00010BF8 File Offset: 0x0000EDF8
		// (set) Token: 0x060003F1 RID: 1009 RVA: 0x0000486A File Offset: 0x00002A6A
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x170000EA RID: 234
		// (get) Token: 0x060003F2 RID: 1010 RVA: 0x00004873 File Offset: 0x00002A73
		// (set) Token: 0x060003F3 RID: 1011 RVA: 0x0000487B File Offset: 0x00002A7B
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x170000EB RID: 235
		// (get) Token: 0x060003F4 RID: 1012 RVA: 0x00004884 File Offset: 0x00002A84
		// (set) Token: 0x060003F5 RID: 1013 RVA: 0x0000488C File Offset: 0x00002A8C
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x170000EC RID: 236
		// (get) Token: 0x060003F6 RID: 1014 RVA: 0x00004895 File Offset: 0x00002A95
		// (set) Token: 0x060003F7 RID: 1015 RVA: 0x0000489D File Offset: 0x00002A9D
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x170000ED RID: 237
		// (get) Token: 0x060003F8 RID: 1016 RVA: 0x000048A6 File Offset: 0x00002AA6
		// (set) Token: 0x060003F9 RID: 1017 RVA: 0x000048AE File Offset: 0x00002AAE
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x170000EE RID: 238
		// (get) Token: 0x060003FA RID: 1018 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x060003FB RID: 1019 RVA: 0x00002923 File Offset: 0x00000B23
		[Category("Metro Behaviour")]
		[DefaultValue(false)]
		[Browsable(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x170000EF RID: 239
		// (get) Token: 0x060003FC RID: 1020 RVA: 0x000048B7 File Offset: 0x00002AB7
		// (set) Token: 0x060003FD RID: 1021 RVA: 0x000048BF File Offset: 0x00002ABF
		[DefaultValue(GEnum23.const_1)]
		[Category("Metro Appearance")]
		public GEnum23 GEnum23_0
		{
			get
			{
				return this.genum23_0;
			}
			set
			{
				this.genum23_0 = value;
			}
		}

		// Token: 0x170000F0 RID: 240
		// (get) Token: 0x060003FE RID: 1022 RVA: 0x000048C8 File Offset: 0x00002AC8
		// (set) Token: 0x060003FF RID: 1023 RVA: 0x000048D0 File Offset: 0x00002AD0
		[DefaultValue(GEnum24.const_0)]
		[Category("Metro Appearance")]
		public GEnum24 GEnum24_0
		{
			get
			{
				return this.genum24_0;
			}
			set
			{
				this.genum24_0 = value;
			}
		}

		// Token: 0x170000F1 RID: 241
		// (get) Token: 0x06000400 RID: 1024 RVA: 0x000048D9 File Offset: 0x00002AD9
		// (set) Token: 0x06000401 RID: 1025 RVA: 0x000048E1 File Offset: 0x00002AE1
		[Category("Metro Appearance")]
		[DefaultValue(ContentAlignment.MiddleLeft)]
		public ContentAlignment ContentAlignment_0
		{
			get
			{
				return this.contentAlignment_0;
			}
			set
			{
				this.contentAlignment_0 = value;
			}
		}

		// Token: 0x170000F2 RID: 242
		// (get) Token: 0x06000402 RID: 1026 RVA: 0x000048EA File Offset: 0x00002AEA
		[Editor("MetroFramework.Design.MetroTabPageCollectionEditor, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a", typeof(UITypeEditor))]
		public TabControl.TabPageCollection TabPageCollection_0
		{
			get
			{
				return base.TabPages;
			}
		}

		// Token: 0x170000F3 RID: 243
		// (get) Token: 0x06000403 RID: 1027 RVA: 0x000048F2 File Offset: 0x00002AF2
		// (set) Token: 0x06000404 RID: 1028 RVA: 0x000048FA File Offset: 0x00002AFA
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_0
		{
			get
			{
				return this.bool_4;
			}
			set
			{
				if (this.bool_4 == value)
				{
					return;
				}
				this.bool_4 = value;
				base.UpdateStyles();
			}
		}

		// Token: 0x06000405 RID: 1029 RVA: 0x00010C50 File Offset: 0x0000EE50
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
				}
				if (color.A == 255 && this.BackgroundImage == null)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x06000406 RID: 1030 RVA: 0x00010CD8 File Offset: 0x0000EED8
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x06000407 RID: 1031 RVA: 0x00010D38 File Offset: 0x0000EF38
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			for (int i = 0; i < this.TabPageCollection_0.Count; i++)
			{
				if (i != base.SelectedIndex)
				{
					this.method_3(i, paintEventArgs_0.Graphics);
				}
			}
			if (base.SelectedIndex <= -1)
			{
				return;
			}
			this.method_0(base.SelectedIndex, paintEventArgs_0.Graphics);
			this.method_3(base.SelectedIndex, paintEventArgs_0.Graphics);
			this.method_1(base.SelectedIndex, paintEventArgs_0.Graphics);
			this.vmethod_2(new GEventArgs3(Color.Empty, Color.Empty, paintEventArgs_0.Graphics));
		}

		// Token: 0x06000408 RID: 1032 RVA: 0x00010DCC File Offset: 0x0000EFCC
		private void method_0(int int_3, Graphics graphics_0)
		{
			using (Brush brush = new SolidBrush(GClass39.GClass40.GClass45.smethod_0(this.GEnum29_0)))
			{
				Rectangle rect = new Rectangle(this.DisplayRectangle.X, this.method_5(int_3).Bottom + 2 - 3, this.DisplayRectangle.Width, 3);
				graphics_0.FillRectangle(brush, rect);
			}
		}

		// Token: 0x06000409 RID: 1033 RVA: 0x00010E48 File Offset: 0x0000F048
		private void method_1(int int_3, Graphics graphics_0)
		{
			using (Brush brush = new SolidBrush(GClass39.smethod_0(this.GEnum10_0)))
			{
				Rectangle rectangle = this.method_5(int_3);
				Rectangle rect = new Rectangle(rectangle.X + ((int_3 == 0) ? 2 : 0), this.method_5(int_3).Bottom + 2 - 3, rectangle.Width + ((int_3 == 0) ? 0 : 2), 3);
				graphics_0.FillRectangle(brush, rect);
			}
		}

		// Token: 0x0600040A RID: 1034 RVA: 0x00010ECC File Offset: 0x0000F0CC
		private Size method_2(string string_0)
		{
			Size result;
			using (Graphics graphics = base.CreateGraphics())
			{
				Size proposedSize = new Size(int.MaxValue, int.MaxValue);
				result = TextRenderer.MeasureText(graphics, string_0, GClass67.smethod_10(this.genum23_0, this.genum24_0), proposedSize, GClass39.smethod_4(this.ContentAlignment_0) | TextFormatFlags.NoPadding);
			}
			return result;
		}

		// Token: 0x0600040B RID: 1035 RVA: 0x00010F3C File Offset: 0x0000F13C
		private void method_3(int int_3, Graphics graphics_0)
		{
			Color color = this.BackColor;
			if (!this.bool_0)
			{
				color = GClass39.GClass46.smethod_0(this.GEnum29_0);
			}
			TabPage tabPage = this.TabPageCollection_0[int_3];
			Rectangle rectangle = this.method_5(int_3);
			Color foreColor;
			if (!base.Enabled)
			{
				foreColor = GClass39.GClass56.GClass60.smethod_1(this.GEnum29_0);
			}
			else if (this.bool_1)
			{
				foreColor = Control.DefaultForeColor;
			}
			else
			{
				foreColor = ((!this.bool_2) ? GClass39.GClass56.GClass64.smethod_0(this.GEnum29_0) : GClass39.smethod_0(this.GEnum10_0));
			}
			if (int_3 == 0)
			{
				rectangle.X = this.DisplayRectangle.X;
			}
			Rectangle rect = rectangle;
			rectangle.Width += 20;
			using (Brush brush = new SolidBrush(color))
			{
				graphics_0.FillRectangle(brush, rect);
			}
			TextRenderer.DrawText(graphics_0, tabPage.Text, GClass67.smethod_10(this.genum23_0, this.genum24_0), rectangle, foreColor, color, GClass39.smethod_4(this.ContentAlignment_0));
		}

		// Token: 0x0600040C RID: 1036 RVA: 0x00011048 File Offset: 0x0000F248
		[SecuritySafeCritical]
		private void method_4(Graphics graphics_0)
		{
			Color color = (base.Parent != null) ? base.Parent.BackColor : GClass39.GClass46.smethod_0(this.GEnum29_0);
			Rectangle rectangle = default(Rectangle);
			Class29.GetClientRect_1(this.class27_0.Handle, ref rectangle);
			graphics_0.CompositingQuality = CompositingQuality.HighQuality;
			graphics_0.SmoothingMode = SmoothingMode.AntiAlias;
			graphics_0.Clear(color);
			using (Brush brush = new SolidBrush(GClass39.GClass40.GClass45.smethod_0(this.GEnum29_0)))
			{
				GraphicsPath graphicsPath = new GraphicsPath(FillMode.Winding);
				PointF[] points = new PointF[]
				{
					new PointF(6f, 6f),
					new PointF(16f, 0f),
					new PointF(16f, 12f)
				};
				graphicsPath.AddLines(points);
				graphics_0.FillPath(brush, graphicsPath);
				graphicsPath.Reset();
				PointF[] points2 = new PointF[]
				{
					new PointF((float)(rectangle.Width - 15), 0f),
					new PointF((float)(rectangle.Width - 5), 6f),
					new PointF((float)(rectangle.Width - 15), 12f)
				};
				graphicsPath.AddLines(points2);
				graphics_0.FillPath(brush, graphicsPath);
				graphicsPath.Dispose();
			}
		}

		// Token: 0x0600040D RID: 1037 RVA: 0x0000472B File Offset: 0x0000292B
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x00004913 File Offset: 0x00002B13
		protected override void OnParentBackColorChanged(EventArgs e)
		{
			base.OnParentBackColorChanged(e);
			base.Invalidate();
		}

		// Token: 0x0600040F RID: 1039 RVA: 0x00004922 File Offset: 0x00002B22
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			base.Invalidate();
		}

		// Token: 0x06000410 RID: 1040 RVA: 0x00004931 File Offset: 0x00002B31
		[SecuritySafeCritical]
		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			if (!base.DesignMode)
			{
				Class29.ShowScrollBar(base.Handle, 3, 0);
			}
		}

		// Token: 0x170000F4 RID: 244
		// (get) Token: 0x06000411 RID: 1041 RVA: 0x000111E4 File Offset: 0x0000F3E4
		protected override CreateParams CreateParams
		{
			[SecurityPermission(SecurityAction.LinkDemand, Flags = SecurityPermissionFlag.UnmanagedCode)]
			get
			{
				CreateParams createParams = base.CreateParams;
				if (this.bool_4)
				{
					createParams.ExStyle = (createParams.ExStyle | 4194304 | 1048576);
				}
				return createParams;
			}
		}

		// Token: 0x06000412 RID: 1042 RVA: 0x0001121C File Offset: 0x0000F41C
		private Rectangle method_5(int int_3)
		{
			if (int_3 < 0)
			{
				return default(Rectangle);
			}
			return base.GetTabRect(int_3);
		}

		// Token: 0x06000413 RID: 1043 RVA: 0x00011240 File Offset: 0x0000F440
		protected override void OnMouseWheel(MouseEventArgs e)
		{
			if (base.SelectedIndex != -1 && !this.TabPageCollection_0[base.SelectedIndex].Focused)
			{
				bool flag = false;
				foreach (object obj in this.TabPageCollection_0[base.SelectedIndex].Controls)
				{
					Control control = (Control)obj;
					if (control.Focused)
					{
						flag = true;
						return;
					}
				}
				if (!flag)
				{
					this.TabPageCollection_0[base.SelectedIndex].Select();
					this.TabPageCollection_0[base.SelectedIndex].Focus();
				}
			}
			base.OnMouseWheel(e);
		}

		// Token: 0x06000414 RID: 1044 RVA: 0x00004950 File Offset: 0x00002B50
		protected override void OnCreateControl()
		{
			base.OnCreateControl();
			this.OnFontChanged(EventArgs.Empty);
			this.method_6();
		}

		// Token: 0x06000415 RID: 1045 RVA: 0x00004969 File Offset: 0x00002B69
		protected override void OnControlAdded(ControlEventArgs e)
		{
			base.OnControlAdded(e);
			this.method_6();
			this.method_7();
		}

		// Token: 0x06000416 RID: 1046 RVA: 0x0000497E File Offset: 0x00002B7E
		protected override void OnControlRemoved(ControlEventArgs e)
		{
			base.OnControlRemoved(e);
			this.method_6();
			this.method_7();
		}

		// Token: 0x06000417 RID: 1047 RVA: 0x00004993 File Offset: 0x00002B93
		protected override void OnSelectedIndexChanged(EventArgs e)
		{
			base.OnSelectedIndexChanged(e);
			this.method_7();
			base.Invalidate();
		}

		// Token: 0x06000418 RID: 1048
		[DllImport("user32.dll")]
		private static extern IntPtr SendMessage(IntPtr intptr_0, int int_3, IntPtr intptr_1, IntPtr intptr_2);

		// Token: 0x06000419 RID: 1049 RVA: 0x00011310 File Offset: 0x0000F510
		[SecuritySafeCritical]
		protected override void OnFontChanged(EventArgs e)
		{
			base.OnFontChanged(e);
			IntPtr intptr_ = GClass67.smethod_10(this.genum23_0, this.genum24_0).ToHfont();
			GControl2.SendMessage(base.Handle, 48, intptr_, (IntPtr)(-1));
			GControl2.SendMessage(base.Handle, 29, IntPtr.Zero, IntPtr.Zero);
			base.UpdateStyles();
		}

		// Token: 0x0600041A RID: 1050 RVA: 0x00011370 File Offset: 0x0000F570
		[SecuritySafeCritical]
		private void method_6()
		{
			bool flag = false;
			IntPtr window = Class29.GetWindow(base.Handle, 5);
			while (window != IntPtr.Zero)
			{
				char[] array = new char[33];
				int className = Class29.GetClassName(window, array, 32);
				string a = new string(array, 0, className);
				if (a == "msctls_updown32")
				{
					flag = true;
					if (!this.bool_3)
					{
						this.class27_0 = new Class27(window, true);
						this.class27_0.Event_0 += this.method_8;
						this.bool_3 = true;
					}
					IL_87:
					if (!flag && this.bool_3)
					{
						this.bool_3 = false;
					}
					return;
				}
				window = Class29.GetWindow(window, 2);
			}
			goto IL_87;
		}

		// Token: 0x0600041B RID: 1051 RVA: 0x00011418 File Offset: 0x0000F618
		[SecuritySafeCritical]
		private void method_7()
		{
			if (this.bool_3 && Class29.IsWindowVisible(this.class27_0.Handle))
			{
				Rectangle rectangle = default(Rectangle);
				Class29.GetClientRect_1(this.class27_0.Handle, ref rectangle);
				Class29.InvalidateRect(this.class27_0.Handle, ref rectangle, true);
			}
		}

		// Token: 0x0600041C RID: 1052 RVA: 0x00011470 File Offset: 0x0000F670
		[SecuritySafeCritical]
		private int method_8(ref Message message_0)
		{
			int msg = message_0.Msg;
			if (msg == 15)
			{
				IntPtr windowDC = Class29.GetWindowDC(this.class27_0.Handle);
				Graphics graphics = Graphics.FromHdc(windowDC);
				this.method_4(graphics);
				graphics.Dispose();
				Class29.ReleaseDC(this.class27_0.Handle, windowDC);
				message_0.Result = IntPtr.Zero;
				Rectangle rectangle = default(Rectangle);
				Class29.GetClientRect_1(this.class27_0.Handle, ref rectangle);
				Class29.ValidateRect(this.class27_0.Handle, ref rectangle);
				return 1;
			}
			return 0;
		}

		// Token: 0x04000179 RID: 377
		private const int int_0 = 3;

		// Token: 0x0400017A RID: 378
		private const int int_1 = 48;

		// Token: 0x0400017B RID: 379
		private const int int_2 = 29;

		// Token: 0x0400017C RID: 380
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x0400017D RID: 381
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x0400017E RID: 382
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x0400017F RID: 383
		private GEnum10 genum10_0;

		// Token: 0x04000180 RID: 384
		private GEnum29 genum29_0;

		// Token: 0x04000181 RID: 385
		private GClass8 gclass8_0;

		// Token: 0x04000182 RID: 386
		private bool bool_0;

		// Token: 0x04000183 RID: 387
		private bool bool_1;

		// Token: 0x04000184 RID: 388
		private bool bool_2;

		// Token: 0x04000185 RID: 389
		private Class27 class27_0;

		// Token: 0x04000186 RID: 390
		private bool bool_3;

		// Token: 0x04000187 RID: 391
		private GEnum23 genum23_0 = GEnum23.const_1;

		// Token: 0x04000188 RID: 392
		private GEnum24 genum24_0;

		// Token: 0x04000189 RID: 393
		private ContentAlignment contentAlignment_0 = ContentAlignment.MiddleLeft;

		// Token: 0x0400018A RID: 394
		private bool bool_4;
	}
}
