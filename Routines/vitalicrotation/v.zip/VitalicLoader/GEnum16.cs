﻿using System;

namespace ns0
{
	// Token: 0x02000098 RID: 152
	public enum GEnum16
	{
		// Token: 0x04000465 RID: 1125
		const_0,
		// Token: 0x04000466 RID: 1126
		const_1,
		// Token: 0x04000467 RID: 1127
		const_2
	}
}
