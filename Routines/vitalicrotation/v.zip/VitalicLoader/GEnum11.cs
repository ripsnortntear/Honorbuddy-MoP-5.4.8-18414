﻿using System;

namespace ns0
{
	// Token: 0x02000093 RID: 147
	public enum GEnum11
	{
		// Token: 0x04000451 RID: 1105
		const_0,
		// Token: 0x04000452 RID: 1106
		const_1,
		// Token: 0x04000453 RID: 1107
		const_2
	}
}
