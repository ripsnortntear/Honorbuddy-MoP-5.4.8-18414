﻿using System;

namespace ns0
{
	// Token: 0x02000089 RID: 137
	public enum GEnum9
	{
		// Token: 0x04000420 RID: 1056
		const_0,
		// Token: 0x04000421 RID: 1057
		const_1,
		// Token: 0x04000422 RID: 1058
		const_2
	}
}
