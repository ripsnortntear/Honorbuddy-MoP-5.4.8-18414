﻿using System;
using System.Drawing;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200000A RID: 10
	public sealed class GClass4 : GClass3
	{
		// Token: 0x06000032 RID: 50 RVA: 0x00007F7C File Offset: 0x0000617C
		public void method_6(Control control_1, string string_0, Color color_0, int int_3)
		{
			GClass4.Class0 @class = new GClass4.Class0();
			@class.control_0 = control_1;
			@class.string_0 = string_0;
			@class.color_0 = color_0;
			@class.gclass4_0 = this;
			if (int_3 == 0)
			{
				int_3 = 1;
			}
			base.method_3(@class.control_0, this.genum0_0, 2 * int_3, new GDelegate0(@class.method_0), new GDelegate1(@class.method_1));
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00007FE4 File Offset: 0x000061E4
		private Color method_7(Color color_0, Color color_1, double double_1)
		{
			this.double_0 += 0.2;
			int alpha = (int)Math.Round((double)color_0.A * (1.0 - double_1) + (double)color_1.A * double_1);
			int red = (int)Math.Round((double)color_0.R * (1.0 - double_1) + (double)color_1.R * double_1);
			int green = (int)Math.Round((double)color_0.G * (1.0 - double_1) + (double)color_1.G * double_1);
			int blue = (int)Math.Round((double)color_0.B * (1.0 - double_1) + (double)color_1.B * double_1);
			return Color.FromArgb(alpha, red, green, blue);
		}

		// Token: 0x06000034 RID: 52 RVA: 0x000080A8 File Offset: 0x000062A8
		private Color method_8(string string_0, Control control_1)
		{
			Type type = control_1.GetType();
			Binder binder = null;
			object[] args = null;
			object obj = type.InvokeMember(string_0, BindingFlags.GetProperty, binder, control_1, args);
			return (Color)obj;
		}

		// Token: 0x0400001D RID: 29
		private double double_0 = 1.0;

		// Token: 0x0200000B RID: 11
		[CompilerGenerated]
		private sealed class Class0
		{
			// Token: 0x06000036 RID: 54 RVA: 0x000080DC File Offset: 0x000062DC
			public void method_0()
			{
				Color color = this.gclass4_0.method_8(this.string_0, this.control_0);
				Color color2 = this.gclass4_0.method_7(color, this.color_0, 0.1 * (this.gclass4_0.double_0 / 2.0));
				PropertyInfo property = this.control_0.GetType().GetProperty(this.string_0);
				MethodInfo setMethod = property.GetSetMethod(true);
				setMethod.Invoke(this.control_0, new object[]
				{
					color2
				});
			}

			// Token: 0x06000037 RID: 55 RVA: 0x00008174 File Offset: 0x00006374
			public bool method_1()
			{
				Color color = this.gclass4_0.method_8(this.string_0, this.control_0);
				return color.A.Equals(this.color_0.A) && color.R.Equals(this.color_0.R) && color.G.Equals(this.color_0.G) && color.B.Equals(this.color_0.B);
			}

			// Token: 0x0400001E RID: 30
			public GClass4 gclass4_0;

			// Token: 0x0400001F RID: 31
			public Control control_0;

			// Token: 0x04000020 RID: 32
			public string string_0;

			// Token: 0x04000021 RID: 33
			public Color color_0;
		}
	}
}
