﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text.RegularExpressions;

namespace ns0
{
	// Token: 0x02000050 RID: 80
	[CLSCompliant(false)]
	public class GClass29
	{
		// Token: 0x0600069A RID: 1690 RVA: 0x0000648D File Offset: 0x0000468D
		private GClass29()
		{
			this.dictionary_0 = new Dictionary<PropertyInfo, string>();
			this.dictionary_1 = new Dictionary<string, string>();
		}

		// Token: 0x0600069B RID: 1691 RVA: 0x000172AC File Offset: 0x000154AC
		public GClass29(string string_1) : this()
		{
			this.string_0 = string_1;
			MatchCollection matchCollection = Class17.smethod_0(";?[^;\\s]*:[^\\{\\}:;]*(\\}|;)?", string_1);
			foreach (object obj in matchCollection)
			{
				Match match = (Match)obj;
				string[] array = match.Value.Split(new char[]
				{
					':'
				});
				if (array.Length == 2)
				{
					string key = array[0].Trim();
					string text = array[1].Trim();
					if (text.EndsWith(";"))
					{
						text = text.Substring(0, text.Length - 1).Trim();
					}
					this.Dictionary_0.Add(key, text);
					if (GClass23.dictionary_0.ContainsKey(key))
					{
						this.Dictionary_1.Add(GClass23.dictionary_0[key], text);
					}
				}
			}
		}

		// Token: 0x170001E0 RID: 480
		// (get) Token: 0x0600069C RID: 1692 RVA: 0x000064AB File Offset: 0x000046AB
		public Dictionary<string, string> Dictionary_0
		{
			get
			{
				return this.dictionary_1;
			}
		}

		// Token: 0x170001E1 RID: 481
		// (get) Token: 0x0600069D RID: 1693 RVA: 0x000064B3 File Offset: 0x000046B3
		public Dictionary<PropertyInfo, string> Dictionary_1
		{
			get
			{
				return this.dictionary_0;
			}
		}

		// Token: 0x170001E2 RID: 482
		// (get) Token: 0x0600069E RID: 1694 RVA: 0x000064BB File Offset: 0x000046BB
		public string String_0
		{
			get
			{
				return this.string_0;
			}
		}

		// Token: 0x0600069F RID: 1695 RVA: 0x000173B8 File Offset: 0x000155B8
		internal void method_0()
		{
			this.Dictionary_1.Clear();
			foreach (string key in this.Dictionary_0.Keys)
			{
				if (GClass23.dictionary_0.ContainsKey(key))
				{
					this.Dictionary_1.Add(GClass23.dictionary_0[key], this.Dictionary_0[key]);
				}
			}
		}

		// Token: 0x060006A0 RID: 1696 RVA: 0x00017444 File Offset: 0x00015644
		public void method_1(GClass23 gclass23_0)
		{
			foreach (PropertyInfo propertyInfo in this.Dictionary_1.Keys)
			{
				string text = this.Dictionary_1[propertyInfo];
				if (text == "inherit" && gclass23_0.GClass23_2 != null)
				{
					text = Convert.ToString(propertyInfo.GetValue(gclass23_0.GClass23_2, null));
				}
				propertyInfo.SetValue(gclass23_0, text, null);
			}
		}

		// Token: 0x04000270 RID: 624
		private string string_0;

		// Token: 0x04000271 RID: 625
		private Dictionary<PropertyInfo, string> dictionary_0;

		// Token: 0x04000272 RID: 626
		private Dictionary<string, string> dictionary_1;
	}
}
