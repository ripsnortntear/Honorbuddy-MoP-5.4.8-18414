﻿using System;

namespace ns0
{
	// Token: 0x02000088 RID: 136
	public enum GEnum8
	{
		// Token: 0x0400041B RID: 1051
		const_0,
		// Token: 0x0400041C RID: 1052
		const_1,
		// Token: 0x0400041D RID: 1053
		const_2,
		// Token: 0x0400041E RID: 1054
		const_3
	}
}
