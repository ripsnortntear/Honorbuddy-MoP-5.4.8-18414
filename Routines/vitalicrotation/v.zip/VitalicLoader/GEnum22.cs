﻿using System;

namespace ns0
{
	// Token: 0x0200009E RID: 158
	public enum GEnum22
	{
		// Token: 0x0400047D RID: 1149
		const_0,
		// Token: 0x0400047E RID: 1150
		const_1,
		// Token: 0x0400047F RID: 1151
		const_2
	}
}
