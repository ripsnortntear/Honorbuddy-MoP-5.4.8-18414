﻿namespace ns0
{
	// Token: 0x0200008A RID: 138
	public sealed partial class GForm1 : global::ns0.MetroForm
	{
	}
}
