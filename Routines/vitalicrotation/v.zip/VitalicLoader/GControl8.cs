﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000063 RID: 99
	[CLSCompliant(false)]
	public class GControl8 : GControl7
	{
		// Token: 0x06000744 RID: 1860 RVA: 0x00006A87 File Offset: 0x00004C87
		public GControl8()
		{
			base.SetStyle(ControlStyles.Opaque, false);
			this.AutoScroll = false;
		}

		// Token: 0x17000217 RID: 535
		// (get) Token: 0x06000745 RID: 1861 RVA: 0x00006A9E File Offset: 0x00004C9E
		// (set) Token: 0x06000746 RID: 1862 RVA: 0x00006AA6 File Offset: 0x00004CA6
		[DefaultValue(true)]
		[Description("Automatically sets the size of the label by measuring the content")]
		[Browsable(true)]
		public override bool AutoSize
		{
			get
			{
				return base.AutoSize;
			}
			set
			{
				base.AutoSize = value;
				if (value)
				{
					this.vmethod_1();
				}
			}
		}

		// Token: 0x06000747 RID: 1863 RVA: 0x0001B8C0 File Offset: 0x00019AC0
		protected override void vmethod_0()
		{
			string text = this.Text;
			string text2 = string.Format("font: {0}pt {1}", this.Font.Size, this.Font.FontFamily.Name);
			this.gclass28_0 = new GClass28(string.Concat(new string[]
			{
				"<table border=0 cellspacing=5 cellpadding=0 style=\"",
				text2,
				"\"><tr><td>",
				text,
				"</td></tr></table>"
			}));
		}

		// Token: 0x06000748 RID: 1864 RVA: 0x00006AB8 File Offset: 0x00004CB8
		public override void vmethod_1()
		{
			base.vmethod_1();
			if (this.gclass28_0 != null && this.AutoSize)
			{
				base.Size = Size.Round(this.gclass28_0.SizeF_1);
			}
		}
	}
}
