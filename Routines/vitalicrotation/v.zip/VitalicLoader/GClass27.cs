﻿using System;

namespace ns0
{
	// Token: 0x0200004F RID: 79
	[CLSCompliant(false)]
	public class GClass27 : GClass26
	{
		// Token: 0x06000699 RID: 1689 RVA: 0x00006484 File Offset: 0x00004684
		public GClass27(GClass23 gclass23_3) : base(gclass23_3)
		{
		}
	}
}
