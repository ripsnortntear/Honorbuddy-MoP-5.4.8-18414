﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Timers;

namespace ns0
{
	// Token: 0x0200000C RID: 12
	internal class Class1 : IDisposable
	{
		// Token: 0x06000039 RID: 57 RVA: 0x000022D8 File Offset: 0x000004D8
		protected Class1()
		{
			this.object_0 = new object();
		}

		// Token: 0x0600003A RID: 58 RVA: 0x000022EB File Offset: 0x000004EB
		[Obsolete("Use the static method DelayedCall.Create instead.")]
		public Class1(Class1.Delegate0 delegate0_1) : this()
		{
			Class1.smethod_4(this, 0, false);
			this.delegate0_0 = delegate0_1;
		}

		// Token: 0x0600003B RID: 59 RVA: 0x00002302 File Offset: 0x00000502
		[Obsolete("Use the static method DelayedCall.Create instead.")]
		public Class1(Class2<object>.Delegate1 delegate1_1, object object_2) : this()
		{
			Class1.smethod_4(this, 0, false);
			this.delegate1_0 = delegate1_1;
			this.object_1 = object_2;
		}

		// Token: 0x0600003C RID: 60 RVA: 0x00002320 File Offset: 0x00000520
		[Obsolete("Use the static method DelayedCall.Start instead.")]
		public Class1(Class1.Delegate0 delegate0_1, int int_0) : this()
		{
			Class1.smethod_4(this, int_0, false);
			this.delegate0_0 = delegate0_1;
			if (int_0 > 0)
			{
				this.method_3();
			}
		}

		// Token: 0x0600003D RID: 61 RVA: 0x00002341 File Offset: 0x00000541
		[Obsolete("Use the static method DelayedCall.Start instead.")]
		public Class1(Class2<object>.Delegate1 delegate1_1, int int_0, object object_2) : this()
		{
			Class1.smethod_4(this, int_0, false);
			this.delegate1_0 = delegate1_1;
			this.object_1 = object_2;
			if (int_0 > 0)
			{
				this.method_3();
			}
		}

		// Token: 0x0600003E RID: 62 RVA: 0x00002369 File Offset: 0x00000569
		[Obsolete("Use the method Restart of the generic class instead.")]
		public void method_0(object object_2)
		{
			this.method_4();
			this.object_1 = object_2;
			this.method_3();
		}

		// Token: 0x0600003F RID: 63 RVA: 0x0000237E File Offset: 0x0000057E
		[Obsolete("Use the method Restart of the generic class instead.")]
		public void method_1(int int_0, object object_2)
		{
			this.method_4();
			this.object_1 = object_2;
			this.method_8(int_0);
		}

		// Token: 0x06000040 RID: 64 RVA: 0x00002394 File Offset: 0x00000594
		[Obsolete("Use the method Restart instead.")]
		public void method_2(int int_0)
		{
			this.method_8(int_0);
		}

		// Token: 0x06000041 RID: 65 RVA: 0x00008210 File Offset: 0x00006410
		public static Class1 smethod_0(Class1.Delegate0 delegate0_1, int int_0)
		{
			Class1 @class = new Class1();
			Class1.smethod_4(@class, int_0, false);
			@class.delegate0_0 = delegate0_1;
			return @class;
		}

		// Token: 0x06000042 RID: 66 RVA: 0x00008234 File Offset: 0x00006434
		public static Class1 smethod_1(Class1.Delegate0 delegate0_1, int int_0)
		{
			Class1 @class = new Class1();
			Class1.smethod_4(@class, int_0, true);
			@class.delegate0_0 = delegate0_1;
			return @class;
		}

		// Token: 0x06000043 RID: 67 RVA: 0x00008258 File Offset: 0x00006458
		public static Class1 smethod_2(Class1.Delegate0 delegate0_1, int int_0)
		{
			Class1 @class = Class1.smethod_0(delegate0_1, int_0);
			if (int_0 > 0)
			{
				@class.method_3();
			}
			else if (int_0 == 0)
			{
				@class.method_6();
			}
			return @class;
		}

		// Token: 0x06000044 RID: 68 RVA: 0x00008284 File Offset: 0x00006484
		public static Class1 smethod_3(Class1.Delegate0 delegate0_1, int int_0)
		{
			Class1 @class = Class1.smethod_1(delegate0_1, int_0);
			if (int_0 > 0)
			{
				@class.method_3();
			}
			else if (int_0 == 0)
			{
				@class.method_6();
			}
			return @class;
		}

		// Token: 0x06000045 RID: 69 RVA: 0x000082B0 File Offset: 0x000064B0
		protected static void smethod_4(Class1 class1_0, int int_0, bool bool_1)
		{
			if (int_0 < 0)
			{
				throw new ArgumentOutOfRangeException("milliseconds", "The new timeout must be 0 or greater.");
			}
			class1_0.synchronizationContext_0 = null;
			if (!bool_1)
			{
				class1_0.synchronizationContext_0 = SynchronizationContext.Current;
				if (class1_0.synchronizationContext_0 == null)
				{
					throw new InvalidOperationException("Cannot delay calls synchronously on a non-UI thread. Use the *Async methods instead.");
				}
			}
			if (class1_0.synchronizationContext_0 == null)
			{
				class1_0.synchronizationContext_0 = new SynchronizationContext();
			}
			class1_0.timer_0 = new System.Timers.Timer();
			if (int_0 > 0)
			{
				class1_0.timer_0.Interval = (double)int_0;
			}
			class1_0.timer_0.AutoReset = false;
			class1_0.timer_0.Elapsed += class1_0.vmethod_0;
			Class1.smethod_5(class1_0);
		}

		// Token: 0x06000046 RID: 70 RVA: 0x00008354 File Offset: 0x00006554
		protected static void smethod_5(Class1 class1_0)
		{
			lock (Class1.list_0)
			{
				if (!Class1.list_0.Contains(class1_0))
				{
					Class1.list_0.Add(class1_0);
				}
			}
		}

		// Token: 0x06000047 RID: 71 RVA: 0x000083A0 File Offset: 0x000065A0
		protected static void smethod_6(Class1 class1_0)
		{
			lock (Class1.list_0)
			{
				Class1.list_0.Remove(class1_0);
			}
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000048 RID: 72 RVA: 0x000083E0 File Offset: 0x000065E0
		public static int Int32_0
		{
			get
			{
				int count;
				lock (Class1.list_0)
				{
					count = Class1.list_0.Count;
				}
				return count;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x06000049 RID: 73 RVA: 0x00008420 File Offset: 0x00006620
		public static bool Boolean_0
		{
			get
			{
				lock (Class1.list_0)
				{
					foreach (Class1 @class in Class1.list_0)
					{
						if (@class.Boolean_1)
						{
							return true;
						}
					}
				}
				return false;
			}
		}

		// Token: 0x0600004A RID: 74 RVA: 0x0000849C File Offset: 0x0000669C
		public static void smethod_7()
		{
			lock (Class1.list_0)
			{
				foreach (Class1 @class in Class1.list_0)
				{
					@class.method_4();
				}
			}
		}

		// Token: 0x0600004B RID: 75 RVA: 0x00008510 File Offset: 0x00006710
		public static void smethod_8()
		{
			lock (Class1.list_0)
			{
				foreach (Class1 @class in Class1.list_0)
				{
					@class.method_5();
				}
			}
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00008584 File Offset: 0x00006784
		public static void smethod_9()
		{
			lock (Class1.list_0)
			{
				while (Class1.list_0.Count > 0)
				{
					Class1.list_0[0].Dispose();
				}
			}
		}

		// Token: 0x0600004D RID: 77 RVA: 0x0000239D File Offset: 0x0000059D
		protected virtual void vmethod_0(object sender, ElapsedEventArgs e)
		{
			this.method_6();
			Class1.smethod_6(this);
		}

		// Token: 0x0600004E RID: 78 RVA: 0x000023AB File Offset: 0x000005AB
		public void Dispose()
		{
			Class1.smethod_6(this);
			this.timer_0.Dispose();
		}

		// Token: 0x0600004F RID: 79 RVA: 0x000085D8 File Offset: 0x000067D8
		public void method_3()
		{
			lock (this.object_0)
			{
				this.bool_0 = false;
				this.timer_0.Start();
				Class1.smethod_5(this);
			}
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00008624 File Offset: 0x00006824
		public void method_4()
		{
			lock (this.object_0)
			{
				this.bool_0 = true;
				Class1.smethod_6(this);
				this.timer_0.Stop();
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000051 RID: 81 RVA: 0x00008670 File Offset: 0x00006870
		public bool Boolean_1
		{
			get
			{
				bool result;
				lock (this.object_0)
				{
					result = (this.timer_0.Enabled && !this.bool_0);
				}
				return result;
			}
		}

		// Token: 0x06000052 RID: 82 RVA: 0x000086C0 File Offset: 0x000068C0
		public void method_5()
		{
			lock (this.object_0)
			{
				if (!this.Boolean_1)
				{
					return;
				}
				this.timer_0.Stop();
			}
			this.method_6();
		}

		// Token: 0x06000053 RID: 83 RVA: 0x000023BE File Offset: 0x000005BE
		public void method_6()
		{
			this.vmethod_1();
			Class1.smethod_6(this);
		}

		// Token: 0x06000054 RID: 84 RVA: 0x000023CC File Offset: 0x000005CC
		protected virtual void vmethod_1()
		{
			this.synchronizationContext_0.Post(new SendOrPostCallback(this.method_9), null);
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00008710 File Offset: 0x00006910
		public void method_7()
		{
			lock (this.object_0)
			{
				this.method_4();
				this.method_3();
			}
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00008750 File Offset: 0x00006950
		public void method_8(int int_0)
		{
			lock (this.object_0)
			{
				this.method_4();
				this.Int32_1 = int_0;
				this.method_3();
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000057 RID: 87 RVA: 0x00008798 File Offset: 0x00006998
		// (set) Token: 0x06000058 RID: 88 RVA: 0x000087DC File Offset: 0x000069DC
		public int Int32_1
		{
			get
			{
				int result;
				lock (this.object_0)
				{
					result = (int)this.timer_0.Interval;
				}
				return result;
			}
			set
			{
				lock (this.object_0)
				{
					if (value < 0)
					{
						throw new ArgumentOutOfRangeException("Milliseconds", "The new timeout must be 0 or greater.");
					}
					if (value == 0)
					{
						this.method_4();
						this.method_6();
						Class1.smethod_6(this);
					}
					else
					{
						this.timer_0.Interval = (double)value;
					}
				}
			}
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00008848 File Offset: 0x00006A48
		[CompilerGenerated]
		private void method_9(object object_2)
		{
			lock (this.object_0)
			{
				if (this.bool_0)
				{
					return;
				}
			}
			if (this.delegate0_0 != null)
			{
				this.delegate0_0();
			}
			if (this.delegate1_0 != null)
			{
				this.delegate1_0(this.object_1);
			}
		}

		// Token: 0x04000022 RID: 34
		protected static List<Class1> list_0 = new List<Class1>();

		// Token: 0x04000023 RID: 35
		protected System.Timers.Timer timer_0;

		// Token: 0x04000024 RID: 36
		protected object object_0;

		// Token: 0x04000025 RID: 37
		private Class1.Delegate0 delegate0_0;

		// Token: 0x04000026 RID: 38
		protected bool bool_0;

		// Token: 0x04000027 RID: 39
		protected SynchronizationContext synchronizationContext_0;

		// Token: 0x04000028 RID: 40
		private Class2<object>.Delegate1 delegate1_0;

		// Token: 0x04000029 RID: 41
		private object object_1;

		// Token: 0x0200000D RID: 13
		// (Invoke) Token: 0x0600005B RID: 91
		public delegate void Delegate0();
	}
}
