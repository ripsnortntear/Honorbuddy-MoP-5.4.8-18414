﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Security;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000040 RID: 64
	[Designer("MetroFramework.Design.Controls.MetroScrollBarDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	[DefaultProperty("Value")]
	[DefaultEvent("Scroll")]
	public class GControl1 : Control, GInterface2
	{
		// Token: 0x06000390 RID: 912 RVA: 0x0000F7B4 File Offset: 0x0000D9B4
		public GControl1()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer, true);
			base.Width = 10;
			base.Height = 200;
			this.method_5();
			this.timer_0.Interval = 20;
			this.timer_0.Tick += this.timer_0_Tick;
		}

		// Token: 0x06000391 RID: 913 RVA: 0x00004431 File Offset: 0x00002631
		public GControl1(GEnum3 genum3_1) : this()
		{
			this.GEnum3_0 = genum3_1;
		}

		// Token: 0x06000392 RID: 914 RVA: 0x00004440 File Offset: 0x00002640
		public GControl1(GEnum3 genum3_1, int int_13) : this(genum3_1)
		{
			base.Width = int_13;
		}

		// Token: 0x14000027 RID: 39
		// (add) Token: 0x06000393 RID: 915 RVA: 0x0000F860 File Offset: 0x0000DA60
		// (remove) Token: 0x06000394 RID: 916 RVA: 0x0000F898 File Offset: 0x0000DA98
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000395 RID: 917 RVA: 0x00004450 File Offset: 0x00002650
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000028 RID: 40
		// (add) Token: 0x06000396 RID: 918 RVA: 0x0000F8D0 File Offset: 0x0000DAD0
		// (remove) Token: 0x06000397 RID: 919 RVA: 0x0000F908 File Offset: 0x0000DB08
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000398 RID: 920 RVA: 0x00004470 File Offset: 0x00002670
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000029 RID: 41
		// (add) Token: 0x06000399 RID: 921 RVA: 0x0000F940 File Offset: 0x0000DB40
		// (remove) Token: 0x0600039A RID: 922 RVA: 0x0000F978 File Offset: 0x0000DB78
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x0600039B RID: 923 RVA: 0x00004490 File Offset: 0x00002690
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x170000D7 RID: 215
		// (get) Token: 0x0600039C RID: 924 RVA: 0x0000F9B0 File Offset: 0x0000DBB0
		// (set) Token: 0x0600039D RID: 925 RVA: 0x000044B0 File Offset: 0x000026B0
		[Category("Metro Appearance")]
		[DefaultValue(GEnum10.const_0)]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x170000D8 RID: 216
		// (get) Token: 0x0600039E RID: 926 RVA: 0x0000FA08 File Offset: 0x0000DC08
		// (set) Token: 0x0600039F RID: 927 RVA: 0x000044B9 File Offset: 0x000026B9
		[DefaultValue(GEnum29.const_0)]
		[Category("Metro Appearance")]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x170000D9 RID: 217
		// (get) Token: 0x060003A0 RID: 928 RVA: 0x000044C2 File Offset: 0x000026C2
		// (set) Token: 0x060003A1 RID: 929 RVA: 0x000044CA File Offset: 0x000026CA
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x170000DA RID: 218
		// (get) Token: 0x060003A2 RID: 930 RVA: 0x000044D3 File Offset: 0x000026D3
		// (set) Token: 0x060003A3 RID: 931 RVA: 0x000044DB File Offset: 0x000026DB
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x170000DB RID: 219
		// (get) Token: 0x060003A4 RID: 932 RVA: 0x000044E4 File Offset: 0x000026E4
		// (set) Token: 0x060003A5 RID: 933 RVA: 0x000044EC File Offset: 0x000026EC
		[Category("Metro Appearance")]
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[DefaultValue(false)]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x170000DC RID: 220
		// (get) Token: 0x060003A6 RID: 934 RVA: 0x000044F5 File Offset: 0x000026F5
		// (set) Token: 0x060003A7 RID: 935 RVA: 0x000044FD File Offset: 0x000026FD
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x170000DD RID: 221
		// (get) Token: 0x060003A8 RID: 936 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x060003A9 RID: 937 RVA: 0x00002923 File Offset: 0x00000B23
		[DefaultValue(false)]
		[Category("Metro Behaviour")]
		[Browsable(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x1400002A RID: 42
		// (add) Token: 0x060003AA RID: 938 RVA: 0x0000FA60 File Offset: 0x0000DC60
		// (remove) Token: 0x060003AB RID: 939 RVA: 0x0000FA98 File Offset: 0x0000DC98
		public event ScrollEventHandler Event_0
		{
			add
			{
				ScrollEventHandler scrollEventHandler = this.scrollEventHandler_0;
				ScrollEventHandler scrollEventHandler2;
				do
				{
					scrollEventHandler2 = scrollEventHandler;
					ScrollEventHandler value2 = (ScrollEventHandler)Delegate.Combine(scrollEventHandler2, value);
					scrollEventHandler = Interlocked.CompareExchange<ScrollEventHandler>(ref this.scrollEventHandler_0, value2, scrollEventHandler2);
				}
				while (scrollEventHandler != scrollEventHandler2);
			}
			remove
			{
				ScrollEventHandler scrollEventHandler = this.scrollEventHandler_0;
				ScrollEventHandler scrollEventHandler2;
				do
				{
					scrollEventHandler2 = scrollEventHandler;
					ScrollEventHandler value2 = (ScrollEventHandler)Delegate.Remove(scrollEventHandler2, value);
					scrollEventHandler = Interlocked.CompareExchange<ScrollEventHandler>(ref this.scrollEventHandler_0, value2, scrollEventHandler2);
				}
				while (scrollEventHandler != scrollEventHandler2);
			}
		}

		// Token: 0x060003AC RID: 940 RVA: 0x0000FAD0 File Offset: 0x0000DCD0
		private void method_0(ScrollEventType scrollEventType_0, int int_13, int int_14, ScrollOrientation scrollOrientation_1)
		{
			if (this.scrollEventHandler_0 == null)
			{
				return;
			}
			if (scrollOrientation_1 == ScrollOrientation.HorizontalScroll)
			{
				if (scrollEventType_0 != ScrollEventType.EndScroll && this.bool_4)
				{
					scrollEventType_0 = ScrollEventType.First;
				}
				else if (!this.bool_4 && scrollEventType_0 == ScrollEventType.EndScroll)
				{
					this.bool_4 = true;
				}
			}
			else if (scrollEventType_0 != ScrollEventType.EndScroll && this.bool_3)
			{
				scrollEventType_0 = ScrollEventType.First;
			}
			else if (!this.bool_4 && scrollEventType_0 == ScrollEventType.EndScroll)
			{
				this.bool_3 = true;
			}
			this.scrollEventHandler_0(this, new ScrollEventArgs(scrollEventType_0, int_13, int_14, scrollOrientation_1));
		}

		// Token: 0x170000DE RID: 222
		// (get) Token: 0x060003AD RID: 941 RVA: 0x00004506 File Offset: 0x00002706
		// (set) Token: 0x060003AE RID: 942 RVA: 0x0000450E File Offset: 0x0000270E
		public int Int32_0
		{
			get
			{
				return this.int_7;
			}
			set
			{
				if (value <= 0)
				{
					throw new ArgumentOutOfRangeException("value", "MouseWheelBarPartitions has to be greather than zero");
				}
				this.int_7 = value;
			}
		}

		// Token: 0x170000DF RID: 223
		// (get) Token: 0x060003AF RID: 943 RVA: 0x0000452B File Offset: 0x0000272B
		// (set) Token: 0x060003B0 RID: 944 RVA: 0x00004533 File Offset: 0x00002733
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_0
		{
			get
			{
				return this.bool_11;
			}
			set
			{
				this.bool_11 = value;
			}
		}

		// Token: 0x170000E0 RID: 224
		// (get) Token: 0x060003B1 RID: 945 RVA: 0x0000453C File Offset: 0x0000273C
		// (set) Token: 0x060003B2 RID: 946 RVA: 0x00004554 File Offset: 0x00002754
		[Category("Metro Appearance")]
		public int Int32_1
		{
			get
			{
				if (this.GEnum3_0 != GEnum3.const_1)
				{
					return base.Height;
				}
				return base.Width;
			}
			set
			{
				if (this.GEnum3_0 == GEnum3.const_1)
				{
					base.Width = value;
					return;
				}
				base.Height = value;
			}
		}

		// Token: 0x170000E1 RID: 225
		// (get) Token: 0x060003B3 RID: 947 RVA: 0x0000456E File Offset: 0x0000276E
		// (set) Token: 0x060003B4 RID: 948 RVA: 0x00004576 File Offset: 0x00002776
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_1
		{
			get
			{
				return this.bool_12;
			}
			set
			{
				this.bool_12 = value;
			}
		}

		// Token: 0x170000E2 RID: 226
		// (get) Token: 0x060003B5 RID: 949 RVA: 0x0000457F File Offset: 0x0000277F
		// (set) Token: 0x060003B6 RID: 950 RVA: 0x0000FB50 File Offset: 0x0000DD50
		public GEnum3 GEnum3_0
		{
			get
			{
				return this.genum3_0;
			}
			set
			{
				if (value == this.genum3_0)
				{
					return;
				}
				this.genum3_0 = value;
				if (value == GEnum3.const_1)
				{
					this.scrollOrientation_0 = ScrollOrientation.VerticalScroll;
				}
				else
				{
					this.scrollOrientation_0 = ScrollOrientation.HorizontalScroll;
				}
				base.Size = new Size(base.Height, base.Width);
				this.method_5();
			}
		}

		// Token: 0x170000E3 RID: 227
		// (get) Token: 0x060003B7 RID: 951 RVA: 0x00004587 File Offset: 0x00002787
		// (set) Token: 0x060003B8 RID: 952 RVA: 0x0000FBA0 File Offset: 0x0000DDA0
		public int Int32_2
		{
			get
			{
				return this.int_8;
			}
			set
			{
				if (this.int_8 == value || value < 0 || value >= this.int_9)
				{
					return;
				}
				this.int_8 = value;
				if (this.int_12 < value)
				{
					this.int_12 = value;
				}
				if (this.int_11 > this.int_9 - this.int_8)
				{
					this.int_11 = this.int_9 - this.int_8;
				}
				this.method_5();
				if (this.int_12 < value)
				{
					this.bool_13 = true;
					this.Int32_6 = value;
					return;
				}
				this.method_12(this.method_8());
				this.Refresh();
			}
		}

		// Token: 0x170000E4 RID: 228
		// (get) Token: 0x060003B9 RID: 953 RVA: 0x0000458F File Offset: 0x0000278F
		// (set) Token: 0x060003BA RID: 954 RVA: 0x0000FC34 File Offset: 0x0000DE34
		public int Int32_3
		{
			get
			{
				return this.int_9;
			}
			set
			{
				if (value == this.int_9 || value < 1 || value <= this.int_8)
				{
					return;
				}
				this.int_9 = value;
				if (this.int_11 > this.int_9 - this.int_8)
				{
					this.int_11 = this.int_9 - this.int_8;
				}
				this.method_5();
				if (this.int_12 > value)
				{
					this.bool_13 = true;
					this.Int32_6 = this.int_9;
					return;
				}
				this.method_12(this.method_8());
				this.Refresh();
			}
		}

		// Token: 0x170000E5 RID: 229
		// (get) Token: 0x060003BB RID: 955 RVA: 0x00004597 File Offset: 0x00002797
		// (set) Token: 0x060003BC RID: 956 RVA: 0x0000459F File Offset: 0x0000279F
		[DefaultValue(1)]
		public int Int32_4
		{
			get
			{
				return this.int_10;
			}
			set
			{
				if (value != this.int_10 && value >= 1 && value < this.int_11)
				{
					this.int_10 = value;
					this.method_5();
					return;
				}
			}
		}

		// Token: 0x170000E6 RID: 230
		// (get) Token: 0x060003BD RID: 957 RVA: 0x000045C5 File Offset: 0x000027C5
		// (set) Token: 0x060003BE RID: 958 RVA: 0x0000FCBC File Offset: 0x0000DEBC
		[DefaultValue(5)]
		public int Int32_5
		{
			get
			{
				return this.int_11;
			}
			set
			{
				if (value != this.int_11 && value >= this.int_10 && value >= 2)
				{
					if (value > this.int_9 - this.int_8)
					{
						this.int_11 = this.int_9 - this.int_8;
					}
					else
					{
						this.int_11 = value;
					}
					this.method_5();
					return;
				}
			}
		}

		// Token: 0x170000E7 RID: 231
		// (get) Token: 0x060003BF RID: 959 RVA: 0x000045CD File Offset: 0x000027CD
		// (set) Token: 0x060003C0 RID: 960 RVA: 0x0000FD14 File Offset: 0x0000DF14
		[DefaultValue(0)]
		[Browsable(false)]
		public int Int32_6
		{
			get
			{
				return this.int_12;
			}
			set
			{
				if (this.int_12 != value && value >= this.int_8 && value <= this.int_9)
				{
					this.int_12 = value;
					this.method_12(this.method_8());
					this.method_0(ScrollEventType.ThumbPosition, -1, value, this.scrollOrientation_0);
					if (!this.bool_13 && this.bool_12)
					{
						if (!this.bool_9)
						{
							this.bool_9 = true;
						}
						if (this.timer_1 == null)
						{
							this.timer_1 = new System.Windows.Forms.Timer();
							this.timer_1.Interval = 1000;
							this.timer_1.Tick += this.timer_1_Tick;
							this.timer_1.Start();
						}
						else
						{
							this.timer_1.Stop();
							this.timer_1.Start();
						}
					}
					else
					{
						this.bool_13 = false;
					}
					this.Refresh();
					return;
				}
			}
		}

		// Token: 0x060003C1 RID: 961 RVA: 0x000045D5 File Offset: 0x000027D5
		private void timer_1_Tick(object sender, EventArgs e)
		{
			this.bool_9 = false;
			base.Invalidate();
			this.timer_1.Stop();
		}

		// Token: 0x060003C2 RID: 962 RVA: 0x000045EF File Offset: 0x000027EF
		public bool method_1(Point point_0)
		{
			return this.rectangle_1.Contains(point_0);
		}

		// Token: 0x060003C3 RID: 963 RVA: 0x000045FD File Offset: 0x000027FD
		[SecuritySafeCritical]
		public void method_2()
		{
			Class29.SendMessage_1(base.Handle, 11, false, 0);
			this.bool_5 = true;
		}

		// Token: 0x060003C4 RID: 964 RVA: 0x00004616 File Offset: 0x00002816
		[SecuritySafeCritical]
		public void method_3()
		{
			Class29.SendMessage_1(base.Handle, 11, true, 0);
			this.bool_5 = false;
			this.method_5();
			this.Refresh();
		}

		// Token: 0x060003C5 RID: 965 RVA: 0x0000FDF4 File Offset: 0x0000DFF4
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					if (base.Parent != null)
					{
						if (base.Parent is GInterface2)
						{
							color = GClass39.GClass46.smethod_0(this.GEnum29_0);
						}
						else
						{
							color = base.Parent.BackColor;
						}
					}
					else
					{
						color = GClass39.GClass46.smethod_0(this.GEnum29_0);
					}
				}
				if (color.A == 255)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060003C6 RID: 966 RVA: 0x0000FEA4 File Offset: 0x0000E0A4
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060003C7 RID: 967 RVA: 0x0000FF04 File Offset: 0x0000E104
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color color;
			if (this.bool_0)
			{
				color = this.BackColor;
			}
			else if (base.Parent != null)
			{
				if (base.Parent is GInterface2)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
				}
				else
				{
					color = base.Parent.BackColor;
				}
			}
			else
			{
				color = GClass39.GClass46.smethod_0(this.GEnum29_0);
			}
			Color color2;
			Color color_;
			if (this.bool_9 && !this.bool_10 && base.Enabled)
			{
				color2 = GClass39.GClass46.GClass51.GClass52.smethod_1(this.GEnum29_0);
				color_ = GClass39.GClass46.GClass51.GClass53.smethod_1(this.GEnum29_0);
			}
			else if (this.bool_9 && this.bool_10 && base.Enabled)
			{
				color2 = GClass39.GClass46.GClass51.GClass52.smethod_2(this.GEnum29_0);
				color_ = GClass39.GClass46.GClass51.GClass53.smethod_2(this.GEnum29_0);
			}
			else if (!base.Enabled)
			{
				color2 = GClass39.GClass46.GClass51.GClass52.smethod_3(this.GEnum29_0);
				color_ = GClass39.GClass46.GClass51.GClass53.smethod_3(this.GEnum29_0);
			}
			else
			{
				color2 = GClass39.GClass46.GClass51.GClass52.smethod_0(this.GEnum29_0);
				color_ = GClass39.GClass46.GClass51.GClass53.smethod_0(this.GEnum29_0);
			}
			this.method_4(paintEventArgs_0.Graphics, color, color2, color_);
			this.vmethod_2(new GEventArgs3(color, color2, paintEventArgs_0.Graphics));
		}

		// Token: 0x060003C8 RID: 968 RVA: 0x00010020 File Offset: 0x0000E220
		private void method_4(Graphics graphics_0, Color color_0, Color color_1, Color color_2)
		{
			if (this.bool_11)
			{
				using (SolidBrush solidBrush = new SolidBrush(color_2))
				{
					graphics_0.FillRectangle(solidBrush, base.ClientRectangle);
				}
			}
			using (SolidBrush solidBrush2 = new SolidBrush(color_0))
			{
				Rectangle rect = new Rectangle(this.rectangle_1.X - 1, this.rectangle_1.Y - 1, this.rectangle_1.Width + 2, this.rectangle_1.Height + 2);
				graphics_0.FillRectangle(solidBrush2, rect);
			}
			using (SolidBrush solidBrush3 = new SolidBrush(color_1))
			{
				graphics_0.FillRectangle(solidBrush3, this.rectangle_1);
			}
		}

		// Token: 0x060003C9 RID: 969 RVA: 0x0000463B File Offset: 0x0000283B
		protected override void OnGotFocus(EventArgs e)
		{
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x060003CA RID: 970 RVA: 0x0000464A File Offset: 0x0000284A
		protected override void OnLostFocus(EventArgs e)
		{
			this.bool_9 = false;
			this.bool_10 = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		// Token: 0x060003CB RID: 971 RVA: 0x00004667 File Offset: 0x00002867
		protected override void OnEnter(EventArgs e)
		{
			base.Invalidate();
			base.OnEnter(e);
		}

		// Token: 0x060003CC RID: 972 RVA: 0x00004676 File Offset: 0x00002876
		protected override void OnLeave(EventArgs e)
		{
			this.bool_9 = false;
			this.bool_10 = false;
			base.Invalidate();
			base.OnLeave(e);
		}

		// Token: 0x060003CD RID: 973 RVA: 0x000100F4 File Offset: 0x0000E2F4
		protected override void OnMouseWheel(MouseEventArgs e)
		{
			base.OnMouseWheel(e);
			int num = e.Delta / 120 * (this.int_9 - this.int_8) / this.int_7;
			if (this.GEnum3_0 == GEnum3.const_1)
			{
				this.Int32_6 -= num;
				return;
			}
			this.Int32_6 += num;
		}

		// Token: 0x060003CE RID: 974 RVA: 0x00010150 File Offset: 0x0000E350
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.bool_10 = true;
				base.Invalidate();
			}
			base.OnMouseDown(e);
			base.Focus();
			if (e.Button != MouseButtons.Left)
			{
				if (e.Button == MouseButtons.Right)
				{
					this.int_6 = ((this.genum3_0 == GEnum3.const_1) ? e.Y : e.X);
				}
				return;
			}
			Point location = e.Location;
			if (this.rectangle_1.Contains(location))
			{
				this.bool_8 = true;
				this.int_5 = ((this.genum3_0 == GEnum3.const_1) ? (location.Y - this.rectangle_1.Y) : (location.X - this.rectangle_1.X));
				base.Invalidate(this.rectangle_1);
				return;
			}
			this.int_6 = ((this.genum3_0 == GEnum3.const_1) ? location.Y : location.X);
			if (this.int_6 < ((this.genum3_0 == GEnum3.const_1) ? this.rectangle_1.Y : this.rectangle_1.X))
			{
				this.bool_6 = true;
			}
			else
			{
				this.bool_7 = true;
			}
			this.method_13(true);
		}

		// Token: 0x060003CF RID: 975 RVA: 0x00010280 File Offset: 0x0000E480
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this.bool_10 = false;
			base.OnMouseUp(e);
			if (e.Button == MouseButtons.Left)
			{
				if (this.bool_8)
				{
					this.bool_8 = false;
					this.method_0(ScrollEventType.EndScroll, -1, this.int_12, this.scrollOrientation_0);
				}
				else if (this.bool_6)
				{
					this.bool_6 = false;
					this.method_11();
				}
				else if (this.bool_7)
				{
					this.bool_7 = false;
					this.method_11();
				}
				base.Invalidate();
			}
		}

		// Token: 0x060003D0 RID: 976 RVA: 0x00004693 File Offset: 0x00002893
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_9 = true;
			base.Invalidate();
			base.OnMouseEnter(e);
		}

		// Token: 0x060003D1 RID: 977 RVA: 0x000046A9 File Offset: 0x000028A9
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_9 = false;
			base.Invalidate();
			base.OnMouseLeave(e);
			this.method_6();
		}

		// Token: 0x060003D2 RID: 978 RVA: 0x00010300 File Offset: 0x0000E500
		protected override void OnMouseMove(MouseEventArgs e)
		{
			base.OnMouseMove(e);
			if (e.Button == MouseButtons.Left)
			{
				if (this.bool_8)
				{
					int num = this.int_12;
					int num2 = (this.genum3_0 == GEnum3.const_1) ? e.Location.Y : e.Location.X;
					int num3 = (this.genum3_0 == GEnum3.const_1) ? (num2 / base.Height / this.int_1) : (num2 / base.Width / this.int_0);
					if (num2 <= this.int_4 + this.int_5)
					{
						this.method_12(this.int_4);
						this.int_12 = this.int_8;
						base.Invalidate();
					}
					else if (num2 >= this.int_3 + this.int_5)
					{
						this.method_12(this.int_3);
						this.int_12 = this.int_9;
						base.Invalidate();
					}
					else
					{
						this.method_12(num2 - this.int_5);
						int num4;
						int num5;
						if (this.GEnum3_0 == GEnum3.const_1)
						{
							num4 = base.Height - num3;
							num5 = this.rectangle_1.Y;
						}
						else
						{
							num4 = base.Width - num3;
							num5 = this.rectangle_1.X;
						}
						float num6 = 0f;
						if (num4 != 0)
						{
							num6 = (float)num5 / (float)num4;
						}
						this.int_12 = Convert.ToInt32(num6 * (float)(this.int_9 - this.int_8) + (float)this.int_8);
					}
					if (num != this.int_12)
					{
						this.method_0(ScrollEventType.ThumbTrack, num, this.int_12, this.scrollOrientation_0);
						this.Refresh();
						return;
					}
				}
			}
			else
			{
				if (!base.ClientRectangle.Contains(e.Location))
				{
					this.method_6();
					return;
				}
				if (e.Button == MouseButtons.None)
				{
					if (this.rectangle_1.Contains(e.Location))
					{
						base.Invalidate(this.rectangle_1);
						return;
					}
					if (base.ClientRectangle.Contains(e.Location))
					{
						base.Invalidate();
					}
				}
			}
		}

		// Token: 0x060003D3 RID: 979 RVA: 0x000046C5 File Offset: 0x000028C5
		protected override void OnKeyDown(KeyEventArgs e)
		{
			this.bool_9 = true;
			this.bool_10 = true;
			base.Invalidate();
			base.OnKeyDown(e);
		}

		// Token: 0x060003D4 RID: 980 RVA: 0x000046E2 File Offset: 0x000028E2
		protected override void OnKeyUp(KeyEventArgs e)
		{
			this.bool_9 = false;
			this.bool_10 = false;
			base.Invalidate();
			base.OnKeyUp(e);
		}

		// Token: 0x060003D5 RID: 981 RVA: 0x000046FF File Offset: 0x000028FF
		protected override void SetBoundsCore(int x, int y, int width, int height, BoundsSpecified specified)
		{
			base.SetBoundsCore(x, y, width, height, specified);
			if (base.DesignMode)
			{
				this.method_5();
			}
		}

		// Token: 0x060003D6 RID: 982 RVA: 0x0000471C File Offset: 0x0000291C
		protected override void OnSizeChanged(EventArgs e)
		{
			base.OnSizeChanged(e);
			this.method_5();
		}

		// Token: 0x060003D7 RID: 983 RVA: 0x000104F8 File Offset: 0x0000E6F8
		protected override bool ProcessDialogKey(Keys keyData)
		{
			Keys keys = Keys.Up;
			Keys keys2 = Keys.Down;
			if (this.GEnum3_0 == GEnum3.const_0)
			{
				keys = Keys.Left;
				keys2 = Keys.Right;
			}
			if (keyData == keys)
			{
				this.Int32_6 -= this.int_10;
				return true;
			}
			if (keyData == keys2)
			{
				this.Int32_6 += this.int_10;
				return true;
			}
			if (keyData == Keys.Prior)
			{
				this.Int32_6 = this.method_7(false, true);
				return true;
			}
			if (keyData == Keys.Next)
			{
				if (this.int_12 + this.int_11 > this.int_9)
				{
					this.Int32_6 = this.int_9;
				}
				else
				{
					this.Int32_6 += this.int_11;
				}
				return true;
			}
			if (keyData == Keys.Home)
			{
				this.Int32_6 = this.int_8;
				return true;
			}
			if (keyData == Keys.End)
			{
				this.Int32_6 = this.int_9;
				return true;
			}
			return base.ProcessDialogKey(keyData);
		}

		// Token: 0x060003D8 RID: 984 RVA: 0x0000472B File Offset: 0x0000292B
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x060003D9 RID: 985 RVA: 0x000105CC File Offset: 0x0000E7CC
		private void method_5()
		{
			if (this.bool_5)
			{
				return;
			}
			if (this.GEnum3_0 == GEnum3.const_1)
			{
				this.int_0 = ((base.Width > 0) ? base.Width : 10);
				this.int_1 = this.method_9();
				this.rectangle_0 = base.ClientRectangle;
				this.rectangle_0.Inflate(-1, -1);
				this.rectangle_1 = new Rectangle(base.ClientRectangle.X, base.ClientRectangle.Y, this.int_0, this.int_1);
				this.int_5 = this.rectangle_1.Height / 2;
				this.int_2 = base.ClientRectangle.Bottom;
				this.int_3 = this.int_2 - this.rectangle_1.Height;
				this.int_4 = base.ClientRectangle.Y;
			}
			else
			{
				this.int_1 = ((base.Height > 0) ? base.Height : 10);
				this.int_0 = this.method_9();
				this.rectangle_0 = base.ClientRectangle;
				this.rectangle_0.Inflate(-1, -1);
				this.rectangle_1 = new Rectangle(base.ClientRectangle.X, base.ClientRectangle.Y, this.int_0, this.int_1);
				this.int_5 = this.rectangle_1.Width / 2;
				this.int_2 = base.ClientRectangle.Right;
				this.int_3 = this.int_2 - this.rectangle_1.Width;
				this.int_4 = base.ClientRectangle.X;
			}
			this.method_12(this.method_8());
			this.Refresh();
		}

		// Token: 0x060003DA RID: 986 RVA: 0x0000473A File Offset: 0x0000293A
		private void method_6()
		{
			this.bool_6 = false;
			this.bool_7 = false;
			this.method_11();
			this.Refresh();
		}

		// Token: 0x060003DB RID: 987 RVA: 0x00004756 File Offset: 0x00002956
		private void timer_0_Tick(object sender, EventArgs e)
		{
			this.method_13(true);
		}

		// Token: 0x060003DC RID: 988 RVA: 0x00010794 File Offset: 0x0000E994
		private int method_7(bool bool_14, bool bool_15)
		{
			int num;
			if (bool_15)
			{
				num = this.int_12 - (bool_14 ? this.int_10 : this.int_11);
				if (num < this.int_8)
				{
					num = this.int_8;
				}
			}
			else
			{
				num = this.int_12 + (bool_14 ? this.int_10 : this.int_11);
				if (num > this.int_9)
				{
					num = this.int_9;
				}
			}
			return num;
		}

		// Token: 0x060003DD RID: 989 RVA: 0x000107FC File Offset: 0x0000E9FC
		private int method_8()
		{
			if (this.int_1 != 0 && this.int_0 != 0)
			{
				int num = (this.genum3_0 == GEnum3.const_1) ? (this.int_5 / base.Height / this.int_1) : (this.int_5 / base.Width / this.int_0);
				int num2;
				if (this.GEnum3_0 == GEnum3.const_1)
				{
					num2 = base.Height - num;
				}
				else
				{
					num2 = base.Width - num;
				}
				int num3 = this.int_9 - this.int_8;
				float num4 = 0f;
				if (num3 != 0)
				{
					num4 = ((float)this.int_12 - (float)this.int_8) / (float)num3;
				}
				return Math.Max(this.int_4, Math.Min(this.int_3, Convert.ToInt32(num4 * (float)num2)));
			}
			return 0;
		}

		// Token: 0x060003DE RID: 990 RVA: 0x000108BC File Offset: 0x0000EABC
		private int method_9()
		{
			int num = (this.genum3_0 == GEnum3.const_1) ? base.Height : base.Width;
			if (this.int_9 != 0 && this.int_11 != 0)
			{
				float val = (float)this.int_11 * (float)num / (float)this.int_9;
				return Convert.ToInt32(Math.Min((float)num, Math.Max(val, 10f)));
			}
			return num;
		}

		// Token: 0x060003DF RID: 991 RVA: 0x0000475F File Offset: 0x0000295F
		private void method_10()
		{
			if (!this.timer_0.Enabled)
			{
				this.timer_0.Interval = 600;
				this.timer_0.Start();
				return;
			}
			this.timer_0.Interval = 10;
		}

		// Token: 0x060003E0 RID: 992 RVA: 0x00004797 File Offset: 0x00002997
		private void method_11()
		{
			this.timer_0.Stop();
		}

		// Token: 0x060003E1 RID: 993 RVA: 0x000047A4 File Offset: 0x000029A4
		private void method_12(int int_13)
		{
			if (this.GEnum3_0 == GEnum3.const_1)
			{
				this.rectangle_1.Y = int_13;
				return;
			}
			this.rectangle_1.X = int_13;
		}

		// Token: 0x060003E2 RID: 994 RVA: 0x00010920 File Offset: 0x0000EB20
		private void method_13(bool bool_14)
		{
			int num = this.int_12;
			ScrollEventType scrollEventType_ = ScrollEventType.First;
			int num2;
			int num3;
			if (this.GEnum3_0 == GEnum3.const_1)
			{
				num2 = this.rectangle_1.Y;
				num3 = this.rectangle_1.Height;
			}
			else
			{
				num2 = this.rectangle_1.X;
				num3 = this.rectangle_1.Width;
			}
			if (this.bool_7 && num2 + num3 < this.int_6)
			{
				scrollEventType_ = ScrollEventType.LargeIncrement;
				this.int_12 = this.method_7(false, false);
				if (this.int_12 == this.int_9)
				{
					this.method_12(this.int_3);
					scrollEventType_ = ScrollEventType.Last;
				}
				else
				{
					this.method_12(Math.Min(this.int_3, this.method_8()));
				}
			}
			else if (this.bool_6 && num2 > this.int_6)
			{
				scrollEventType_ = ScrollEventType.LargeDecrement;
				this.int_12 = this.method_7(false, true);
				if (this.int_12 == this.int_8)
				{
					this.method_12(this.int_4);
					scrollEventType_ = ScrollEventType.First;
				}
				else
				{
					this.method_12(Math.Max(this.int_4, this.method_8()));
				}
			}
			if (num != this.int_12)
			{
				this.method_0(scrollEventType_, num, this.int_12, this.scrollOrientation_0);
				base.Invalidate();
				if (bool_14)
				{
					this.method_10();
				}
			}
		}

		// Token: 0x04000151 RID: 337
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x04000152 RID: 338
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x04000153 RID: 339
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x04000154 RID: 340
		private GEnum10 genum10_0;

		// Token: 0x04000155 RID: 341
		private GEnum29 genum29_0;

		// Token: 0x04000156 RID: 342
		private GClass8 gclass8_0;

		// Token: 0x04000157 RID: 343
		private bool bool_0;

		// Token: 0x04000158 RID: 344
		private bool bool_1;

		// Token: 0x04000159 RID: 345
		private bool bool_2;

		// Token: 0x0400015A RID: 346
		private ScrollEventHandler scrollEventHandler_0;

		// Token: 0x0400015B RID: 347
		private bool bool_3 = true;

		// Token: 0x0400015C RID: 348
		private bool bool_4 = true;

		// Token: 0x0400015D RID: 349
		private bool bool_5;

		// Token: 0x0400015E RID: 350
		private Rectangle rectangle_0;

		// Token: 0x0400015F RID: 351
		private Rectangle rectangle_1;

		// Token: 0x04000160 RID: 352
		private bool bool_6;

		// Token: 0x04000161 RID: 353
		private bool bool_7;

		// Token: 0x04000162 RID: 354
		private bool bool_8;

		// Token: 0x04000163 RID: 355
		private int int_0 = 6;

		// Token: 0x04000164 RID: 356
		private int int_1;

		// Token: 0x04000165 RID: 357
		private int int_2;

		// Token: 0x04000166 RID: 358
		private int int_3;

		// Token: 0x04000167 RID: 359
		private int int_4;

		// Token: 0x04000168 RID: 360
		private int int_5;

		// Token: 0x04000169 RID: 361
		private int int_6;

		// Token: 0x0400016A RID: 362
		private readonly System.Windows.Forms.Timer timer_0 = new System.Windows.Forms.Timer();

		// Token: 0x0400016B RID: 363
		private int int_7 = 10;

		// Token: 0x0400016C RID: 364
		private bool bool_9;

		// Token: 0x0400016D RID: 365
		private bool bool_10;

		// Token: 0x0400016E RID: 366
		private bool bool_11;

		// Token: 0x0400016F RID: 367
		private bool bool_12;

		// Token: 0x04000170 RID: 368
		private GEnum3 genum3_0 = GEnum3.const_1;

		// Token: 0x04000171 RID: 369
		private ScrollOrientation scrollOrientation_0 = ScrollOrientation.VerticalScroll;

		// Token: 0x04000172 RID: 370
		private int int_8;

		// Token: 0x04000173 RID: 371
		private int int_9 = 100;

		// Token: 0x04000174 RID: 372
		private int int_10 = 1;

		// Token: 0x04000175 RID: 373
		private int int_11 = 10;

		// Token: 0x04000176 RID: 374
		private int int_12;

		// Token: 0x04000177 RID: 375
		private bool bool_13;

		// Token: 0x04000178 RID: 376
		private System.Windows.Forms.Timer timer_1;
	}
}
