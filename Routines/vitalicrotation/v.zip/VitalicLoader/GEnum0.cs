﻿using System;

namespace ns0
{
	// Token: 0x02000018 RID: 24
	public enum GEnum0
	{
		// Token: 0x0400003A RID: 58
		const_0,
		// Token: 0x0400003B RID: 59
		const_1,
		// Token: 0x0400003C RID: 60
		const_2,
		// Token: 0x0400003D RID: 61
		const_3,
		// Token: 0x0400003E RID: 62
		const_4,
		// Token: 0x0400003F RID: 63
		const_5,
		// Token: 0x04000040 RID: 64
		const_6,
		// Token: 0x04000041 RID: 65
		const_7,
		// Token: 0x04000042 RID: 66
		const_8,
		// Token: 0x04000043 RID: 67
		const_9,
		// Token: 0x04000044 RID: 68
		const_10
	}
}
