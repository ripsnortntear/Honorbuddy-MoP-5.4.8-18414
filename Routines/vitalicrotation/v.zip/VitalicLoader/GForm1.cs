﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200008A RID: 138
	public sealed partial class GForm1 : MetroForm
	{
		// Token: 0x060007E3 RID: 2019 RVA: 0x00007133 File Offset: 0x00005333
		public GForm1()
		{
			this.gclass17_0 = new GClass17();
			base.Controls.Add(this.gclass17_0);
		}

		// Token: 0x060007E4 RID: 2020 RVA: 0x0001D094 File Offset: 0x0001B294
		public GForm1(int int_7, Control control_0) : this()
		{
			this.gclass17_0.Controls.Add(control_0);
			control_0.Dock = DockStyle.Fill;
			this.int_4 = int_7 * 500;
			if (this.int_4 > 0)
			{
				this.class1_0 = Class1.smethod_2(new Class1.Delegate0(this.method_16), 5);
			}
		}

		// Token: 0x060007E5 RID: 2021 RVA: 0x0001D0F0 File Offset: 0x0001B2F0
		public static void smethod_2(IWin32Window iwin32Window_0, string string_0, Control control_0, int int_7)
		{
			if (GForm1.gform1_0 != null)
			{
				GForm1.gform1_0.Close();
				GForm1.gform1_0.Dispose();
				GForm1.gform1_0 = null;
			}
			GForm1.gform1_0 = new GForm1(int_7, control_0);
			GForm1.gform1_0.Text = string_0;
			GForm1.gform1_0.Boolean_2 = false;
			GForm1.gform1_0.Boolean_0 = true;
			GForm1.gform1_0.StartPosition = FormStartPosition.Manual;
			if (iwin32Window_0 != null && iwin32Window_0 is GInterface1)
			{
				GForm1.gform1_0.GEnum29_0 = ((GInterface1)iwin32Window_0).GEnum29_0;
				GForm1.gform1_0.GEnum10_0 = ((GInterface1)iwin32Window_0).GEnum10_0;
				GForm1.gform1_0.GClass8_0 = (((GInterface1)iwin32Window_0).GClass8_0.method_0(GForm1.gform1_0) as GClass8);
			}
			GForm1.gform1_0.Show();
		}

		// Token: 0x060007E6 RID: 2022 RVA: 0x00007157 File Offset: 0x00005357
		public static bool smethod_3()
		{
			return GForm1.gform1_0 != null && GForm1.gform1_0.Visible;
		}

		// Token: 0x060007E7 RID: 2023 RVA: 0x0000716C File Offset: 0x0000536C
		public static void smethod_4(IWin32Window iwin32Window_0, string string_0, Control control_0)
		{
			GForm1.smethod_2(iwin32Window_0, string_0, control_0, 0);
		}

		// Token: 0x060007E8 RID: 2024 RVA: 0x00007177 File Offset: 0x00005377
		public static void smethod_5(string string_0, Control control_0, int int_7)
		{
			GForm1.smethod_2(null, string_0, control_0, int_7);
		}

		// Token: 0x060007E9 RID: 2025 RVA: 0x00007182 File Offset: 0x00005382
		public static void smethod_6(string string_0, Control control_0)
		{
			GForm1.smethod_4(null, string_0, control_0);
		}

		// Token: 0x060007EA RID: 2026 RVA: 0x0000718C File Offset: 0x0000538C
		public static void smethod_7()
		{
			if (GForm1.gform1_0 != null)
			{
				GForm1.gform1_0.Boolean_3 = true;
			}
		}

		// Token: 0x060007EB RID: 2027 RVA: 0x000071A0 File Offset: 0x000053A0
		public static void smethod_8()
		{
			if (GForm1.gform1_0 != null)
			{
				GForm1.smethod_7();
				GForm1.gform1_0.Close();
				GForm1.gform1_0.Dispose();
				GForm1.gform1_0 = null;
			}
		}

		// Token: 0x17000227 RID: 551
		// (get) Token: 0x060007EC RID: 2028 RVA: 0x000071C8 File Offset: 0x000053C8
		// (set) Token: 0x060007ED RID: 2029 RVA: 0x000071D0 File Offset: 0x000053D0
		public bool Boolean_3
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x060007EE RID: 2030 RVA: 0x0001D1BC File Offset: 0x0001B3BC
		protected override void OnActivated(EventArgs e)
		{
			if (!this.bool_4)
			{
				this.gclass17_0.GEnum29_0 = base.GEnum29_0;
				this.gclass17_0.GEnum10_0 = base.GEnum10_0;
				this.gclass17_0.GClass8_0 = base.GClass8_0;
				base.MaximizeBox = false;
				base.MinimizeBox = false;
				base.Boolean_0 = true;
				base.TopMost = true;
				base.Size = new Size(400, 200);
				Class28 @class = new Class28();
				switch (@class.GEnum30_0)
				{
				default:
					base.Location = new Point(Screen.PrimaryScreen.Bounds.Width - base.Width - 5, Screen.PrimaryScreen.Bounds.Height - base.Height - 5);
					break;
				case GEnum30.const_1:
					base.Location = new Point(@class.Rectangle_0.Width + 5, @class.Rectangle_0.Height - base.Height - 5);
					break;
				case GEnum30.const_2:
					base.Location = new Point(@class.Rectangle_0.Width - base.Width - 5, @class.Rectangle_0.Height + 5);
					break;
				case GEnum30.const_3:
					base.Location = new Point(@class.Rectangle_0.X - base.Width - 5, @class.Rectangle_0.Height - base.Height - 5);
					break;
				case GEnum30.const_4:
					base.Location = new Point(@class.Rectangle_0.Width - base.Width - 5, @class.Rectangle_0.Y - base.Height - 5);
					break;
				}
				this.gclass17_0.Location = new Point(0, 60);
				this.gclass17_0.Size = new Size(base.Width - 40, base.Height - 80);
				this.gclass17_0.Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right);
				this.gclass17_0.Boolean_7 = false;
				this.gclass17_0.Boolean_0 = false;
				this.gclass17_0.Boolean_4 = false;
				this.gclass17_0.Refresh();
				if (base.GClass8_0 != null)
				{
					base.GClass8_0.method_1();
				}
				this.bool_4 = true;
				GClass6 gclass = new GClass6();
				gclass.method_6(this.gclass17_0, new Point(20, 60), GEnum0.const_6, 15);
			}
			base.OnActivated(e);
		}

		// Token: 0x060007EF RID: 2031 RVA: 0x0001D440 File Offset: 0x0001B640
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			using (SolidBrush solidBrush = new SolidBrush(GClass39.GClass46.smethod_0(base.GEnum29_0)))
			{
				e.Graphics.FillRectangle(solidBrush, new Rectangle(base.Width - this.int_6, 0, this.int_6, 5));
			}
		}

		// Token: 0x060007F0 RID: 2032 RVA: 0x0001D4A8 File Offset: 0x0001B6A8
		private void method_16()
		{
			if (this.int_5 == this.int_4)
			{
				this.class1_0.Dispose();
				this.class1_0 = null;
				base.Close();
				return;
			}
			this.int_5 += 5;
			if (this.bool_3)
			{
				this.int_5 = 0;
			}
			double num = (double)this.int_5 / ((double)this.int_4 / 100.0);
			this.int_6 = (int)((double)base.Width * (num / 100.0));
			base.Invalidate(new Rectangle(0, 0, base.Width, 5));
			if (!this.bool_3)
			{
				this.class1_0.method_7();
			}
		}

		// Token: 0x04000423 RID: 1059
		private static GForm1 gform1_0;

		// Token: 0x04000424 RID: 1060
		private bool bool_3;

		// Token: 0x04000425 RID: 1061
		private readonly int int_4;

		// Token: 0x04000426 RID: 1062
		private int int_5;

		// Token: 0x04000427 RID: 1063
		private int int_6;

		// Token: 0x04000428 RID: 1064
		private Class1 class1_0;

		// Token: 0x04000429 RID: 1065
		private readonly GClass17 gclass17_0;

		// Token: 0x0400042A RID: 1066
		private bool bool_4;
	}
}
