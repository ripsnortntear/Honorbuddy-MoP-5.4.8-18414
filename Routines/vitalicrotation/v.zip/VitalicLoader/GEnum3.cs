﻿using System;

namespace ns0
{
	// Token: 0x0200003F RID: 63
	public enum GEnum3
	{
		// Token: 0x0400014F RID: 335
		const_0,
		// Token: 0x04000150 RID: 336
		const_1
	}
}
