﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200003C RID: 60
	[ToolboxBitmap(typeof(ProgressBar))]
	[Designer("MetroFramework.Design.Controls.MetroProgressBarDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	public class GClass18 : ProgressBar, GInterface2
	{
		// Token: 0x06000300 RID: 768 RVA: 0x00003DFD File Offset: 0x00001FFD
		public GClass18()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x1400001E RID: 30
		// (add) Token: 0x06000301 RID: 769 RVA: 0x0000E4F8 File Offset: 0x0000C6F8
		// (remove) Token: 0x06000302 RID: 770 RVA: 0x0000E530 File Offset: 0x0000C730
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000303 RID: 771 RVA: 0x00003E35 File Offset: 0x00002035
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x1400001F RID: 31
		// (add) Token: 0x06000304 RID: 772 RVA: 0x0000E568 File Offset: 0x0000C768
		// (remove) Token: 0x06000305 RID: 773 RVA: 0x0000E5A0 File Offset: 0x0000C7A0
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000306 RID: 774 RVA: 0x00003E55 File Offset: 0x00002055
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000020 RID: 32
		// (add) Token: 0x06000307 RID: 775 RVA: 0x0000E5D8 File Offset: 0x0000C7D8
		// (remove) Token: 0x06000308 RID: 776 RVA: 0x0000E610 File Offset: 0x0000C810
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000309 RID: 777 RVA: 0x00003E75 File Offset: 0x00002075
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x0600030A RID: 778 RVA: 0x0000E648 File Offset: 0x0000C848
		// (set) Token: 0x0600030B RID: 779 RVA: 0x00003E95 File Offset: 0x00002095
		[Category("Metro Appearance")]
		[DefaultValue(GEnum10.const_0)]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x0600030C RID: 780 RVA: 0x0000E6A0 File Offset: 0x0000C8A0
		// (set) Token: 0x0600030D RID: 781 RVA: 0x00003E9E File Offset: 0x0000209E
		[DefaultValue(GEnum29.const_0)]
		[Category("Metro Appearance")]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x0600030E RID: 782 RVA: 0x00003EA7 File Offset: 0x000020A7
		// (set) Token: 0x0600030F RID: 783 RVA: 0x00003EAF File Offset: 0x000020AF
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x06000310 RID: 784 RVA: 0x00003EB8 File Offset: 0x000020B8
		// (set) Token: 0x06000311 RID: 785 RVA: 0x00003EC0 File Offset: 0x000020C0
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000312 RID: 786 RVA: 0x00003EC9 File Offset: 0x000020C9
		// (set) Token: 0x06000313 RID: 787 RVA: 0x00003ED1 File Offset: 0x000020D1
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000314 RID: 788 RVA: 0x00003EDA File Offset: 0x000020DA
		// (set) Token: 0x06000315 RID: 789 RVA: 0x00003EE2 File Offset: 0x000020E2
		[DefaultValue(true)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x170000B1 RID: 177
		// (get) Token: 0x06000316 RID: 790 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x06000317 RID: 791 RVA: 0x00002923 File Offset: 0x00000B23
		[Browsable(false)]
		[Category("Metro Behaviour")]
		[DefaultValue(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x170000B2 RID: 178
		// (get) Token: 0x06000318 RID: 792 RVA: 0x00003EEB File Offset: 0x000020EB
		// (set) Token: 0x06000319 RID: 793 RVA: 0x00003EF3 File Offset: 0x000020F3
		[DefaultValue(GEnum21.const_1)]
		[Category("Metro Appearance")]
		public GEnum21 GEnum21_0
		{
			get
			{
				return this.genum21_0;
			}
			set
			{
				this.genum21_0 = value;
			}
		}

		// Token: 0x170000B3 RID: 179
		// (get) Token: 0x0600031A RID: 794 RVA: 0x00003EFC File Offset: 0x000020FC
		// (set) Token: 0x0600031B RID: 795 RVA: 0x00003F04 File Offset: 0x00002104
		[Category("Metro Appearance")]
		[DefaultValue(GEnum22.const_0)]
		public GEnum22 GEnum22_0
		{
			get
			{
				return this.genum22_0;
			}
			set
			{
				this.genum22_0 = value;
			}
		}

		// Token: 0x170000B4 RID: 180
		// (get) Token: 0x0600031C RID: 796 RVA: 0x00003F0D File Offset: 0x0000210D
		// (set) Token: 0x0600031D RID: 797 RVA: 0x00003F15 File Offset: 0x00002115
		[Category("Metro Appearance")]
		[DefaultValue(ContentAlignment.MiddleRight)]
		public ContentAlignment ContentAlignment_0
		{
			get
			{
				return this.contentAlignment_0;
			}
			set
			{
				this.contentAlignment_0 = value;
			}
		}

		// Token: 0x170000B5 RID: 181
		// (get) Token: 0x0600031E RID: 798 RVA: 0x00003F1E File Offset: 0x0000211E
		// (set) Token: 0x0600031F RID: 799 RVA: 0x00003F26 File Offset: 0x00002126
		[Category("Metro Appearance")]
		[DefaultValue(true)]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x170000B6 RID: 182
		// (get) Token: 0x06000320 RID: 800 RVA: 0x00003F2F File Offset: 0x0000212F
		// (set) Token: 0x06000321 RID: 801 RVA: 0x00003F37 File Offset: 0x00002137
		[DefaultValue(ProgressBarStyle.Continuous)]
		[Category("Metro Appearance")]
		public ProgressBarStyle ProgressBarStyle_0
		{
			get
			{
				return this.progressBarStyle_0;
			}
			set
			{
				this.progressBarStyle_0 = value;
			}
		}

		// Token: 0x170000B7 RID: 183
		// (get) Token: 0x06000322 RID: 802 RVA: 0x00003F40 File Offset: 0x00002140
		// (set) Token: 0x06000323 RID: 803 RVA: 0x00003F48 File Offset: 0x00002148
		public int Int32_0
		{
			get
			{
				return base.Value;
			}
			set
			{
				if (value > base.Maximum)
				{
					return;
				}
				base.Value = value;
				base.Invalidate();
			}
		}

		// Token: 0x170000B8 RID: 184
		// (get) Token: 0x06000324 RID: 804 RVA: 0x00003F61 File Offset: 0x00002161
		[Browsable(false)]
		public double Double_0
		{
			get
			{
				return (1.0 - (double)(base.Maximum - this.Int32_0) / (double)base.Maximum) * 100.0;
			}
		}

		// Token: 0x170000B9 RID: 185
		// (get) Token: 0x06000325 RID: 805 RVA: 0x00003F8D File Offset: 0x0000218D
		[Browsable(false)]
		public double Double_1
		{
			get
			{
				return 1.0 - (double)(base.Maximum - this.Int32_0) / (double)base.Maximum;
			}
		}

		// Token: 0x170000BA RID: 186
		// (get) Token: 0x06000326 RID: 806 RVA: 0x00003FAF File Offset: 0x000021AF
		[Browsable(false)]
		public string String_0
		{
			get
			{
				return string.Format("{0}%", Math.Round(this.Double_0));
			}
		}

		// Token: 0x170000BB RID: 187
		// (get) Token: 0x06000327 RID: 807 RVA: 0x0000E6F8 File Offset: 0x0000C8F8
		private double Double_2
		{
			get
			{
				return (double)this.Int32_0 / (double)base.Maximum * (double)base.ClientRectangle.Width;
			}
		}

		// Token: 0x170000BC RID: 188
		// (get) Token: 0x06000328 RID: 808 RVA: 0x0000E724 File Offset: 0x0000C924
		private int Int32_1
		{
			get
			{
				return base.ClientRectangle.Width / 3;
			}
		}

		// Token: 0x06000329 RID: 809 RVA: 0x0000E744 File Offset: 0x0000C944
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					if (!base.Enabled)
					{
						color = GClass39.GClass46.GClass54.GClass55.smethod_3(this.GEnum29_0);
					}
					else
					{
						color = GClass39.GClass46.GClass54.GClass55.smethod_0(this.GEnum29_0);
					}
				}
				if (color.A == 255)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600032A RID: 810 RVA: 0x0000E7D8 File Offset: 0x0000C9D8
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600032B RID: 811 RVA: 0x0000E838 File Offset: 0x0000CA38
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			if (this.progressBarStyle_0 == ProgressBarStyle.Continuous)
			{
				if (!base.DesignMode)
				{
					this.method_4();
				}
				this.method_0(paintEventArgs_0.Graphics);
			}
			else if (this.progressBarStyle_0 == ProgressBarStyle.Blocks)
			{
				if (!base.DesignMode)
				{
					this.method_4();
				}
				this.method_0(paintEventArgs_0.Graphics);
			}
			else if (this.progressBarStyle_0 == ProgressBarStyle.Marquee)
			{
				if (!base.DesignMode && base.Enabled)
				{
					this.method_3();
				}
				if (!base.Enabled)
				{
					this.method_4();
				}
				if (this.Int32_0 == base.Maximum)
				{
					this.method_4();
					this.method_0(paintEventArgs_0.Graphics);
				}
				else
				{
					this.method_1(paintEventArgs_0.Graphics);
				}
			}
			this.method_2(paintEventArgs_0.Graphics);
			using (Pen pen = new Pen(GClass39.GClass40.GClass44.smethod_0(this.GEnum29_0)))
			{
				Rectangle rect = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
				paintEventArgs_0.Graphics.DrawRectangle(pen, rect);
			}
			this.vmethod_2(new GEventArgs3(Color.Empty, Color.Empty, paintEventArgs_0.Graphics));
		}

		// Token: 0x0600032C RID: 812 RVA: 0x0000E964 File Offset: 0x0000CB64
		private void method_0(Graphics graphics_0)
		{
			graphics_0.FillRectangle(GClass39.smethod_1(this.GEnum10_0), 0, 0, (int)this.Double_2, base.ClientRectangle.Height);
		}

		// Token: 0x0600032D RID: 813 RVA: 0x0000E99C File Offset: 0x0000CB9C
		private void method_1(Graphics graphics_0)
		{
			graphics_0.FillRectangle(GClass39.smethod_1(this.GEnum10_0), this.int_0, 0, this.Int32_1, base.ClientRectangle.Height);
		}

		// Token: 0x0600032E RID: 814 RVA: 0x0000E9D8 File Offset: 0x0000CBD8
		private void method_2(Graphics graphics_0)
		{
			if (this.Boolean_0)
			{
				return;
			}
			Color foreColor;
			if (!base.Enabled)
			{
				foreColor = GClass39.GClass56.GClass63.smethod_1(this.GEnum29_0);
			}
			else
			{
				foreColor = GClass39.GClass56.GClass63.smethod_0(this.GEnum29_0);
			}
			TextRenderer.DrawText(graphics_0, this.String_0, GClass67.smethod_9(this.genum21_0, this.genum22_0), base.ClientRectangle, foreColor, GClass39.smethod_4(this.ContentAlignment_0));
		}

		// Token: 0x0600032F RID: 815 RVA: 0x0000EA40 File Offset: 0x0000CC40
		public override Size GetPreferredSize(Size proposedSize)
		{
			base.GetPreferredSize(proposedSize);
			Size result;
			using (Graphics graphics = base.CreateGraphics())
			{
				proposedSize = new Size(int.MaxValue, int.MaxValue);
				result = TextRenderer.MeasureText(graphics, this.String_0, GClass67.smethod_9(this.genum21_0, this.genum22_0), proposedSize, GClass39.smethod_4(this.ContentAlignment_0));
			}
			return result;
		}

		// Token: 0x06000330 RID: 816 RVA: 0x0000EAB8 File Offset: 0x0000CCB8
		private void method_3()
		{
			if (this.bool_4)
			{
				return;
			}
			if (this.timer_0 == null)
			{
				this.timer_0 = new System.Windows.Forms.Timer();
				this.timer_0.Interval = 10;
				this.timer_0.Tick += this.timer_0_Tick;
			}
			this.int_0 = -this.Int32_1;
			this.timer_0.Stop();
			this.timer_0.Start();
			this.bool_4 = true;
			base.Invalidate();
		}

		// Token: 0x06000331 RID: 817 RVA: 0x00003FCB File Offset: 0x000021CB
		private void method_4()
		{
			if (this.timer_0 == null)
			{
				return;
			}
			this.timer_0.Stop();
			base.Invalidate();
		}

		// Token: 0x06000332 RID: 818 RVA: 0x0000EB38 File Offset: 0x0000CD38
		private void timer_0_Tick(object sender, EventArgs e)
		{
			this.int_0++;
			if (this.int_0 > base.ClientRectangle.Width)
			{
				this.int_0 = -this.Int32_1;
			}
			base.Invalidate();
		}

		// Token: 0x0400011C RID: 284
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x0400011D RID: 285
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x0400011E RID: 286
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x0400011F RID: 287
		private GEnum10 genum10_0;

		// Token: 0x04000120 RID: 288
		private GEnum29 genum29_0;

		// Token: 0x04000121 RID: 289
		private GClass8 gclass8_0;

		// Token: 0x04000122 RID: 290
		private bool bool_0;

		// Token: 0x04000123 RID: 291
		private bool bool_1;

		// Token: 0x04000124 RID: 292
		private bool bool_2 = true;

		// Token: 0x04000125 RID: 293
		private GEnum21 genum21_0 = GEnum21.const_1;

		// Token: 0x04000126 RID: 294
		private GEnum22 genum22_0;

		// Token: 0x04000127 RID: 295
		private ContentAlignment contentAlignment_0 = ContentAlignment.MiddleRight;

		// Token: 0x04000128 RID: 296
		private bool bool_3 = true;

		// Token: 0x04000129 RID: 297
		private ProgressBarStyle progressBarStyle_0 = ProgressBarStyle.Continuous;

		// Token: 0x0400012A RID: 298
		private int int_0;

		// Token: 0x0400012B RID: 299
		private System.Windows.Forms.Timer timer_0;

		// Token: 0x0400012C RID: 300
		private bool bool_4;
	}
}
