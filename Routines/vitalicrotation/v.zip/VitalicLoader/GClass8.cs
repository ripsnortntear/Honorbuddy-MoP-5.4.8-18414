﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200001B RID: 27
	[Designer("MetroFramework.Design.Components.MetroStyleManagerDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	public sealed class GClass8 : Component, ICloneable, ISupportInitialize
	{
		// Token: 0x060000A0 RID: 160 RVA: 0x00002501 File Offset: 0x00000701
		public GClass8()
		{
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x00002517 File Offset: 0x00000717
		public GClass8(IContainer icontainer_1) : this()
		{
			if (icontainer_1 != null)
			{
				this.icontainer_0 = icontainer_1;
				this.icontainer_0.Add(this);
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x060000A2 RID: 162 RVA: 0x00002535 File Offset: 0x00000735
		// (set) Token: 0x060000A3 RID: 163 RVA: 0x0000253D File Offset: 0x0000073D
		[Category("Metro Appearance")]
		[DefaultValue(GEnum10.const_3)]
		public GEnum10 GEnum10_0
		{
			get
			{
				return this.genum10_0;
			}
			set
			{
				if (value == GEnum10.const_0)
				{
					value = GEnum10.const_3;
				}
				this.genum10_0 = value;
				if (!this.bool_0)
				{
					this.method_1();
				}
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x060000A4 RID: 164 RVA: 0x0000255C File Offset: 0x0000075C
		// (set) Token: 0x060000A5 RID: 165 RVA: 0x00002564 File Offset: 0x00000764
		[DefaultValue(GEnum29.const_1)]
		[Category("Metro Appearance")]
		public GEnum29 GEnum29_0
		{
			get
			{
				return this.genum29_0;
			}
			set
			{
				if (value == GEnum29.const_0)
				{
					value = GEnum29.const_1;
				}
				this.genum29_0 = value;
				if (!this.bool_0)
				{
					this.method_1();
				}
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x060000A6 RID: 166 RVA: 0x00002583 File Offset: 0x00000783
		// (set) Token: 0x060000A7 RID: 167 RVA: 0x00008FD8 File Offset: 0x000071D8
		public ContainerControl ContainerControl_0
		{
			get
			{
				return this.containerControl_0;
			}
			set
			{
				if (this.containerControl_0 != null)
				{
					this.containerControl_0.ControlAdded -= this.containerControl_0_ControlAdded;
				}
				this.containerControl_0 = value;
				if (value != null)
				{
					this.containerControl_0.ControlAdded += this.containerControl_0_ControlAdded;
					if (!this.bool_0)
					{
						this.method_2(value);
					}
				}
			}
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x00009034 File Offset: 0x00007234
		public object Clone()
		{
			return new GClass8
			{
				genum29_0 = this.GEnum29_0,
				genum10_0 = this.GEnum10_0
			};
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x00009060 File Offset: 0x00007260
		public object method_0(ContainerControl containerControl_1)
		{
			GClass8 gclass = this.Clone() as GClass8;
			if (containerControl_1 is GInterface1)
			{
				gclass.ContainerControl_0 = containerControl_1;
			}
			return gclass;
		}

		// Token: 0x060000AA RID: 170 RVA: 0x0000258B File Offset: 0x0000078B
		void ISupportInitialize.BeginInit()
		{
			this.bool_0 = true;
		}

		// Token: 0x060000AB RID: 171 RVA: 0x00002594 File Offset: 0x00000794
		void ISupportInitialize.EndInit()
		{
			this.bool_0 = false;
			this.method_1();
		}

		// Token: 0x060000AC RID: 172 RVA: 0x000025A3 File Offset: 0x000007A3
		private void containerControl_0_ControlAdded(object sender, ControlEventArgs e)
		{
			if (!this.bool_0)
			{
				this.method_2(e.Control);
			}
		}

		// Token: 0x060000AD RID: 173 RVA: 0x0000908C File Offset: 0x0000728C
		public void method_1()
		{
			if (this.containerControl_0 != null)
			{
				this.method_2(this.containerControl_0);
			}
			if (this.icontainer_0 != null && this.icontainer_0.Components != null)
			{
				foreach (object obj in this.icontainer_0.Components)
				{
					if (obj is GInterface0)
					{
						this.method_4((GInterface0)obj);
					}
				}
				return;
			}
		}

		// Token: 0x060000AE RID: 174 RVA: 0x00009120 File Offset: 0x00007320
		private void method_2(Control control_0)
		{
			if (control_0 == null)
			{
				return;
			}
			GInterface2 ginterface = control_0 as GInterface2;
			if (ginterface != null)
			{
				this.method_3(ginterface);
			}
			GInterface0 ginterface2 = control_0 as GInterface0;
			if (ginterface2 != null)
			{
				this.method_4(ginterface2);
			}
			TabControl tabControl = control_0 as TabControl;
			if (tabControl != null)
			{
				foreach (object obj in ((TabControl)control_0).TabPages)
				{
					TabPage control_ = (TabPage)obj;
					this.method_2(control_);
				}
			}
			if (control_0.Controls != null)
			{
				foreach (object obj2 in control_0.Controls)
				{
					Control control_2 = (Control)obj2;
					this.method_2(control_2);
				}
			}
			if (control_0.ContextMenuStrip != null)
			{
				this.method_2(control_0.ContextMenuStrip);
			}
			control_0.Refresh();
		}

		// Token: 0x060000AF RID: 175 RVA: 0x000025B9 File Offset: 0x000007B9
		private void method_3(GInterface2 ginterface2_0)
		{
			ginterface2_0.GClass8_0 = this;
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x000025C2 File Offset: 0x000007C2
		private void method_4(GInterface0 ginterface0_0)
		{
			ginterface0_0.GClass8_0 = this;
		}

		// Token: 0x04000048 RID: 72
		private readonly IContainer icontainer_0;

		// Token: 0x04000049 RID: 73
		private GEnum10 genum10_0 = GEnum10.const_3;

		// Token: 0x0400004A RID: 74
		private GEnum29 genum29_0 = GEnum29.const_1;

		// Token: 0x0400004B RID: 75
		private ContainerControl containerControl_0;

		// Token: 0x0400004C RID: 76
		private bool bool_0;
	}
}
