﻿using System;

namespace ns0
{
	// Token: 0x02000096 RID: 150
	public enum GEnum14
	{
		// Token: 0x0400045D RID: 1117
		const_0,
		// Token: 0x0400045E RID: 1118
		const_1,
		// Token: 0x0400045F RID: 1119
		const_2
	}
}
