﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Text.RegularExpressions;

namespace ns0
{
	// Token: 0x0200004B RID: 75
	[CLSCompliant(false)]
	public class GClass23
	{
		// Token: 0x0600059B RID: 1435 RVA: 0x0001412C File Offset: 0x0001232C
		static GClass23()
		{
			PropertyInfo[] properties = typeof(GClass23).GetProperties();
			for (int i = 0; i < properties.Length; i++)
			{
				GAttribute0 gattribute = Attribute.GetCustomAttribute(properties[i], typeof(GAttribute0)) as GAttribute0;
				if (gattribute != null)
				{
					GClass23.dictionary_0.Add(gattribute.Name, properties[i]);
					GClass23.dictionary_1.Add(gattribute.Name, GClass23.smethod_0(properties[i]));
					GClass23.list_1.Add(properties[i]);
					GAttribute1 gattribute2 = Attribute.GetCustomAttribute(properties[i], typeof(GAttribute1)) as GAttribute1;
					if (gattribute2 != null)
					{
						GClass23.list_0.Add(properties[i]);
					}
				}
			}
			GClass23.gclass23_0 = new GClass23();
		}

		// Token: 0x0600059C RID: 1436 RVA: 0x00014224 File Offset: 0x00012424
		protected GClass23()
		{
			this.list_2 = new List<Class11>();
			this.list_3 = new List<GClass23>();
			this.list_4 = new List<Class15>();
			this.list_5 = new List<Class15>();
			this.dictionary_2 = new Dictionary<Class15, RectangleF>();
			foreach (string key in GClass23.dictionary_0.Keys)
			{
				GClass23.dictionary_0[key].SetValue(this, GClass23.dictionary_1[key], null);
			}
		}

		// Token: 0x0600059D RID: 1437 RVA: 0x00005AC1 File Offset: 0x00003CC1
		public GClass23(GClass23 gclass23_3) : this()
		{
			this.GClass23_2 = gclass23_3;
		}

		// Token: 0x0600059E RID: 1438 RVA: 0x00005AD0 File Offset: 0x00003CD0
		internal GClass23(GClass23 gclass23_3, GClass37 gclass37_1) : this(gclass23_3)
		{
			this.gclass37_0 = gclass37_1;
		}

		// Token: 0x0600059F RID: 1439 RVA: 0x00014424 File Offset: 0x00012624
		private static string smethod_0(PropertyInfo propertyInfo_0)
		{
			DefaultValueAttribute defaultValueAttribute = Attribute.GetCustomAttribute(propertyInfo_0, typeof(DefaultValueAttribute)) as DefaultValueAttribute;
			if (defaultValueAttribute == null)
			{
				return string.Empty;
			}
			string text = Convert.ToString(defaultValueAttribute.Value);
			if (!string.IsNullOrEmpty(text))
			{
				return text;
			}
			return string.Empty;
		}

		// Token: 0x1700015D RID: 349
		// (get) Token: 0x060005A0 RID: 1440 RVA: 0x00005AE0 File Offset: 0x00003CE0
		// (set) Token: 0x060005A1 RID: 1441 RVA: 0x00005AE8 File Offset: 0x00003CE8
		[GAttribute0("border-bottom-width")]
		[DefaultValue("medium")]
		public string String_0
		{
			get
			{
				return this.string_7;
			}
			set
			{
				this.string_7 = value;
			}
		}

		// Token: 0x1700015E RID: 350
		// (get) Token: 0x060005A2 RID: 1442 RVA: 0x00005AF1 File Offset: 0x00003CF1
		// (set) Token: 0x060005A3 RID: 1443 RVA: 0x00005AF9 File Offset: 0x00003CF9
		[GAttribute0("border-left-width")]
		[DefaultValue("medium")]
		public string String_1
		{
			get
			{
				return this.string_8;
			}
			set
			{
				this.string_8 = value;
			}
		}

		// Token: 0x1700015F RID: 351
		// (get) Token: 0x060005A4 RID: 1444 RVA: 0x00005B02 File Offset: 0x00003D02
		// (set) Token: 0x060005A5 RID: 1445 RVA: 0x00005B0A File Offset: 0x00003D0A
		[DefaultValue("medium")]
		[GAttribute0("border-right-width")]
		public string String_2
		{
			get
			{
				return this.string_6;
			}
			set
			{
				this.string_6 = value;
			}
		}

		// Token: 0x17000160 RID: 352
		// (get) Token: 0x060005A6 RID: 1446 RVA: 0x00005B13 File Offset: 0x00003D13
		// (set) Token: 0x060005A7 RID: 1447 RVA: 0x00005B1B File Offset: 0x00003D1B
		[DefaultValue("medium")]
		[GAttribute0("border-top-width")]
		public string String_3
		{
			get
			{
				return this.string_5;
			}
			set
			{
				this.string_5 = value;
			}
		}

		// Token: 0x17000161 RID: 353
		// (get) Token: 0x060005A8 RID: 1448 RVA: 0x00005B24 File Offset: 0x00003D24
		// (set) Token: 0x060005A9 RID: 1449 RVA: 0x0001446C File Offset: 0x0001266C
		[GAttribute0("border-width")]
		[DefaultValue("")]
		public string String_4
		{
			get
			{
				return this.string_9;
			}
			set
			{
				this.string_9 = value;
				string[] array = GClass34.smethod_5(value);
				switch (array.Length)
				{
				case 1:
					this.String_3 = (this.String_1 = (this.String_2 = (this.String_0 = array[0])));
					return;
				case 2:
					this.String_3 = (this.String_0 = array[0]);
					this.String_1 = (this.String_2 = array[1]);
					return;
				case 3:
					this.String_3 = array[0];
					this.String_1 = (this.String_2 = array[1]);
					this.String_0 = array[2];
					return;
				case 4:
					this.String_3 = array[0];
					this.String_2 = array[1];
					this.String_0 = array[2];
					this.String_1 = array[3];
					return;
				default:
					return;
				}
			}
		}

		// Token: 0x17000162 RID: 354
		// (get) Token: 0x060005AA RID: 1450 RVA: 0x00005B2C File Offset: 0x00003D2C
		// (set) Token: 0x060005AB RID: 1451 RVA: 0x00005B34 File Offset: 0x00003D34
		[GAttribute0("border-bottom-style")]
		[DefaultValue("none")]
		public string String_5
		{
			get
			{
				return this.string_17;
			}
			set
			{
				this.string_17 = value;
			}
		}

		// Token: 0x17000163 RID: 355
		// (get) Token: 0x060005AC RID: 1452 RVA: 0x00005B3D File Offset: 0x00003D3D
		// (set) Token: 0x060005AD RID: 1453 RVA: 0x00005B45 File Offset: 0x00003D45
		[GAttribute0("border-left-style")]
		[DefaultValue("none")]
		public string String_6
		{
			get
			{
				return this.string_18;
			}
			set
			{
				this.string_18 = value;
			}
		}

		// Token: 0x17000164 RID: 356
		// (get) Token: 0x060005AE RID: 1454 RVA: 0x00005B4E File Offset: 0x00003D4E
		// (set) Token: 0x060005AF RID: 1455 RVA: 0x00005B56 File Offset: 0x00003D56
		[GAttribute0("border-right-style")]
		[DefaultValue("none")]
		public string String_7
		{
			get
			{
				return this.string_16;
			}
			set
			{
				this.string_16 = value;
			}
		}

		// Token: 0x17000165 RID: 357
		// (get) Token: 0x060005B0 RID: 1456 RVA: 0x00005B5F File Offset: 0x00003D5F
		// (set) Token: 0x060005B1 RID: 1457 RVA: 0x00014568 File Offset: 0x00012768
		[DefaultValue("")]
		[GAttribute0("border-style")]
		public string String_8
		{
			get
			{
				return this.string_19;
			}
			set
			{
				this.string_19 = value;
				string[] array = GClass34.smethod_5(value);
				switch (array.Length)
				{
				case 1:
					this.String_9 = (this.String_6 = (this.String_7 = (this.String_5 = array[0])));
					return;
				case 2:
					this.String_9 = (this.String_5 = array[0]);
					this.String_6 = (this.String_7 = array[1]);
					return;
				case 3:
					this.String_9 = array[0];
					this.String_6 = (this.String_7 = array[1]);
					this.String_5 = array[2];
					return;
				case 4:
					this.String_9 = array[0];
					this.String_7 = array[1];
					this.String_5 = array[2];
					this.String_6 = array[3];
					return;
				default:
					return;
				}
			}
		}

		// Token: 0x17000166 RID: 358
		// (get) Token: 0x060005B2 RID: 1458 RVA: 0x00005B67 File Offset: 0x00003D67
		// (set) Token: 0x060005B3 RID: 1459 RVA: 0x00005B6F File Offset: 0x00003D6F
		[GAttribute0("border-top-style")]
		[DefaultValue("none")]
		public string String_9
		{
			get
			{
				return this.string_15;
			}
			set
			{
				this.string_15 = value;
			}
		}

		// Token: 0x17000167 RID: 359
		// (get) Token: 0x060005B4 RID: 1460 RVA: 0x00005B78 File Offset: 0x00003D78
		// (set) Token: 0x060005B5 RID: 1461 RVA: 0x00014664 File Offset: 0x00012864
		[GAttribute0("border-color")]
		[DefaultValue("black")]
		public string String_10
		{
			get
			{
				return this.string_14;
			}
			set
			{
				this.string_14 = value;
				MatchCollection matchCollection = Class17.smethod_0("(#\\S{6}|#\\S{3}|rgb\\(\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\)|maroon|red|orange|yellow|olive|purple|fuchsia|white|lime|green|navy|blue|aqua|teal|black|silver|gray)", value);
				string[] array = new string[matchCollection.Count];
				for (int i = 0; i < array.Length; i++)
				{
					array[i] = matchCollection[i].Value;
				}
				switch (array.Length)
				{
				case 1:
					this.String_14 = (this.String_12 = (this.String_13 = (this.String_11 = array[0])));
					return;
				case 2:
					this.String_14 = (this.String_11 = array[0]);
					this.String_12 = (this.String_13 = array[1]);
					return;
				case 3:
					this.String_14 = array[0];
					this.String_12 = (this.String_13 = array[1]);
					this.String_11 = array[2];
					return;
				case 4:
					this.String_14 = array[0];
					this.String_13 = array[1];
					this.String_11 = array[2];
					this.String_12 = array[3];
					return;
				default:
					return;
				}
			}
		}

		// Token: 0x17000168 RID: 360
		// (get) Token: 0x060005B6 RID: 1462 RVA: 0x00005B80 File Offset: 0x00003D80
		// (set) Token: 0x060005B7 RID: 1463 RVA: 0x00005B88 File Offset: 0x00003D88
		[GAttribute0("border-bottom-color")]
		[DefaultValue("black")]
		public string String_11
		{
			get
			{
				return this.string_12;
			}
			set
			{
				this.string_12 = value;
			}
		}

		// Token: 0x17000169 RID: 361
		// (get) Token: 0x060005B8 RID: 1464 RVA: 0x00005B91 File Offset: 0x00003D91
		// (set) Token: 0x060005B9 RID: 1465 RVA: 0x00005B99 File Offset: 0x00003D99
		[DefaultValue("black")]
		[GAttribute0("border-left-color")]
		public string String_12
		{
			get
			{
				return this.string_13;
			}
			set
			{
				this.string_13 = value;
			}
		}

		// Token: 0x1700016A RID: 362
		// (get) Token: 0x060005BA RID: 1466 RVA: 0x00005BA2 File Offset: 0x00003DA2
		// (set) Token: 0x060005BB RID: 1467 RVA: 0x00005BAA File Offset: 0x00003DAA
		[GAttribute0("border-right-color")]
		[DefaultValue("black")]
		public string String_13
		{
			get
			{
				return this.string_11;
			}
			set
			{
				this.string_11 = value;
			}
		}

		// Token: 0x1700016B RID: 363
		// (get) Token: 0x060005BC RID: 1468 RVA: 0x00005BB3 File Offset: 0x00003DB3
		// (set) Token: 0x060005BD RID: 1469 RVA: 0x00005BBB File Offset: 0x00003DBB
		[GAttribute0("border-top-color")]
		[DefaultValue("black")]
		public string String_14
		{
			get
			{
				return this.string_10;
			}
			set
			{
				this.string_10 = value;
			}
		}

		// Token: 0x1700016C RID: 364
		// (get) Token: 0x060005BE RID: 1470 RVA: 0x00005BC4 File Offset: 0x00003DC4
		// (set) Token: 0x060005BF RID: 1471 RVA: 0x00014798 File Offset: 0x00012998
		[GAttribute0("border")]
		[DefaultValue("")]
		public string String_15
		{
			get
			{
				return this.string_26;
			}
			set
			{
				this.string_26 = value;
				string text = Class17.smethod_1("(([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|thin|medium|thick)", value);
				string text2 = Class17.smethod_1("(none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset)", value);
				string text3 = Class17.smethod_1("(#\\S{6}|#\\S{3}|rgb\\(\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\)|maroon|red|orange|yellow|olive|purple|fuchsia|white|lime|green|navy|blue|aqua|teal|black|silver|gray)", value);
				if (text != null)
				{
					this.String_4 = text;
				}
				if (text2 != null)
				{
					this.String_8 = text2;
				}
				if (text3 != null)
				{
					this.String_10 = text3;
				}
			}
		}

		// Token: 0x1700016D RID: 365
		// (get) Token: 0x060005C0 RID: 1472 RVA: 0x00005BCC File Offset: 0x00003DCC
		// (set) Token: 0x060005C1 RID: 1473 RVA: 0x000147F0 File Offset: 0x000129F0
		[DefaultValue("")]
		[GAttribute0("border-bottom")]
		public string String_16
		{
			get
			{
				return this.string_20;
			}
			set
			{
				this.string_20 = value;
				string text = Class17.smethod_1("(([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|thin|medium|thick)", value);
				string text2 = Class17.smethod_1("(none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset)", value);
				string text3 = Class17.smethod_1("(#\\S{6}|#\\S{3}|rgb\\(\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\)|maroon|red|orange|yellow|olive|purple|fuchsia|white|lime|green|navy|blue|aqua|teal|black|silver|gray)", value);
				if (text != null)
				{
					this.String_0 = text;
				}
				if (text2 != null)
				{
					this.String_5 = text2;
				}
				if (text3 != null)
				{
					this.String_11 = text3;
				}
			}
		}

		// Token: 0x1700016E RID: 366
		// (get) Token: 0x060005C2 RID: 1474 RVA: 0x00005BD4 File Offset: 0x00003DD4
		// (set) Token: 0x060005C3 RID: 1475 RVA: 0x00014848 File Offset: 0x00012A48
		[GAttribute0("border-left")]
		[DefaultValue("")]
		public string String_17
		{
			get
			{
				return this.string_21;
			}
			set
			{
				this.string_21 = value;
				string text = Class17.smethod_1("(([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|thin|medium|thick)", value);
				string text2 = Class17.smethod_1("(none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset)", value);
				string text3 = Class17.smethod_1("(#\\S{6}|#\\S{3}|rgb\\(\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\)|maroon|red|orange|yellow|olive|purple|fuchsia|white|lime|green|navy|blue|aqua|teal|black|silver|gray)", value);
				if (text != null)
				{
					this.String_1 = text;
				}
				if (text2 != null)
				{
					this.String_6 = text2;
				}
				if (text3 != null)
				{
					this.String_12 = text3;
				}
			}
		}

		// Token: 0x1700016F RID: 367
		// (get) Token: 0x060005C4 RID: 1476 RVA: 0x00005BDC File Offset: 0x00003DDC
		// (set) Token: 0x060005C5 RID: 1477 RVA: 0x000148A0 File Offset: 0x00012AA0
		[DefaultValue("")]
		[GAttribute0("border-right")]
		public string String_18
		{
			get
			{
				return this.string_22;
			}
			set
			{
				this.string_22 = value;
				string text = Class17.smethod_1("(([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|thin|medium|thick)", value);
				string text2 = Class17.smethod_1("(none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset)", value);
				string text3 = Class17.smethod_1("(#\\S{6}|#\\S{3}|rgb\\(\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\)|maroon|red|orange|yellow|olive|purple|fuchsia|white|lime|green|navy|blue|aqua|teal|black|silver|gray)", value);
				if (text != null)
				{
					this.String_2 = text;
				}
				if (text2 != null)
				{
					this.String_7 = text2;
				}
				if (text3 != null)
				{
					this.String_13 = text3;
				}
			}
		}

		// Token: 0x17000170 RID: 368
		// (get) Token: 0x060005C6 RID: 1478 RVA: 0x00005BE4 File Offset: 0x00003DE4
		// (set) Token: 0x060005C7 RID: 1479 RVA: 0x000148F8 File Offset: 0x00012AF8
		[GAttribute0("border-top")]
		[DefaultValue("")]
		public string String_19
		{
			get
			{
				return this.string_23;
			}
			set
			{
				this.string_23 = value;
				string text = Class17.smethod_1("(([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|thin|medium|thick)", value);
				string text2 = Class17.smethod_1("(none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset)", value);
				string text3 = Class17.smethod_1("(#\\S{6}|#\\S{3}|rgb\\(\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\)|maroon|red|orange|yellow|olive|purple|fuchsia|white|lime|green|navy|blue|aqua|teal|black|silver|gray)", value);
				if (text != null)
				{
					this.String_3 = text;
				}
				if (text2 != null)
				{
					this.String_9 = text2;
				}
				if (text3 != null)
				{
					this.String_14 = text3;
				}
			}
		}

		// Token: 0x17000171 RID: 369
		// (get) Token: 0x060005C8 RID: 1480 RVA: 0x00005BEC File Offset: 0x00003DEC
		// (set) Token: 0x060005C9 RID: 1481 RVA: 0x00005BF4 File Offset: 0x00003DF4
		[DefaultValue("0")]
		[GAttribute1]
		[GAttribute0("border-spacing")]
		public string String_20
		{
			get
			{
				return this.string_24;
			}
			set
			{
				this.string_24 = value;
			}
		}

		// Token: 0x17000172 RID: 370
		// (get) Token: 0x060005CA RID: 1482 RVA: 0x00005BFD File Offset: 0x00003DFD
		// (set) Token: 0x060005CB RID: 1483 RVA: 0x00005C05 File Offset: 0x00003E05
		[DefaultValue("separate")]
		[GAttribute1]
		[GAttribute0("border-collapse")]
		public string String_21
		{
			get
			{
				return this.string_25;
			}
			set
			{
				this.string_25 = value;
			}
		}

		// Token: 0x17000173 RID: 371
		// (get) Token: 0x060005CC RID: 1484 RVA: 0x00005C0E File Offset: 0x00003E0E
		// (set) Token: 0x060005CD RID: 1485 RVA: 0x00014950 File Offset: 0x00012B50
		[GAttribute0("corner-radius")]
		[DefaultValue("0")]
		public string String_22
		{
			get
			{
				return this.string_32;
			}
			set
			{
				MatchCollection matchCollection = Class17.smethod_0("([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)", value);
				switch (matchCollection.Count)
				{
				case 1:
					this.String_24 = matchCollection[0].Value;
					this.String_23 = matchCollection[0].Value;
					this.String_25 = matchCollection[0].Value;
					this.String_26 = matchCollection[0].Value;
					break;
				case 2:
					this.String_24 = matchCollection[0].Value;
					this.String_23 = matchCollection[0].Value;
					this.String_25 = matchCollection[1].Value;
					this.String_26 = matchCollection[1].Value;
					break;
				case 3:
					this.String_24 = matchCollection[0].Value;
					this.String_23 = matchCollection[1].Value;
					this.String_25 = matchCollection[2].Value;
					break;
				case 4:
					this.String_24 = matchCollection[0].Value;
					this.String_23 = matchCollection[1].Value;
					this.String_25 = matchCollection[2].Value;
					this.String_26 = matchCollection[3].Value;
					break;
				}
				this.string_32 = value;
			}
		}

		// Token: 0x17000174 RID: 372
		// (get) Token: 0x060005CE RID: 1486 RVA: 0x00005C16 File Offset: 0x00003E16
		// (set) Token: 0x060005CF RID: 1487 RVA: 0x00005C1E File Offset: 0x00003E1E
		[DefaultValue("0")]
		[GAttribute0("corner-nw-radius")]
		public string String_23
		{
			get
			{
				return this.string_28;
			}
			set
			{
				this.string_28 = value;
			}
		}

		// Token: 0x17000175 RID: 373
		// (get) Token: 0x060005D0 RID: 1488 RVA: 0x00005C27 File Offset: 0x00003E27
		// (set) Token: 0x060005D1 RID: 1489 RVA: 0x00005C2F File Offset: 0x00003E2F
		[GAttribute0("corner-ne-radius")]
		[DefaultValue("0")]
		public string String_24
		{
			get
			{
				return this.string_29;
			}
			set
			{
				this.string_29 = value;
			}
		}

		// Token: 0x17000176 RID: 374
		// (get) Token: 0x060005D2 RID: 1490 RVA: 0x00005C38 File Offset: 0x00003E38
		// (set) Token: 0x060005D3 RID: 1491 RVA: 0x00005C40 File Offset: 0x00003E40
		[GAttribute0("corner-se-radius")]
		[DefaultValue("0")]
		public string String_25
		{
			get
			{
				return this.string_30;
			}
			set
			{
				this.string_30 = value;
			}
		}

		// Token: 0x17000177 RID: 375
		// (get) Token: 0x060005D4 RID: 1492 RVA: 0x00005C49 File Offset: 0x00003E49
		// (set) Token: 0x060005D5 RID: 1493 RVA: 0x00005C51 File Offset: 0x00003E51
		[GAttribute0("corner-sw-radius")]
		[DefaultValue("0")]
		public string String_26
		{
			get
			{
				return this.string_31;
			}
			set
			{
				this.string_31 = value;
			}
		}

		// Token: 0x17000178 RID: 376
		// (get) Token: 0x060005D6 RID: 1494 RVA: 0x00005C5A File Offset: 0x00003E5A
		// (set) Token: 0x060005D7 RID: 1495 RVA: 0x00014AB0 File Offset: 0x00012CB0
		[DefaultValue("")]
		[GAttribute0("margin")]
		public string String_27
		{
			get
			{
				return this.string_48;
			}
			set
			{
				this.string_48 = value;
				string[] array = GClass34.smethod_5(value);
				switch (array.Length)
				{
				case 1:
					this.String_31 = (this.String_29 = (this.String_30 = (this.String_28 = array[0])));
					return;
				case 2:
					this.String_31 = (this.String_28 = array[0]);
					this.String_29 = (this.String_30 = array[1]);
					return;
				case 3:
					this.String_31 = array[0];
					this.String_29 = (this.String_30 = array[1]);
					this.String_28 = array[2];
					return;
				case 4:
					this.String_31 = array[0];
					this.String_30 = array[1];
					this.String_28 = array[2];
					this.String_29 = array[3];
					return;
				default:
					return;
				}
			}
		}

		// Token: 0x17000179 RID: 377
		// (get) Token: 0x060005D8 RID: 1496 RVA: 0x00005C62 File Offset: 0x00003E62
		// (set) Token: 0x060005D9 RID: 1497 RVA: 0x00005C6A File Offset: 0x00003E6A
		[GAttribute0("margin-bottom")]
		[DefaultValue("0")]
		public string String_28
		{
			get
			{
				return this.string_44;
			}
			set
			{
				this.string_44 = value;
			}
		}

		// Token: 0x1700017A RID: 378
		// (get) Token: 0x060005DA RID: 1498 RVA: 0x00005C73 File Offset: 0x00003E73
		// (set) Token: 0x060005DB RID: 1499 RVA: 0x00005C7B File Offset: 0x00003E7B
		[DefaultValue("0")]
		[GAttribute0("margin-left")]
		public string String_29
		{
			get
			{
				return this.string_45;
			}
			set
			{
				this.string_45 = value;
			}
		}

		// Token: 0x1700017B RID: 379
		// (get) Token: 0x060005DC RID: 1500 RVA: 0x00005C84 File Offset: 0x00003E84
		// (set) Token: 0x060005DD RID: 1501 RVA: 0x00005C8C File Offset: 0x00003E8C
		[DefaultValue("0")]
		[GAttribute0("margin-right")]
		public string String_30
		{
			get
			{
				return this.string_46;
			}
			set
			{
				this.string_46 = value;
			}
		}

		// Token: 0x1700017C RID: 380
		// (get) Token: 0x060005DE RID: 1502 RVA: 0x00005C95 File Offset: 0x00003E95
		// (set) Token: 0x060005DF RID: 1503 RVA: 0x00005C9D File Offset: 0x00003E9D
		[GAttribute0("margin-top")]
		[DefaultValue("0")]
		public string String_31
		{
			get
			{
				return this.string_47;
			}
			set
			{
				this.string_47 = value;
			}
		}

		// Token: 0x1700017D RID: 381
		// (get) Token: 0x060005E0 RID: 1504 RVA: 0x00005CA6 File Offset: 0x00003EA6
		// (set) Token: 0x060005E1 RID: 1505 RVA: 0x00014BAC File Offset: 0x00012DAC
		[DefaultValue("")]
		[GAttribute0("padding")]
		public string String_32
		{
			get
			{
				return this.string_59;
			}
			set
			{
				this.string_59 = value;
				string[] array = GClass34.smethod_5(value);
				switch (array.Length)
				{
				case 1:
					this.String_36 = (this.String_34 = (this.String_35 = (this.String_33 = array[0])));
					return;
				case 2:
					this.String_36 = (this.String_33 = array[0]);
					this.String_34 = (this.String_35 = array[1]);
					return;
				case 3:
					this.String_36 = array[0];
					this.String_34 = (this.String_35 = array[1]);
					this.String_33 = array[2];
					return;
				case 4:
					this.String_36 = array[0];
					this.String_35 = array[1];
					this.String_33 = array[2];
					this.String_34 = array[3];
					return;
				default:
					return;
				}
			}
		}

		// Token: 0x1700017E RID: 382
		// (get) Token: 0x060005E2 RID: 1506 RVA: 0x00005CAE File Offset: 0x00003EAE
		// (set) Token: 0x060005E3 RID: 1507 RVA: 0x00005CB6 File Offset: 0x00003EB6
		[GAttribute0("padding-bottom")]
		[DefaultValue("0")]
		public string String_33
		{
			get
			{
				return this.string_56;
			}
			set
			{
				this.string_56 = value;
				this.float_9 = float.NaN;
			}
		}

		// Token: 0x1700017F RID: 383
		// (get) Token: 0x060005E4 RID: 1508 RVA: 0x00005CCA File Offset: 0x00003ECA
		// (set) Token: 0x060005E5 RID: 1509 RVA: 0x00005CD2 File Offset: 0x00003ED2
		[GAttribute0("padding-left")]
		[DefaultValue("0")]
		public string String_34
		{
			get
			{
				return this.string_55;
			}
			set
			{
				this.string_55 = value;
				this.float_11 = float.NaN;
			}
		}

		// Token: 0x17000180 RID: 384
		// (get) Token: 0x060005E6 RID: 1510 RVA: 0x00005CE6 File Offset: 0x00003EE6
		// (set) Token: 0x060005E7 RID: 1511 RVA: 0x00005CEE File Offset: 0x00003EEE
		[GAttribute0("padding-right")]
		[DefaultValue("0")]
		public string String_35
		{
			get
			{
				return this.string_57;
			}
			set
			{
				this.string_57 = value;
				this.float_10 = float.NaN;
			}
		}

		// Token: 0x17000181 RID: 385
		// (get) Token: 0x060005E8 RID: 1512 RVA: 0x00005D02 File Offset: 0x00003F02
		// (set) Token: 0x060005E9 RID: 1513 RVA: 0x00005D0A File Offset: 0x00003F0A
		[DefaultValue("0")]
		[GAttribute0("padding-top")]
		public string String_36
		{
			get
			{
				return this.string_58;
			}
			set
			{
				this.string_58 = value;
				this.float_8 = float.NaN;
			}
		}

		// Token: 0x17000182 RID: 386
		// (get) Token: 0x060005EA RID: 1514 RVA: 0x00005D1E File Offset: 0x00003F1E
		// (set) Token: 0x060005EB RID: 1515 RVA: 0x00005D26 File Offset: 0x00003F26
		[GAttribute0("left")]
		[DefaultValue("auto")]
		public string String_37
		{
			get
			{
				return this.string_49;
			}
			set
			{
				this.string_49 = value;
			}
		}

		// Token: 0x17000183 RID: 387
		// (get) Token: 0x060005EC RID: 1516 RVA: 0x00005D2F File Offset: 0x00003F2F
		// (set) Token: 0x060005ED RID: 1517 RVA: 0x00005D37 File Offset: 0x00003F37
		[GAttribute0("top")]
		[DefaultValue("auto")]
		public string String_38
		{
			get
			{
				return this.string_64;
			}
			set
			{
				this.string_64 = value;
			}
		}

		// Token: 0x17000184 RID: 388
		// (get) Token: 0x060005EE RID: 1518 RVA: 0x00005D40 File Offset: 0x00003F40
		// (set) Token: 0x060005EF RID: 1519 RVA: 0x00005D48 File Offset: 0x00003F48
		[GAttribute0("width")]
		[DefaultValue("auto")]
		public string String_39
		{
			get
			{
				return this.string_67;
			}
			set
			{
				this.string_67 = value;
			}
		}

		// Token: 0x17000185 RID: 389
		// (get) Token: 0x060005F0 RID: 1520 RVA: 0x00005D51 File Offset: 0x00003F51
		// (set) Token: 0x060005F1 RID: 1521 RVA: 0x00005D59 File Offset: 0x00003F59
		[DefaultValue("auto")]
		[GAttribute0("height")]
		public string String_40
		{
			get
			{
				return this.string_43;
			}
			set
			{
				this.string_43 = value;
			}
		}

		// Token: 0x17000186 RID: 390
		// (get) Token: 0x060005F2 RID: 1522 RVA: 0x00005D62 File Offset: 0x00003F62
		// (set) Token: 0x060005F3 RID: 1523 RVA: 0x00005D6A File Offset: 0x00003F6A
		[DefaultValue("transparent")]
		[GAttribute0("background-color")]
		public string String_41
		{
			get
			{
				return this.string_0;
			}
			set
			{
				this.string_0 = value;
			}
		}

		// Token: 0x17000187 RID: 391
		// (get) Token: 0x060005F4 RID: 1524 RVA: 0x00005D73 File Offset: 0x00003F73
		// (set) Token: 0x060005F5 RID: 1525 RVA: 0x00005D7B File Offset: 0x00003F7B
		[GAttribute0("background-image")]
		[DefaultValue("none")]
		public string String_42
		{
			get
			{
				return this.string_3;
			}
			set
			{
				this.string_3 = value;
			}
		}

		// Token: 0x17000188 RID: 392
		// (get) Token: 0x060005F6 RID: 1526 RVA: 0x00005D84 File Offset: 0x00003F84
		// (set) Token: 0x060005F7 RID: 1527 RVA: 0x00005D8C File Offset: 0x00003F8C
		[GAttribute0("background-repeat")]
		[DefaultValue("repeat")]
		public string String_43
		{
			get
			{
				return this.string_4;
			}
			set
			{
				this.string_4 = value;
			}
		}

		// Token: 0x17000189 RID: 393
		// (get) Token: 0x060005F8 RID: 1528 RVA: 0x00005D95 File Offset: 0x00003F95
		// (set) Token: 0x060005F9 RID: 1529 RVA: 0x00005D9D File Offset: 0x00003F9D
		[DefaultValue("none")]
		[GAttribute0("background-gradient")]
		public string String_44
		{
			get
			{
				return this.string_1;
			}
			set
			{
				this.string_1 = value;
			}
		}

		// Token: 0x1700018A RID: 394
		// (get) Token: 0x060005FA RID: 1530 RVA: 0x00005DA6 File Offset: 0x00003FA6
		// (set) Token: 0x060005FB RID: 1531 RVA: 0x00005DAE File Offset: 0x00003FAE
		[DefaultValue("90")]
		[GAttribute0("background-gradient-angle")]
		public string String_45
		{
			get
			{
				return this.string_2;
			}
			set
			{
				this.string_2 = value;
			}
		}

		// Token: 0x1700018B RID: 395
		// (get) Token: 0x060005FC RID: 1532 RVA: 0x00005DB7 File Offset: 0x00003FB7
		// (set) Token: 0x060005FD RID: 1533 RVA: 0x00005DBF File Offset: 0x00003FBF
		[DefaultValue("black")]
		[GAttribute0("color")]
		[GAttribute1]
		public string String_46
		{
			get
			{
				return this.string_27;
			}
			set
			{
				this.string_27 = value;
				this.color_0 = Color.Empty;
			}
		}

		// Token: 0x1700018C RID: 396
		// (get) Token: 0x060005FE RID: 1534 RVA: 0x00005DD3 File Offset: 0x00003FD3
		// (set) Token: 0x060005FF RID: 1535 RVA: 0x00005DDB File Offset: 0x00003FDB
		[GAttribute0("display")]
		[DefaultValue("inline")]
		public string String_47
		{
			get
			{
				return this.string_35;
			}
			set
			{
				this.string_35 = value;
			}
		}

		// Token: 0x1700018D RID: 397
		// (get) Token: 0x06000600 RID: 1536 RVA: 0x00005DE4 File Offset: 0x00003FE4
		// (set) Token: 0x06000601 RID: 1537 RVA: 0x00005DEC File Offset: 0x00003FEC
		[GAttribute0("direction")]
		[DefaultValue("ltr")]
		public string String_48
		{
			get
			{
				return this.string_34;
			}
			set
			{
				this.string_34 = value;
			}
		}

		// Token: 0x1700018E RID: 398
		// (get) Token: 0x06000602 RID: 1538 RVA: 0x00005DF5 File Offset: 0x00003FF5
		// (set) Token: 0x06000603 RID: 1539 RVA: 0x00005DFD File Offset: 0x00003FFD
		[GAttribute0("empty-cells")]
		[DefaultValue("show")]
		[GAttribute1]
		public string String_49
		{
			get
			{
				return this.string_33;
			}
			set
			{
				this.string_33 = value;
			}
		}

		// Token: 0x1700018F RID: 399
		// (get) Token: 0x06000604 RID: 1540 RVA: 0x00005E06 File Offset: 0x00004006
		// (set) Token: 0x06000605 RID: 1541 RVA: 0x00005E0E File Offset: 0x0000400E
		[DefaultValue("none")]
		[GAttribute0("float")]
		public string String_50
		{
			get
			{
				return this.string_42;
			}
			set
			{
				this.string_42 = value;
			}
		}

		// Token: 0x17000190 RID: 400
		// (get) Token: 0x06000606 RID: 1542 RVA: 0x00005E17 File Offset: 0x00004017
		// (set) Token: 0x06000607 RID: 1543 RVA: 0x00005E1F File Offset: 0x0000401F
		[DefaultValue("static")]
		[GAttribute0("position")]
		public string String_51
		{
			get
			{
				return this.string_65;
			}
			set
			{
				this.string_65 = value;
			}
		}

		// Token: 0x17000191 RID: 401
		// (get) Token: 0x06000608 RID: 1544 RVA: 0x00005E28 File Offset: 0x00004028
		// (set) Token: 0x06000609 RID: 1545 RVA: 0x00005E30 File Offset: 0x00004030
		[DefaultValue("normal")]
		[GAttribute0("line-height")]
		public string String_52
		{
			get
			{
				return this.string_50;
			}
			set
			{
				this.string_50 = this.method_22(value);
			}
		}

		// Token: 0x17000192 RID: 402
		// (get) Token: 0x0600060A RID: 1546 RVA: 0x00005E3F File Offset: 0x0000403F
		// (set) Token: 0x0600060B RID: 1547 RVA: 0x00005E47 File Offset: 0x00004047
		[GAttribute0("vertical-align")]
		[GAttribute1]
		[DefaultValue("baseline")]
		public string String_53
		{
			get
			{
				return this.string_66;
			}
			set
			{
				this.string_66 = value;
			}
		}

		// Token: 0x17000193 RID: 403
		// (get) Token: 0x0600060C RID: 1548 RVA: 0x00005E50 File Offset: 0x00004050
		// (set) Token: 0x0600060D RID: 1549 RVA: 0x00005E58 File Offset: 0x00004058
		[DefaultValue("0")]
		[GAttribute1]
		[GAttribute0("text-indent")]
		public string String_54
		{
			get
			{
				return this.string_63;
			}
			set
			{
				this.string_63 = this.method_22(value);
			}
		}

		// Token: 0x17000194 RID: 404
		// (get) Token: 0x0600060E RID: 1550 RVA: 0x00005E67 File Offset: 0x00004067
		// (set) Token: 0x0600060F RID: 1551 RVA: 0x00005E6F File Offset: 0x0000406F
		[GAttribute1]
		[DefaultValue("")]
		[GAttribute0("text-align")]
		public string String_55
		{
			get
			{
				return this.string_61;
			}
			set
			{
				this.string_61 = value;
			}
		}

		// Token: 0x17000195 RID: 405
		// (get) Token: 0x06000610 RID: 1552 RVA: 0x00005E78 File Offset: 0x00004078
		// (set) Token: 0x06000611 RID: 1553 RVA: 0x00005E80 File Offset: 0x00004080
		[DefaultValue("")]
		[GAttribute0("text-decoration")]
		public string String_56
		{
			get
			{
				return this.string_62;
			}
			set
			{
				this.string_62 = value;
			}
		}

		// Token: 0x17000196 RID: 406
		// (get) Token: 0x06000612 RID: 1554 RVA: 0x00005E89 File Offset: 0x00004089
		// (set) Token: 0x06000613 RID: 1555 RVA: 0x00005E91 File Offset: 0x00004091
		[DefaultValue("normal")]
		[GAttribute1]
		[GAttribute0("white-space")]
		public string String_57
		{
			get
			{
				return this.string_69;
			}
			set
			{
				this.string_69 = value;
			}
		}

		// Token: 0x17000197 RID: 407
		// (get) Token: 0x06000614 RID: 1556 RVA: 0x00005E9A File Offset: 0x0000409A
		// (set) Token: 0x06000615 RID: 1557 RVA: 0x00005EA2 File Offset: 0x000040A2
		[GAttribute0("word-spacing")]
		[DefaultValue("normal")]
		public string String_58
		{
			get
			{
				return this.string_68;
			}
			set
			{
				this.string_68 = this.method_22(value);
			}
		}

		// Token: 0x17000198 RID: 408
		// (get) Token: 0x06000616 RID: 1558 RVA: 0x00005EB1 File Offset: 0x000040B1
		// (set) Token: 0x06000617 RID: 1559 RVA: 0x00014CA8 File Offset: 0x00012EA8
		[GAttribute0("font")]
		[GAttribute1]
		[DefaultValue("")]
		public string String_59
		{
			get
			{
				return this.string_36;
			}
			set
			{
				this.string_36 = value;
				int num;
				string text = Class17.smethod_2("(([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|([0-9]+|[0-9]*\\.[0-9]+)\\%|xx-small|x-small|small|medium|large|x-large|xx-large|larger|smaller)(\\/(normal|{[0-9]+|[0-9]*\\.[0-9]+}|([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|([0-9]+|[0-9]*\\.[0-9]+)\\%))?(\\s|$)", value, out num);
				if (!string.IsNullOrEmpty(text))
				{
					text = text.Trim();
					string text2 = value.Substring(0, num);
					string value2 = Class17.smethod_1("(normal|italic|oblique)", text2);
					string value3 = Class17.smethod_1("(normal|small-caps)", text2);
					string value4 = Class17.smethod_1("(normal|bold|bolder|lighter|100|200|300|400|500|600|700|800|900)", text2);
					string text3 = value.Substring(num + text.Length);
					string value5 = text3.Trim();
					string value6 = text;
					string value7 = string.Empty;
					if (text.Contains("/") && text.Length > text.IndexOf("/") + 1)
					{
						int num2 = text.IndexOf("/");
						value6 = text.Substring(0, num2);
						value7 = text.Substring(num2 + 1);
					}
					if (!string.IsNullOrEmpty(value2))
					{
						this.String_62 = value2;
					}
					if (!string.IsNullOrEmpty(value3))
					{
						this.String_63 = value3;
					}
					if (!string.IsNullOrEmpty(value4))
					{
						this.String_64 = value4;
					}
					if (!string.IsNullOrEmpty(value5))
					{
						this.String_60 = value5;
					}
					if (!string.IsNullOrEmpty(value6))
					{
						this.String_61 = value6;
					}
					if (!string.IsNullOrEmpty(value7))
					{
						this.String_52 = value7;
					}
				}
			}
		}

		// Token: 0x17000199 RID: 409
		// (get) Token: 0x06000618 RID: 1560 RVA: 0x00005EB9 File Offset: 0x000040B9
		// (set) Token: 0x06000619 RID: 1561 RVA: 0x00014DD8 File Offset: 0x00012FD8
		[GAttribute1]
		[DefaultValue("serif")]
		[GAttribute0("font-family")]
		public string String_60
		{
			get
			{
				return this.string_37;
			}
			set
			{
				if (value != null)
				{
					if (value == "serif")
					{
						this.string_37 = GClass32.string_3;
						return;
					}
					if (value == "sans-serif")
					{
						this.string_37 = GClass32.string_4;
						return;
					}
					if (value == "cursive")
					{
						this.string_37 = GClass32.string_5;
						return;
					}
					if (value == "fantasy")
					{
						this.string_37 = GClass32.string_6;
						return;
					}
					if (value == "monospace")
					{
						this.string_37 = GClass32.string_7;
						return;
					}
				}
				this.string_37 = value;
			}
		}

		// Token: 0x1700019A RID: 410
		// (get) Token: 0x0600061A RID: 1562 RVA: 0x00005EC1 File Offset: 0x000040C1
		// (set) Token: 0x0600061B RID: 1563 RVA: 0x00014E70 File Offset: 0x00013070
		[GAttribute0("font-size")]
		[GAttribute1]
		[DefaultValue("medium")]
		public string String_61
		{
			get
			{
				return this.string_38;
			}
			set
			{
				string text = Class17.smethod_1("([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)", value);
				if (text != null)
				{
					string text2 = string.Empty;
					GClass33 gclass = new GClass33(text);
					if (gclass.Boolean_0)
					{
						text2 = GClass23.dictionary_1["font-size"];
					}
					else if (gclass.GEnum4_0 == GClass33.GEnum4.const_1 && this.GClass23_2 != null)
					{
						text2 = gclass.method_0(this.GClass23_2.Font_1.SizeInPoints).ToString();
					}
					else
					{
						text2 = gclass.ToString();
					}
					this.string_38 = text2;
					return;
				}
				this.string_38 = value;
			}
		}

		// Token: 0x1700019B RID: 411
		// (get) Token: 0x0600061C RID: 1564 RVA: 0x00005EC9 File Offset: 0x000040C9
		// (set) Token: 0x0600061D RID: 1565 RVA: 0x00005ED1 File Offset: 0x000040D1
		[GAttribute1]
		[DefaultValue("normal")]
		[GAttribute0("font-style")]
		public string String_62
		{
			get
			{
				return this.string_39;
			}
			set
			{
				this.string_39 = value;
			}
		}

		// Token: 0x1700019C RID: 412
		// (get) Token: 0x0600061E RID: 1566 RVA: 0x00005EDA File Offset: 0x000040DA
		// (set) Token: 0x0600061F RID: 1567 RVA: 0x00005EE2 File Offset: 0x000040E2
		[GAttribute0("font-variant")]
		[GAttribute1]
		[DefaultValue("normal")]
		public string String_63
		{
			get
			{
				return this.string_40;
			}
			set
			{
				this.string_40 = value;
			}
		}

		// Token: 0x1700019D RID: 413
		// (get) Token: 0x06000620 RID: 1568 RVA: 0x00005EEB File Offset: 0x000040EB
		// (set) Token: 0x06000621 RID: 1569 RVA: 0x00005EF3 File Offset: 0x000040F3
		[GAttribute0("font-weight")]
		[GAttribute1]
		[DefaultValue("normal")]
		public string String_64
		{
			get
			{
				return this.string_41;
			}
			set
			{
				this.string_41 = value;
			}
		}

		// Token: 0x1700019E RID: 414
		// (get) Token: 0x06000622 RID: 1570 RVA: 0x00005EFC File Offset: 0x000040FC
		// (set) Token: 0x06000623 RID: 1571 RVA: 0x00005F04 File Offset: 0x00004104
		[GAttribute0("list-style")]
		[GAttribute1]
		[DefaultValue("")]
		public string String_65
		{
			get
			{
				return this.string_54;
			}
			set
			{
				this.string_54 = value;
			}
		}

		// Token: 0x1700019F RID: 415
		// (get) Token: 0x06000624 RID: 1572 RVA: 0x00005F0D File Offset: 0x0000410D
		// (set) Token: 0x06000625 RID: 1573 RVA: 0x00005F15 File Offset: 0x00004115
		[DefaultValue("outside")]
		[GAttribute1]
		[GAttribute0("list-style-position")]
		public string String_66
		{
			get
			{
				return this.string_53;
			}
			set
			{
				this.string_53 = value;
			}
		}

		// Token: 0x170001A0 RID: 416
		// (get) Token: 0x06000626 RID: 1574 RVA: 0x00005F1E File Offset: 0x0000411E
		// (set) Token: 0x06000627 RID: 1575 RVA: 0x00005F26 File Offset: 0x00004126
		[GAttribute1]
		[GAttribute0("list-style-image")]
		[DefaultValue("")]
		public string String_67
		{
			get
			{
				return this.string_52;
			}
			set
			{
				this.string_52 = value;
			}
		}

		// Token: 0x170001A1 RID: 417
		// (get) Token: 0x06000628 RID: 1576 RVA: 0x00005F2F File Offset: 0x0000412F
		// (set) Token: 0x06000629 RID: 1577 RVA: 0x00005F37 File Offset: 0x00004137
		[GAttribute1]
		[DefaultValue("disc")]
		[GAttribute0("list-style-type")]
		public string String_68
		{
			get
			{
				return this.string_51;
			}
			set
			{
				this.string_51 = value;
			}
		}

		// Token: 0x170001A2 RID: 418
		// (get) Token: 0x0600062A RID: 1578 RVA: 0x00014EF8 File Offset: 0x000130F8
		public float Single_0
		{
			get
			{
				if (float.IsNaN(this.float_8))
				{
					this.float_8 = GClass34.smethod_1(this.String_36, this.SizeF_0.Width, this);
				}
				return this.float_8;
			}
		}

		// Token: 0x170001A3 RID: 419
		// (get) Token: 0x0600062B RID: 1579 RVA: 0x00014F38 File Offset: 0x00013138
		public float Single_1
		{
			get
			{
				if (float.IsNaN(this.float_11))
				{
					this.float_11 = GClass34.smethod_1(this.String_34, this.SizeF_0.Width, this);
				}
				return this.float_11;
			}
		}

		// Token: 0x170001A4 RID: 420
		// (get) Token: 0x0600062C RID: 1580 RVA: 0x00014F78 File Offset: 0x00013178
		public float Single_2
		{
			get
			{
				if (float.IsNaN(this.float_9))
				{
					this.float_9 = GClass34.smethod_1(this.String_33, this.SizeF_0.Width, this);
				}
				return this.float_9;
			}
		}

		// Token: 0x170001A5 RID: 421
		// (get) Token: 0x0600062D RID: 1581 RVA: 0x00014FB8 File Offset: 0x000131B8
		public float Single_3
		{
			get
			{
				if (float.IsNaN(this.float_10))
				{
					this.float_10 = GClass34.smethod_1(this.String_35, this.SizeF_0.Width, this);
				}
				return this.float_10;
			}
		}

		// Token: 0x170001A6 RID: 422
		// (get) Token: 0x0600062E RID: 1582 RVA: 0x00014FF8 File Offset: 0x000131F8
		public float Single_4
		{
			get
			{
				if (float.IsNaN(this.float_12))
				{
					if (this.String_31 == "auto")
					{
						this.String_31 = "0";
					}
					this.float_12 = GClass34.smethod_1(this.String_31, this.SizeF_0.Width, this);
				}
				return this.float_12;
			}
		}

		// Token: 0x170001A7 RID: 423
		// (get) Token: 0x0600062F RID: 1583 RVA: 0x00015058 File Offset: 0x00013258
		public float Single_5
		{
			get
			{
				if (float.IsNaN(this.float_15))
				{
					if (this.String_29 == "auto")
					{
						this.String_29 = "0";
					}
					this.float_15 = GClass34.smethod_1(this.String_29, this.SizeF_0.Width, this);
				}
				return this.float_15;
			}
		}

		// Token: 0x170001A8 RID: 424
		// (get) Token: 0x06000630 RID: 1584 RVA: 0x000150B8 File Offset: 0x000132B8
		public float Single_6
		{
			get
			{
				if (float.IsNaN(this.float_13))
				{
					if (this.String_28 == "auto")
					{
						this.String_28 = "0";
					}
					this.float_13 = GClass34.smethod_1(this.String_28, this.SizeF_0.Width, this);
				}
				return this.float_13;
			}
		}

		// Token: 0x170001A9 RID: 425
		// (get) Token: 0x06000631 RID: 1585 RVA: 0x00015118 File Offset: 0x00013318
		public float Single_7
		{
			get
			{
				if (float.IsNaN(this.float_14))
				{
					if (this.String_30 == "auto")
					{
						this.String_30 = "0";
					}
					this.float_14 = GClass34.smethod_1(this.String_30, this.SizeF_0.Width, this);
				}
				return this.float_14;
			}
		}

		// Token: 0x170001AA RID: 426
		// (get) Token: 0x06000632 RID: 1586 RVA: 0x00015178 File Offset: 0x00013378
		public float Single_8
		{
			get
			{
				if (float.IsNaN(this.float_16))
				{
					this.float_16 = GClass34.smethod_4(this.String_3, this);
					if (string.IsNullOrEmpty(this.String_9) || this.String_9 == "none")
					{
						this.float_16 = 0f;
					}
				}
				return this.float_16;
			}
		}

		// Token: 0x170001AB RID: 427
		// (get) Token: 0x06000633 RID: 1587 RVA: 0x000151D4 File Offset: 0x000133D4
		public float Single_9
		{
			get
			{
				if (float.IsNaN(this.float_17))
				{
					this.float_17 = GClass34.smethod_4(this.String_1, this);
					if (string.IsNullOrEmpty(this.String_6) || this.String_6 == "none")
					{
						this.float_17 = 0f;
					}
				}
				return this.float_17;
			}
		}

		// Token: 0x170001AC RID: 428
		// (get) Token: 0x06000634 RID: 1588 RVA: 0x00015230 File Offset: 0x00013430
		public float Single_10
		{
			get
			{
				if (float.IsNaN(this.float_18))
				{
					this.float_18 = GClass34.smethod_4(this.String_0, this);
					if (string.IsNullOrEmpty(this.String_5) || this.String_5 == "none")
					{
						this.float_18 = 0f;
					}
				}
				return this.float_18;
			}
		}

		// Token: 0x170001AD RID: 429
		// (get) Token: 0x06000635 RID: 1589 RVA: 0x0001528C File Offset: 0x0001348C
		public float Single_11
		{
			get
			{
				if (float.IsNaN(this.float_19))
				{
					this.float_19 = GClass34.smethod_4(this.String_2, this);
					if (string.IsNullOrEmpty(this.String_7) || this.String_7 == "none")
					{
						this.float_19 = 0f;
					}
				}
				return this.float_19;
			}
		}

		// Token: 0x170001AE RID: 430
		// (get) Token: 0x06000636 RID: 1590 RVA: 0x00005F40 File Offset: 0x00004140
		public Color Color_0
		{
			get
			{
				if (this.color_2.IsEmpty)
				{
					this.color_2 = GClass34.smethod_3(this.String_14);
				}
				return this.color_2;
			}
		}

		// Token: 0x170001AF RID: 431
		// (get) Token: 0x06000637 RID: 1591 RVA: 0x00005F66 File Offset: 0x00004166
		public Color Color_1
		{
			get
			{
				if (this.color_3.IsEmpty)
				{
					this.color_3 = GClass34.smethod_3(this.String_12);
				}
				return this.color_3;
			}
		}

		// Token: 0x170001B0 RID: 432
		// (get) Token: 0x06000638 RID: 1592 RVA: 0x00005F8C File Offset: 0x0000418C
		public Color Color_2
		{
			get
			{
				if (this.color_4.IsEmpty)
				{
					this.color_4 = GClass34.smethod_3(this.String_11);
				}
				return this.color_4;
			}
		}

		// Token: 0x170001B1 RID: 433
		// (get) Token: 0x06000639 RID: 1593 RVA: 0x00005FB2 File Offset: 0x000041B2
		public Color Color_3
		{
			get
			{
				if (this.color_5.IsEmpty)
				{
					this.color_5 = GClass34.smethod_3(this.String_13);
				}
				return this.color_5;
			}
		}

		// Token: 0x170001B2 RID: 434
		// (get) Token: 0x0600063A RID: 1594 RVA: 0x00005FD8 File Offset: 0x000041D8
		public float Single_12
		{
			get
			{
				if (float.IsNaN(this.float_3))
				{
					this.float_3 = GClass34.smethod_1(this.String_23, 0f, this);
				}
				return this.float_3;
			}
		}

		// Token: 0x170001B3 RID: 435
		// (get) Token: 0x0600063B RID: 1595 RVA: 0x00006004 File Offset: 0x00004204
		public float Single_13
		{
			get
			{
				if (float.IsNaN(this.float_4))
				{
					this.float_4 = GClass34.smethod_1(this.String_24, 0f, this);
				}
				return this.float_4;
			}
		}

		// Token: 0x170001B4 RID: 436
		// (get) Token: 0x0600063C RID: 1596 RVA: 0x00006030 File Offset: 0x00004230
		public float Single_14
		{
			get
			{
				if (float.IsNaN(this.float_6))
				{
					this.float_6 = GClass34.smethod_1(this.String_25, 0f, this);
				}
				return this.float_6;
			}
		}

		// Token: 0x170001B5 RID: 437
		// (get) Token: 0x0600063D RID: 1597 RVA: 0x0000605C File Offset: 0x0000425C
		public float Single_15
		{
			get
			{
				if (float.IsNaN(this.float_5))
				{
					this.float_5 = GClass34.smethod_1(this.String_26, 0f, this);
				}
				return this.float_5;
			}
		}

		// Token: 0x170001B6 RID: 438
		// (get) Token: 0x0600063E RID: 1598 RVA: 0x00006088 File Offset: 0x00004288
		public float Single_16
		{
			get
			{
				if (float.IsNaN(this.float_20))
				{
					throw new Exception("Space must be calculated before using this property");
				}
				return this.float_20;
			}
		}

		// Token: 0x170001B7 RID: 439
		// (get) Token: 0x0600063F RID: 1599 RVA: 0x000060A8 File Offset: 0x000042A8
		public Color Color_4
		{
			get
			{
				if (this.color_0.IsEmpty)
				{
					this.color_0 = GClass34.smethod_3(this.String_46);
				}
				return this.color_0;
			}
		}

		// Token: 0x170001B8 RID: 440
		// (get) Token: 0x06000640 RID: 1600 RVA: 0x000060CE File Offset: 0x000042CE
		public Color Color_5
		{
			get
			{
				if (this.color_6.IsEmpty)
				{
					this.color_6 = GClass34.smethod_3(this.String_41);
				}
				return this.color_6;
			}
		}

		// Token: 0x170001B9 RID: 441
		// (get) Token: 0x06000641 RID: 1601 RVA: 0x000060F4 File Offset: 0x000042F4
		public Color Color_6
		{
			get
			{
				if (this.color_1.IsEmpty)
				{
					this.color_1 = GClass34.smethod_3(this.String_44);
				}
				return this.color_1;
			}
		}

		// Token: 0x170001BA RID: 442
		// (get) Token: 0x06000642 RID: 1602 RVA: 0x0000611A File Offset: 0x0000431A
		public float Single_17
		{
			get
			{
				if (float.IsNaN(this.float_7))
				{
					this.float_7 = GClass34.smethod_0(this.String_45, 360f);
				}
				return this.float_7;
			}
		}

		// Token: 0x170001BB RID: 443
		// (get) Token: 0x06000643 RID: 1603 RVA: 0x00006145 File Offset: 0x00004345
		public Font Font_0
		{
			get
			{
				if (this.GClass23_2 == null)
				{
					return this.Font_1;
				}
				return this.GClass23_2.Font_1;
			}
		}

		// Token: 0x170001BC RID: 444
		// (get) Token: 0x06000644 RID: 1604 RVA: 0x000152E8 File Offset: 0x000134E8
		public Font Font_1
		{
			get
			{
				if (this.font_0 == null)
				{
					if (string.IsNullOrEmpty(this.String_60))
					{
						this.String_60 = GClass32.string_3;
					}
					if (string.IsNullOrEmpty(this.String_61))
					{
						this.String_61 = GClass32.float_0 + "pt";
					}
					FontStyle fontStyle = FontStyle.Regular;
					if (this.String_62 == "italic" || this.String_62 == "oblique")
					{
						fontStyle |= FontStyle.Italic;
					}
					if (this.String_64 != "normal" && this.String_64 != "lighter" && !string.IsNullOrEmpty(this.String_64))
					{
						fontStyle |= FontStyle.Bold;
					}
					float size = GClass32.float_0;
					if (this.GClass23_2 != null)
					{
						size = this.GClass23_2.Font_1.Size;
					}
					string key;
					float num2;
					switch (key = this.String_61)
					{
					case "medium":
						num2 = GClass32.float_0;
						goto IL_21F;
					case "xx-small":
						num2 = GClass32.float_0 - 4f;
						goto IL_21F;
					case "x-small":
						num2 = GClass32.float_0 - 3f;
						goto IL_21F;
					case "small":
						num2 = GClass32.float_0 - 2f;
						goto IL_21F;
					case "large":
						num2 = GClass32.float_0 + 2f;
						goto IL_21F;
					case "x-large":
						num2 = GClass32.float_0 + 3f;
						goto IL_21F;
					case "xx-large":
						num2 = GClass32.float_0 + 4f;
						goto IL_21F;
					case "smaller":
						num2 = size - 2f;
						goto IL_21F;
					case "larger":
						num2 = size + 2f;
						goto IL_21F;
					}
					num2 = GClass34.smethod_2(this.String_61, size, this, size, true);
					IL_21F:
					if (num2 <= 1f)
					{
						num2 = GClass32.float_0;
					}
					this.font_0 = new Font(this.String_60, num2, fontStyle);
				}
				return this.font_0;
			}
		}

		// Token: 0x170001BD RID: 445
		// (get) Token: 0x06000645 RID: 1605 RVA: 0x0001553C File Offset: 0x0001373C
		public float Single_18
		{
			get
			{
				if (float.IsNaN(this.float_21))
				{
					this.float_21 = GClass34.smethod_1(this.String_54, this.SizeF_0.Width, this);
				}
				return this.float_21;
			}
		}

		// Token: 0x170001BE RID: 446
		// (get) Token: 0x06000646 RID: 1606 RVA: 0x0001557C File Offset: 0x0001377C
		public float Single_19
		{
			get
			{
				if (float.IsNaN(this.float_22))
				{
					MatchCollection matchCollection = Class17.smethod_0("([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)", this.String_20);
					if (matchCollection.Count == 0)
					{
						this.float_22 = 0f;
					}
					else if (matchCollection.Count > 0)
					{
						this.float_22 = GClass34.smethod_1(matchCollection[0].Value, 1f, this);
					}
				}
				return this.float_22;
			}
		}

		// Token: 0x170001BF RID: 447
		// (get) Token: 0x06000647 RID: 1607 RVA: 0x000155E8 File Offset: 0x000137E8
		public float Single_20
		{
			get
			{
				if (float.IsNaN(this.float_23))
				{
					MatchCollection matchCollection = Class17.smethod_0("([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)", this.String_20);
					if (matchCollection.Count == 0)
					{
						this.float_23 = 0f;
					}
					else if (matchCollection.Count == 1)
					{
						this.float_23 = GClass34.smethod_1(matchCollection[0].Value, 1f, this);
					}
					else
					{
						this.float_23 = GClass34.smethod_1(matchCollection[1].Value, 1f, this);
					}
				}
				return this.float_23;
			}
		}

		// Token: 0x170001C0 RID: 448
		// (get) Token: 0x06000648 RID: 1608 RVA: 0x00006161 File Offset: 0x00004361
		public GClass23 GClass23_0
		{
			get
			{
				return this.gclass23_2;
			}
		}

		// Token: 0x170001C1 RID: 449
		// (get) Token: 0x06000649 RID: 1609 RVA: 0x00015674 File Offset: 0x00013874
		public float Single_21
		{
			get
			{
				return this.SizeF_0.Width - this.Single_9 - this.Single_1 - this.Single_3 - this.Single_11;
			}
		}

		// Token: 0x170001C2 RID: 450
		// (get) Token: 0x0600064A RID: 1610 RVA: 0x00006169 File Offset: 0x00004369
		public RectangleF RectangleF_0
		{
			get
			{
				return new RectangleF(this.PointF_0, this.SizeF_0);
			}
		}

		// Token: 0x170001C3 RID: 451
		// (get) Token: 0x0600064B RID: 1611 RVA: 0x000156AC File Offset: 0x000138AC
		// (set) Token: 0x0600064C RID: 1612 RVA: 0x000156D8 File Offset: 0x000138D8
		public float Single_22
		{
			get
			{
				return this.PointF_0.Y + this.SizeF_0.Height;
			}
			set
			{
				this.SizeF_0 = new SizeF(this.SizeF_0.Width, value - this.PointF_0.Y);
			}
		}

		// Token: 0x170001C4 RID: 452
		// (get) Token: 0x0600064D RID: 1613 RVA: 0x0000617C File Offset: 0x0000437C
		public List<GClass23> List_0
		{
			get
			{
				return this.list_3;
			}
		}

		// Token: 0x170001C5 RID: 453
		// (get) Token: 0x0600064E RID: 1614 RVA: 0x00015710 File Offset: 0x00013910
		public float Single_23
		{
			get
			{
				return this.PointF_0.X + this.Single_9 + this.Single_1;
			}
		}

		// Token: 0x170001C6 RID: 454
		// (get) Token: 0x0600064F RID: 1615 RVA: 0x0001573C File Offset: 0x0001393C
		public float Single_24
		{
			get
			{
				return this.PointF_0.Y + this.Single_8 + this.Single_0;
			}
		}

		// Token: 0x170001C7 RID: 455
		// (get) Token: 0x06000650 RID: 1616 RVA: 0x00006184 File Offset: 0x00004384
		public float Single_25
		{
			get
			{
				return this.Single_30 - this.Single_3 - this.Single_11;
			}
		}

		// Token: 0x170001C8 RID: 456
		// (get) Token: 0x06000651 RID: 1617 RVA: 0x0000619A File Offset: 0x0000439A
		public float Single_26
		{
			get
			{
				return this.Single_22 - this.Single_2 - this.Single_10;
			}
		}

		// Token: 0x170001C9 RID: 457
		// (get) Token: 0x06000652 RID: 1618 RVA: 0x000061B0 File Offset: 0x000043B0
		public RectangleF RectangleF_1
		{
			get
			{
				return RectangleF.FromLTRB(this.Single_23, this.Single_24, this.Single_25, this.Single_26);
			}
		}

		// Token: 0x170001CA RID: 458
		// (get) Token: 0x06000653 RID: 1619 RVA: 0x00015768 File Offset: 0x00013968
		public GClass23 GClass23_1
		{
			get
			{
				if (this.GClass23_2 == null)
				{
					return this;
				}
				GClass23 gclass = this.GClass23_2;
				while (gclass.String_47 != "block" && gclass.String_47 != "table" && gclass.String_47 != "table-cell" && gclass.GClass23_2 != null)
				{
					gclass = gclass.GClass23_2;
				}
				if (gclass == null)
				{
					throw new Exception("There's no containing block on the chain");
				}
				return gclass;
			}
		}

		// Token: 0x170001CB RID: 459
		// (get) Token: 0x06000654 RID: 1620 RVA: 0x000061CF File Offset: 0x000043CF
		public float Single_27
		{
			get
			{
				if (float.IsNaN(this.float_0))
				{
					this.float_0 = Class14.smethod_6(this.Font_1);
				}
				return this.float_0;
			}
		}

		// Token: 0x170001CC RID: 460
		// (get) Token: 0x06000655 RID: 1621 RVA: 0x000061F5 File Offset: 0x000043F5
		public float Single_28
		{
			get
			{
				if (float.IsNaN(this.float_2))
				{
					this.float_2 = Class14.smethod_8(this.Font_1);
				}
				return this.float_2;
			}
		}

		// Token: 0x170001CD RID: 461
		// (get) Token: 0x06000656 RID: 1622 RVA: 0x0000621B File Offset: 0x0000441B
		public float Single_29
		{
			get
			{
				if (float.IsNaN(this.float_1))
				{
					this.float_1 = Class14.smethod_7(this.Font_1);
				}
				return this.float_1;
			}
		}

		// Token: 0x170001CE RID: 462
		// (get) Token: 0x06000657 RID: 1623 RVA: 0x00006241 File Offset: 0x00004441
		internal Class11 Class11_0
		{
			get
			{
				return this.List_3[0];
			}
		}

		// Token: 0x170001CF RID: 463
		// (get) Token: 0x06000658 RID: 1624 RVA: 0x0000624F File Offset: 0x0000444F
		// (set) Token: 0x06000659 RID: 1625 RVA: 0x00006257 File Offset: 0x00004457
		internal Class15 Class15_0
		{
			get
			{
				return this.class15_0;
			}
			set
			{
				this.class15_0 = value;
			}
		}

		// Token: 0x170001D0 RID: 464
		// (get) Token: 0x0600065A RID: 1626 RVA: 0x00006260 File Offset: 0x00004460
		// (set) Token: 0x0600065B RID: 1627 RVA: 0x00006268 File Offset: 0x00004468
		internal Class15 Class15_1
		{
			get
			{
				return this.class15_1;
			}
			set
			{
				this.class15_1 = value;
			}
		}

		// Token: 0x170001D1 RID: 465
		// (get) Token: 0x0600065C RID: 1628 RVA: 0x00006271 File Offset: 0x00004471
		public GClass37 GClass37_0
		{
			get
			{
				return this.gclass37_0;
			}
		}

		// Token: 0x170001D2 RID: 466
		// (get) Token: 0x0600065D RID: 1629 RVA: 0x00006279 File Offset: 0x00004479
		public GClass28 GClass28_0
		{
			get
			{
				return this.gclass28_0;
			}
		}

		// Token: 0x170001D3 RID: 467
		// (get) Token: 0x0600065E RID: 1630 RVA: 0x00006281 File Offset: 0x00004481
		public bool Boolean_0
		{
			get
			{
				return this.List_3.Count == 1 && this.List_3[0].Boolean_0;
			}
		}

		// Token: 0x170001D4 RID: 468
		// (get) Token: 0x0600065F RID: 1631 RVA: 0x000062A4 File Offset: 0x000044A4
		public bool Boolean_1
		{
			get
			{
				return this.Single_13 > 0f || this.Single_12 > 0f || this.Single_14 > 0f || this.Single_15 > 0f;
			}
		}

		// Token: 0x170001D5 RID: 469
		// (get) Token: 0x06000660 RID: 1632 RVA: 0x000157DC File Offset: 0x000139DC
		public bool Boolean_2
		{
			get
			{
				if ((this.List_3.Count == 0 && this.List_0.Count == 0) || (this.List_3.Count == 1 && this.List_3[0].Boolean_1) || (this.List_0.Count == 1 && this.List_0[0] is GClass25))
				{
					return true;
				}
				foreach (Class11 @class in this.List_3)
				{
					if (!@class.Boolean_1)
					{
						return false;
					}
				}
				return true;
			}
		}

		// Token: 0x170001D6 RID: 470
		// (get) Token: 0x06000661 RID: 1633 RVA: 0x000062DC File Offset: 0x000044DC
		internal Class11 Class11_1
		{
			get
			{
				return this.List_3[this.List_3.Count - 1];
			}
		}

		// Token: 0x170001D7 RID: 471
		// (get) Token: 0x06000662 RID: 1634 RVA: 0x000062F6 File Offset: 0x000044F6
		internal List<Class15> List_1
		{
			get
			{
				return this.list_4;
			}
		}

		// Token: 0x170001D8 RID: 472
		// (get) Token: 0x06000663 RID: 1635 RVA: 0x000062FE File Offset: 0x000044FE
		// (set) Token: 0x06000664 RID: 1636 RVA: 0x00006306 File Offset: 0x00004506
		public PointF PointF_0
		{
			get
			{
				return this.pointF_0;
			}
			set
			{
				this.pointF_0 = value;
			}
		}

		// Token: 0x170001D9 RID: 473
		// (get) Token: 0x06000665 RID: 1637 RVA: 0x0000630F File Offset: 0x0000450F
		// (set) Token: 0x06000666 RID: 1638 RVA: 0x00015898 File Offset: 0x00013A98
		public GClass23 GClass23_2
		{
			get
			{
				return this.gclass23_1;
			}
			set
			{
				if (this.gclass23_1 != null && this.gclass23_1.List_0.Contains(this))
				{
					this.gclass23_1.List_0.Remove(this);
				}
				this.gclass23_1 = value;
				if (value != null && !value.List_0.Contains(this))
				{
					this.gclass23_1.List_0.Add(this);
					this.gclass28_0 = value.GClass28_0;
				}
			}
		}

		// Token: 0x170001DA RID: 474
		// (get) Token: 0x06000667 RID: 1639 RVA: 0x00006317 File Offset: 0x00004517
		internal List<Class15> List_2
		{
			get
			{
				return this.list_5;
			}
		}

		// Token: 0x170001DB RID: 475
		// (get) Token: 0x06000668 RID: 1640 RVA: 0x0000631F File Offset: 0x0000451F
		internal Dictionary<Class15, RectangleF> Dictionary_0
		{
			get
			{
				return this.dictionary_2;
			}
		}

		// Token: 0x170001DC RID: 476
		// (get) Token: 0x06000669 RID: 1641 RVA: 0x00015908 File Offset: 0x00013B08
		// (set) Token: 0x0600066A RID: 1642 RVA: 0x00015934 File Offset: 0x00013B34
		public float Single_30
		{
			get
			{
				return this.PointF_0.X + this.SizeF_0.Width;
			}
			set
			{
				this.SizeF_0 = new SizeF(value - this.PointF_0.X, this.SizeF_0.Height);
			}
		}

		// Token: 0x170001DD RID: 477
		// (get) Token: 0x0600066B RID: 1643 RVA: 0x00006327 File Offset: 0x00004527
		// (set) Token: 0x0600066C RID: 1644 RVA: 0x0000632F File Offset: 0x0000452F
		public SizeF SizeF_0
		{
			get
			{
				return this.sizeF_0;
			}
			set
			{
				this.sizeF_0 = value;
			}
		}

		// Token: 0x170001DE RID: 478
		// (get) Token: 0x0600066D RID: 1645 RVA: 0x00006338 File Offset: 0x00004538
		// (set) Token: 0x0600066E RID: 1646 RVA: 0x00006340 File Offset: 0x00004540
		public string String_69
		{
			get
			{
				return this.string_60;
			}
			set
			{
				this.string_60 = value;
				this.method_33();
			}
		}

		// Token: 0x170001DF RID: 479
		// (get) Token: 0x0600066F RID: 1647 RVA: 0x0000634F File Offset: 0x0000454F
		internal List<Class11> List_3
		{
			get
			{
				return this.list_2;
			}
		}

		// Token: 0x06000670 RID: 1648 RVA: 0x00006357 File Offset: 0x00004557
		private void method_0(GClass28 gclass28_1)
		{
			this.gclass28_0 = gclass28_1;
		}

		// Token: 0x06000671 RID: 1649 RVA: 0x0001596C File Offset: 0x00013B6C
		internal bool method_1()
		{
			foreach (GClass23 gclass in this.List_0)
			{
				if (gclass.String_47 != "inline")
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000672 RID: 1650 RVA: 0x000159D4 File Offset: 0x00013BD4
		private int method_2()
		{
			int num = 0;
			foreach (GClass23 gclass in this.GClass23_2.List_0)
			{
				if (gclass.String_47 == "list-item")
				{
					num++;
				}
				if (gclass.Equals(this))
				{
					return num;
				}
			}
			return num;
		}

		// Token: 0x06000673 RID: 1651 RVA: 0x00015A50 File Offset: 0x00013C50
		private void method_3(Graphics graphics_0)
		{
			if (this.String_47 == "list-item")
			{
				if (this.gclass23_2 == null)
				{
					this.gclass23_2 = new GClass23();
					this.gclass23_2.method_18(this, false);
					this.gclass23_2.String_47 = "inline";
					this.gclass23_2.method_0(this.GClass28_0);
					if (this.GClass23_2 != null && this.String_68 == "decimal")
					{
						this.gclass23_2.String_69 = this.method_2().ToString() + ".";
					}
					else
					{
						this.gclass23_2.String_69 = "•";
					}
					this.gclass23_2.vmethod_0(graphics_0);
					this.gclass23_2.SizeF_0 = new SizeF(this.gclass23_2.List_3[0].Single_2, this.gclass23_2.List_3[0].Single_3);
				}
				this.gclass23_2.List_3[0].Single_0 = this.PointF_0.X - this.gclass23_2.SizeF_0.Width - 5f;
				this.gclass23_2.List_3[0].Single_1 = this.PointF_0.Y + this.Single_0;
			}
		}

		// Token: 0x06000674 RID: 1652 RVA: 0x00015BB8 File Offset: 0x00013DB8
		internal Class11 method_4(GClass23 gclass23_3, Class15 class15_2)
		{
			if (gclass23_3.List_3.Count == 0 && gclass23_3.List_0.Count == 0)
			{
				return null;
			}
			if (gclass23_3.List_3.Count > 0)
			{
				foreach (Class11 @class in gclass23_3.List_3)
				{
					if (class15_2.List_1.Contains(@class))
					{
						return @class;
					}
				}
				return null;
			}
			foreach (GClass23 gclass23_4 in gclass23_3.List_0)
			{
				Class11 class2 = this.method_4(gclass23_4, class15_2);
				if (class2 != null)
				{
					return class2;
				}
			}
			return null;
		}

		// Token: 0x06000675 RID: 1653 RVA: 0x00006360 File Offset: 0x00004560
		internal string method_5(string string_70)
		{
			return this.method_6(string_70, string.Empty);
		}

		// Token: 0x06000676 RID: 1654 RVA: 0x0000636E File Offset: 0x0000456E
		internal string method_6(string string_70, string string_71)
		{
			if (this.GClass37_0 == null)
			{
				return string_71;
			}
			if (!this.GClass37_0.method_4(string_70))
			{
				return string_71;
			}
			return this.GClass37_0.Dictionary_0[string_70];
		}

		// Token: 0x06000677 RID: 1655 RVA: 0x00015C98 File Offset: 0x00013E98
		public float method_7()
		{
			return this.Font_1.GetHeight();
		}

		// Token: 0x06000678 RID: 1656 RVA: 0x00015CB4 File Offset: 0x00013EB4
		private GClass23 method_8(GClass23 gclass23_3)
		{
			if (gclass23_3.GClass23_2 == null)
			{
				return null;
			}
			int num = gclass23_3.GClass23_2.List_0.IndexOf(this);
			if (num < 0)
			{
				throw new Exception("Box doesn't exist on parent's Box list");
			}
			if (num == 0)
			{
				return null;
			}
			int num2 = 1;
			GClass23 gclass = gclass23_3.GClass23_2.List_0[num - 1];
			for (;;)
			{
				if (!(gclass.String_47 == "none"))
				{
					if (!(gclass.String_51 == "absolute"))
					{
						break;
					}
				}
				if (num - num2 - 1 < 0)
				{
					break;
				}
				gclass = gclass23_3.GClass23_2.List_0[num - ++num2];
			}
			if (!(gclass.String_47 == "none"))
			{
				return gclass;
			}
			return null;
		}

		// Token: 0x06000679 RID: 1657 RVA: 0x00015D68 File Offset: 0x00013F68
		internal float method_9()
		{
			float num = 0f;
			float num2 = 0f;
			Class11 @class = null;
			this.method_11(this, ref num, ref @class);
			if (@class != null)
			{
				this.method_10(@class.GClass23_0, this, ref num2);
			}
			return num + num2;
		}

		// Token: 0x0600067A RID: 1658 RVA: 0x00015DA4 File Offset: 0x00013FA4
		private void method_10(GClass23 gclass23_3, GClass23 gclass23_4, ref float float_24)
		{
			float num = gclass23_3.Single_9 + gclass23_3.Single_1 + gclass23_3.Single_11 + gclass23_3.Single_3;
			float_24 += num;
			if (!gclass23_3.Equals(gclass23_4))
			{
				this.method_10(gclass23_3.GClass23_2, gclass23_4, ref float_24);
			}
		}

		// Token: 0x0600067B RID: 1659 RVA: 0x00015DEC File Offset: 0x00013FEC
		private void method_11(GClass23 gclass23_3, ref float float_24, ref Class11 class11_0)
		{
			if (gclass23_3.List_3.Count > 0)
			{
				using (List<Class11>.Enumerator enumerator = gclass23_3.List_3.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						Class11 @class = enumerator.Current;
						if (@class.Single_6 > float_24)
						{
							float_24 = @class.Single_6;
							class11_0 = @class;
						}
					}
					return;
				}
			}
			foreach (GClass23 gclass23_4 in gclass23_3.List_0)
			{
				this.method_11(gclass23_4, ref float_24, ref class11_0);
			}
		}

		// Token: 0x0600067C RID: 1660 RVA: 0x00015EA4 File Offset: 0x000140A4
		internal float method_12(GClass23 gclass23_3, float float_24)
		{
			foreach (Class15 key in gclass23_3.Dictionary_0.Keys)
			{
				float_24 = Math.Max(float_24, gclass23_3.Dictionary_0[key].Bottom);
			}
			foreach (GClass23 gclass in gclass23_3.List_0)
			{
				float_24 = Math.Max(float_24, gclass.Single_22);
				float_24 = Math.Max(float_24, this.method_12(gclass, float_24));
			}
			return float_24;
		}

		// Token: 0x0600067D RID: 1661 RVA: 0x00015F78 File Offset: 0x00014178
		internal float method_13(Graphics graphics_0)
		{
			float num = 0f;
			float num2 = 0f;
			this.method_14(this, graphics_0, ref num, ref num2);
			return num2 + num;
		}

		// Token: 0x0600067E RID: 1662 RVA: 0x00015FA0 File Offset: 0x000141A0
		private void method_14(GClass23 gclass23_3, Graphics graphics_0, ref float float_24, ref float float_25)
		{
			if (gclass23_3.String_47 != "inline")
			{
				float_24 = 0f;
			}
			float_25 += gclass23_3.Single_9 + gclass23_3.Single_11 + gclass23_3.Single_3 + gclass23_3.Single_1;
			if (gclass23_3.List_3.Count > 0)
			{
				using (List<Class11>.Enumerator enumerator = gclass23_3.List_3.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						Class11 @class = enumerator.Current;
						float_24 += @class.Single_6;
					}
					return;
				}
			}
			foreach (GClass23 gclass23_4 in gclass23_3.List_0)
			{
				this.method_14(gclass23_4, graphics_0, ref float_24, ref float_25);
			}
		}

		// Token: 0x0600067F RID: 1663 RVA: 0x00016088 File Offset: 0x00014288
		private GClass23 method_15()
		{
			if (this.GClass23_2 == null)
			{
				return null;
			}
			int num = this.GClass23_2.List_0.IndexOf(this);
			if (num < 0)
			{
				throw new Exception("Box doesn't exist on parent's Box list");
			}
			if (num == this.GClass23_2.List_0.Count - 1)
			{
				return null;
			}
			return this.GClass23_2.List_0[num + 1];
		}

		// Token: 0x06000680 RID: 1664 RVA: 0x0000639B File Offset: 0x0000459B
		internal bool method_16()
		{
			return this.GClass23_2 != null && this.GClass23_2.method_1();
		}

		// Token: 0x06000681 RID: 1665 RVA: 0x000063B2 File Offset: 0x000045B2
		internal void method_17()
		{
			this.method_18(this.GClass23_2, false);
		}

		// Token: 0x06000682 RID: 1666 RVA: 0x000160EC File Offset: 0x000142EC
		internal void method_18(GClass23 gclass23_3, bool bool_2)
		{
			if (gclass23_3 != null)
			{
				IEnumerable<PropertyInfo> enumerable = bool_2 ? GClass23.list_1 : GClass23.list_0;
				foreach (PropertyInfo propertyInfo in enumerable)
				{
					propertyInfo.SetValue(this, propertyInfo.GetValue(gclass23_3, null), null);
				}
			}
		}

		// Token: 0x06000683 RID: 1667 RVA: 0x000063C1 File Offset: 0x000045C1
		private float method_19(GClass23 gclass23_3, GClass23 gclass23_4)
		{
			return Math.Max((gclass23_3 == null) ? 0f : gclass23_3.Single_6, (gclass23_4 == null) ? 0f : gclass23_4.Single_4);
		}

		// Token: 0x06000684 RID: 1668 RVA: 0x00016154 File Offset: 0x00014354
		public virtual void vmethod_0(Graphics graphics_0)
		{
			if (this.String_47 == "none")
			{
				return;
			}
			this.method_29();
			this.method_21(graphics_0);
			if (this.String_47 == "block" || this.String_47 == "list-item" || this.String_47 == "table" || this.String_47 == "inline-table" || this.String_47 == "table-cell" || this.String_47 == "none")
			{
				if (this.String_47 != "table-cell")
				{
					GClass23 gclass = this.method_8(this);
					float x = this.GClass23_1.PointF_0.X + this.GClass23_1.Single_1 + this.Single_5 + this.GClass23_1.Single_9;
					float num = ((gclass != null || this.GClass23_2 == null) ? 0f : this.GClass23_2.Single_24) + this.method_19(gclass, this) + ((gclass != null) ? (gclass.Single_22 + gclass.Single_10) : 0f);
					this.PointF_0 = new PointF(x, num);
					this.Single_22 = num;
				}
				if (this.String_47 != "table-cell" && this.String_47 != "table")
				{
					float num2 = this.method_9();
					float num3 = this.GClass23_1.SizeF_0.Width - this.GClass23_1.Single_1 - this.GClass23_1.Single_3 - this.GClass23_1.Single_9 - this.GClass23_1.Single_11 - this.Single_5 - this.Single_7 - this.Single_9 - this.Single_11;
					if (this.String_39 != "auto" && !string.IsNullOrEmpty(this.String_39))
					{
						num3 = GClass34.smethod_1(this.String_39, num3, this);
					}
					if (num3 < num2)
					{
						num3 = num2;
					}
					this.SizeF_0 = new SizeF(num3, this.SizeF_0.Height);
				}
				if (!(this.String_47 == "table") && !(this.String_47 == "inline-table"))
				{
					if (this.String_47 != "none")
					{
						if (this.method_1())
						{
							this.Single_22 = this.PointF_0.Y;
							Class14.smethod_0(graphics_0, this);
						}
						else
						{
							GClass23 gclass2 = null;
							foreach (GClass23 gclass3 in this.List_0)
							{
								if (!(gclass3.String_47 == "none"))
								{
									gclass3.vmethod_0(graphics_0);
									gclass2 = gclass3;
								}
							}
							if (gclass2 != null)
							{
								this.Single_22 = Math.Max(this.Single_22, gclass2.Single_22 + gclass2.Single_6 + this.Single_2);
							}
						}
					}
				}
				else
				{
					new Class16(this, graphics_0);
				}
			}
			if (this.GClass28_0 != null)
			{
				this.GClass28_0.SizeF_1 = new SizeF(Math.Max(this.GClass28_0.SizeF_1.Width, this.Single_30), Math.Max(this.GClass28_0.SizeF_1.Height, this.Single_22));
			}
		}

		// Token: 0x06000685 RID: 1669 RVA: 0x000164D4 File Offset: 0x000146D4
		private void method_20(Graphics graphics_0)
		{
			this.float_20 = Class14.smethod_3(graphics_0, this);
			if (this.String_58 != "normal")
			{
				string text = Class17.smethod_1("([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)", this.String_58);
				this.float_20 += GClass34.smethod_1(text, 1f, this);
			}
		}

		// Token: 0x06000686 RID: 1670 RVA: 0x0001652C File Offset: 0x0001472C
		internal void method_21(Graphics graphics_0)
		{
			if (this.bool_1)
			{
				return;
			}
			if (float.IsNaN(this.float_20))
			{
				this.method_20(graphics_0);
			}
			if (this.GClass37_0 != null && this.GClass37_0.String_0.Equals("img", StringComparison.CurrentCultureIgnoreCase))
			{
				Class11 item = new Class11(this, GClass34.smethod_9(this.method_5("src")));
				this.List_3.Clear();
				this.List_3.Add(item);
			}
			else
			{
				bool flag = false;
				foreach (Class11 @class in this.List_3)
				{
					bool flag2 = Class12.smethod_0(this);
					if (Class12.smethod_1(this))
					{
						@class.method_0();
					}
					if (@class.Boolean_1)
					{
						@class.Single_3 = this.Single_28;
						if (@class.Boolean_3)
						{
							@class.Single_2 = this.Single_16 * 4f;
						}
						else if (@class.Boolean_2)
						{
							@class.Single_2 = 0f;
						}
						else if (!flag || !flag2)
						{
							@class.Single_2 = this.Single_16 * (float)(flag2 ? 1 : @class.String_0.Length);
						}
						flag = true;
					}
					else
					{
						string text = @class.String_0;
						CharacterRange[] measurableCharacterRanges = new CharacterRange[]
						{
							new CharacterRange(0, text.Length)
						};
						StringFormat stringFormat = new StringFormat();
						stringFormat.SetMeasurableCharacterRanges(measurableCharacterRanges);
						Region[] array = graphics_0.MeasureCharacterRanges(text, this.Font_1, new RectangleF(0f, 0f, float.MaxValue, float.MaxValue), stringFormat);
						SizeF size = array[0].GetBounds(graphics_0).Size;
						PointF location = array[0].GetBounds(graphics_0).Location;
						@class.PointF_1 = new PointF(location.X, location.Y);
						@class.Single_2 = size.Width;
						@class.Single_3 = size.Height;
						flag = false;
					}
				}
			}
			this.bool_1 = true;
		}

		// Token: 0x06000687 RID: 1671 RVA: 0x00016760 File Offset: 0x00014960
		private string method_22(string string_70)
		{
			GClass33 gclass = new GClass33(string_70);
			if (gclass.GEnum4_0 == GClass33.GEnum4.const_1)
			{
				string_70 = gclass.method_1(this.method_7()).ToString();
			}
			return string_70;
		}

		// Token: 0x06000688 RID: 1672 RVA: 0x00016794 File Offset: 0x00014994
		internal void method_23(float float_24)
		{
			List<Class15> list = new List<Class15>();
			foreach (Class15 item in this.Dictionary_0.Keys)
			{
				list.Add(item);
			}
			foreach (Class15 key in list)
			{
				RectangleF rectangleF = this.Dictionary_0[key];
				this.Dictionary_0[key] = new RectangleF(rectangleF.X, rectangleF.Y + float_24, rectangleF.Width, rectangleF.Height);
			}
			foreach (Class11 @class in this.List_3)
			{
				@class.Single_1 += float_24;
			}
			foreach (GClass23 gclass in this.List_0)
			{
				gclass.method_23(float_24);
			}
			this.PointF_0 = new PointF(this.PointF_0.X, this.PointF_0.Y + float_24);
		}

		// Token: 0x06000689 RID: 1673 RVA: 0x00016928 File Offset: 0x00014B28
		public void method_24(Graphics graphics_0)
		{
			if (this.String_47 == "none")
			{
				return;
			}
			if (this.String_47 == "table-cell" && this.String_49 == "hide" && this.Boolean_2)
			{
				return;
			}
			List<RectangleF> list = (this.Dictionary_0.Count == 0) ? new List<RectangleF>(new RectangleF[]
			{
				this.RectangleF_0
			}) : new List<RectangleF>(this.Dictionary_0.Values);
			RectangleF[] array = list.ToArray();
			PointF pos = (this.GClass28_0 != null) ? this.GClass28_0.PointF_1 : PointF.Empty;
			for (int i = 0; i < array.Length; i++)
			{
				RectangleF rectangleF = array[i];
				rectangleF.Offset(pos);
				if (this.GClass28_0 != null && this.GClass37_0 != null && this.GClass37_0.String_0.Equals("a", StringComparison.CurrentCultureIgnoreCase))
				{
					if (this.GClass28_0.Dictionary_1.ContainsKey(this))
					{
						this.GClass28_0.Dictionary_1.Remove(this);
					}
					this.GClass28_0.Dictionary_1.Add(this, rectangleF);
				}
				this.method_26(graphics_0, rectangleF);
				this.method_25(graphics_0, rectangleF, i == 0, i == array.Length - 1);
			}
			if (this.Boolean_0)
			{
				RectangleF rectangleF_ = this.List_3[0].RectangleF_0;
				rectangleF_.Offset(pos);
				rectangleF_.Height -= this.Single_8 + this.Single_10 + this.Single_0 + this.Single_2;
				rectangleF_.Y += this.Single_8 + this.Single_0;
				graphics_0.DrawImage(this.List_3[0].Image_0, Rectangle.Round(rectangleF_));
			}
			else
			{
				Font font_ = this.Font_1;
				using (SolidBrush solidBrush = new SolidBrush(GClass34.smethod_3(this.String_46)))
				{
					foreach (Class11 @class in this.List_3)
					{
						graphics_0.DrawString(@class.String_0, font_, solidBrush, @class.Single_0 - @class.PointF_1.X + pos.X, @class.Single_1 + pos.Y);
					}
				}
			}
			for (int j = 0; j < array.Length; j++)
			{
				RectangleF rectangleF_2 = array[j];
				rectangleF_2.Offset(pos);
				this.method_27(graphics_0, rectangleF_2, j == 0, j == array.Length - 1);
			}
			foreach (GClass23 gclass in this.List_0)
			{
				gclass.method_24(graphics_0);
			}
			this.method_3(graphics_0);
			if (this.GClass23_0 != null)
			{
				this.GClass23_0.method_24(graphics_0);
			}
		}

		// Token: 0x0600068A RID: 1674 RVA: 0x00016C6C File Offset: 0x00014E6C
		private void method_25(Graphics graphics_0, RectangleF rectangleF_0, bool bool_2, bool bool_3)
		{
			SmoothingMode smoothingMode = graphics_0.SmoothingMode;
			if (this.GClass28_0 != null && !this.GClass28_0.Boolean_3 && this.Boolean_1)
			{
				graphics_0.SmoothingMode = SmoothingMode.AntiAlias;
			}
			if (!string.IsNullOrEmpty(this.String_9) && !(this.String_9 == "none"))
			{
				using (SolidBrush solidBrush = new SolidBrush(this.Color_0))
				{
					if (this.String_9 == "inset")
					{
						solidBrush.Color = Class13.smethod_5(this.Color_0);
					}
					graphics_0.FillPath(solidBrush, Class13.smethod_2(Class13.Enum1.const_0, this, rectangleF_0, bool_2, bool_3));
				}
			}
			if (bool_3 && !string.IsNullOrEmpty(this.String_7) && !(this.String_7 == "none"))
			{
				using (SolidBrush solidBrush2 = new SolidBrush(this.Color_3))
				{
					if (this.String_7 == "outset")
					{
						solidBrush2.Color = Class13.smethod_5(this.Color_3);
					}
					graphics_0.FillPath(solidBrush2, Class13.smethod_2(Class13.Enum1.const_1, this, rectangleF_0, bool_2, bool_3));
				}
			}
			if (!string.IsNullOrEmpty(this.String_5) && !(this.String_5 == "none"))
			{
				using (SolidBrush solidBrush3 = new SolidBrush(this.Color_2))
				{
					if (this.String_5 == "outset")
					{
						solidBrush3.Color = Class13.smethod_5(this.Color_2);
					}
					graphics_0.FillPath(solidBrush3, Class13.smethod_2(Class13.Enum1.const_2, this, rectangleF_0, bool_2, bool_3));
				}
			}
			if (bool_2 && !string.IsNullOrEmpty(this.String_6) && !(this.String_6 == "none"))
			{
				using (SolidBrush solidBrush4 = new SolidBrush(this.Color_1))
				{
					if (this.String_6 == "inset")
					{
						solidBrush4.Color = Class13.smethod_5(this.Color_1);
					}
					graphics_0.FillPath(solidBrush4, Class13.smethod_2(Class13.Enum1.const_3, this, rectangleF_0, bool_2, bool_3));
				}
			}
			graphics_0.SmoothingMode = smoothingMode;
		}

		// Token: 0x0600068B RID: 1675 RVA: 0x00016E9C File Offset: 0x0001509C
		private void method_26(Graphics graphics_0, RectangleF rectangleF_0)
		{
			if (this.GClass23_1.String_55 == "justify")
			{
				return;
			}
			GraphicsPath graphicsPath = null;
			SmoothingMode smoothingMode = graphics_0.SmoothingMode;
			if (this.Boolean_1)
			{
				graphicsPath = Class13.smethod_4(rectangleF_0, this.Single_12, this.Single_13, this.Single_14, this.Single_15);
			}
			Brush brush;
			if (this.String_44 != "none" && rectangleF_0.Width > 0f && rectangleF_0.Height > 0f)
			{
				brush = new LinearGradientBrush(rectangleF_0, this.Color_5, this.Color_6, this.Single_17);
			}
			else
			{
				brush = new SolidBrush(this.Color_5);
			}
			if (this.GClass28_0 != null && !this.GClass28_0.Boolean_3 && this.Boolean_1)
			{
				graphics_0.SmoothingMode = SmoothingMode.AntiAlias;
			}
			if (graphicsPath != null)
			{
				graphics_0.FillPath(brush, graphicsPath);
			}
			else
			{
				graphics_0.FillRectangle(brush, rectangleF_0);
			}
			graphics_0.SmoothingMode = smoothingMode;
			if (graphicsPath != null)
			{
				graphicsPath.Dispose();
			}
			if (brush != null)
			{
				brush.Dispose();
			}
		}

		// Token: 0x0600068C RID: 1676 RVA: 0x00016F9C File Offset: 0x0001519C
		private void method_27(Graphics graphics_0, RectangleF rectangleF_0, bool bool_2, bool bool_3)
		{
			if (!string.IsNullOrEmpty(this.String_56) && !(this.String_56 == "none") && !this.Boolean_0)
			{
				float num = Class14.smethod_7(this.Font_1);
				float num2 = Class14.smethod_6(this.Font_1);
				float num3 = 0f;
				if (this.String_56 == "underline")
				{
					num3 = rectangleF_0.Bottom - num;
				}
				else if (this.String_56 == "line-through")
				{
					num3 = rectangleF_0.Bottom - num - num2 / 2f;
				}
				else if (this.String_56 == "overline")
				{
					num3 = rectangleF_0.Bottom - num - num2 - 2f;
				}
				num3 -= this.Single_2 - this.Single_10;
				float num4 = rectangleF_0.X;
				float num5 = rectangleF_0.Right;
				if (bool_2)
				{
					num4 += this.Single_1 + this.Single_9;
				}
				if (bool_3)
				{
					num5 -= this.Single_3 + this.Single_11;
				}
				graphics_0.DrawLine(new Pen(this.Color_4), num4, num3, num5, num3);
				return;
			}
		}

		// Token: 0x0600068D RID: 1677 RVA: 0x000170C0 File Offset: 0x000152C0
		internal void method_28(Class15 class15_2, float float_24)
		{
			if (this.Dictionary_0.ContainsKey(class15_2))
			{
				RectangleF rectangleF = this.Dictionary_0[class15_2];
				this.Dictionary_0[class15_2] = new RectangleF(rectangleF.X, rectangleF.Y + float_24, rectangleF.Width, rectangleF.Height);
			}
		}

		// Token: 0x0600068E RID: 1678 RVA: 0x000063E8 File Offset: 0x000045E8
		internal void method_29()
		{
			this.dictionary_2.Clear();
		}

		// Token: 0x0600068F RID: 1679 RVA: 0x00017118 File Offset: 0x00015318
		internal void method_30()
		{
			for (int i = 0; i < this.List_0.Count; i++)
			{
				if (this.List_0[i] is GClass25 || this.List_0[i] is GClass27)
				{
					this.List_0.RemoveAt(i);
					i--;
				}
			}
		}

		// Token: 0x06000690 RID: 1680 RVA: 0x000063F5 File Offset: 0x000045F5
		public void method_31(Rectangle rectangle_0)
		{
			this.method_32(new RectangleF((float)rectangle_0.X, (float)rectangle_0.Y, (float)rectangle_0.Width, (float)rectangle_0.Height));
		}

		// Token: 0x06000691 RID: 1681 RVA: 0x00006422 File Offset: 0x00004622
		public void method_32(RectangleF rectangleF_0)
		{
			this.SizeF_0 = rectangleF_0.Size;
			this.PointF_0 = rectangleF_0.Location;
		}

		// Token: 0x06000692 RID: 1682 RVA: 0x00017174 File Offset: 0x00015374
		public override string ToString()
		{
			string arg = base.GetType().Name;
			if (this.GClass37_0 != null)
			{
				arg = string.Format("<{0}>", this.GClass37_0.String_0);
			}
			if (this.GClass23_2 == null)
			{
				return "Initial Container";
			}
			if (this.String_47 == "block")
			{
				return string.Format("{0} BlockBox {2}, Children:{1}", arg, this.List_0.Count, this.String_61);
			}
			if (this.String_47 == "none")
			{
				return string.Format("{0} None", arg);
			}
			return string.Format("{0} {2}: {1}", arg, this.String_69, this.String_47);
		}

		// Token: 0x06000693 RID: 1683 RVA: 0x00017224 File Offset: 0x00015424
		private void method_33()
		{
			this.List_3.Clear();
			Class12 @class = new Class12(this, this.String_69);
			@class.method_0();
			this.List_3.AddRange(@class.List_0);
		}

		// Token: 0x040001F6 RID: 502
		internal static readonly GClass23 gclass23_0;

		// Token: 0x040001F7 RID: 503
		internal static Dictionary<string, PropertyInfo> dictionary_0 = new Dictionary<string, PropertyInfo>();

		// Token: 0x040001F8 RID: 504
		private static Dictionary<string, string> dictionary_1 = new Dictionary<string, string>();

		// Token: 0x040001F9 RID: 505
		private static List<PropertyInfo> list_0 = new List<PropertyInfo>();

		// Token: 0x040001FA RID: 506
		private static List<PropertyInfo> list_1 = new List<PropertyInfo>();

		// Token: 0x040001FB RID: 507
		private string string_0;

		// Token: 0x040001FC RID: 508
		private string string_1;

		// Token: 0x040001FD RID: 509
		private string string_2;

		// Token: 0x040001FE RID: 510
		private string string_3;

		// Token: 0x040001FF RID: 511
		private string string_4;

		// Token: 0x04000200 RID: 512
		private string string_5;

		// Token: 0x04000201 RID: 513
		private string string_6;

		// Token: 0x04000202 RID: 514
		private string string_7;

		// Token: 0x04000203 RID: 515
		private string string_8;

		// Token: 0x04000204 RID: 516
		private string string_9;

		// Token: 0x04000205 RID: 517
		private string string_10;

		// Token: 0x04000206 RID: 518
		private string string_11;

		// Token: 0x04000207 RID: 519
		private string string_12;

		// Token: 0x04000208 RID: 520
		private string string_13;

		// Token: 0x04000209 RID: 521
		private string string_14;

		// Token: 0x0400020A RID: 522
		private string string_15;

		// Token: 0x0400020B RID: 523
		private string string_16;

		// Token: 0x0400020C RID: 524
		private string string_17;

		// Token: 0x0400020D RID: 525
		private string string_18;

		// Token: 0x0400020E RID: 526
		private string string_19;

		// Token: 0x0400020F RID: 527
		private string string_20;

		// Token: 0x04000210 RID: 528
		private string string_21;

		// Token: 0x04000211 RID: 529
		private string string_22;

		// Token: 0x04000212 RID: 530
		private string string_23;

		// Token: 0x04000213 RID: 531
		private string string_24;

		// Token: 0x04000214 RID: 532
		private string string_25;

		// Token: 0x04000215 RID: 533
		private string string_26;

		// Token: 0x04000216 RID: 534
		private string string_27;

		// Token: 0x04000217 RID: 535
		private string string_28;

		// Token: 0x04000218 RID: 536
		private string string_29;

		// Token: 0x04000219 RID: 537
		private string string_30;

		// Token: 0x0400021A RID: 538
		private string string_31;

		// Token: 0x0400021B RID: 539
		private string string_32;

		// Token: 0x0400021C RID: 540
		private string string_33;

		// Token: 0x0400021D RID: 541
		private string string_34;

		// Token: 0x0400021E RID: 542
		private string string_35;

		// Token: 0x0400021F RID: 543
		private string string_36;

		// Token: 0x04000220 RID: 544
		private string string_37;

		// Token: 0x04000221 RID: 545
		private string string_38;

		// Token: 0x04000222 RID: 546
		private string string_39;

		// Token: 0x04000223 RID: 547
		private string string_40;

		// Token: 0x04000224 RID: 548
		private string string_41;

		// Token: 0x04000225 RID: 549
		private string string_42;

		// Token: 0x04000226 RID: 550
		private string string_43;

		// Token: 0x04000227 RID: 551
		private string string_44;

		// Token: 0x04000228 RID: 552
		private string string_45;

		// Token: 0x04000229 RID: 553
		private string string_46;

		// Token: 0x0400022A RID: 554
		private string string_47;

		// Token: 0x0400022B RID: 555
		private string string_48;

		// Token: 0x0400022C RID: 556
		private string string_49;

		// Token: 0x0400022D RID: 557
		private string string_50;

		// Token: 0x0400022E RID: 558
		private string string_51;

		// Token: 0x0400022F RID: 559
		private string string_52;

		// Token: 0x04000230 RID: 560
		private string string_53;

		// Token: 0x04000231 RID: 561
		private string string_54;

		// Token: 0x04000232 RID: 562
		private string string_55;

		// Token: 0x04000233 RID: 563
		private string string_56;

		// Token: 0x04000234 RID: 564
		private string string_57;

		// Token: 0x04000235 RID: 565
		private string string_58;

		// Token: 0x04000236 RID: 566
		private string string_59;

		// Token: 0x04000237 RID: 567
		private string string_60;

		// Token: 0x04000238 RID: 568
		private string string_61;

		// Token: 0x04000239 RID: 569
		private string string_62;

		// Token: 0x0400023A RID: 570
		private string string_63;

		// Token: 0x0400023B RID: 571
		private string string_64;

		// Token: 0x0400023C RID: 572
		private string string_65;

		// Token: 0x0400023D RID: 573
		private string string_66;

		// Token: 0x0400023E RID: 574
		private string string_67;

		// Token: 0x0400023F RID: 575
		private string string_68;

		// Token: 0x04000240 RID: 576
		private string string_69;

		// Token: 0x04000241 RID: 577
		internal bool bool_0;

		// Token: 0x04000242 RID: 578
		private List<Class11> list_2;

		// Token: 0x04000243 RID: 579
		private List<GClass23> list_3;

		// Token: 0x04000244 RID: 580
		private GClass23 gclass23_1;

		// Token: 0x04000245 RID: 581
		private bool bool_1;

		// Token: 0x04000246 RID: 582
		private SizeF sizeF_0;

		// Token: 0x04000247 RID: 583
		private PointF pointF_0;

		// Token: 0x04000248 RID: 584
		private List<Class15> list_4;

		// Token: 0x04000249 RID: 585
		private List<Class15> list_5;

		// Token: 0x0400024A RID: 586
		private float float_0 = float.NaN;

		// Token: 0x0400024B RID: 587
		private float float_1 = float.NaN;

		// Token: 0x0400024C RID: 588
		private float float_2 = float.NaN;

		// Token: 0x0400024D RID: 589
		private GClass37 gclass37_0;

		// Token: 0x0400024E RID: 590
		private Dictionary<Class15, RectangleF> dictionary_2;

		// Token: 0x0400024F RID: 591
		protected GClass28 gclass28_0;

		// Token: 0x04000250 RID: 592
		private GClass23 gclass23_2;

		// Token: 0x04000251 RID: 593
		private Class15 class15_0;

		// Token: 0x04000252 RID: 594
		private Class15 class15_1;

		// Token: 0x04000253 RID: 595
		private float float_3 = float.NaN;

		// Token: 0x04000254 RID: 596
		private float float_4 = float.NaN;

		// Token: 0x04000255 RID: 597
		private float float_5 = float.NaN;

		// Token: 0x04000256 RID: 598
		private float float_6 = float.NaN;

		// Token: 0x04000257 RID: 599
		private Color color_0 = Color.Empty;

		// Token: 0x04000258 RID: 600
		private float float_7 = float.NaN;

		// Token: 0x04000259 RID: 601
		private float float_8 = float.NaN;

		// Token: 0x0400025A RID: 602
		private float float_9 = float.NaN;

		// Token: 0x0400025B RID: 603
		private float float_10 = float.NaN;

		// Token: 0x0400025C RID: 604
		private float float_11 = float.NaN;

		// Token: 0x0400025D RID: 605
		private float float_12 = float.NaN;

		// Token: 0x0400025E RID: 606
		private float float_13 = float.NaN;

		// Token: 0x0400025F RID: 607
		private float float_14 = float.NaN;

		// Token: 0x04000260 RID: 608
		private float float_15 = float.NaN;

		// Token: 0x04000261 RID: 609
		private float float_16 = float.NaN;

		// Token: 0x04000262 RID: 610
		private float float_17 = float.NaN;

		// Token: 0x04000263 RID: 611
		private float float_18 = float.NaN;

		// Token: 0x04000264 RID: 612
		private float float_19 = float.NaN;

		// Token: 0x04000265 RID: 613
		private Color color_1 = Color.Empty;

		// Token: 0x04000266 RID: 614
		private Color color_2 = Color.Empty;

		// Token: 0x04000267 RID: 615
		private Color color_3 = Color.Empty;

		// Token: 0x04000268 RID: 616
		private Color color_4 = Color.Empty;

		// Token: 0x04000269 RID: 617
		private Color color_5 = Color.Empty;

		// Token: 0x0400026A RID: 618
		private float float_20 = float.NaN;

		// Token: 0x0400026B RID: 619
		private Color color_6 = Color.Empty;

		// Token: 0x0400026C RID: 620
		private Font font_0;

		// Token: 0x0400026D RID: 621
		private float float_21 = float.NaN;

		// Token: 0x0400026E RID: 622
		private float float_22 = float.NaN;

		// Token: 0x0400026F RID: 623
		private float float_23 = float.NaN;
	}
}
