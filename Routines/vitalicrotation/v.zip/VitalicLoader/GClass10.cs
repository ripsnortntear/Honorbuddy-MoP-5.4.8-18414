﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000030 RID: 48
	public class GClass10 : GInterface4
	{
		// Token: 0x060001B2 RID: 434 RVA: 0x00002E64 File Offset: 0x00001064
		public object imethod_0(string string_0)
		{
			return string_0;
		}

		// Token: 0x060001B3 RID: 435 RVA: 0x00002E67 File Offset: 0x00001067
		public void imethod_1(string string_0, Control control_0)
		{
			if (this.gdelegate4_0 != null)
			{
				this.gdelegate4_0(this, new GEventArgs2(string_0, control_0));
			}
		}

		// Token: 0x060001B4 RID: 436 RVA: 0x00002470 File Offset: 0x00000670
		public void imethod_2(Control control_0)
		{
		}

		// Token: 0x1400000B RID: 11
		// (add) Token: 0x060001B5 RID: 437 RVA: 0x0000B994 File Offset: 0x00009B94
		// (remove) Token: 0x060001B6 RID: 438 RVA: 0x0000B9CC File Offset: 0x00009BCC
		public event GDelegate4 Event_0
		{
			add
			{
				GDelegate4 gdelegate = this.gdelegate4_0;
				GDelegate4 gdelegate2;
				do
				{
					gdelegate2 = gdelegate;
					GDelegate4 value2 = (GDelegate4)Delegate.Combine(gdelegate2, value);
					gdelegate = Interlocked.CompareExchange<GDelegate4>(ref this.gdelegate4_0, value2, gdelegate2);
				}
				while (gdelegate != gdelegate2);
			}
			remove
			{
				GDelegate4 gdelegate = this.gdelegate4_0;
				GDelegate4 gdelegate2;
				do
				{
					gdelegate2 = gdelegate;
					GDelegate4 value2 = (GDelegate4)Delegate.Remove(gdelegate2, value);
					gdelegate = Interlocked.CompareExchange<GDelegate4>(ref this.gdelegate4_0, value2, gdelegate2);
				}
				while (gdelegate != gdelegate2);
			}
		}

		// Token: 0x040000B3 RID: 179
		private GDelegate4 gdelegate4_0;
	}
}
