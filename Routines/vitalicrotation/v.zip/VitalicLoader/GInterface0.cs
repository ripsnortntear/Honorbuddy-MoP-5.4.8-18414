﻿using System;

namespace ns0
{
	// Token: 0x02000019 RID: 25
	public interface GInterface0
	{
		// Token: 0x17000011 RID: 17
		// (get) Token: 0x0600008E RID: 142
		// (set) Token: 0x0600008F RID: 143
		GEnum10 GEnum10_0 { get; set; }

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000090 RID: 144
		// (set) Token: 0x06000091 RID: 145
		GEnum29 GEnum29_0 { get; set; }

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000092 RID: 146
		// (set) Token: 0x06000093 RID: 147
		GClass8 GClass8_0 { get; set; }
	}
}
