﻿using System;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000009 RID: 9
	public abstract class GClass3
	{
		// Token: 0x14000001 RID: 1
		// (add) Token: 0x06000027 RID: 39 RVA: 0x00007CA8 File Offset: 0x00005EA8
		// (remove) Token: 0x06000028 RID: 40 RVA: 0x00007CE0 File Offset: 0x00005EE0
		public event EventHandler Event_0
		{
			add
			{
				EventHandler eventHandler = this.eventHandler_0;
				EventHandler eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler eventHandler = this.eventHandler_0;
				EventHandler eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000029 RID: 41 RVA: 0x00002246 File Offset: 0x00000446
		private void method_0()
		{
			if (this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, EventArgs.Empty);
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x0600002A RID: 42 RVA: 0x00002261 File Offset: 0x00000461
		public bool Boolean_0
		{
			get
			{
				return this.class1_0 == null || !this.class1_0.Boolean_1;
			}
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x0600002B RID: 43 RVA: 0x0000227B File Offset: 0x0000047B
		public bool Boolean_1
		{
			get
			{
				return this.class1_0 != null && this.class1_0.Boolean_1;
			}
		}

		// Token: 0x0600002C RID: 44 RVA: 0x00002292 File Offset: 0x00000492
		public void method_1()
		{
			if (this.Boolean_1)
			{
				this.class1_0.method_4();
			}
		}

		// Token: 0x0600002D RID: 45 RVA: 0x000022A7 File Offset: 0x000004A7
		protected void method_2(Control control_1, GEnum0 genum0_1, int int_3, GDelegate0 gdelegate0_1)
		{
			this.method_3(control_1, genum0_1, int_3, gdelegate0_1, null);
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00007D18 File Offset: 0x00005F18
		protected void method_3(Control control_1, GEnum0 genum0_1, int int_3, GDelegate0 gdelegate0_1, GDelegate1 gdelegate1_1)
		{
			this.control_0 = control_1;
			this.genum0_0 = genum0_1;
			this.gdelegate0_0 = gdelegate0_1;
			this.gdelegate1_0 = gdelegate1_1;
			this.int_0 = 0;
			this.int_1 = 0;
			this.int_2 = int_3;
			this.class1_0 = Class1.smethod_2(new Class1.Delegate0(this.method_4), int_3);
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00007D70 File Offset: 0x00005F70
		private void method_4()
		{
			if (this.gdelegate1_0 != null && !this.gdelegate1_0())
			{
				this.gdelegate0_0();
				this.int_0++;
				this.class1_0.method_3();
				return;
			}
			this.method_0();
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00007DC0 File Offset: 0x00005FC0
		protected int method_5(float float_0, float float_1, float float_2, float float_3)
		{
			switch (this.genum0_0)
			{
			case GEnum0.const_0:
				return (int)(float_3 * float_0 / float_2 + float_1);
			case GEnum0.const_1:
				return (int)(float_3 * (float_0 /= float_2) * float_0 + float_1);
			case GEnum0.const_2:
				return (int)(-float_3 * (float_0 /= float_2) * (float_0 - 2f) + float_1);
			case GEnum0.const_3:
				if ((float_0 /= float_2 / 2f) < 1f)
				{
					return (int)(float_3 / 2f * float_0 * float_0 + float_1);
				}
				return (int)(-float_3 / 2f * ((float_0 -= 1f) * (float_0 - 2f) - 1f) + float_1);
			case GEnum0.const_4:
				return (int)(float_3 * (float_0 /= float_2) * float_0 * float_0 + float_1);
			case GEnum0.const_5:
				return (int)(float_3 * ((float_0 = float_0 / float_2 - 1f) * float_0 * float_0 + 1f) + float_1);
			case GEnum0.const_6:
				if ((float_0 /= float_2 / 2f) < 1f)
				{
					return (int)(float_3 / 2f * float_0 * float_0 * float_0 + float_1);
				}
				return (int)(float_3 / 2f * ((float_0 -= 2f) * float_0 * float_0 + 2f) + float_1);
			case GEnum0.const_7:
				return (int)(float_3 * (float_0 /= float_2) * float_0 * float_0 * float_0 + float_1);
			case GEnum0.const_8:
				if (float_0 == 0f)
				{
					return (int)float_1;
				}
				return (int)((double)float_3 * Math.Pow(2.0, (double)(10f * (float_0 / float_2 - 1f))) + (double)float_1);
			case GEnum0.const_9:
				if (float_0 == float_2)
				{
					return (int)(float_1 + float_3);
				}
				return (int)((double)float_3 * (-Math.Pow(2.0, (double)(-10f * float_0 / float_2)) + 1.0) + (double)float_1);
			default:
				return 0;
			}
		}

		// Token: 0x04000014 RID: 20
		private EventHandler eventHandler_0;

		// Token: 0x04000015 RID: 21
		private Class1 class1_0;

		// Token: 0x04000016 RID: 22
		private Control control_0;

		// Token: 0x04000017 RID: 23
		private GDelegate0 gdelegate0_0;

		// Token: 0x04000018 RID: 24
		private GDelegate1 gdelegate1_0;

		// Token: 0x04000019 RID: 25
		protected GEnum0 genum0_0;

		// Token: 0x0400001A RID: 26
		protected int int_0;

		// Token: 0x0400001B RID: 27
		protected int int_1;

		// Token: 0x0400001C RID: 28
		protected int int_2;
	}
}
