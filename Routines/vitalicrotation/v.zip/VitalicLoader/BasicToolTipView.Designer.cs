﻿namespace ns0
{
	// Token: 0x02000028 RID: 40
	public partial class BasicToolTipView : global::ns0.GForm0, global::ns0.GInterface1, global::ns0.GInterface3
	{
		// Token: 0x0600017F RID: 383 RVA: 0x00002C86 File Offset: 0x00000E86
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.icontainer_0 != null)
			{
				this.icontainer_0.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000180 RID: 384 RVA: 0x0000B384 File Offset: 0x00009584
		private void InitializeComponent()
		{
			this.panel = new global::System.Windows.Forms.Panel();
			this.panel.SuspendLayout();
			base.SuspendLayout();
			this.panel.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.panel.Location = new global::System.Drawing.Point(0, 0);
			this.panel.Name = "panel";
			this.panel.Size = new global::System.Drawing.Size(56, 56);
			this.panel.TabIndex = 1;
			this.panel.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panel_Paint);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.SystemColors.MenuHighlight;
			base.ClientSize = new global::System.Drawing.Size(56, 56);
			base.Controls.Add(this.panel);
			this.DoubleBuffered = true;
			base.FormBorderStyle_0 = global::System.Windows.Forms.FormBorderStyle.None;
			base.Name = "BasicToolTipView";
			base.ShowInTaskbar = false;
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "BasicToolTipView";
			base.TopMost = true;
			this.panel.ResumeLayout(false);
			base.ResumeLayout(false);
		}

		// Token: 0x0400009A RID: 154
		private global::System.ComponentModel.IContainer icontainer_0;

		// Token: 0x0400009B RID: 155
		private global::System.Windows.Forms.Panel panel;
	}
}
