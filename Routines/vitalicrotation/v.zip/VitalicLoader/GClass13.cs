﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000035 RID: 53
	[ToolboxBitmap(typeof(CheckBox))]
	[Designer("MetroFramework.Design.Controls.MetroCheckBoxDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	public class GClass13 : CheckBox, GInterface2
	{
		// Token: 0x06000203 RID: 515 RVA: 0x000032BD File Offset: 0x000014BD
		public GClass13()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x1400000F RID: 15
		// (add) Token: 0x06000204 RID: 516 RVA: 0x0000C28C File Offset: 0x0000A48C
		// (remove) Token: 0x06000205 RID: 517 RVA: 0x0000C2C4 File Offset: 0x0000A4C4
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000206 RID: 518 RVA: 0x000032D8 File Offset: 0x000014D8
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000010 RID: 16
		// (add) Token: 0x06000207 RID: 519 RVA: 0x0000C2FC File Offset: 0x0000A4FC
		// (remove) Token: 0x06000208 RID: 520 RVA: 0x0000C334 File Offset: 0x0000A534
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000209 RID: 521 RVA: 0x000032F8 File Offset: 0x000014F8
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000011 RID: 17
		// (add) Token: 0x0600020A RID: 522 RVA: 0x0000C36C File Offset: 0x0000A56C
		// (remove) Token: 0x0600020B RID: 523 RVA: 0x0000C3A4 File Offset: 0x0000A5A4
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x0600020C RID: 524 RVA: 0x00003318 File Offset: 0x00001518
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x0600020D RID: 525 RVA: 0x0000C3DC File Offset: 0x0000A5DC
		// (set) Token: 0x0600020E RID: 526 RVA: 0x00003338 File Offset: 0x00001538
		[Category("Metro Appearance")]
		[DefaultValue(GEnum10.const_0)]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x0600020F RID: 527 RVA: 0x0000C434 File Offset: 0x0000A634
		// (set) Token: 0x06000210 RID: 528 RVA: 0x00003341 File Offset: 0x00001541
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x06000211 RID: 529 RVA: 0x0000334A File Offset: 0x0000154A
		// (set) Token: 0x06000212 RID: 530 RVA: 0x00003352 File Offset: 0x00001552
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000213 RID: 531 RVA: 0x0000335B File Offset: 0x0000155B
		// (set) Token: 0x06000214 RID: 532 RVA: 0x00003363 File Offset: 0x00001563
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x06000215 RID: 533 RVA: 0x0000336C File Offset: 0x0000156C
		// (set) Token: 0x06000216 RID: 534 RVA: 0x00003374 File Offset: 0x00001574
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000217 RID: 535 RVA: 0x0000337D File Offset: 0x0000157D
		// (set) Token: 0x06000218 RID: 536 RVA: 0x00003385 File Offset: 0x00001585
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000219 RID: 537 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x0600021A RID: 538 RVA: 0x00002923 File Offset: 0x00000B23
		[Category("Metro Behaviour")]
		[Browsable(false)]
		[DefaultValue(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x0600021B RID: 539 RVA: 0x0000338E File Offset: 0x0000158E
		// (set) Token: 0x0600021C RID: 540 RVA: 0x00003396 File Offset: 0x00001596
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x0600021D RID: 541 RVA: 0x0000339F File Offset: 0x0000159F
		// (set) Token: 0x0600021E RID: 542 RVA: 0x000033A7 File Offset: 0x000015A7
		[DefaultValue(GEnum25.const_0)]
		[Category("Metro Appearance")]
		public GEnum25 GEnum25_0
		{
			get
			{
				return this.genum25_0;
			}
			set
			{
				this.genum25_0 = value;
			}
		}

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x0600021F RID: 543 RVA: 0x000033B0 File Offset: 0x000015B0
		// (set) Token: 0x06000220 RID: 544 RVA: 0x000033B8 File Offset: 0x000015B8
		[Category("Metro Appearance")]
		[DefaultValue(GEnum26.const_1)]
		public GEnum26 GEnum26_0
		{
			get
			{
				return this.genum26_0;
			}
			set
			{
				this.genum26_0 = value;
			}
		}

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x06000221 RID: 545 RVA: 0x000033C1 File Offset: 0x000015C1
		// (set) Token: 0x06000222 RID: 546 RVA: 0x000033C9 File Offset: 0x000015C9
		[Browsable(false)]
		public override Font Font
		{
			get
			{
				return base.Font;
			}
			set
			{
				base.Font = value;
			}
		}

		// Token: 0x06000223 RID: 547 RVA: 0x0000C48C File Offset: 0x0000A68C
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
					if (base.Parent is GClass22)
					{
						color = GClass39.smethod_0(this.GEnum10_0);
					}
				}
				if (color.A == 255)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x06000224 RID: 548 RVA: 0x0000C524 File Offset: 0x0000A724
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x06000225 RID: 549 RVA: 0x0000C584 File Offset: 0x0000A784
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color color;
			Color color2;
			if (this.bool_1)
			{
				color = this.ForeColor;
				if (this.bool_4 && !this.bool_5 && base.Enabled)
				{
					color2 = GClass39.GClass40.GClass42.smethod_1(this.GEnum29_0);
				}
				else if (this.bool_4 && this.bool_5 && base.Enabled)
				{
					color2 = GClass39.GClass40.GClass42.smethod_2(this.GEnum29_0);
				}
				else if (!base.Enabled)
				{
					color2 = GClass39.GClass40.GClass42.smethod_3(this.GEnum29_0);
				}
				else
				{
					color2 = GClass39.GClass40.GClass42.smethod_0(this.GEnum29_0);
				}
			}
			else if (this.bool_4 && !this.bool_5 && base.Enabled)
			{
				color = GClass39.GClass56.GClass61.smethod_1(this.GEnum29_0);
				color2 = GClass39.GClass40.GClass42.smethod_1(this.GEnum29_0);
			}
			else if (this.bool_4 && this.bool_5 && base.Enabled)
			{
				color = GClass39.GClass56.GClass61.smethod_2(this.GEnum29_0);
				color2 = GClass39.GClass40.GClass42.smethod_2(this.GEnum29_0);
			}
			else if (!base.Enabled)
			{
				color = GClass39.GClass56.GClass61.smethod_3(this.GEnum29_0);
				color2 = GClass39.GClass40.GClass42.smethod_3(this.GEnum29_0);
			}
			else
			{
				color = ((!this.bool_2) ? GClass39.GClass56.GClass61.smethod_0(this.GEnum29_0) : GClass39.smethod_0(this.GEnum10_0));
				color2 = GClass39.GClass40.GClass42.smethod_0(this.GEnum29_0);
			}
			using (Pen pen = new Pen(color2))
			{
				Rectangle rect = new Rectangle(0, base.Height / 2 - 6, 12, 12);
				paintEventArgs_0.Graphics.DrawRectangle(pen, rect);
			}
			if (base.Checked)
			{
				Color color3 = (base.CheckState == CheckState.Indeterminate) ? color2 : GClass39.smethod_0(this.GEnum10_0);
				using (SolidBrush solidBrush = new SolidBrush(color3))
				{
					Rectangle rect2 = new Rectangle(2, base.Height / 2 - 4, 9, 9);
					paintEventArgs_0.Graphics.FillRectangle(solidBrush, rect2);
				}
			}
			Rectangle bounds = new Rectangle(16, 0, base.Width - 16, base.Height);
			TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Text, GClass67.smethod_11(this.genum25_0, this.genum26_0), bounds, color, GClass39.smethod_4(this.TextAlign));
			this.vmethod_2(new GEventArgs3(Color.Empty, color, paintEventArgs_0.Graphics));
			if (this.bool_3 && this.bool_6)
			{
				ControlPaint.DrawFocusRectangle(paintEventArgs_0.Graphics, base.ClientRectangle);
			}
		}

		// Token: 0x06000226 RID: 550 RVA: 0x000033D2 File Offset: 0x000015D2
		protected override void OnGotFocus(EventArgs e)
		{
			this.bool_6 = true;
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x06000227 RID: 551 RVA: 0x000033E8 File Offset: 0x000015E8
		protected override void OnLostFocus(EventArgs e)
		{
			this.bool_6 = false;
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		// Token: 0x06000228 RID: 552 RVA: 0x0000340C File Offset: 0x0000160C
		protected override void OnEnter(EventArgs e)
		{
			this.bool_6 = true;
			base.Invalidate();
			base.OnEnter(e);
		}

		// Token: 0x06000229 RID: 553 RVA: 0x00003422 File Offset: 0x00001622
		protected override void OnLeave(EventArgs e)
		{
			this.bool_6 = false;
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnLeave(e);
		}

		// Token: 0x0600022A RID: 554 RVA: 0x00003446 File Offset: 0x00001646
		protected override void OnKeyDown(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Space)
			{
				this.bool_4 = true;
				this.bool_5 = true;
				base.Invalidate();
			}
			base.OnKeyDown(e);
		}

		// Token: 0x0600022B RID: 555 RVA: 0x0000346D File Offset: 0x0000166D
		protected override void OnKeyUp(KeyEventArgs e)
		{
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnKeyUp(e);
		}

		// Token: 0x0600022C RID: 556 RVA: 0x0000348A File Offset: 0x0000168A
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_4 = true;
			base.Invalidate();
			base.OnMouseEnter(e);
		}

		// Token: 0x0600022D RID: 557 RVA: 0x000034A0 File Offset: 0x000016A0
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.bool_5 = true;
				base.Invalidate();
			}
			base.OnMouseDown(e);
		}

		// Token: 0x0600022E RID: 558 RVA: 0x000034C3 File Offset: 0x000016C3
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this.bool_5 = false;
			base.Invalidate();
			base.OnMouseUp(e);
		}

		// Token: 0x0600022F RID: 559 RVA: 0x000034D9 File Offset: 0x000016D9
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_4 = false;
			base.Invalidate();
			base.OnMouseLeave(e);
		}

		// Token: 0x06000230 RID: 560 RVA: 0x0000311B File Offset: 0x0000131B
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x06000231 RID: 561 RVA: 0x000034EF File Offset: 0x000016EF
		protected override void OnCheckedChanged(EventArgs e)
		{
			base.OnCheckedChanged(e);
			base.Invalidate();
		}

		// Token: 0x06000232 RID: 562 RVA: 0x0000C808 File Offset: 0x0000AA08
		public override Size GetPreferredSize(Size proposedSize)
		{
			base.GetPreferredSize(proposedSize);
			Size result;
			using (Graphics graphics = base.CreateGraphics())
			{
				proposedSize = new Size(int.MaxValue, int.MaxValue);
				result = TextRenderer.MeasureText(graphics, this.Text, GClass67.smethod_11(this.genum25_0, this.genum26_0), proposedSize, GClass39.smethod_4(this.TextAlign));
				result.Width += 16;
			}
			return result;
		}

		// Token: 0x040000CB RID: 203
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x040000CC RID: 204
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x040000CD RID: 205
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x040000CE RID: 206
		private GEnum10 genum10_0;

		// Token: 0x040000CF RID: 207
		private GEnum29 genum29_0;

		// Token: 0x040000D0 RID: 208
		private GClass8 gclass8_0;

		// Token: 0x040000D1 RID: 209
		private bool bool_0;

		// Token: 0x040000D2 RID: 210
		private bool bool_1;

		// Token: 0x040000D3 RID: 211
		private bool bool_2;

		// Token: 0x040000D4 RID: 212
		private bool bool_3;

		// Token: 0x040000D5 RID: 213
		private GEnum25 genum25_0;

		// Token: 0x040000D6 RID: 214
		private GEnum26 genum26_0 = GEnum26.const_1;

		// Token: 0x040000D7 RID: 215
		private bool bool_4;

		// Token: 0x040000D8 RID: 216
		private bool bool_5;

		// Token: 0x040000D9 RID: 217
		private bool bool_6;
	}
}
