﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;

namespace ns0
{
	// Token: 0x02000056 RID: 86
	internal static class Class13
	{
		// Token: 0x060006D3 RID: 1747 RVA: 0x000067D1 File Offset: 0x000049D1
		private static PointF smethod_0(PointF pointF_0, GClass23 gclass23_0)
		{
			return pointF_0;
		}

		// Token: 0x060006D4 RID: 1748 RVA: 0x000067D4 File Offset: 0x000049D4
		private static RectangleF smethod_1(RectangleF rectangleF_0, GClass23 gclass23_0)
		{
			return Rectangle.Round(rectangleF_0);
		}

		// Token: 0x060006D5 RID: 1749 RVA: 0x000177A4 File Offset: 0x000159A4
		public static GraphicsPath smethod_2(Class13.Enum1 enum1_0, GClass23 gclass23_0, RectangleF rectangleF_0, bool bool_0, bool bool_1)
		{
			PointF[] array = new PointF[4];
			GraphicsPath graphicsPath = null;
			switch (enum1_0)
			{
			case Class13.Enum1.const_0:
			{
				float num = gclass23_0.Single_8;
				array[0] = Class13.smethod_0(new PointF(rectangleF_0.Left + gclass23_0.Single_12, rectangleF_0.Top), gclass23_0);
				array[1] = Class13.smethod_0(new PointF(rectangleF_0.Right - gclass23_0.Single_13, rectangleF_0.Top), gclass23_0);
				array[2] = Class13.smethod_0(new PointF(rectangleF_0.Right - gclass23_0.Single_13, rectangleF_0.Top + num), gclass23_0);
				array[3] = Class13.smethod_0(new PointF(rectangleF_0.Left + gclass23_0.Single_12, rectangleF_0.Top + num), gclass23_0);
				if (bool_1 && gclass23_0.Single_13 == 0f)
				{
					PointF[] array2 = array;
					int num2 = 2;
					array2[num2].X = array2[num2].X - gclass23_0.Single_11;
				}
				if (bool_0 && gclass23_0.Single_12 == 0f)
				{
					PointF[] array3 = array;
					int num3 = 3;
					array3[num3].X = array3[num3].X + gclass23_0.Single_9;
				}
				if (gclass23_0.Single_12 > 0f)
				{
					graphicsPath = Class13.smethod_3(gclass23_0, rectangleF_0, 1);
				}
				break;
			}
			case Class13.Enum1.const_1:
			{
				float num = gclass23_0.Single_11;
				array[0] = Class13.smethod_0(new PointF(rectangleF_0.Right - num, rectangleF_0.Top + gclass23_0.Single_13), gclass23_0);
				array[1] = Class13.smethod_0(new PointF(rectangleF_0.Right, rectangleF_0.Top + gclass23_0.Single_13), gclass23_0);
				array[2] = Class13.smethod_0(new PointF(rectangleF_0.Right, rectangleF_0.Bottom - gclass23_0.Single_14), gclass23_0);
				array[3] = Class13.smethod_0(new PointF(rectangleF_0.Right - num, rectangleF_0.Bottom - gclass23_0.Single_14), gclass23_0);
				if (gclass23_0.Single_13 == 0f)
				{
					PointF[] array4 = array;
					int num4 = 0;
					array4[num4].Y = array4[num4].Y + gclass23_0.Single_8;
				}
				if (gclass23_0.Single_14 == 0f)
				{
					PointF[] array5 = array;
					int num5 = 3;
					array5[num5].Y = array5[num5].Y - gclass23_0.Single_10;
				}
				if (gclass23_0.Single_13 > 0f)
				{
					graphicsPath = Class13.smethod_3(gclass23_0, rectangleF_0, 2);
				}
				break;
			}
			case Class13.Enum1.const_2:
			{
				float num = gclass23_0.Single_10;
				array[0] = Class13.smethod_0(new PointF(rectangleF_0.Left + gclass23_0.Single_15, rectangleF_0.Bottom - num), gclass23_0);
				array[1] = Class13.smethod_0(new PointF(rectangleF_0.Right - gclass23_0.Single_14, rectangleF_0.Bottom - num), gclass23_0);
				array[2] = Class13.smethod_0(new PointF(rectangleF_0.Right - gclass23_0.Single_14, rectangleF_0.Bottom), gclass23_0);
				array[3] = Class13.smethod_0(new PointF(rectangleF_0.Left + gclass23_0.Single_15, rectangleF_0.Bottom), gclass23_0);
				if (bool_0 && gclass23_0.Single_15 == 0f)
				{
					PointF[] array6 = array;
					int num6 = 0;
					array6[num6].X = array6[num6].X + gclass23_0.Single_9;
				}
				if (bool_1 && gclass23_0.Single_14 == 0f)
				{
					PointF[] array7 = array;
					int num7 = 1;
					array7[num7].X = array7[num7].X - gclass23_0.Single_11;
				}
				if (gclass23_0.Single_14 > 0f)
				{
					graphicsPath = Class13.smethod_3(gclass23_0, rectangleF_0, 3);
				}
				break;
			}
			case Class13.Enum1.const_3:
			{
				float num = gclass23_0.Single_9;
				array[0] = Class13.smethod_0(new PointF(rectangleF_0.Left, rectangleF_0.Top + gclass23_0.Single_12), gclass23_0);
				array[1] = Class13.smethod_0(new PointF(rectangleF_0.Left + num, rectangleF_0.Top + gclass23_0.Single_12), gclass23_0);
				array[2] = Class13.smethod_0(new PointF(rectangleF_0.Left + num, rectangleF_0.Bottom - gclass23_0.Single_15), gclass23_0);
				array[3] = Class13.smethod_0(new PointF(rectangleF_0.Left, rectangleF_0.Bottom - gclass23_0.Single_15), gclass23_0);
				if (gclass23_0.Single_12 == 0f)
				{
					PointF[] array8 = array;
					int num8 = 1;
					array8[num8].Y = array8[num8].Y + gclass23_0.Single_8;
				}
				if (gclass23_0.Single_15 == 0f)
				{
					PointF[] array9 = array;
					int num9 = 2;
					array9[num9].Y = array9[num9].Y - gclass23_0.Single_10;
				}
				if (gclass23_0.Single_15 > 0f)
				{
					graphicsPath = Class13.smethod_3(gclass23_0, rectangleF_0, 4);
				}
				break;
			}
			}
			GraphicsPath graphicsPath2 = new GraphicsPath(array, new byte[]
			{
				1,
				1,
				1,
				1
			});
			if (graphicsPath != null)
			{
				graphicsPath2.AddPath(graphicsPath, true);
			}
			return graphicsPath2;
		}

		// Token: 0x060006D6 RID: 1750 RVA: 0x00017CA0 File Offset: 0x00015EA0
		private static GraphicsPath smethod_3(GClass23 gclass23_0, RectangleF rectangleF_0, int int_0)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			RectangleF rectangleF = RectangleF.Empty;
			RectangleF rectangleF2 = RectangleF.Empty;
			float startAngle = 0f;
			float startAngle2 = 0f;
			switch (int_0)
			{
			case 1:
				rectangleF = new RectangleF(rectangleF_0.Left, rectangleF_0.Top, gclass23_0.Single_12, gclass23_0.Single_12);
				rectangleF2 = RectangleF.FromLTRB(rectangleF.Left + gclass23_0.Single_9, rectangleF.Top + gclass23_0.Single_8, rectangleF.Right, rectangleF.Bottom);
				startAngle = 180f;
				startAngle2 = 270f;
				break;
			case 2:
				rectangleF = new RectangleF(rectangleF_0.Right - gclass23_0.Single_13, rectangleF_0.Top, gclass23_0.Single_13, gclass23_0.Single_13);
				rectangleF2 = RectangleF.FromLTRB(rectangleF.Left, rectangleF.Top + gclass23_0.Single_8, rectangleF.Right - gclass23_0.Single_11, rectangleF.Bottom);
				rectangleF.X -= rectangleF.Width;
				rectangleF2.X -= rectangleF2.Width;
				startAngle = -90f;
				startAngle2 = 0f;
				break;
			case 3:
				rectangleF = RectangleF.FromLTRB(rectangleF_0.Right - gclass23_0.Single_14, rectangleF_0.Bottom - gclass23_0.Single_14, rectangleF_0.Right, rectangleF_0.Bottom);
				rectangleF2 = new RectangleF(rectangleF.Left, rectangleF.Top, rectangleF.Width - gclass23_0.Single_11, rectangleF.Height - gclass23_0.Single_10);
				rectangleF.X -= rectangleF.Width;
				rectangleF.Y -= rectangleF.Height;
				rectangleF2.X -= rectangleF2.Width;
				rectangleF2.Y -= rectangleF2.Height;
				startAngle = 0f;
				startAngle2 = 90f;
				break;
			case 4:
				rectangleF = new RectangleF(rectangleF_0.Left, rectangleF_0.Bottom - gclass23_0.Single_15, gclass23_0.Single_15, gclass23_0.Single_15);
				rectangleF2 = RectangleF.FromLTRB(rectangleF_0.Left + gclass23_0.Single_9, rectangleF.Top, rectangleF.Right, rectangleF.Bottom - gclass23_0.Single_10);
				startAngle = 90f;
				startAngle2 = 180f;
				rectangleF.Y -= rectangleF.Height;
				rectangleF2.Y -= rectangleF2.Height;
				break;
			}
			if (rectangleF.Width <= 0f)
			{
				rectangleF.Width = 1f;
			}
			if (rectangleF.Height <= 0f)
			{
				rectangleF.Height = 1f;
			}
			if (rectangleF2.Width <= 0f)
			{
				rectangleF2.Width = 1f;
			}
			if (rectangleF2.Height <= 0f)
			{
				rectangleF2.Height = 1f;
			}
			rectangleF.Width *= 2f;
			rectangleF.Height *= 2f;
			rectangleF2.Width *= 2f;
			rectangleF2.Height *= 2f;
			rectangleF = Class13.smethod_1(rectangleF, gclass23_0);
			rectangleF2 = Class13.smethod_1(rectangleF2, gclass23_0);
			graphicsPath.AddArc(rectangleF, startAngle, 90f);
			graphicsPath.AddArc(rectangleF2, startAngle2, -90f);
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x060006D7 RID: 1751 RVA: 0x00018020 File Offset: 0x00016220
		public static GraphicsPath smethod_4(RectangleF rectangleF_0, float float_0, float float_1, float float_2, float float_3)
		{
			GraphicsPath graphicsPath = new GraphicsPath();
			float_0 *= 2f;
			float_1 *= 2f;
			float_2 *= 2f;
			float_3 *= 2f;
			graphicsPath.AddLine(rectangleF_0.X + float_0, rectangleF_0.Y, rectangleF_0.Right - float_1, rectangleF_0.Y);
			if (float_1 > 0f)
			{
				graphicsPath.AddArc(RectangleF.FromLTRB(rectangleF_0.Right - float_1, rectangleF_0.Top, rectangleF_0.Right, rectangleF_0.Top + float_1), -90f, 90f);
			}
			graphicsPath.AddLine(rectangleF_0.Right, rectangleF_0.Top + float_1, rectangleF_0.Right, rectangleF_0.Bottom - float_2);
			if (float_2 > 0f)
			{
				graphicsPath.AddArc(RectangleF.FromLTRB(rectangleF_0.Right - float_2, rectangleF_0.Bottom - float_2, rectangleF_0.Right, rectangleF_0.Bottom), 0f, 90f);
			}
			graphicsPath.AddLine(rectangleF_0.Right - float_2, rectangleF_0.Bottom, rectangleF_0.Left + float_3, rectangleF_0.Bottom);
			if (float_3 > 0f)
			{
				graphicsPath.AddArc(RectangleF.FromLTRB(rectangleF_0.Left, rectangleF_0.Bottom - float_3, rectangleF_0.Left + float_3, rectangleF_0.Bottom), 90f, 90f);
			}
			graphicsPath.AddLine(rectangleF_0.Left, rectangleF_0.Bottom - float_3, rectangleF_0.Left, rectangleF_0.Top + float_0);
			if (float_0 > 0f)
			{
				graphicsPath.AddArc(RectangleF.FromLTRB(rectangleF_0.Left, rectangleF_0.Top, rectangleF_0.Left + float_0, rectangleF_0.Top + float_0), 180f, 90f);
			}
			graphicsPath.CloseFigure();
			return graphicsPath;
		}

		// Token: 0x060006D8 RID: 1752 RVA: 0x000067E1 File Offset: 0x000049E1
		public static Color smethod_5(Color color_0)
		{
			return Color.FromArgb((int)(color_0.R / 2), (int)(color_0.G / 2), (int)(color_0.B / 2));
		}

		// Token: 0x02000057 RID: 87
		internal enum Enum1
		{
			// Token: 0x040002E6 RID: 742
			const_0,
			// Token: 0x040002E7 RID: 743
			const_1,
			// Token: 0x040002E8 RID: 744
			const_2,
			// Token: 0x040002E9 RID: 745
			const_3
		}
	}
}
