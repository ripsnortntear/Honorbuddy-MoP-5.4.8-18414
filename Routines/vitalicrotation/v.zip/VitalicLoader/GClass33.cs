﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace ns0
{
	// Token: 0x02000059 RID: 89
	public class GClass33
	{
		// Token: 0x060006E8 RID: 1768 RVA: 0x00018F88 File Offset: 0x00017188
		public GClass33(string string_1)
		{
			this.string_0 = string_1;
			this.float_0 = 0f;
			this.genum4_0 = GClass33.GEnum4.const_0;
			this.bool_1 = false;
			if (string.IsNullOrEmpty(string_1) || string_1 == "0")
			{
				return;
			}
			if (string_1.EndsWith("%"))
			{
				this.float_0 = GClass34.smethod_0(string_1, 1f);
				this.bool_1 = true;
				return;
			}
			if (string_1.Length < 3)
			{
				float.TryParse(string_1, out this.float_0);
				this.bool_2 = true;
				return;
			}
			string text = string_1.Substring(string_1.Length - 2, 2);
			string s = string_1.Substring(0, string_1.Length - 2);
			string key;
			if ((key = text) != null)
			{
				if (Class31.dictionary_2 == null)
				{
					Class31.dictionary_2 = new Dictionary<string, int>(8)
					{
						{
							"em",
							0
						},
						{
							"ex",
							1
						},
						{
							"px",
							2
						},
						{
							"mm",
							3
						},
						{
							"cm",
							4
						},
						{
							"in",
							5
						},
						{
							"pt",
							6
						},
						{
							"pc",
							7
						}
					};
				}
				int num;
				if (Class31.dictionary_2.TryGetValue(key, out num))
				{
					switch (num)
					{
					case 0:
						this.genum4_0 = GClass33.GEnum4.const_1;
						this.bool_0 = true;
						break;
					case 1:
						this.genum4_0 = GClass33.GEnum4.const_3;
						this.bool_0 = true;
						break;
					case 2:
						this.genum4_0 = GClass33.GEnum4.const_2;
						this.bool_0 = true;
						break;
					case 3:
						this.genum4_0 = GClass33.GEnum4.const_6;
						break;
					case 4:
						this.genum4_0 = GClass33.GEnum4.const_5;
						break;
					case 5:
						this.genum4_0 = GClass33.GEnum4.const_4;
						break;
					case 6:
						this.genum4_0 = GClass33.GEnum4.const_7;
						break;
					case 7:
						this.genum4_0 = GClass33.GEnum4.const_8;
						break;
					default:
						goto IL_1D7;
					}
					if (!float.TryParse(s, NumberStyles.Number, NumberFormatInfo.InvariantInfo, out this.float_0))
					{
						this.bool_2 = true;
					}
					return;
				}
			}
			IL_1D7:
			this.bool_2 = true;
		}

		// Token: 0x170001F8 RID: 504
		// (get) Token: 0x060006E9 RID: 1769 RVA: 0x00006803 File Offset: 0x00004A03
		public float Single_0
		{
			get
			{
				return this.float_0;
			}
		}

		// Token: 0x170001F9 RID: 505
		// (get) Token: 0x060006EA RID: 1770 RVA: 0x0000680B File Offset: 0x00004A0B
		public bool Boolean_0
		{
			get
			{
				return this.bool_2;
			}
		}

		// Token: 0x170001FA RID: 506
		// (get) Token: 0x060006EB RID: 1771 RVA: 0x00006813 File Offset: 0x00004A13
		public bool Boolean_1
		{
			get
			{
				return this.bool_1;
			}
		}

		// Token: 0x170001FB RID: 507
		// (get) Token: 0x060006EC RID: 1772 RVA: 0x0000681B File Offset: 0x00004A1B
		public bool Boolean_2
		{
			get
			{
				return this.bool_0;
			}
		}

		// Token: 0x170001FC RID: 508
		// (get) Token: 0x060006ED RID: 1773 RVA: 0x00006823 File Offset: 0x00004A23
		public GClass33.GEnum4 GEnum4_0
		{
			get
			{
				return this.genum4_0;
			}
		}

		// Token: 0x170001FD RID: 509
		// (get) Token: 0x060006EE RID: 1774 RVA: 0x0000682B File Offset: 0x00004A2B
		public string String_0
		{
			get
			{
				return this.string_0;
			}
		}

		// Token: 0x060006EF RID: 1775 RVA: 0x00019174 File Offset: 0x00017374
		public GClass33 method_0(float float_1)
		{
			if (this.Boolean_0)
			{
				throw new InvalidOperationException("Invalid length");
			}
			if (this.GEnum4_0 != GClass33.GEnum4.const_1)
			{
				throw new InvalidOperationException("Length is not in ems");
			}
			return new GClass33(string.Format("{0}pt", Convert.ToSingle(this.Single_0 * float_1).ToString("0.0", NumberFormatInfo.InvariantInfo)));
		}

		// Token: 0x060006F0 RID: 1776 RVA: 0x000191D8 File Offset: 0x000173D8
		public GClass33 method_1(float float_1)
		{
			if (this.Boolean_0)
			{
				throw new InvalidOperationException("Invalid length");
			}
			if (this.GEnum4_0 != GClass33.GEnum4.const_1)
			{
				throw new InvalidOperationException("Length is not in ems");
			}
			return new GClass33(string.Format("{0}px", Convert.ToSingle(this.Single_0 * float_1).ToString("0.0", NumberFormatInfo.InvariantInfo)));
		}

		// Token: 0x060006F1 RID: 1777 RVA: 0x0001923C File Offset: 0x0001743C
		public override string ToString()
		{
			if (this.Boolean_0)
			{
				return string.Empty;
			}
			if (this.Boolean_1)
			{
				return string.Format(NumberFormatInfo.InvariantInfo, "{0}%", new object[]
				{
					this.Single_0
				});
			}
			string text = string.Empty;
			switch (this.GEnum4_0)
			{
			case GClass33.GEnum4.const_1:
				text = "em";
				break;
			case GClass33.GEnum4.const_2:
				text = "px";
				break;
			case GClass33.GEnum4.const_3:
				text = "ex";
				break;
			case GClass33.GEnum4.const_4:
				text = "in";
				break;
			case GClass33.GEnum4.const_5:
				text = "cm";
				break;
			case GClass33.GEnum4.const_6:
				text = "mm";
				break;
			case GClass33.GEnum4.const_7:
				text = "pt";
				break;
			case GClass33.GEnum4.const_8:
				text = "pc";
				break;
			}
			return string.Format(NumberFormatInfo.InvariantInfo, "{0}{1}", new object[]
			{
				this.Single_0,
				text
			});
		}

		// Token: 0x040002EB RID: 747
		private float float_0;

		// Token: 0x040002EC RID: 748
		private bool bool_0;

		// Token: 0x040002ED RID: 749
		private GClass33.GEnum4 genum4_0;

		// Token: 0x040002EE RID: 750
		private string string_0;

		// Token: 0x040002EF RID: 751
		private bool bool_1;

		// Token: 0x040002F0 RID: 752
		private bool bool_2;

		// Token: 0x0200005A RID: 90
		public enum GEnum4
		{
			// Token: 0x040002F2 RID: 754
			const_0,
			// Token: 0x040002F3 RID: 755
			const_1,
			// Token: 0x040002F4 RID: 756
			const_2,
			// Token: 0x040002F5 RID: 757
			const_3,
			// Token: 0x040002F6 RID: 758
			const_4,
			// Token: 0x040002F7 RID: 759
			const_5,
			// Token: 0x040002F8 RID: 760
			const_6,
			// Token: 0x040002F9 RID: 761
			const_7,
			// Token: 0x040002FA RID: 762
			const_8
		}
	}
}
