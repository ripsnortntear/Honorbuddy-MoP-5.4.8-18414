﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Security;

namespace ns0
{
	// Token: 0x020000AB RID: 171
	[SuppressUnmanagedCodeSecurity]
	internal class Class26
	{
		// Token: 0x06000846 RID: 2118
		[DllImport("dwmapi.dll")]
		public static extern int DwmDefWindowProc(IntPtr intptr_0, int int_11, IntPtr intptr_1, IntPtr intptr_2, ref IntPtr intptr_3);

		// Token: 0x06000847 RID: 2119
		[DllImport("dwmapi.dll")]
		public static extern int DwmEnableComposition(int int_11);

		// Token: 0x06000848 RID: 2120
		[DllImport("dwmapi.dll")]
		public static extern int DwmEnableMMCSS(int int_11);

		// Token: 0x06000849 RID: 2121
		[DllImport("dwmapi.dll")]
		public static extern int DwmExtendFrameIntoClientArea(IntPtr intptr_0, ref Class26.Struct7 struct7_0);

		// Token: 0x0600084A RID: 2122
		[DllImport("dwmapi.dll")]
		public static extern int DwmGetColorizationColor(ref int int_11, ref int int_12);

		// Token: 0x0600084B RID: 2123
		[DllImport("dwmapi.dll")]
		public static extern int DwmGetCompositionTimingInfo(IntPtr intptr_0, ref Class26.Struct5 struct5_0);

		// Token: 0x0600084C RID: 2124
		[DllImport("dwmapi.dll")]
		public static extern int DwmGetWindowAttribute(IntPtr intptr_0, int int_11, IntPtr intptr_1, int int_12);

		// Token: 0x0600084D RID: 2125
		[DllImport("dwmapi.dll")]
		public static extern int DwmIsCompositionEnabled(ref int int_11);

		// Token: 0x0600084E RID: 2126
		[DllImport("dwmapi.dll", EntryPoint = "DwmIsCompositionEnabled")]
		public static extern int DwmIsCompositionEnabled_1(out bool bool_1);

		// Token: 0x0600084F RID: 2127
		[DllImport("dwmapi.dll")]
		public static extern int DwmModifyPreviousDxFrameDuration(IntPtr intptr_0, int int_11, int int_12);

		// Token: 0x06000850 RID: 2128
		[DllImport("dwmapi.dll")]
		public static extern int DwmQueryThumbnailSourceSize(IntPtr intptr_0, ref Size size_0);

		// Token: 0x06000851 RID: 2129
		[DllImport("dwmapi.dll")]
		public static extern int DwmRegisterThumbnail(IntPtr intptr_0, IntPtr intptr_1, ref Size size_0, ref IntPtr intptr_2);

		// Token: 0x06000852 RID: 2130
		[DllImport("dwmapi.dll")]
		public static extern int DwmSetDxFrameDuration(IntPtr intptr_0, int int_11);

		// Token: 0x06000853 RID: 2131
		[DllImport("dwmapi.dll")]
		public static extern int DwmSetPresentParameters(IntPtr intptr_0, ref Class26.Struct3 struct3_0);

		// Token: 0x06000854 RID: 2132
		[DllImport("dwmapi.dll")]
		public static extern int DwmSetWindowAttribute(IntPtr intptr_0, int int_11, IntPtr intptr_1, int int_12);

		// Token: 0x06000855 RID: 2133
		[DllImport("dwmapi.dll", EntryPoint = "DwmSetWindowAttribute")]
		public static extern int DwmSetWindowAttribute_1(IntPtr intptr_0, int int_11, ref int int_12, int int_13);

		// Token: 0x06000856 RID: 2134
		[DllImport("dwmapi.dll")]
		public static extern int DwmUnregisterThumbnail(IntPtr intptr_0);

		// Token: 0x06000857 RID: 2135
		[DllImport("dwmapi.dll")]
		public static extern int DwmUpdateThumbnailProperties(IntPtr intptr_0, ref Class26.Struct4 struct4_0);

		// Token: 0x06000858 RID: 2136
		[DllImport("dwmapi.dll")]
		public static extern int DwmEnableBlurBehindWindow(IntPtr intptr_0, ref Class26.Struct2 struct2_0);

		// Token: 0x06000859 RID: 2137
		[DllImport("uxtheme.dll")]
		public static extern int SetWindowThemeAttribute(IntPtr intptr_0, Class26.Enum5 enum5_0, ref Class26.Struct8 struct8_0, uint uint_4);

		// Token: 0x0400049E RID: 1182
		public const int int_0 = 2;

		// Token: 0x0400049F RID: 1183
		public const int int_1 = 1;

		// Token: 0x040004A0 RID: 1184
		public const int int_2 = 4;

		// Token: 0x040004A1 RID: 1185
		public const string string_0 = "DwmComposedEvent_";

		// Token: 0x040004A2 RID: 1186
		public const string string_1 = "%s%d";

		// Token: 0x040004A3 RID: 1187
		public const int int_3 = 64;

		// Token: 0x040004A4 RID: 1188
		public const int int_4 = -1;

		// Token: 0x040004A5 RID: 1189
		public const int int_5 = 4;

		// Token: 0x040004A6 RID: 1190
		public const int int_6 = 1;

		// Token: 0x040004A7 RID: 1191
		public const int int_7 = 2;

		// Token: 0x040004A8 RID: 1192
		public const int int_8 = 16;

		// Token: 0x040004A9 RID: 1193
		public const int int_9 = 8;

		// Token: 0x040004AA RID: 1194
		public const int int_10 = 798;

		// Token: 0x040004AB RID: 1195
		public static uint uint_0 = 1U;

		// Token: 0x040004AC RID: 1196
		public static uint uint_1 = 2U;

		// Token: 0x040004AD RID: 1197
		public static uint uint_2 = 4U;

		// Token: 0x040004AE RID: 1198
		public static uint uint_3 = 8U;

		// Token: 0x040004AF RID: 1199
		public static readonly bool bool_0 = Environment.OSVersion.Version.Major >= 6;

		// Token: 0x020000AC RID: 172
		[StructLayout(LayoutKind.Explicit)]
		public struct Struct1
		{
			// Token: 0x0600085A RID: 2138 RVA: 0x00007599 File Offset: 0x00005799
			public Struct1(Rectangle rectangle_0)
			{
				this.int_1 = rectangle_0.Left;
				this.int_3 = rectangle_0.Top;
				this.int_2 = rectangle_0.Right;
				this.int_0 = rectangle_0.Bottom;
			}

			// Token: 0x0600085B RID: 2139 RVA: 0x000075CF File Offset: 0x000057CF
			public Struct1(int int_4, int int_5, int int_6, int int_7)
			{
				this.int_1 = int_4;
				this.int_3 = int_5;
				this.int_2 = int_6;
				this.int_0 = int_7;
			}

			// Token: 0x0600085C RID: 2140 RVA: 0x000075EE File Offset: 0x000057EE
			public void method_0()
			{
				this.int_1 = Class26.Struct1.smethod_0<int>(ref this.int_3, Class26.Struct1.smethod_0<int>(ref this.int_2, Class26.Struct1.smethod_0<int>(ref this.int_0, 0)));
			}

			// Token: 0x0600085D RID: 2141 RVA: 0x00007599 File Offset: 0x00005799
			public void method_1(Rectangle rectangle_0)
			{
				this.int_1 = rectangle_0.Left;
				this.int_3 = rectangle_0.Top;
				this.int_2 = rectangle_0.Right;
				this.int_0 = rectangle_0.Bottom;
			}

			// Token: 0x0600085E RID: 2142 RVA: 0x000075CF File Offset: 0x000057CF
			public void method_2(int int_4, int int_5, int int_6, int int_7)
			{
				this.int_1 = int_4;
				this.int_3 = int_5;
				this.int_2 = int_6;
				this.int_0 = int_7;
			}

			// Token: 0x0600085F RID: 2143 RVA: 0x00007618 File Offset: 0x00005818
			public Rectangle method_3()
			{
				return new Rectangle(this.int_1, this.int_3, this.int_2 - this.int_1, this.int_0 - this.int_3);
			}

			// Token: 0x17000255 RID: 597
			// (get) Token: 0x06000860 RID: 2144 RVA: 0x00007645 File Offset: 0x00005845
			public int Int32_0
			{
				get
				{
					return this.int_0 - this.int_3;
				}
			}

			// Token: 0x17000256 RID: 598
			// (get) Token: 0x06000861 RID: 2145 RVA: 0x00007654 File Offset: 0x00005854
			public Size Size_0
			{
				get
				{
					return new Size(this.Int32_1, this.Int32_0);
				}
			}

			// Token: 0x17000257 RID: 599
			// (get) Token: 0x06000862 RID: 2146 RVA: 0x00007667 File Offset: 0x00005867
			public int Int32_1
			{
				get
				{
					return this.int_2 - this.int_1;
				}
			}

			// Token: 0x06000863 RID: 2147 RVA: 0x00007676 File Offset: 0x00005876
			private static T smethod_0<T>(ref T gparam_0, T gparam_1)
			{
				gparam_0 = gparam_1;
				return gparam_1;
			}

			// Token: 0x040004B0 RID: 1200
			[FieldOffset(12)]
			public int int_0;

			// Token: 0x040004B1 RID: 1201
			[FieldOffset(0)]
			public int int_1;

			// Token: 0x040004B2 RID: 1202
			[FieldOffset(8)]
			public int int_2;

			// Token: 0x040004B3 RID: 1203
			[FieldOffset(4)]
			public int int_3;
		}

		// Token: 0x020000AD RID: 173
		public struct Struct2
		{
			// Token: 0x06000864 RID: 2148 RVA: 0x00007680 File Offset: 0x00005880
			private Struct2(bool bool_0)
			{
				this.int_3 = 1;
				this.int_4 = (bool_0 ? 1 : 0);
				this.intptr_0 = IntPtr.Zero;
				this.int_5 = 0;
			}

			// Token: 0x040004B4 RID: 1204
			public const int int_0 = 1;

			// Token: 0x040004B5 RID: 1205
			public const int int_1 = 2;

			// Token: 0x040004B6 RID: 1206
			public const int int_2 = 4;

			// Token: 0x040004B7 RID: 1207
			public int int_3;

			// Token: 0x040004B8 RID: 1208
			public int int_4;

			// Token: 0x040004B9 RID: 1209
			public IntPtr intptr_0;

			// Token: 0x040004BA RID: 1210
			public int int_5;

			// Token: 0x040004BB RID: 1211
			public static Class26.Struct2 struct2_0 = new Class26.Struct2(true);

			// Token: 0x040004BC RID: 1212
			public static Class26.Struct2 struct2_1 = new Class26.Struct2(false);
		}

		// Token: 0x020000AE RID: 174
		public struct Struct3
		{
			// Token: 0x040004BD RID: 1213
			public int int_0;

			// Token: 0x040004BE RID: 1214
			public int int_1;

			// Token: 0x040004BF RID: 1215
			public long long_0;

			// Token: 0x040004C0 RID: 1216
			public int int_2;

			// Token: 0x040004C1 RID: 1217
			public int int_3;

			// Token: 0x040004C2 RID: 1218
			public Class26.Struct6 struct6_0;

			// Token: 0x040004C3 RID: 1219
			public int int_4;

			// Token: 0x040004C4 RID: 1220
			public Class26.Enum2 enum2_0;
		}

		// Token: 0x020000AF RID: 175
		public struct Struct4
		{
			// Token: 0x040004C5 RID: 1221
			public int int_0;

			// Token: 0x040004C6 RID: 1222
			public Class26.Struct1 struct1_0;

			// Token: 0x040004C7 RID: 1223
			public Class26.Struct1 struct1_1;

			// Token: 0x040004C8 RID: 1224
			public byte byte_0;

			// Token: 0x040004C9 RID: 1225
			public int int_1;

			// Token: 0x040004CA RID: 1226
			public int int_2;
		}

		// Token: 0x020000B0 RID: 176
		public struct Struct5
		{
			// Token: 0x040004CB RID: 1227
			public int int_0;

			// Token: 0x040004CC RID: 1228
			public Class26.Struct6 struct6_0;

			// Token: 0x040004CD RID: 1229
			public Class26.Struct6 struct6_1;

			// Token: 0x040004CE RID: 1230
			public long long_0;

			// Token: 0x040004CF RID: 1231
			public long long_1;

			// Token: 0x040004D0 RID: 1232
			public long long_2;

			// Token: 0x040004D1 RID: 1233
			public long long_3;

			// Token: 0x040004D2 RID: 1234
			public long long_4;

			// Token: 0x040004D3 RID: 1235
			public long long_5;

			// Token: 0x040004D4 RID: 1236
			public int int_1;

			// Token: 0x040004D5 RID: 1237
			public long long_6;

			// Token: 0x040004D6 RID: 1238
			public long long_7;

			// Token: 0x040004D7 RID: 1239
			public long long_8;

			// Token: 0x040004D8 RID: 1240
			public long long_9;

			// Token: 0x040004D9 RID: 1241
			public long long_10;

			// Token: 0x040004DA RID: 1242
			public long long_11;

			// Token: 0x040004DB RID: 1243
			public long long_12;
		}

		// Token: 0x020000B1 RID: 177
		public struct Struct6
		{
			// Token: 0x040004DC RID: 1244
			public int int_0;

			// Token: 0x040004DD RID: 1245
			public int int_1;
		}

		// Token: 0x020000B2 RID: 178
		public struct Struct7
		{
			// Token: 0x06000866 RID: 2150 RVA: 0x000076C0 File Offset: 0x000058C0
			public Struct7(int int_4, int int_5, int int_6, int int_7)
			{
				this.int_0 = int_4;
				this.int_1 = int_5;
				this.int_2 = int_6;
				this.int_3 = int_7;
			}

			// Token: 0x040004DE RID: 1246
			public int int_0;

			// Token: 0x040004DF RID: 1247
			public int int_1;

			// Token: 0x040004E0 RID: 1248
			public int int_2;

			// Token: 0x040004E1 RID: 1249
			public int int_3;
		}

		// Token: 0x020000B3 RID: 179
		public struct Struct8
		{
			// Token: 0x040004E2 RID: 1250
			public uint uint_0;

			// Token: 0x040004E3 RID: 1251
			public uint uint_1;
		}

		// Token: 0x020000B4 RID: 180
		public enum Enum2
		{
			// Token: 0x040004E5 RID: 1253
			const_0,
			// Token: 0x040004E6 RID: 1254
			const_1,
			// Token: 0x040004E7 RID: 1255
			const_2
		}

		// Token: 0x020000B5 RID: 181
		public enum Enum3
		{
			// Token: 0x040004E9 RID: 1257
			const_0,
			// Token: 0x040004EA RID: 1258
			const_1,
			// Token: 0x040004EB RID: 1259
			const_2
		}

		// Token: 0x020000B6 RID: 182
		public enum Enum4
		{
			// Token: 0x040004ED RID: 1261
			const_0 = 4,
			// Token: 0x040004EE RID: 1262
			const_1,
			// Token: 0x040004EF RID: 1263
			const_2 = 8,
			// Token: 0x040004F0 RID: 1264
			const_3 = 7,
			// Token: 0x040004F1 RID: 1265
			const_4 = 9,
			// Token: 0x040004F2 RID: 1266
			const_5 = 1,
			// Token: 0x040004F3 RID: 1267
			const_6,
			// Token: 0x040004F4 RID: 1268
			const_7 = 6,
			// Token: 0x040004F5 RID: 1269
			const_8 = 3
		}

		// Token: 0x020000B7 RID: 183
		public enum Enum5
		{
			// Token: 0x040004F7 RID: 1271
			const_0 = 1
		}
	}
}
