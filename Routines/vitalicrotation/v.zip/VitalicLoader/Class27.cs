﻿using System;
using System.Security;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x020000B8 RID: 184
	[SuppressUnmanagedCodeSecurity]
	internal class Class27 : NativeWindow
	{
		// Token: 0x06000867 RID: 2151 RVA: 0x000076DF File Offset: 0x000058DF
		public Class27(IntPtr intptr_0, bool bool_1)
		{
			base.AssignHandle(intptr_0);
			this.bool_0 = bool_1;
		}

		// Token: 0x14000043 RID: 67
		// (add) Token: 0x06000868 RID: 2152 RVA: 0x0001DC68 File Offset: 0x0001BE68
		// (remove) Token: 0x06000869 RID: 2153 RVA: 0x0001DCA0 File Offset: 0x0001BEA0
		public event Class27.Delegate4 Event_0
		{
			add
			{
				Class27.Delegate4 @delegate = this.delegate4_0;
				Class27.Delegate4 delegate2;
				do
				{
					delegate2 = @delegate;
					Class27.Delegate4 value2 = (Class27.Delegate4)Delegate.Combine(delegate2, value);
					@delegate = Interlocked.CompareExchange<Class27.Delegate4>(ref this.delegate4_0, value2, delegate2);
				}
				while (@delegate != delegate2);
			}
			remove
			{
				Class27.Delegate4 @delegate = this.delegate4_0;
				Class27.Delegate4 delegate2;
				do
				{
					delegate2 = @delegate;
					Class27.Delegate4 value2 = (Class27.Delegate4)Delegate.Remove(delegate2, value);
					@delegate = Interlocked.CompareExchange<Class27.Delegate4>(ref this.delegate4_0, value2, delegate2);
				}
				while (@delegate != delegate2);
			}
		}

		// Token: 0x17000258 RID: 600
		// (get) Token: 0x0600086A RID: 2154 RVA: 0x000076F5 File Offset: 0x000058F5
		// (set) Token: 0x0600086B RID: 2155 RVA: 0x000076FD File Offset: 0x000058FD
		public bool Boolean_0
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x0600086C RID: 2156 RVA: 0x00007706 File Offset: 0x00005906
		protected override void WndProc(ref Message m)
		{
			if (this.bool_0 && this.method_5(ref m) != 0)
			{
				return;
			}
			base.WndProc(ref m);
		}

		// Token: 0x0600086D RID: 2157 RVA: 0x00007721 File Offset: 0x00005921
		public void method_0(ref Message message_0)
		{
			base.WndProc(ref message_0);
		}

		// Token: 0x0600086E RID: 2158 RVA: 0x0000772A File Offset: 0x0000592A
		public int method_1(int int_0)
		{
			return int_0 >> 16 & 65535;
		}

		// Token: 0x0600086F RID: 2159 RVA: 0x00007736 File Offset: 0x00005936
		public int method_2(int int_0)
		{
			return int_0 & 65535;
		}

		// Token: 0x06000870 RID: 2160 RVA: 0x0000773F File Offset: 0x0000593F
		public int method_3(int int_0, int int_1)
		{
			return int_1 << 16 | (int_0 & 65535);
		}

		// Token: 0x06000871 RID: 2161 RVA: 0x0000774D File Offset: 0x0000594D
		public IntPtr method_4(int int_0, int int_1)
		{
			return (IntPtr)(int_1 << 16 | (int_0 & 65535));
		}

		// Token: 0x06000872 RID: 2162 RVA: 0x00007760 File Offset: 0x00005960
		private int method_5(ref Message message_0)
		{
			if (this.delegate4_0 != null)
			{
				return this.delegate4_0(ref message_0);
			}
			return 0;
		}

		// Token: 0x040004F8 RID: 1272
		private Class27.Delegate4 delegate4_0;

		// Token: 0x040004F9 RID: 1273
		private bool bool_0;

		// Token: 0x020000B9 RID: 185
		// (Invoke) Token: 0x06000874 RID: 2164
		public delegate int Delegate4(ref Message m);
	}
}
