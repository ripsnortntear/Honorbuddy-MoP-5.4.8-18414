﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000046 RID: 70
	[ToolboxBitmap(typeof(Button))]
	[Designer("MetroFramework.Design.Controls.MetroTileDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	public class GClass22 : Button, GInterface2, IContainerControl
	{
		// Token: 0x060004BD RID: 1213 RVA: 0x000050DB File Offset: 0x000032DB
		public GClass22()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.ContentAlignment_0 = ContentAlignment.BottomLeft;
		}

		// Token: 0x14000035 RID: 53
		// (add) Token: 0x060004BE RID: 1214 RVA: 0x000124D8 File Offset: 0x000106D8
		// (remove) Token: 0x060004BF RID: 1215 RVA: 0x00012510 File Offset: 0x00010710
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060004C0 RID: 1216 RVA: 0x0000510F File Offset: 0x0000330F
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000036 RID: 54
		// (add) Token: 0x060004C1 RID: 1217 RVA: 0x00012548 File Offset: 0x00010748
		// (remove) Token: 0x060004C2 RID: 1218 RVA: 0x00012580 File Offset: 0x00010780
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060004C3 RID: 1219 RVA: 0x0000512F File Offset: 0x0000332F
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000037 RID: 55
		// (add) Token: 0x060004C4 RID: 1220 RVA: 0x000125B8 File Offset: 0x000107B8
		// (remove) Token: 0x060004C5 RID: 1221 RVA: 0x000125F0 File Offset: 0x000107F0
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060004C6 RID: 1222 RVA: 0x0000514F File Offset: 0x0000334F
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x17000122 RID: 290
		// (get) Token: 0x060004C7 RID: 1223 RVA: 0x00012628 File Offset: 0x00010828
		// (set) Token: 0x060004C8 RID: 1224 RVA: 0x0000516F File Offset: 0x0000336F
		[DefaultValue(GEnum10.const_0)]
		[Category("Metro Appearance")]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x17000123 RID: 291
		// (get) Token: 0x060004C9 RID: 1225 RVA: 0x00012680 File Offset: 0x00010880
		// (set) Token: 0x060004CA RID: 1226 RVA: 0x00005178 File Offset: 0x00003378
		[DefaultValue(GEnum29.const_0)]
		[Category("Metro Appearance")]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x17000124 RID: 292
		// (get) Token: 0x060004CB RID: 1227 RVA: 0x00005181 File Offset: 0x00003381
		// (set) Token: 0x060004CC RID: 1228 RVA: 0x00005189 File Offset: 0x00003389
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x17000125 RID: 293
		// (get) Token: 0x060004CD RID: 1229 RVA: 0x00005192 File Offset: 0x00003392
		// (set) Token: 0x060004CE RID: 1230 RVA: 0x0000519A File Offset: 0x0000339A
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x17000126 RID: 294
		// (get) Token: 0x060004CF RID: 1231 RVA: 0x000051A3 File Offset: 0x000033A3
		// (set) Token: 0x060004D0 RID: 1232 RVA: 0x000051AB File Offset: 0x000033AB
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x17000127 RID: 295
		// (get) Token: 0x060004D1 RID: 1233 RVA: 0x000051B4 File Offset: 0x000033B4
		// (set) Token: 0x060004D2 RID: 1234 RVA: 0x000051BC File Offset: 0x000033BC
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x17000128 RID: 296
		// (get) Token: 0x060004D3 RID: 1235 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x060004D4 RID: 1236 RVA: 0x00002923 File Offset: 0x00000B23
		[DefaultValue(false)]
		[Category("Metro Behaviour")]
		[Browsable(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x17000129 RID: 297
		// (get) Token: 0x060004D5 RID: 1237 RVA: 0x000051C5 File Offset: 0x000033C5
		// (set) Token: 0x060004D6 RID: 1238 RVA: 0x000051CD File Offset: 0x000033CD
		[Browsable(false)]
		public Control ActiveControl
		{
			get
			{
				return this.control_0;
			}
			set
			{
				this.control_0 = value;
			}
		}

		// Token: 0x060004D7 RID: 1239 RVA: 0x000051D6 File Offset: 0x000033D6
		public bool ActivateControl(Control ctrl)
		{
			if (base.Controls.Contains(ctrl))
			{
				ctrl.Select();
				this.control_0 = ctrl;
				return true;
			}
			return false;
		}

		// Token: 0x1700012A RID: 298
		// (get) Token: 0x060004D8 RID: 1240 RVA: 0x000051F6 File Offset: 0x000033F6
		// (set) Token: 0x060004D9 RID: 1241 RVA: 0x000051FE File Offset: 0x000033FE
		[Category("Metro Appearance")]
		[DefaultValue(true)]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x1700012B RID: 299
		// (get) Token: 0x060004DA RID: 1242 RVA: 0x00005207 File Offset: 0x00003407
		// (set) Token: 0x060004DB RID: 1243 RVA: 0x0000520F File Offset: 0x0000340F
		[DefaultValue(0)]
		public int Int32_0
		{
			get
			{
				return this.int_0;
			}
			set
			{
				this.int_0 = value;
			}
		}

		// Token: 0x1700012C RID: 300
		// (get) Token: 0x060004DC RID: 1244 RVA: 0x00005218 File Offset: 0x00003418
		// (set) Token: 0x060004DD RID: 1245 RVA: 0x00005220 File Offset: 0x00003420
		[DefaultValue(ContentAlignment.BottomLeft)]
		public ContentAlignment ContentAlignment_0
		{
			get
			{
				return base.TextAlign;
			}
			set
			{
				base.TextAlign = value;
			}
		}

		// Token: 0x1700012D RID: 301
		// (get) Token: 0x060004DE RID: 1246 RVA: 0x00005229 File Offset: 0x00003429
		// (set) Token: 0x060004DF RID: 1247 RVA: 0x00005231 File Offset: 0x00003431
		[DefaultValue(null)]
		[Category("Metro Appearance")]
		public Image Image_0
		{
			get
			{
				return this.image_0;
			}
			set
			{
				this.image_0 = value;
			}
		}

		// Token: 0x1700012E RID: 302
		// (get) Token: 0x060004E0 RID: 1248 RVA: 0x0000523A File Offset: 0x0000343A
		// (set) Token: 0x060004E1 RID: 1249 RVA: 0x00005242 File Offset: 0x00003442
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_1
		{
			get
			{
				return this.bool_4;
			}
			set
			{
				this.bool_4 = value;
			}
		}

		// Token: 0x1700012F RID: 303
		// (get) Token: 0x060004E2 RID: 1250 RVA: 0x0000524B File Offset: 0x0000344B
		// (set) Token: 0x060004E3 RID: 1251 RVA: 0x00005253 File Offset: 0x00003453
		[Category("Metro Appearance")]
		[DefaultValue(ContentAlignment.TopLeft)]
		public ContentAlignment ContentAlignment_1
		{
			get
			{
				return this.contentAlignment_0;
			}
			set
			{
				this.contentAlignment_0 = value;
			}
		}

		// Token: 0x17000130 RID: 304
		// (get) Token: 0x060004E4 RID: 1252 RVA: 0x0000525C File Offset: 0x0000345C
		// (set) Token: 0x060004E5 RID: 1253 RVA: 0x00005264 File Offset: 0x00003464
		[Category("Metro Appearance")]
		[DefaultValue(GEnum13.const_1)]
		public GEnum13 GEnum13_0
		{
			get
			{
				return this.genum13_0;
			}
			set
			{
				this.genum13_0 = value;
				this.Refresh();
			}
		}

		// Token: 0x17000131 RID: 305
		// (get) Token: 0x060004E6 RID: 1254 RVA: 0x00005273 File Offset: 0x00003473
		// (set) Token: 0x060004E7 RID: 1255 RVA: 0x0000527B File Offset: 0x0000347B
		[DefaultValue(GEnum14.const_0)]
		[Category("Metro Appearance")]
		public GEnum14 GEnum14_0
		{
			get
			{
				return this.genum14_0;
			}
			set
			{
				this.genum14_0 = value;
				this.Refresh();
			}
		}

		// Token: 0x060004E8 RID: 1256 RVA: 0x000126D8 File Offset: 0x000108D8
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.smethod_0(this.GEnum10_0);
				}
				if (color.A == 255)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060004E9 RID: 1257 RVA: 0x00012758 File Offset: 0x00010958
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060004EA RID: 1258 RVA: 0x000127B8 File Offset: 0x000109B8
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color foreColor;
			if (this.bool_5 && !this.bool_6 && base.Enabled)
			{
				foreColor = GClass39.GClass56.GClass58.smethod_1(this.GEnum29_0);
			}
			else if (this.bool_5 && this.bool_6 && base.Enabled)
			{
				foreColor = GClass39.GClass56.GClass58.smethod_2(this.GEnum29_0);
			}
			else if (!base.Enabled)
			{
				foreColor = GClass39.GClass56.GClass58.smethod_3(this.GEnum29_0);
			}
			else
			{
				foreColor = GClass39.GClass56.GClass58.smethod_0(this.GEnum29_0);
			}
			if (this.bool_1)
			{
				foreColor = this.ForeColor;
			}
			paintEventArgs_0.Graphics.SmoothingMode = SmoothingMode.HighQuality;
			paintEventArgs_0.Graphics.CompositingQuality = CompositingQuality.HighQuality;
			if (this.bool_4 && this.image_0 != null)
			{
				ContentAlignment contentAlignment = this.contentAlignment_0;
				Rectangle rect;
				if (contentAlignment <= ContentAlignment.MiddleCenter)
				{
					switch (contentAlignment)
					{
					case ContentAlignment.TopLeft:
						rect = new Rectangle(new Point(0, 0), new Size(this.Image_0.Width, this.Image_0.Height));
						goto IL_3B9;
					case ContentAlignment.TopCenter:
						rect = new Rectangle(new Point(base.Width / 2 - this.Image_0.Width / 2, 0), new Size(this.Image_0.Width, this.Image_0.Height));
						goto IL_3B9;
					case (ContentAlignment)3:
						break;
					case ContentAlignment.TopRight:
						rect = new Rectangle(new Point(base.Width - this.Image_0.Width, 0), new Size(this.Image_0.Width, this.Image_0.Height));
						goto IL_3B9;
					default:
						if (contentAlignment == ContentAlignment.MiddleLeft)
						{
							rect = new Rectangle(new Point(0, base.Height / 2 - this.Image_0.Height / 2), new Size(this.Image_0.Width, this.Image_0.Height));
							goto IL_3B9;
						}
						if (contentAlignment == ContentAlignment.MiddleCenter)
						{
							rect = new Rectangle(new Point(base.Width / 2 - this.Image_0.Width / 2, base.Height / 2 - this.Image_0.Height / 2), new Size(this.Image_0.Width, this.Image_0.Height));
							goto IL_3B9;
						}
						break;
					}
				}
				else if (contentAlignment <= ContentAlignment.BottomLeft)
				{
					if (contentAlignment == ContentAlignment.MiddleRight)
					{
						rect = new Rectangle(new Point(base.Width - this.Image_0.Width, base.Height / 2 - this.Image_0.Height / 2), new Size(this.Image_0.Width, this.Image_0.Height));
						goto IL_3B9;
					}
					if (contentAlignment == ContentAlignment.BottomLeft)
					{
						rect = new Rectangle(new Point(0, base.Height - this.Image_0.Height), new Size(this.Image_0.Width, this.Image_0.Height));
						goto IL_3B9;
					}
				}
				else
				{
					if (contentAlignment == ContentAlignment.BottomCenter)
					{
						rect = new Rectangle(new Point(base.Width / 2 - this.Image_0.Width / 2, base.Height - this.Image_0.Height), new Size(this.Image_0.Width, this.Image_0.Height));
						goto IL_3B9;
					}
					if (contentAlignment == ContentAlignment.BottomRight)
					{
						rect = new Rectangle(new Point(base.Width - this.Image_0.Width, base.Height - this.Image_0.Height), new Size(this.Image_0.Width, this.Image_0.Height));
						goto IL_3B9;
					}
				}
				rect = new Rectangle(new Point(0, 0), new Size(this.Image_0.Width, this.Image_0.Height));
				IL_3B9:
				paintEventArgs_0.Graphics.DrawImage(this.Image_0, rect);
			}
			if (this.Int32_0 > 0 && this.bool_3)
			{
				Size size = TextRenderer.MeasureText(this.Int32_0.ToString(), GClass67.Font_2);
				paintEventArgs_0.Graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
				TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Int32_0.ToString(), GClass67.Font_2, new Point(base.Width - size.Width, 0), foreColor);
				paintEventArgs_0.Graphics.TextRenderingHint = TextRenderingHint.SystemDefault;
			}
			TextRenderer.MeasureText(this.Text, GClass67.smethod_4(this.genum13_0, this.genum14_0));
			TextFormatFlags flags = GClass39.smethod_4(this.ContentAlignment_0) | TextFormatFlags.LeftAndRightPadding | TextFormatFlags.EndEllipsis;
			Rectangle clientRectangle = base.ClientRectangle;
			if (this.bool_6)
			{
				clientRectangle.Inflate(-2, -2);
			}
			TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Text, GClass67.smethod_4(this.genum13_0, this.genum14_0), clientRectangle, foreColor, flags);
		}

		// Token: 0x060004EB RID: 1259 RVA: 0x0000528A File Offset: 0x0000348A
		protected override void OnGotFocus(EventArgs e)
		{
			this.bool_7 = true;
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x060004EC RID: 1260 RVA: 0x000052A0 File Offset: 0x000034A0
		protected override void OnLostFocus(EventArgs e)
		{
			this.bool_7 = false;
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		// Token: 0x060004ED RID: 1261 RVA: 0x000052C4 File Offset: 0x000034C4
		protected override void OnEnter(EventArgs e)
		{
			this.bool_7 = true;
			base.Invalidate();
			base.OnEnter(e);
		}

		// Token: 0x060004EE RID: 1262 RVA: 0x000052DA File Offset: 0x000034DA
		protected override void OnLeave(EventArgs e)
		{
			this.bool_7 = false;
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnLeave(e);
		}

		// Token: 0x060004EF RID: 1263 RVA: 0x000052FE File Offset: 0x000034FE
		protected override void OnKeyDown(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Space)
			{
				this.bool_5 = true;
				this.bool_6 = true;
				base.Invalidate();
			}
			base.OnKeyDown(e);
		}

		// Token: 0x060004F0 RID: 1264 RVA: 0x00005325 File Offset: 0x00003525
		protected override void OnKeyUp(KeyEventArgs e)
		{
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnKeyUp(e);
		}

		// Token: 0x060004F1 RID: 1265 RVA: 0x00005342 File Offset: 0x00003542
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_5 = true;
			base.Invalidate();
			base.OnMouseEnter(e);
		}

		// Token: 0x060004F2 RID: 1266 RVA: 0x00005358 File Offset: 0x00003558
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.bool_6 = true;
				base.Invalidate();
			}
			base.OnMouseDown(e);
		}

		// Token: 0x060004F3 RID: 1267 RVA: 0x0000537B File Offset: 0x0000357B
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this.bool_6 = false;
			base.Invalidate();
			base.OnMouseUp(e);
		}

		// Token: 0x060004F4 RID: 1268 RVA: 0x00005391 File Offset: 0x00003591
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_5 = false;
			base.Invalidate();
			base.OnMouseLeave(e);
		}

		// Token: 0x060004F5 RID: 1269 RVA: 0x0000311B File Offset: 0x0000131B
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x040001AF RID: 431
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x040001B0 RID: 432
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x040001B1 RID: 433
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x040001B2 RID: 434
		private GEnum10 genum10_0;

		// Token: 0x040001B3 RID: 435
		private GEnum29 genum29_0;

		// Token: 0x040001B4 RID: 436
		private GClass8 gclass8_0;

		// Token: 0x040001B5 RID: 437
		private bool bool_0;

		// Token: 0x040001B6 RID: 438
		private bool bool_1;

		// Token: 0x040001B7 RID: 439
		private bool bool_2;

		// Token: 0x040001B8 RID: 440
		private Control control_0;

		// Token: 0x040001B9 RID: 441
		private bool bool_3 = true;

		// Token: 0x040001BA RID: 442
		private int int_0;

		// Token: 0x040001BB RID: 443
		private Image image_0;

		// Token: 0x040001BC RID: 444
		private bool bool_4;

		// Token: 0x040001BD RID: 445
		private ContentAlignment contentAlignment_0 = ContentAlignment.TopLeft;

		// Token: 0x040001BE RID: 446
		private GEnum13 genum13_0 = GEnum13.const_1;

		// Token: 0x040001BF RID: 447
		private GEnum14 genum14_0;

		// Token: 0x040001C0 RID: 448
		private bool bool_5;

		// Token: 0x040001C1 RID: 449
		private bool bool_6;

		// Token: 0x040001C2 RID: 450
		private bool bool_7;
	}
}
