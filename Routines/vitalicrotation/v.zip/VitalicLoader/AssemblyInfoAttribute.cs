﻿using System;

namespace ns0
{
	// Token: 0x02000003 RID: 3
	internal class AssemblyInfoAttribute : Attribute
	{
		// Token: 0x06000004 RID: 4 RVA: 0x000020FF File Offset: 0x000002FF
		public AssemblyInfoAttribute(string str)
		{
		}
	}
}
