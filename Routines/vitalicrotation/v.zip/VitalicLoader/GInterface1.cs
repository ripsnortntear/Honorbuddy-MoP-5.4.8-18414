﻿using System;

namespace ns0
{
	// Token: 0x0200001C RID: 28
	public interface GInterface1
	{
		// Token: 0x1700001A RID: 26
		// (get) Token: 0x060000B1 RID: 177
		// (set) Token: 0x060000B2 RID: 178
		GEnum10 GEnum10_0 { get; set; }

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x060000B3 RID: 179
		// (set) Token: 0x060000B4 RID: 180
		GEnum29 GEnum29_0 { get; set; }

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x060000B5 RID: 181
		// (set) Token: 0x060000B6 RID: 182
		GClass8 GClass8_0 { get; set; }
	}
}
