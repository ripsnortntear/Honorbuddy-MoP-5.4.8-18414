﻿using System;

namespace ns0
{
	// Token: 0x0200005D RID: 93
	public class GAttribute1 : Attribute
	{
	}
}
