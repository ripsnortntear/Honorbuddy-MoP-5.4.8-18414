﻿using System;

namespace ns0
{
	// Token: 0x0200009A RID: 154
	public enum GEnum18
	{
		// Token: 0x0400046D RID: 1133
		const_0,
		// Token: 0x0400046E RID: 1134
		const_1,
		// Token: 0x0400046F RID: 1135
		const_2
	}
}
