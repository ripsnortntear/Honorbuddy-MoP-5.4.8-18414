﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace ns0
{
	// Token: 0x02000058 RID: 88
	internal static class Class14
	{
		// Token: 0x060006D9 RID: 1753 RVA: 0x000181F8 File Offset: 0x000163F8
		public static void smethod_0(Graphics graphics_0, GClass23 gclass23_0)
		{
			gclass23_0.List_1.Clear();
			float float_ = gclass23_0.Single_30 - gclass23_0.Single_3 - gclass23_0.Single_11;
			float num = gclass23_0.PointF_0.X + gclass23_0.Single_1 - 0f + gclass23_0.Single_9;
			float num2 = gclass23_0.PointF_0.Y + gclass23_0.Single_0 - 0f + gclass23_0.Single_8;
			float num3 = num + gclass23_0.Single_18;
			float num4 = num2;
			float num5 = num2;
			float float_2 = 0f;
			Class15 @class = new Class15(gclass23_0);
			Class14.smethod_1(graphics_0, gclass23_0, gclass23_0, float_, float_2, num, ref @class, ref num3, ref num4, ref num5);
			foreach (Class15 class2 in gclass23_0.List_1)
			{
				Class14.smethod_2(gclass23_0, class2);
				class2.method_4();
				Class14.smethod_4(graphics_0, class2);
				if (gclass23_0.String_48 == "rtl")
				{
					Class14.smethod_5(class2);
				}
			}
			gclass23_0.Single_22 = num5 + gclass23_0.Single_2 + gclass23_0.Single_10;
		}

		// Token: 0x060006DA RID: 1754 RVA: 0x0001832C File Offset: 0x0001652C
		private static void smethod_1(Graphics graphics_0, GClass23 gclass23_0, GClass23 gclass23_1, float float_0, float float_1, float float_2, ref Class15 class15_0, ref float float_3, ref float float_4, ref float float_5)
		{
			gclass23_1.Class15_0 = class15_0;
			foreach (GClass23 gclass in gclass23_1.List_0)
			{
				float num = gclass.Single_5 + gclass.Single_9 + gclass.Single_1;
				float num2 = gclass.Single_7 + gclass.Single_11 + gclass.Single_3;
				float single_ = gclass.Single_8;
				float single_2 = gclass.Single_0;
				float single_3 = gclass.Single_10;
				float single_4 = gclass.Single_0;
				gclass.method_29();
				gclass.method_21(graphics_0);
				float_3 += num;
				if (gclass.List_3.Count > 0)
				{
					using (List<Class11>.Enumerator enumerator2 = gclass.List_3.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							Class11 @class = enumerator2.Current;
							if ((gclass.String_57 != "nowrap" && float_3 + @class.Single_2 + num2 > float_0) || @class.Boolean_2)
							{
								float_3 = float_2;
								float_4 = float_5 + float_1;
								class15_0 = new Class15(gclass23_0);
								if (@class.Boolean_0 || @class.Equals(gclass.Class11_0))
								{
									float_3 += num;
								}
							}
							class15_0.method_1(@class);
							@class.Single_0 = float_3;
							@class.Single_1 = float_4;
							float_3 = @class.Single_4;
							float_5 = Math.Max(float_5, @class.Single_5);
							Class14.class11_0 = @class;
						}
						goto IL_17D;
					}
					goto IL_168;
				}
				goto IL_168;
				IL_17D:
				float_3 += num2;
				continue;
				IL_168:
				Class14.smethod_1(graphics_0, gclass23_0, gclass, float_0, float_1, float_2, ref class15_0, ref float_3, ref float_4, ref float_5);
				goto IL_17D;
			}
			gclass23_1.Class15_1 = class15_0;
		}

		// Token: 0x060006DB RID: 1755 RVA: 0x00018518 File Offset: 0x00016718
		private static void smethod_2(GClass23 gclass23_0, Class15 class15_0)
		{
			if (gclass23_0.List_3.Count > 0)
			{
				float num = float.MaxValue;
				float num2 = float.MaxValue;
				float num3 = float.MinValue;
				float num4 = float.MinValue;
				List<Class11> list = class15_0.method_2(gclass23_0);
				if (list.Count > 0)
				{
					foreach (Class11 @class in list)
					{
						num = Math.Min(num, @class.Single_0);
						num3 = Math.Max(num3, @class.Single_4);
						num2 = Math.Min(num2, @class.Single_1);
						num4 = Math.Max(num4, @class.Single_5);
					}
					class15_0.method_3(gclass23_0, num, num2, num3, num4);
					return;
				}
			}
			else
			{
				foreach (GClass23 gclass23_ in gclass23_0.List_0)
				{
					Class14.smethod_2(gclass23_, class15_0);
				}
			}
		}

		// Token: 0x060006DC RID: 1756 RVA: 0x0001862C File Offset: 0x0001682C
		public static float smethod_3(Graphics graphics_0, GClass23 gclass23_0)
		{
			string text = " .";
			float result = 5f;
			StringFormat stringFormat = new StringFormat();
			stringFormat.SetMeasurableCharacterRanges(new CharacterRange[]
			{
				new CharacterRange(0, 1)
			});
			Region[] array = graphics_0.MeasureCharacterRanges(text, gclass23_0.Font_1, new RectangleF(0f, 0f, float.MaxValue, float.MaxValue), stringFormat);
			if (array != null && array.Length != 0)
			{
				float num = array[0].GetBounds(graphics_0).Width;
				if (!string.IsNullOrEmpty(gclass23_0.String_58) && !(gclass23_0.String_58 == "normal"))
				{
					num += GClass34.smethod_1(gclass23_0.String_58, 0f, gclass23_0);
				}
				return num;
			}
			return result;
		}

		// Token: 0x060006DD RID: 1757 RVA: 0x000186F8 File Offset: 0x000168F8
		private static void smethod_4(Graphics graphics_0, Class15 class15_0)
		{
			string string_;
			if ((string_ = class15_0.GClass23_0.String_55) != null)
			{
				if (string_ == "right")
				{
					Class14.smethod_13(graphics_0, class15_0);
					goto IL_58;
				}
				if (string_ == "center")
				{
					Class14.smethod_12(graphics_0, class15_0);
					goto IL_58;
				}
				if (string_ == "justify")
				{
					Class14.smethod_11(graphics_0, class15_0);
					goto IL_58;
				}
			}
			Class14.smethod_14(graphics_0, class15_0);
			IL_58:
			Class14.smethod_9(graphics_0, class15_0);
		}

		// Token: 0x060006DE RID: 1758 RVA: 0x00018764 File Offset: 0x00016964
		private static void smethod_5(Class15 class15_0)
		{
			float single_ = class15_0.GClass23_0.Single_23;
			float single_2 = class15_0.GClass23_0.Single_25;
			foreach (Class11 @class in class15_0.List_1)
			{
				float num = @class.Single_0 - single_;
				float num2 = single_2 - num;
				@class.Single_0 = num2 - @class.Single_2;
			}
		}

		// Token: 0x060006DF RID: 1759 RVA: 0x000187E8 File Offset: 0x000169E8
		public static float smethod_6(Font font_0)
		{
			return font_0.Size * (float)font_0.FontFamily.GetCellAscent(font_0.Style) / (float)font_0.FontFamily.GetEmHeight(font_0.Style);
		}

		// Token: 0x060006E0 RID: 1760 RVA: 0x00018824 File Offset: 0x00016A24
		public static float smethod_7(Font font_0)
		{
			return font_0.Size * (float)font_0.FontFamily.GetCellDescent(font_0.Style) / (float)font_0.FontFamily.GetEmHeight(font_0.Style);
		}

		// Token: 0x060006E1 RID: 1761 RVA: 0x00018860 File Offset: 0x00016A60
		public static float smethod_8(Font font_0)
		{
			return font_0.Size * (float)font_0.FontFamily.GetLineSpacing(font_0.Style) / (float)font_0.FontFamily.GetEmHeight(font_0.Style);
		}

		// Token: 0x060006E2 RID: 1762 RVA: 0x0001889C File Offset: 0x00016A9C
		private static void smethod_9(Graphics graphics_0, Class15 class15_0)
		{
			class15_0.GClass23_0.String_47 == "table-cell";
			float num = class15_0.method_0() - Class14.smethod_7(class15_0.GClass23_0.Font_1) - 2f;
			List<GClass23> list = new List<GClass23>(class15_0.Dictionary_0.Keys);
			foreach (GClass23 gclass in list)
			{
				Class14.smethod_6(gclass.Font_1);
				Class14.smethod_7(gclass.Font_1);
				string string_;
				switch (string_ = gclass.String_53)
				{
				case "sub":
					class15_0.method_7(graphics_0, gclass, num + class15_0.Dictionary_0[gclass].Height * 0.2f);
					continue;
				case "super":
					class15_0.method_7(graphics_0, gclass, num - class15_0.Dictionary_0[gclass].Height * 0.2f);
					continue;
				case "text-top":
				case "text-bottom":
				case "top":
				case "bottom":
				case "middle":
					continue;
				}
				class15_0.method_7(graphics_0, gclass, num);
			}
		}

		// Token: 0x060006E3 RID: 1763 RVA: 0x00018A5C File Offset: 0x00016C5C
		public static void smethod_10(Graphics graphics_0, GClass23 gclass23_0)
		{
			if (!(gclass23_0.String_53 == "top") && !(gclass23_0.String_53 == "baseline"))
			{
				float single_ = gclass23_0.Single_24;
				float single_2 = gclass23_0.Single_26;
				float num = gclass23_0.method_12(gclass23_0, 0f);
				float float_ = 0f;
				if (gclass23_0.String_53 == "bottom")
				{
					float_ = single_2 - num;
				}
				else if (gclass23_0.String_53 == "middle")
				{
					float_ = (single_2 - num) / 2f;
				}
				foreach (GClass23 gclass in gclass23_0.List_0)
				{
					gclass.method_23(float_);
				}
				return;
			}
		}

		// Token: 0x060006E4 RID: 1764 RVA: 0x00018B34 File Offset: 0x00016D34
		private static void smethod_11(Graphics graphics_0, Class15 class15_0)
		{
			if (class15_0.Equals(class15_0.GClass23_0.List_1[class15_0.GClass23_0.List_1.Count - 1]))
			{
				return;
			}
			float num = class15_0.Equals(class15_0.GClass23_0.List_1[0]) ? class15_0.GClass23_0.Single_18 : 0f;
			float num2 = 0f;
			float num3 = 0f;
			float num4 = class15_0.GClass23_0.RectangleF_1.Width - num;
			foreach (Class11 @class in class15_0.List_1)
			{
				num2 += @class.Single_2;
				num3 += 1f;
			}
			if (num3 <= 0f)
			{
				return;
			}
			float num5 = (num4 - num2) / num3;
			float single_ = class15_0.GClass23_0.Single_23 + num;
			foreach (Class11 class2 in class15_0.List_1)
			{
				class2.Single_0 = single_;
				single_ = class2.Single_4 + num5;
				if (class2 == class15_0.List_1[class15_0.List_1.Count - 1])
				{
					class2.Single_0 = class15_0.GClass23_0.Single_25 - class2.Single_2;
				}
			}
		}

		// Token: 0x060006E5 RID: 1765 RVA: 0x00018CB8 File Offset: 0x00016EB8
		private static void smethod_12(Graphics graphics_0, Class15 class15_0)
		{
			if (class15_0.List_1.Count == 0)
			{
				return;
			}
			Class11 @class = class15_0.List_1[class15_0.List_1.Count - 1];
			float num = class15_0.GClass23_0.Single_30 - class15_0.GClass23_0.Single_3 - class15_0.GClass23_0.Single_11;
			float num2 = num - @class.Single_4 - @class.PointF_1.X - @class.GClass23_0.Single_11 - @class.GClass23_0.Single_3;
			num2 /= 2f;
			if (num2 <= 0f)
			{
				return;
			}
			foreach (Class11 class2 in class15_0.List_1)
			{
				class2.Single_0 += num2;
			}
			foreach (GClass23 gclass in class15_0.Dictionary_0.Keys)
			{
				RectangleF rectangleF = gclass.Dictionary_0[class15_0];
				gclass.Dictionary_0[class15_0] = new RectangleF(rectangleF.X + num2, rectangleF.Y, rectangleF.Width, rectangleF.Height);
			}
		}

		// Token: 0x060006E6 RID: 1766 RVA: 0x00018E24 File Offset: 0x00017024
		private static void smethod_13(Graphics graphics_0, Class15 class15_0)
		{
			if (class15_0.List_1.Count == 0)
			{
				return;
			}
			Class11 @class = class15_0.List_1[class15_0.List_1.Count - 1];
			float num = class15_0.GClass23_0.Single_30 - class15_0.GClass23_0.Single_3 - class15_0.GClass23_0.Single_11;
			float num2 = num - @class.Single_4 - @class.PointF_1.X - @class.GClass23_0.Single_11 - @class.GClass23_0.Single_3;
			if (num2 <= 0f)
			{
				return;
			}
			foreach (Class11 class2 in class15_0.List_1)
			{
				class2.Single_0 += num2;
			}
			foreach (GClass23 gclass in class15_0.Dictionary_0.Keys)
			{
				RectangleF rectangleF = gclass.Dictionary_0[class15_0];
				gclass.Dictionary_0[class15_0] = new RectangleF(rectangleF.X + num2, rectangleF.Y, rectangleF.Width, rectangleF.Height);
			}
		}

		// Token: 0x060006E7 RID: 1767 RVA: 0x00002470 File Offset: 0x00000670
		private static void smethod_14(Graphics graphics_0, Class15 class15_0)
		{
		}

		// Token: 0x040002EA RID: 746
		private static Class11 class11_0;
	}
}
