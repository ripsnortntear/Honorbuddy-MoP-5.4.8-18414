﻿using System;

namespace ns0
{
	// Token: 0x020000A3 RID: 163
	public enum GEnum27
	{
		// Token: 0x04000491 RID: 1169
		const_0,
		// Token: 0x04000492 RID: 1170
		const_1,
		// Token: 0x04000493 RID: 1171
		const_2
	}
}
