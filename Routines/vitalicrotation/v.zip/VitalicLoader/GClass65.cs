﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace ns0
{
	// Token: 0x0200008E RID: 142
	public sealed class GClass65
	{
		// Token: 0x060007FF RID: 2047 RVA: 0x0001D8D8 File Offset: 0x0001BAD8
		private static SolidBrush smethod_0(string string_0, Color color_0)
		{
			SolidBrush result;
			lock (GClass65.dictionary_0)
			{
				if (!GClass65.dictionary_0.ContainsKey(string_0))
				{
					GClass65.dictionary_0.Add(string_0, new SolidBrush(color_0));
				}
				result = (GClass65.dictionary_0[string_0].Clone() as SolidBrush);
			}
			return result;
		}

		// Token: 0x17000228 RID: 552
		// (get) Token: 0x06000800 RID: 2048 RVA: 0x00007220 File Offset: 0x00005420
		public static SolidBrush SolidBrush_0
		{
			get
			{
				return GClass65.smethod_0("Black", GClass66.Color_0);
			}
		}

		// Token: 0x17000229 RID: 553
		// (get) Token: 0x06000801 RID: 2049 RVA: 0x00007231 File Offset: 0x00005431
		public static SolidBrush SolidBrush_1
		{
			get
			{
				return GClass65.smethod_0("White", GClass66.Color_1);
			}
		}

		// Token: 0x1700022A RID: 554
		// (get) Token: 0x06000802 RID: 2050 RVA: 0x00007242 File Offset: 0x00005442
		public static SolidBrush SolidBrush_2
		{
			get
			{
				return GClass65.smethod_0("Silver", GClass66.Color_2);
			}
		}

		// Token: 0x1700022B RID: 555
		// (get) Token: 0x06000803 RID: 2051 RVA: 0x00007253 File Offset: 0x00005453
		public static SolidBrush SolidBrush_3
		{
			get
			{
				return GClass65.smethod_0("Blue", GClass66.Color_3);
			}
		}

		// Token: 0x1700022C RID: 556
		// (get) Token: 0x06000804 RID: 2052 RVA: 0x00007264 File Offset: 0x00005464
		public static SolidBrush SolidBrush_4
		{
			get
			{
				return GClass65.smethod_0("Green", GClass66.Color_4);
			}
		}

		// Token: 0x1700022D RID: 557
		// (get) Token: 0x06000805 RID: 2053 RVA: 0x00007275 File Offset: 0x00005475
		public static SolidBrush SolidBrush_5
		{
			get
			{
				return GClass65.smethod_0("Lime", GClass66.Color_5);
			}
		}

		// Token: 0x1700022E RID: 558
		// (get) Token: 0x06000806 RID: 2054 RVA: 0x00007286 File Offset: 0x00005486
		public static SolidBrush SolidBrush_6
		{
			get
			{
				return GClass65.smethod_0("Teal", GClass66.Color_6);
			}
		}

		// Token: 0x1700022F RID: 559
		// (get) Token: 0x06000807 RID: 2055 RVA: 0x00007297 File Offset: 0x00005497
		public static SolidBrush SolidBrush_7
		{
			get
			{
				return GClass65.smethod_0("Orange", GClass66.Color_7);
			}
		}

		// Token: 0x17000230 RID: 560
		// (get) Token: 0x06000808 RID: 2056 RVA: 0x000072A8 File Offset: 0x000054A8
		public static SolidBrush SolidBrush_8
		{
			get
			{
				return GClass65.smethod_0("Brown", GClass66.Color_8);
			}
		}

		// Token: 0x17000231 RID: 561
		// (get) Token: 0x06000809 RID: 2057 RVA: 0x000072B9 File Offset: 0x000054B9
		public static SolidBrush SolidBrush_9
		{
			get
			{
				return GClass65.smethod_0("Pink", GClass66.Color_9);
			}
		}

		// Token: 0x17000232 RID: 562
		// (get) Token: 0x0600080A RID: 2058 RVA: 0x000072CA File Offset: 0x000054CA
		public static SolidBrush SolidBrush_10
		{
			get
			{
				return GClass65.smethod_0("Magenta", GClass66.Color_10);
			}
		}

		// Token: 0x17000233 RID: 563
		// (get) Token: 0x0600080B RID: 2059 RVA: 0x000072DB File Offset: 0x000054DB
		public static SolidBrush SolidBrush_11
		{
			get
			{
				return GClass65.smethod_0("Purple", GClass66.Color_11);
			}
		}

		// Token: 0x17000234 RID: 564
		// (get) Token: 0x0600080C RID: 2060 RVA: 0x000072EC File Offset: 0x000054EC
		public static SolidBrush SolidBrush_12
		{
			get
			{
				return GClass65.smethod_0("Red", GClass66.Color_12);
			}
		}

		// Token: 0x17000235 RID: 565
		// (get) Token: 0x0600080D RID: 2061 RVA: 0x000072FD File Offset: 0x000054FD
		public static SolidBrush SolidBrush_13
		{
			get
			{
				return GClass65.smethod_0("Yellow", GClass66.Color_13);
			}
		}

		// Token: 0x0400043C RID: 1084
		private static Dictionary<string, SolidBrush> dictionary_0 = new Dictionary<string, SolidBrush>();
	}
}
