﻿using System;
using System.Collections.Generic;
using System.Drawing;

namespace ns0
{
	// Token: 0x0200005B RID: 91
	internal class Class15
	{
		// Token: 0x060006F2 RID: 1778 RVA: 0x00019328 File Offset: 0x00017528
		public Class15(GClass23 gclass23_1)
		{
			this.dictionary_0 = new Dictionary<GClass23, RectangleF>();
			this.list_1 = new List<GClass23>();
			this.list_0 = new List<Class11>();
			this.gclass23_0 = gclass23_1;
			this.gclass23_0.List_1.Add(this);
		}

		// Token: 0x170001FE RID: 510
		// (get) Token: 0x060006F3 RID: 1779 RVA: 0x00006833 File Offset: 0x00004A33
		public List<GClass23> List_0
		{
			get
			{
				return this.list_1;
			}
		}

		// Token: 0x170001FF RID: 511
		// (get) Token: 0x060006F4 RID: 1780 RVA: 0x0000683B File Offset: 0x00004A3B
		public List<Class11> List_1
		{
			get
			{
				return this.list_0;
			}
		}

		// Token: 0x17000200 RID: 512
		// (get) Token: 0x060006F5 RID: 1781 RVA: 0x00006843 File Offset: 0x00004A43
		public GClass23 GClass23_0
		{
			get
			{
				return this.gclass23_0;
			}
		}

		// Token: 0x17000201 RID: 513
		// (get) Token: 0x060006F6 RID: 1782 RVA: 0x0000684B File Offset: 0x00004A4B
		public Dictionary<GClass23, RectangleF> Dictionary_0
		{
			get
			{
				return this.dictionary_0;
			}
		}

		// Token: 0x060006F7 RID: 1783 RVA: 0x00019374 File Offset: 0x00017574
		public float method_0()
		{
			float num = float.MinValue;
			foreach (Class11 @class in this.List_1)
			{
				num = Math.Max(num, @class.Single_5);
			}
			return num;
		}

		// Token: 0x060006F8 RID: 1784 RVA: 0x00006853 File Offset: 0x00004A53
		internal void method_1(Class11 class11_0)
		{
			if (!this.List_1.Contains(class11_0))
			{
				this.List_1.Add(class11_0);
			}
			if (!this.List_0.Contains(class11_0.GClass23_0))
			{
				this.List_0.Add(class11_0.GClass23_0);
			}
		}

		// Token: 0x060006F9 RID: 1785 RVA: 0x000193D8 File Offset: 0x000175D8
		internal List<Class11> method_2(GClass23 gclass23_1)
		{
			List<Class11> list = new List<Class11>();
			foreach (Class11 @class in this.List_1)
			{
				if (@class.GClass23_0.Equals(gclass23_1))
				{
					list.Add(@class);
				}
			}
			return list;
		}

		// Token: 0x060006FA RID: 1786 RVA: 0x00019444 File Offset: 0x00017644
		internal void method_3(GClass23 gclass23_1, float float_0, float float_1, float float_2, float float_3)
		{
			float num = gclass23_1.Single_9 + gclass23_1.Single_1;
			float num2 = gclass23_1.Single_11 + gclass23_1.Single_3;
			float num3 = gclass23_1.Single_8 + gclass23_1.Single_0;
			float num4 = gclass23_1.Single_10 + gclass23_1.Single_0;
			if ((gclass23_1.Class15_0 != null && gclass23_1.Class15_0.Equals(this)) || gclass23_1.Boolean_0)
			{
				float_0 -= num;
			}
			if ((gclass23_1.Class15_1 != null && gclass23_1.Class15_1.Equals(this)) || gclass23_1.Boolean_0)
			{
				float_2 += num2;
			}
			if (!gclass23_1.Boolean_0)
			{
				float_1 -= num3;
				float_3 += num4;
			}
			if (!this.Dictionary_0.ContainsKey(gclass23_1))
			{
				this.Dictionary_0.Add(gclass23_1, RectangleF.FromLTRB(float_0, float_1, float_2, float_3));
			}
			else
			{
				RectangleF rectangleF = this.Dictionary_0[gclass23_1];
				this.Dictionary_0[gclass23_1] = RectangleF.FromLTRB(Math.Min(rectangleF.X, float_0), Math.Min(rectangleF.Y, float_1), Math.Max(rectangleF.Right, float_2), Math.Max(rectangleF.Bottom, float_3));
			}
			if (gclass23_1.GClass23_2 != null && gclass23_1.GClass23_2.String_47 == "inline")
			{
				this.method_3(gclass23_1.GClass23_2, float_0, float_1, float_2, float_3);
			}
		}

		// Token: 0x060006FB RID: 1787 RVA: 0x00019598 File Offset: 0x00017798
		internal void method_4()
		{
			foreach (GClass23 gclass in this.Dictionary_0.Keys)
			{
				gclass.Dictionary_0.Add(this, this.Dictionary_0[gclass]);
			}
		}

		// Token: 0x060006FC RID: 1788 RVA: 0x00019604 File Offset: 0x00017804
		internal void method_5(Graphics graphics_0)
		{
			foreach (GClass23 key in this.Dictionary_0.Keys)
			{
				if (!float.IsInfinity(this.Dictionary_0[key].Width))
				{
					graphics_0.FillRectangle(new SolidBrush(Color.FromArgb(50, Color.Black)), Rectangle.Round(this.Dictionary_0[key]));
					graphics_0.DrawRectangle(Pens.Red, Rectangle.Round(this.Dictionary_0[key]));
				}
			}
		}

		// Token: 0x060006FD RID: 1789 RVA: 0x000196B8 File Offset: 0x000178B8
		public float method_6(GClass23 gclass23_1, Graphics graphics_0)
		{
			Font font_ = gclass23_1.Font_1;
			FontFamily fontFamily = font_.FontFamily;
			FontStyle style = font_.Style;
			return font_.GetHeight(graphics_0) * (float)fontFamily.GetCellAscent(style) / (float)fontFamily.GetLineSpacing(style);
		}

		// Token: 0x060006FE RID: 1790 RVA: 0x000196F4 File Offset: 0x000178F4
		internal void method_7(Graphics graphics_0, GClass23 gclass23_1, float float_0)
		{
			List<Class11> list = this.method_2(gclass23_1);
			if (!this.Dictionary_0.ContainsKey(gclass23_1))
			{
				return;
			}
			RectangleF rectangleF = this.Dictionary_0[gclass23_1];
			float num = 0f;
			if (list.Count > 0)
			{
				num = list[0].Single_1 - rectangleF.Top;
			}
			else
			{
				Class11 @class = gclass23_1.method_4(gclass23_1, this);
				if (@class != null)
				{
					num = @class.Single_1 - rectangleF.Top;
				}
			}
			float num2 = float_0 - this.method_6(gclass23_1, graphics_0);
			if (gclass23_1.GClass23_2 != null && gclass23_1.GClass23_2.Dictionary_0.ContainsKey(this) && rectangleF.Height < gclass23_1.GClass23_2.Dictionary_0[this].Height)
			{
				float y = num2 - num;
				RectangleF value = new RectangleF(rectangleF.X, y, rectangleF.Width, rectangleF.Height);
				this.Dictionary_0[gclass23_1] = value;
				gclass23_1.method_28(this, num);
			}
			foreach (Class11 class2 in list)
			{
				if (!class2.Boolean_0)
				{
					class2.Single_1 = num2;
				}
			}
		}

		// Token: 0x060006FF RID: 1791 RVA: 0x0001983C File Offset: 0x00017A3C
		public override string ToString()
		{
			string[] array = new string[this.List_1.Count];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = this.List_1[i].String_0;
			}
			return string.Join(" ", array);
		}

		// Token: 0x040002FB RID: 763
		private List<Class11> list_0;

		// Token: 0x040002FC RID: 764
		private GClass23 gclass23_0;

		// Token: 0x040002FD RID: 765
		private Dictionary<GClass23, RectangleF> dictionary_0;

		// Token: 0x040002FE RID: 766
		private List<GClass23> list_1;
	}
}
