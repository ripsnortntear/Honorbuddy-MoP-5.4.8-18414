﻿using System;

namespace ns0
{
	// Token: 0x0200009B RID: 155
	public enum GEnum19
	{
		// Token: 0x04000471 RID: 1137
		const_0,
		// Token: 0x04000472 RID: 1138
		const_1,
		// Token: 0x04000473 RID: 1139
		const_2
	}
}
