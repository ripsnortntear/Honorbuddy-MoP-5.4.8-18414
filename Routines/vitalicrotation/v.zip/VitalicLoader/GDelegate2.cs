﻿using System;

namespace ns0
{
	// Token: 0x0200002B RID: 43
	// (Invoke) Token: 0x0600018B RID: 395
	public delegate void GDelegate2(object sender, GEventArgs0 e);
}
