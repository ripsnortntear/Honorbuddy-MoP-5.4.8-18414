﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200003A RID: 58
	[Designer("MetroFramework.Design.Controls.MetroLinkDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	[ToolboxBitmap(typeof(LinkLabel))]
	[DefaultEvent("Click")]
	public class GClass16 : Button, GInterface2
	{
		// Token: 0x0600029E RID: 670 RVA: 0x0000398C File Offset: 0x00001B8C
		public GClass16()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x0600029F RID: 671 RVA: 0x000039A7 File Offset: 0x00001BA7
		// (set) Token: 0x060002A0 RID: 672 RVA: 0x000039AF File Offset: 0x00001BAF
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_0
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x14000018 RID: 24
		// (add) Token: 0x060002A1 RID: 673 RVA: 0x0000D9FC File Offset: 0x0000BBFC
		// (remove) Token: 0x060002A2 RID: 674 RVA: 0x0000DA34 File Offset: 0x0000BC34
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060002A3 RID: 675 RVA: 0x000039B8 File Offset: 0x00001BB8
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000019 RID: 25
		// (add) Token: 0x060002A4 RID: 676 RVA: 0x0000DA6C File Offset: 0x0000BC6C
		// (remove) Token: 0x060002A5 RID: 677 RVA: 0x0000DAA4 File Offset: 0x0000BCA4
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060002A6 RID: 678 RVA: 0x000039D8 File Offset: 0x00001BD8
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x1400001A RID: 26
		// (add) Token: 0x060002A7 RID: 679 RVA: 0x0000DADC File Offset: 0x0000BCDC
		// (remove) Token: 0x060002A8 RID: 680 RVA: 0x0000DB14 File Offset: 0x0000BD14
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060002A9 RID: 681 RVA: 0x000039F8 File Offset: 0x00001BF8
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x060002AA RID: 682 RVA: 0x0000DB4C File Offset: 0x0000BD4C
		// (set) Token: 0x060002AB RID: 683 RVA: 0x00003A18 File Offset: 0x00001C18
		[DefaultValue(GEnum10.const_0)]
		[Category("Metro Appearance")]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x060002AC RID: 684 RVA: 0x0000DBA4 File Offset: 0x0000BDA4
		// (set) Token: 0x060002AD RID: 685 RVA: 0x00003A21 File Offset: 0x00001C21
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x060002AE RID: 686 RVA: 0x00003A2A File Offset: 0x00001C2A
		// (set) Token: 0x060002AF RID: 687 RVA: 0x00003A32 File Offset: 0x00001C32
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x060002B0 RID: 688 RVA: 0x00003A3B File Offset: 0x00001C3B
		// (set) Token: 0x060002B1 RID: 689 RVA: 0x00003A43 File Offset: 0x00001C43
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_8
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x060002B2 RID: 690 RVA: 0x00003A4C File Offset: 0x00001C4C
		// (set) Token: 0x060002B3 RID: 691 RVA: 0x00003A54 File Offset: 0x00001C54
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_9
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x060002B4 RID: 692 RVA: 0x00003A5D File Offset: 0x00001C5D
		// (set) Token: 0x060002B5 RID: 693 RVA: 0x00003A65 File Offset: 0x00001C65
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_10
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x060002B6 RID: 694 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x060002B7 RID: 695 RVA: 0x00002923 File Offset: 0x00000B23
		[Category("Metro Behaviour")]
		[Browsable(false)]
		[DefaultValue(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x060002B8 RID: 696 RVA: 0x00003A6E File Offset: 0x00001C6E
		// (set) Token: 0x060002B9 RID: 697 RVA: 0x00003A76 File Offset: 0x00001C76
		[Category("Metro Appearance")]
		[DefaultValue(GEnum15.const_0)]
		public GEnum15 GEnum15_0
		{
			get
			{
				return this.genum15_0;
			}
			set
			{
				this.genum15_0 = value;
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x060002BA RID: 698 RVA: 0x00003A7F File Offset: 0x00001C7F
		// (set) Token: 0x060002BB RID: 699 RVA: 0x00003A87 File Offset: 0x00001C87
		[DefaultValue(GEnum16.const_2)]
		[Category("Metro Appearance")]
		public GEnum16 GEnum16_0
		{
			get
			{
				return this.genum16_0;
			}
			set
			{
				this.genum16_0 = value;
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x060002BC RID: 700 RVA: 0x000033C1 File Offset: 0x000015C1
		// (set) Token: 0x060002BD RID: 701 RVA: 0x000033C9 File Offset: 0x000015C9
		[Browsable(false)]
		public override Font Font
		{
			get
			{
				return base.Font;
			}
			set
			{
				base.Font = value;
			}
		}

		// Token: 0x060002BE RID: 702 RVA: 0x0000DBFC File Offset: 0x0000BDFC
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_1)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
				}
				if (color.A == 255 && this.BackgroundImage == null)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060002BF RID: 703 RVA: 0x0000DC84 File Offset: 0x0000BE84
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060002C0 RID: 704 RVA: 0x0000DCE4 File Offset: 0x0000BEE4
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color color;
			if (this.bool_2)
			{
				color = this.ForeColor;
			}
			else if (this.bool_4 && !this.bool_5 && base.Enabled)
			{
				color = GClass39.GClass56.GClass59.smethod_1(this.GEnum29_0);
			}
			else if (this.bool_4 && this.bool_5 && base.Enabled)
			{
				color = GClass39.GClass56.GClass59.smethod_2(this.GEnum29_0);
			}
			else if (!base.Enabled)
			{
				color = GClass39.GClass56.GClass59.smethod_3(this.GEnum29_0);
			}
			else
			{
				color = ((!this.bool_3) ? GClass39.GClass56.GClass59.smethod_0(this.GEnum29_0) : GClass39.smethod_0(this.GEnum10_0));
			}
			TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Text, GClass67.smethod_5(this.genum15_0, this.genum16_0), base.ClientRectangle, color, GClass39.smethod_4(this.TextAlign));
			this.vmethod_2(new GEventArgs3(Color.Empty, color, paintEventArgs_0.Graphics));
			if (this.bool_0 && this.bool_6)
			{
				ControlPaint.DrawFocusRectangle(paintEventArgs_0.Graphics, base.ClientRectangle);
			}
		}

		// Token: 0x060002C1 RID: 705 RVA: 0x00003A90 File Offset: 0x00001C90
		protected override void OnGotFocus(EventArgs e)
		{
			this.bool_6 = true;
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x060002C2 RID: 706 RVA: 0x00003AA6 File Offset: 0x00001CA6
		protected override void OnLostFocus(EventArgs e)
		{
			this.bool_6 = false;
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		// Token: 0x060002C3 RID: 707 RVA: 0x00003ACA File Offset: 0x00001CCA
		protected override void OnEnter(EventArgs e)
		{
			this.bool_6 = true;
			base.Invalidate();
			base.OnEnter(e);
		}

		// Token: 0x060002C4 RID: 708 RVA: 0x00003AE0 File Offset: 0x00001CE0
		protected override void OnLeave(EventArgs e)
		{
			this.bool_6 = false;
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnLeave(e);
		}

		// Token: 0x060002C5 RID: 709 RVA: 0x00003B04 File Offset: 0x00001D04
		protected override void OnKeyDown(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Space)
			{
				this.bool_4 = true;
				this.bool_5 = true;
				base.Invalidate();
			}
			base.OnKeyDown(e);
		}

		// Token: 0x060002C6 RID: 710 RVA: 0x00003B2B File Offset: 0x00001D2B
		protected override void OnKeyUp(KeyEventArgs e)
		{
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnKeyUp(e);
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x00003B48 File Offset: 0x00001D48
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_4 = true;
			base.Invalidate();
			base.OnMouseEnter(e);
		}

		// Token: 0x060002C8 RID: 712 RVA: 0x00003B5E File Offset: 0x00001D5E
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.bool_5 = true;
				base.Invalidate();
			}
			base.OnMouseDown(e);
		}

		// Token: 0x060002C9 RID: 713 RVA: 0x00003B81 File Offset: 0x00001D81
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this.bool_5 = false;
			base.Invalidate();
			base.OnMouseUp(e);
		}

		// Token: 0x060002CA RID: 714 RVA: 0x00003B97 File Offset: 0x00001D97
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_4 = false;
			base.Invalidate();
			base.OnMouseLeave(e);
		}

		// Token: 0x060002CB RID: 715 RVA: 0x0000311B File Offset: 0x0000131B
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x040000FF RID: 255
		private bool bool_0;

		// Token: 0x04000100 RID: 256
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x04000101 RID: 257
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x04000102 RID: 258
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x04000103 RID: 259
		private GEnum10 genum10_0;

		// Token: 0x04000104 RID: 260
		private GEnum29 genum29_0;

		// Token: 0x04000105 RID: 261
		private GClass8 gclass8_0;

		// Token: 0x04000106 RID: 262
		private bool bool_1;

		// Token: 0x04000107 RID: 263
		private bool bool_2;

		// Token: 0x04000108 RID: 264
		private bool bool_3;

		// Token: 0x04000109 RID: 265
		private GEnum15 genum15_0;

		// Token: 0x0400010A RID: 266
		private GEnum16 genum16_0 = GEnum16.const_2;

		// Token: 0x0400010B RID: 267
		private bool bool_4;

		// Token: 0x0400010C RID: 268
		private bool bool_5;

		// Token: 0x0400010D RID: 269
		private bool bool_6;
	}
}
