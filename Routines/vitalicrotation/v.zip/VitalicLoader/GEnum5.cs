﻿using System;

namespace ns0
{
	// Token: 0x02000085 RID: 133
	public enum GEnum5
	{
		// Token: 0x0400040E RID: 1038
		const_0,
		// Token: 0x0400040F RID: 1039
		const_1,
		// Token: 0x04000410 RID: 1040
		const_2
	}
}
