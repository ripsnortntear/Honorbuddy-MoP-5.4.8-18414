﻿using System;

namespace ns0
{
	// Token: 0x02000086 RID: 134
	public enum GEnum6
	{
		// Token: 0x04000412 RID: 1042
		const_0,
		// Token: 0x04000413 RID: 1043
		const_1,
		// Token: 0x04000414 RID: 1044
		const_2,
		// Token: 0x04000415 RID: 1045
		const_3,
		// Token: 0x04000416 RID: 1046
		const_4
	}
}
