﻿using System;
using System.Drawing;

namespace ns0
{
	// Token: 0x02000055 RID: 85
	public class GClass32
	{
		// Token: 0x040002DC RID: 732
		public const string string_0 = "\n\n        \n        html, address,\n        blockquote,\n        body, dd, div,\n        dl, dt, fieldset, form,\n        frame, frameset,\n        h1, h2, h3, h4,\n        h5, h6, noframes,\n        ol, p, ul, center,\n        dir, hr, menu, pre   { display: block }\n        li              { display: list-item }\n        head            { display: none }\n        table           { display: table }\n        tr              { display: table-row }\n        thead           { display: table-header-group }\n        tbody           { display: table-row-group }\n        tfoot           { display: table-footer-group }\n        col             { display: table-column }\n        colgroup        { display: table-column-group }\n        td, th          { display: table-cell }\n        caption         { display: table-caption }\n        th              { font-weight: bolder; text-align: center }\n        caption         { text-align: center }\n        body            { margin: 8px }\n        h1              { font-size: 2em; margin: .67em 0 }\n        h2              { font-size: 1.5em; margin: .75em 0 }\n        h3              { font-size: 1.17em; margin: .83em 0 }\n        h4, p,\n        blockquote, ul,\n        fieldset, form,\n        ol, dl, dir,\n        menu            { margin: 0 0 }\n        h5              { font-size: .83em; margin: 1.5em 0 }\n        h6              { font-size: .75em; margin: 1.67em 0 }\n        h1, h2, h3, h4,\n        h5, h6, b,\n        strong          { font-weight: bolder; }\n        blockquote      { margin-left: 40px; margin-right: 40px }\n        i, cite, em,\n        var, address    { font-style: italic }\n        pre, tt, code,\n        kbd, samp       { font-family: monospace }\n        pre             { white-space: pre }\n        button, textarea,\n        input, select   { display: inline-block }\n        big             { font-size: 1.17em }\n        small, sub, sup { font-size: .83em }\n        sub             { vertical-align: sub }\n        sup             { vertical-align: super }\n        table           { border-spacing: 2px; }\n        thead, tbody,\n        tfoot           { vertical-align: middle }\n        td, th          { vertical-align: inherit }\n        s, strike, del  { text-decoration: line-through }\n        hr              { border: 1px inset }\n        ol, ul, dir,\n        menu, dd        { margin-left: 40px }\n        ol              { list-style-type: decimal }\n        ol ul, ul ol,\n        ul ul, ol ol    { margin-top: 0; margin-bottom: 0 }\n        u, ins          { text-decoration: underline }\n        br:before       { content: \"\\A\" }\n        :before, :after { white-space: pre-line }\n        center          { text-align: center }\n        :link, :visited { text-decoration: underline }\n        :focus          { outline: thin dotted invert }\n\n        /* Begin bidirectionality settings (do not change) */\n        BDO[DIR=\"ltr\"]  { direction: ltr; unicode-bidi: bidi-override }\n        BDO[DIR=\"rtl\"]  { direction: rtl; unicode-bidi: bidi-override }\n\n        *[DIR=\"ltr\"]    { direction: ltr; unicode-bidi: embed }\n        *[DIR=\"rtl\"]    { direction: rtl; unicode-bidi: embed }\n\n        @media print {\n          h1            { page-break-before: always }\n          h1, h2, h3,\n          h4, h5, h6    { page-break-after: avoid }\n          ul, ol, dl    { page-break-before: avoid }\n        }\n\n        /* Not in the specification but necessary */\n        a               { font-weight: bold; text-decoration:underline }\n        table           { border-color:#dfdfdf; border-style:outset; }\n        td, th          { border-color:#dfdfdf; border-style:inset; }\n        style, title,\n        script, link,\n        meta, area,\n        base, param     { display:none }\n        hr              { border-color: #ccc }  \n        pre             { font-size:10pt }\n        \n        /*This is the background of the HtmlToolTip*/\n        .htmltooltipbackground {\n              border:solid 1px #767676;\n              background-color:#white;\n              background-gradient:#E4E5F0;\n              text-align:center;\n        }\n\n        ";

		// Token: 0x040002DD RID: 733
		public const string string_1 = "\n        <style>\n          table { \n\n               border-bottom:1px solid #bbb;\n               border-right:1px solid #bbb;\n               border-spacing:0;\n          }\n          td { \n               border:1px solid #555;\n               font:bold 9pt Arial;\n               padding:3px;\n               color:red;\n               background-color:#fbfbfb;\n           }\n        </style>\n        <table>\n        <tr>\n        <td>X</td>\n        </tr>\n        </table>";

		// Token: 0x040002DE RID: 734
		public const string string_2 = "\n        <style>\n          table { \n\n               border-bottom:1px solid #bbb;\n               border-right:1px solid #bbb;\n               border-spacing:0;\n          }\n          td { \n               border:1px solid #555;\n               font:bold 7pt Arial;\n               padding:3px;\n               color:red;\n               background-color:#fbfbfb;\n           }\n        </style>\n        <table>\n        <tr>\n        <td>X</td>\n        </tr>\n        </table>";

		// Token: 0x040002DF RID: 735
		public static float float_0 = 12f;

		// Token: 0x040002E0 RID: 736
		public static string string_3 = FontFamily.GenericSerif.Name;

		// Token: 0x040002E1 RID: 737
		public static string string_4 = FontFamily.GenericSansSerif.Name;

		// Token: 0x040002E2 RID: 738
		public static string string_5 = "Monotype Corsiva";

		// Token: 0x040002E3 RID: 739
		public static string string_6 = "Comic Sans MS";

		// Token: 0x040002E4 RID: 740
		public static string string_7 = FontFamily.GenericMonospace.Name;
	}
}
