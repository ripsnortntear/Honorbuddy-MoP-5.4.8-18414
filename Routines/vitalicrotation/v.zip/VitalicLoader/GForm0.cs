﻿using System;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000026 RID: 38
	public partial class GForm0 : MetroForm
	{
		// Token: 0x06000153 RID: 339 RVA: 0x0000AD68 File Offset: 0x00008F68
		public GForm0()
		{
			base.ShowInTaskbar = false;
			base.Boolean_0 = false;
			base.Boolean_2 = false;
			base.ControlBox = false;
			base.Int32_0 = 0;
			base.Boolean_1 = false;
			base.Padding_0 = new Padding(0);
			base.GEnum6_0 = GEnum6.const_4;
		}

		// Token: 0x06000154 RID: 340 RVA: 0x00002B42 File Offset: 0x00000D42
		protected override void OnMouseEnter(EventArgs e)
		{
			base.Hide();
			base.OnMouseEnter(e);
		}

		// Token: 0x06000155 RID: 341 RVA: 0x00002B51 File Offset: 0x00000D51
		protected override void OnMouseLeave(EventArgs e)
		{
			base.Hide();
			base.OnMouseLeave(e);
		}

		// Token: 0x04000080 RID: 128
		public GClass15 gclass15_0;
	}
}
