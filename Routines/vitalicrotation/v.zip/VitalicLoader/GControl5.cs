﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000049 RID: 73
	public class GControl5 : GControl4
	{
		// Token: 0x1700014E RID: 334
		// (get) Token: 0x0600056C RID: 1388 RVA: 0x00005918 File Offset: 0x00003B18
		// (set) Token: 0x0600056D RID: 1389 RVA: 0x00005920 File Offset: 0x00003B20
		[Category("Metro Appearance")]
		[DefaultValue(GEnum21.const_1)]
		public GEnum21 GEnum21_0
		{
			get
			{
				return this.genum21_0;
			}
			set
			{
				this.genum21_0 = value;
			}
		}

		// Token: 0x1700014F RID: 335
		// (get) Token: 0x0600056E RID: 1390 RVA: 0x00005929 File Offset: 0x00003B29
		// (set) Token: 0x0600056F RID: 1391 RVA: 0x00005931 File Offset: 0x00003B31
		[Category("Metro Appearance")]
		[DefaultValue(GEnum22.const_0)]
		public GEnum22 GEnum22_0
		{
			get
			{
				return this.genum22_0;
			}
			set
			{
				this.genum22_0 = value;
			}
		}

		// Token: 0x17000150 RID: 336
		// (get) Token: 0x06000570 RID: 1392 RVA: 0x0000593A File Offset: 0x00003B3A
		// (set) Token: 0x06000571 RID: 1393 RVA: 0x00005942 File Offset: 0x00003B42
		[DefaultValue(ContentAlignment.MiddleRight)]
		[Category("Metro Appearance")]
		public ContentAlignment ContentAlignment_0
		{
			get
			{
				return this.contentAlignment_0;
			}
			set
			{
				this.contentAlignment_0 = value;
			}
		}

		// Token: 0x17000151 RID: 337
		// (get) Token: 0x06000572 RID: 1394 RVA: 0x0000594B File Offset: 0x00003B4B
		// (set) Token: 0x06000573 RID: 1395 RVA: 0x00005953 File Offset: 0x00003B53
		[DefaultValue(true)]
		[Category("Metro Appearance")]
		public bool Boolean_1
		{
			get
			{
				return this.bool_7;
			}
			set
			{
				this.bool_7 = value;
			}
		}

		// Token: 0x17000152 RID: 338
		// (get) Token: 0x06000574 RID: 1396 RVA: 0x0000595C File Offset: 0x00003B5C
		[Browsable(false)]
		public double Double_0
		{
			get
			{
				return (1.0 - (double)(base.Int32_2 - base.Int32_0) / (double)base.Int32_2) * 100.0;
			}
		}

		// Token: 0x17000153 RID: 339
		// (get) Token: 0x06000575 RID: 1397 RVA: 0x00005988 File Offset: 0x00003B88
		[Browsable(false)]
		public double Double_1
		{
			get
			{
				return 1.0 - (double)(base.Int32_2 - base.Int32_0) / (double)base.Int32_2;
			}
		}

		// Token: 0x17000154 RID: 340
		// (get) Token: 0x06000576 RID: 1398 RVA: 0x000059AA File Offset: 0x00003BAA
		[Browsable(false)]
		public string String_0
		{
			get
			{
				return string.Format("{0}%", Math.Round(this.Double_0));
			}
		}

		// Token: 0x17000155 RID: 341
		// (get) Token: 0x06000577 RID: 1399 RVA: 0x00013C54 File Offset: 0x00011E54
		private double Double_2
		{
			get
			{
				return (double)base.Int32_0 / (double)base.Int32_2 * (double)base.ClientRectangle.Width;
			}
		}

		// Token: 0x06000578 RID: 1400 RVA: 0x00013760 File Offset: 0x00011960
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x06000579 RID: 1401 RVA: 0x00013C80 File Offset: 0x00011E80
		protected override void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			this.method_4(paintEventArgs_0.Graphics);
			this.method_5(paintEventArgs_0.Graphics);
			Color color = this.bool_8 ? GClass39.GClass40.GClass43.smethod_0(base.GEnum29_0) : GClass39.GClass40.GClass44.smethod_0(base.GEnum29_0);
			using (Pen pen = new Pen(color))
			{
				Rectangle rect = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
				paintEventArgs_0.Graphics.DrawRectangle(pen, rect);
			}
			this.vmethod_2(new GEventArgs3(Color.Empty, Color.Empty, paintEventArgs_0.Graphics));
		}

		// Token: 0x0600057A RID: 1402 RVA: 0x00013D2C File Offset: 0x00011F2C
		private void method_4(Graphics graphics_0)
		{
			graphics_0.FillRectangle(GClass39.smethod_1(base.GEnum10_0), 0, 0, (int)this.Double_2, base.ClientRectangle.Height);
		}

		// Token: 0x0600057B RID: 1403 RVA: 0x00013D64 File Offset: 0x00011F64
		private void method_5(Graphics graphics_0)
		{
			if (this.Boolean_1)
			{
				return;
			}
			Color foreColor;
			if (!base.Enabled)
			{
				foreColor = GClass39.GClass56.GClass63.smethod_1(base.GEnum29_0);
			}
			else
			{
				foreColor = GClass39.GClass56.GClass63.smethod_0(base.GEnum29_0);
			}
			TextRenderer.DrawText(graphics_0, this.String_0, GClass67.smethod_9(this.genum21_0, this.genum22_0), base.ClientRectangle, foreColor, GClass39.smethod_4(this.ContentAlignment_0));
		}

		// Token: 0x0600057C RID: 1404 RVA: 0x00013DCC File Offset: 0x00011FCC
		public override Size GetPreferredSize(Size proposedSize)
		{
			base.GetPreferredSize(proposedSize);
			Size result;
			using (Graphics graphics = base.CreateGraphics())
			{
				proposedSize = new Size(int.MaxValue, int.MaxValue);
				result = TextRenderer.MeasureText(graphics, this.String_0, GClass67.smethod_9(this.genum21_0, this.genum22_0), proposedSize, GClass39.smethod_4(this.ContentAlignment_0));
			}
			return result;
		}

		// Token: 0x0600057D RID: 1405 RVA: 0x000059C6 File Offset: 0x00003BC6
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_8 = true;
			base.OnMouseEnter(e);
		}

		// Token: 0x0600057E RID: 1406 RVA: 0x000059D6 File Offset: 0x00003BD6
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_8 = false;
			base.OnMouseLeave(e);
		}

		// Token: 0x040001E8 RID: 488
		private GEnum21 genum21_0 = GEnum21.const_1;

		// Token: 0x040001E9 RID: 489
		private GEnum22 genum22_0;

		// Token: 0x040001EA RID: 490
		private ContentAlignment contentAlignment_0 = ContentAlignment.MiddleRight;

		// Token: 0x040001EB RID: 491
		private bool bool_7 = true;

		// Token: 0x040001EC RID: 492
		private bool bool_8;
	}
}
