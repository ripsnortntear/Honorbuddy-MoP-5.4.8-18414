﻿using System;
using System.Drawing;

namespace ns0
{
	// Token: 0x020000A5 RID: 165
	public static class GClass67
	{
		// Token: 0x0600081D RID: 2077 RVA: 0x0001D940 File Offset: 0x0001BB40
		static GClass67()
		{
			try
			{
				Type type = Type.GetType("MetroFramework.Fonts.FontResolver, MetroFramework.Fonts, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a");
				if (type != null)
				{
					GClass67.ginterface5_0 = (GClass67.GInterface5)Activator.CreateInstance(type);
					if (GClass67.ginterface5_0 != null)
					{
						return;
					}
				}
			}
			catch (Exception)
			{
			}
			GClass67.ginterface5_0 = new GClass67.Class24();
		}

		// Token: 0x0600081E RID: 2078 RVA: 0x000073F7 File Offset: 0x000055F7
		public static void smethod_0(GClass67.GInterface5 ginterface5_1)
		{
			GClass67.ginterface5_0 = ginterface5_1;
		}

		// Token: 0x0600081F RID: 2079 RVA: 0x000073FF File Offset: 0x000055FF
		public static Font smethod_1(float float_0)
		{
			return GClass67.ginterface5_0.imethod_0("Segoe UI Light", float_0, FontStyle.Regular, GraphicsUnit.Pixel);
		}

		// Token: 0x06000820 RID: 2080 RVA: 0x00007413 File Offset: 0x00005613
		public static Font smethod_2(float float_0)
		{
			return GClass67.ginterface5_0.imethod_0("Segoe UI", float_0, FontStyle.Regular, GraphicsUnit.Pixel);
		}

		// Token: 0x06000821 RID: 2081 RVA: 0x00007427 File Offset: 0x00005627
		public static Font smethod_3(float float_0)
		{
			return GClass67.ginterface5_0.imethod_0("Segoe UI", float_0, FontStyle.Bold, GraphicsUnit.Pixel);
		}

		// Token: 0x17000244 RID: 580
		// (get) Token: 0x06000822 RID: 2082 RVA: 0x0000743B File Offset: 0x0000563B
		public static Font Font_0
		{
			get
			{
				return GClass67.smethod_1(24f);
			}
		}

		// Token: 0x17000245 RID: 581
		// (get) Token: 0x06000823 RID: 2083 RVA: 0x00007447 File Offset: 0x00005647
		public static Font Font_1
		{
			get
			{
				return GClass67.smethod_2(14f);
			}
		}

		// Token: 0x06000824 RID: 2084 RVA: 0x0001D994 File Offset: 0x0001BB94
		public static Font smethod_4(GEnum13 genum13_0, GEnum14 genum14_0)
		{
			if (genum13_0 == GEnum13.const_0)
			{
				if (genum14_0 == GEnum14.const_0)
				{
					return GClass67.smethod_1(12f);
				}
				if (genum14_0 == GEnum14.const_1)
				{
					return GClass67.smethod_2(12f);
				}
				if (genum14_0 == GEnum14.const_2)
				{
					return GClass67.smethod_3(12f);
				}
			}
			else if (genum13_0 == GEnum13.const_1)
			{
				if (genum14_0 == GEnum14.const_0)
				{
					return GClass67.smethod_1(14f);
				}
				if (genum14_0 == GEnum14.const_1)
				{
					return GClass67.smethod_2(14f);
				}
				if (genum14_0 == GEnum14.const_2)
				{
					return GClass67.smethod_3(14f);
				}
			}
			else if (genum13_0 == GEnum13.const_2)
			{
				if (genum14_0 == GEnum14.const_0)
				{
					return GClass67.smethod_1(18f);
				}
				if (genum14_0 == GEnum14.const_1)
				{
					return GClass67.smethod_2(18f);
				}
				if (genum14_0 == GEnum14.const_2)
				{
					return GClass67.smethod_3(18f);
				}
			}
			return GClass67.smethod_1(14f);
		}

		// Token: 0x17000246 RID: 582
		// (get) Token: 0x06000825 RID: 2085 RVA: 0x00007453 File Offset: 0x00005653
		public static Font Font_2
		{
			get
			{
				return GClass67.smethod_2(44f);
			}
		}

		// Token: 0x06000826 RID: 2086 RVA: 0x0001DA3C File Offset: 0x0001BC3C
		public static Font smethod_5(GEnum15 genum15_0, GEnum16 genum16_0)
		{
			if (genum15_0 == GEnum15.const_0)
			{
				if (genum16_0 == GEnum16.const_0)
				{
					return GClass67.smethod_1(12f);
				}
				if (genum16_0 == GEnum16.const_1)
				{
					return GClass67.smethod_2(12f);
				}
				if (genum16_0 == GEnum16.const_2)
				{
					return GClass67.smethod_3(12f);
				}
			}
			else if (genum15_0 == GEnum15.const_1)
			{
				if (genum16_0 == GEnum16.const_0)
				{
					return GClass67.smethod_1(14f);
				}
				if (genum16_0 == GEnum16.const_1)
				{
					return GClass67.smethod_2(14f);
				}
				if (genum16_0 == GEnum16.const_2)
				{
					return GClass67.smethod_3(14f);
				}
			}
			else if (genum15_0 == GEnum15.const_2)
			{
				if (genum16_0 == GEnum16.const_0)
				{
					return GClass67.smethod_1(18f);
				}
				if (genum16_0 == GEnum16.const_1)
				{
					return GClass67.smethod_2(18f);
				}
				if (genum16_0 == GEnum16.const_2)
				{
					return GClass67.smethod_3(18f);
				}
			}
			return GClass67.smethod_2(12f);
		}

		// Token: 0x06000827 RID: 2087 RVA: 0x0001DA3C File Offset: 0x0001BC3C
		public static Font smethod_6(GEnum17 genum17_0, GEnum18 genum18_0)
		{
			if (genum17_0 == GEnum17.const_0)
			{
				if (genum18_0 == GEnum18.const_0)
				{
					return GClass67.smethod_1(12f);
				}
				if (genum18_0 == GEnum18.const_1)
				{
					return GClass67.smethod_2(12f);
				}
				if (genum18_0 == GEnum18.const_2)
				{
					return GClass67.smethod_3(12f);
				}
			}
			else if (genum17_0 == GEnum17.const_1)
			{
				if (genum18_0 == GEnum18.const_0)
				{
					return GClass67.smethod_1(14f);
				}
				if (genum18_0 == GEnum18.const_1)
				{
					return GClass67.smethod_2(14f);
				}
				if (genum18_0 == GEnum18.const_2)
				{
					return GClass67.smethod_3(14f);
				}
			}
			else if (genum17_0 == GEnum17.const_2)
			{
				if (genum18_0 == GEnum18.const_0)
				{
					return GClass67.smethod_1(18f);
				}
				if (genum18_0 == GEnum18.const_1)
				{
					return GClass67.smethod_2(18f);
				}
				if (genum18_0 == GEnum18.const_2)
				{
					return GClass67.smethod_3(18f);
				}
			}
			return GClass67.smethod_2(12f);
		}

		// Token: 0x06000828 RID: 2088 RVA: 0x0001D994 File Offset: 0x0001BB94
		public static Font smethod_7(GEnum11 genum11_0, GEnum12 genum12_0)
		{
			if (genum11_0 == GEnum11.const_0)
			{
				if (genum12_0 == GEnum12.const_0)
				{
					return GClass67.smethod_1(12f);
				}
				if (genum12_0 == GEnum12.const_1)
				{
					return GClass67.smethod_2(12f);
				}
				if (genum12_0 == GEnum12.const_2)
				{
					return GClass67.smethod_3(12f);
				}
			}
			else if (genum11_0 == GEnum11.const_1)
			{
				if (genum12_0 == GEnum12.const_0)
				{
					return GClass67.smethod_1(14f);
				}
				if (genum12_0 == GEnum12.const_1)
				{
					return GClass67.smethod_2(14f);
				}
				if (genum12_0 == GEnum12.const_2)
				{
					return GClass67.smethod_3(14f);
				}
			}
			else if (genum11_0 == GEnum11.const_2)
			{
				if (genum12_0 == GEnum12.const_0)
				{
					return GClass67.smethod_1(18f);
				}
				if (genum12_0 == GEnum12.const_1)
				{
					return GClass67.smethod_2(18f);
				}
				if (genum12_0 == GEnum12.const_2)
				{
					return GClass67.smethod_3(18f);
				}
			}
			return GClass67.smethod_1(14f);
		}

		// Token: 0x06000829 RID: 2089 RVA: 0x0001DA3C File Offset: 0x0001BC3C
		public static Font smethod_8(GEnum19 genum19_0, GEnum20 genum20_0)
		{
			if (genum19_0 == GEnum19.const_0)
			{
				if (genum20_0 == GEnum20.const_0)
				{
					return GClass67.smethod_1(12f);
				}
				if (genum20_0 == GEnum20.const_1)
				{
					return GClass67.smethod_2(12f);
				}
				if (genum20_0 == GEnum20.const_2)
				{
					return GClass67.smethod_3(12f);
				}
			}
			else if (genum19_0 == GEnum19.const_1)
			{
				if (genum20_0 == GEnum20.const_0)
				{
					return GClass67.smethod_1(14f);
				}
				if (genum20_0 == GEnum20.const_1)
				{
					return GClass67.smethod_2(14f);
				}
				if (genum20_0 == GEnum20.const_2)
				{
					return GClass67.smethod_3(14f);
				}
			}
			else if (genum19_0 == GEnum19.const_2)
			{
				if (genum20_0 == GEnum20.const_0)
				{
					return GClass67.smethod_1(18f);
				}
				if (genum20_0 == GEnum20.const_1)
				{
					return GClass67.smethod_2(18f);
				}
				if (genum20_0 == GEnum20.const_2)
				{
					return GClass67.smethod_3(18f);
				}
			}
			return GClass67.smethod_2(12f);
		}

		// Token: 0x0600082A RID: 2090 RVA: 0x0001D994 File Offset: 0x0001BB94
		public static Font smethod_9(GEnum21 genum21_0, GEnum22 genum22_0)
		{
			if (genum21_0 == GEnum21.const_0)
			{
				if (genum22_0 == GEnum22.const_0)
				{
					return GClass67.smethod_1(12f);
				}
				if (genum22_0 == GEnum22.const_1)
				{
					return GClass67.smethod_2(12f);
				}
				if (genum22_0 == GEnum22.const_2)
				{
					return GClass67.smethod_3(12f);
				}
			}
			else if (genum21_0 == GEnum21.const_1)
			{
				if (genum22_0 == GEnum22.const_0)
				{
					return GClass67.smethod_1(14f);
				}
				if (genum22_0 == GEnum22.const_1)
				{
					return GClass67.smethod_2(14f);
				}
				if (genum22_0 == GEnum22.const_2)
				{
					return GClass67.smethod_3(14f);
				}
			}
			else if (genum21_0 == GEnum21.const_2)
			{
				if (genum22_0 == GEnum22.const_0)
				{
					return GClass67.smethod_1(18f);
				}
				if (genum22_0 == GEnum22.const_1)
				{
					return GClass67.smethod_2(18f);
				}
				if (genum22_0 == GEnum22.const_2)
				{
					return GClass67.smethod_3(18f);
				}
			}
			return GClass67.smethod_1(14f);
		}

		// Token: 0x0600082B RID: 2091 RVA: 0x0001D994 File Offset: 0x0001BB94
		public static Font smethod_10(GEnum23 genum23_0, GEnum24 genum24_0)
		{
			if (genum23_0 == GEnum23.const_0)
			{
				if (genum24_0 == GEnum24.const_0)
				{
					return GClass67.smethod_1(12f);
				}
				if (genum24_0 == GEnum24.const_1)
				{
					return GClass67.smethod_2(12f);
				}
				if (genum24_0 == GEnum24.const_2)
				{
					return GClass67.smethod_3(12f);
				}
			}
			else if (genum23_0 == GEnum23.const_1)
			{
				if (genum24_0 == GEnum24.const_0)
				{
					return GClass67.smethod_1(14f);
				}
				if (genum24_0 == GEnum24.const_1)
				{
					return GClass67.smethod_2(14f);
				}
				if (genum24_0 == GEnum24.const_2)
				{
					return GClass67.smethod_3(14f);
				}
			}
			else if (genum23_0 == GEnum23.const_2)
			{
				if (genum24_0 == GEnum24.const_0)
				{
					return GClass67.smethod_1(18f);
				}
				if (genum24_0 == GEnum24.const_1)
				{
					return GClass67.smethod_2(18f);
				}
				if (genum24_0 == GEnum24.const_2)
				{
					return GClass67.smethod_3(18f);
				}
			}
			return GClass67.smethod_1(14f);
		}

		// Token: 0x0600082C RID: 2092 RVA: 0x0001DA3C File Offset: 0x0001BC3C
		public static Font smethod_11(GEnum25 genum25_0, GEnum26 genum26_0)
		{
			if (genum25_0 == GEnum25.const_0)
			{
				if (genum26_0 == GEnum26.const_0)
				{
					return GClass67.smethod_1(12f);
				}
				if (genum26_0 == GEnum26.const_1)
				{
					return GClass67.smethod_2(12f);
				}
				if (genum26_0 == GEnum26.const_2)
				{
					return GClass67.smethod_3(12f);
				}
			}
			else if (genum25_0 == GEnum25.const_1)
			{
				if (genum26_0 == GEnum26.const_0)
				{
					return GClass67.smethod_1(14f);
				}
				if (genum26_0 == GEnum26.const_1)
				{
					return GClass67.smethod_2(14f);
				}
				if (genum26_0 == GEnum26.const_2)
				{
					return GClass67.smethod_3(14f);
				}
			}
			else if (genum25_0 == GEnum25.const_2)
			{
				if (genum26_0 == GEnum26.const_0)
				{
					return GClass67.smethod_1(18f);
				}
				if (genum26_0 == GEnum26.const_1)
				{
					return GClass67.smethod_2(18f);
				}
				if (genum26_0 == GEnum26.const_2)
				{
					return GClass67.smethod_3(18f);
				}
			}
			return GClass67.smethod_2(12f);
		}

		// Token: 0x0600082D RID: 2093 RVA: 0x0001DAE4 File Offset: 0x0001BCE4
		public static Font smethod_12(GEnum27 genum27_0, GEnum28 genum28_0)
		{
			if (genum27_0 == GEnum27.const_0)
			{
				if (genum28_0 == GEnum28.const_0)
				{
					return GClass67.smethod_1(11f);
				}
				if (genum28_0 == GEnum28.const_1)
				{
					return GClass67.smethod_2(11f);
				}
				if (genum28_0 == GEnum28.const_2)
				{
					return GClass67.smethod_3(11f);
				}
			}
			else if (genum27_0 == GEnum27.const_1)
			{
				if (genum28_0 == GEnum28.const_0)
				{
					return GClass67.smethod_1(13f);
				}
				if (genum28_0 == GEnum28.const_1)
				{
					return GClass67.smethod_2(13f);
				}
				if (genum28_0 == GEnum28.const_2)
				{
					return GClass67.smethod_3(13f);
				}
			}
			else if (genum27_0 == GEnum27.const_2)
			{
				if (genum28_0 == GEnum28.const_0)
				{
					return GClass67.smethod_1(16f);
				}
				if (genum28_0 == GEnum28.const_1)
				{
					return GClass67.smethod_2(16f);
				}
				if (genum28_0 == GEnum28.const_2)
				{
					return GClass67.smethod_3(16f);
				}
			}
			return GClass67.smethod_2(11f);
		}

		// Token: 0x04000498 RID: 1176
		private static GClass67.GInterface5 ginterface5_0;

		// Token: 0x020000A6 RID: 166
		public interface GInterface5
		{
			// Token: 0x0600082E RID: 2094
			Font imethod_0(string string_0, float float_0, FontStyle fontStyle_0, GraphicsUnit graphicsUnit_0);
		}

		// Token: 0x020000A7 RID: 167
		private class Class24 : GClass67.GInterface5
		{
			// Token: 0x06000830 RID: 2096 RVA: 0x0000745F File Offset: 0x0000565F
			public Font imethod_0(string string_0, float float_0, FontStyle fontStyle_0, GraphicsUnit graphicsUnit_0)
			{
				return new Font(string_0, float_0, fontStyle_0, graphicsUnit_0);
			}
		}
	}
}
