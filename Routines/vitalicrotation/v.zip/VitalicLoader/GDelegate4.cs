﻿using System;

namespace ns0
{
	// Token: 0x02000032 RID: 50
	// (Invoke) Token: 0x060001C0 RID: 448
	public delegate void GDelegate4(object sender, GEventArgs2 e);
}
