﻿using System;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000031 RID: 49
	public class GEventArgs2 : EventArgs
	{
		// Token: 0x060001B7 RID: 439 RVA: 0x00002E84 File Offset: 0x00001084
		public GEventArgs2() : this(string.Empty, null, null)
		{
		}

		// Token: 0x060001B8 RID: 440 RVA: 0x00002E93 File Offset: 0x00001093
		public GEventArgs2(object object_1) : this(object_1, null, null)
		{
		}

		// Token: 0x060001B9 RID: 441 RVA: 0x00002E9E File Offset: 0x0000109E
		public GEventArgs2(object object_1, Control control_1) : this(object_1, control_1, null)
		{
		}

		// Token: 0x060001BA RID: 442 RVA: 0x00002EA9 File Offset: 0x000010A9
		public GEventArgs2(object object_1, Control control_1, Exception exception_1)
		{
			this.object_0 = object_1;
			this.control_0 = control_1;
			this.exception_0 = exception_1;
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x060001BB RID: 443 RVA: 0x00002EC6 File Offset: 0x000010C6
		public Control Control_0
		{
			get
			{
				return this.control_0;
			}
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x060001BC RID: 444 RVA: 0x00002ECE File Offset: 0x000010CE
		public object Object_0
		{
			get
			{
				return this.object_0;
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x060001BD RID: 445 RVA: 0x00002ED6 File Offset: 0x000010D6
		public bool Boolean_0
		{
			get
			{
				return this.exception_0 == null;
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x060001BE RID: 446 RVA: 0x00002EE1 File Offset: 0x000010E1
		public Exception Exception_0
		{
			get
			{
				return this.exception_0;
			}
		}

		// Token: 0x040000B4 RID: 180
		private object object_0;

		// Token: 0x040000B5 RID: 181
		private Exception exception_0;

		// Token: 0x040000B6 RID: 182
		private Control control_0;
	}
}
