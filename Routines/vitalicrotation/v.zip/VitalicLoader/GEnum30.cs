﻿using System;

namespace ns0
{
	// Token: 0x020000BA RID: 186
	public enum GEnum30
	{
		// Token: 0x040004FB RID: 1275
		const_0 = -1,
		// Token: 0x040004FC RID: 1276
		const_1,
		// Token: 0x040004FD RID: 1277
		const_2,
		// Token: 0x040004FE RID: 1278
		const_3,
		// Token: 0x040004FF RID: 1279
		const_4
	}
}
