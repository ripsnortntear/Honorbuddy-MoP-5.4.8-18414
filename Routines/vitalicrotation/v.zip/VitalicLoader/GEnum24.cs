﻿using System;

namespace ns0
{
	// Token: 0x020000A0 RID: 160
	public enum GEnum24
	{
		// Token: 0x04000485 RID: 1157
		const_0,
		// Token: 0x04000486 RID: 1158
		const_1,
		// Token: 0x04000487 RID: 1159
		const_2
	}
}
