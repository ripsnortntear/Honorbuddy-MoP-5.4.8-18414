﻿using System;
using System.Collections.Generic;

namespace ns0
{
	// Token: 0x02000053 RID: 83
	internal class Class12
	{
		// Token: 0x060006C4 RID: 1732 RVA: 0x000066BE File Offset: 0x000048BE
		private Class12()
		{
			this.list_0 = new List<Class11>();
			this.class11_0 = null;
		}

		// Token: 0x060006C5 RID: 1733 RVA: 0x000066D8 File Offset: 0x000048D8
		public Class12(GClass23 gclass23_1, string string_1) : this()
		{
			this.gclass23_0 = gclass23_1;
			this.string_0 = string_1.Replace("\r", string.Empty);
		}

		// Token: 0x060006C6 RID: 1734 RVA: 0x000066FD File Offset: 0x000048FD
		public static bool smethod_0(GClass23 gclass23_1)
		{
			return gclass23_1.String_57 == "normal" || gclass23_1.String_57 == "nowrap" || gclass23_1.String_57 == "pre-line";
		}

		// Token: 0x060006C7 RID: 1735 RVA: 0x00006735 File Offset: 0x00004935
		public static bool smethod_1(GClass23 gclass23_1)
		{
			return gclass23_1.String_57 == "normal" || gclass23_1.String_57 == "nowrap";
		}

		// Token: 0x170001F5 RID: 501
		// (get) Token: 0x060006C8 RID: 1736 RVA: 0x0000675B File Offset: 0x0000495B
		public List<Class11> List_0
		{
			get
			{
				return this.list_0;
			}
		}

		// Token: 0x170001F6 RID: 502
		// (get) Token: 0x060006C9 RID: 1737 RVA: 0x00006763 File Offset: 0x00004963
		public string String_0
		{
			get
			{
				return this.string_0;
			}
		}

		// Token: 0x170001F7 RID: 503
		// (get) Token: 0x060006CA RID: 1738 RVA: 0x0000676B File Offset: 0x0000496B
		public GClass23 GClass23_0
		{
			get
			{
				return this.gclass23_0;
			}
		}

		// Token: 0x060006CB RID: 1739 RVA: 0x00017648 File Offset: 0x00015848
		public void method_0()
		{
			if (string.IsNullOrEmpty(this.String_0))
			{
				return;
			}
			this.class11_0 = new Class11(this.GClass23_0);
			bool flag = this.method_2(this.String_0[0]);
			for (int i = 0; i < this.String_0.Length; i++)
			{
				if (this.method_2(this.String_0[i]))
				{
					if (!flag)
					{
						this.method_1();
					}
					if (this.method_3(this.String_0[i]))
					{
						this.class11_0.method_1('\n');
						this.method_1();
					}
					else if (this.method_4(this.String_0[i]))
					{
						this.class11_0.method_1('\t');
						this.method_1();
					}
					else
					{
						this.class11_0.method_1(' ');
					}
					flag = true;
				}
				else
				{
					if (flag)
					{
						this.method_1();
					}
					this.class11_0.method_1(this.String_0[i]);
					flag = false;
				}
			}
			this.method_1();
		}

		// Token: 0x060006CC RID: 1740 RVA: 0x00006773 File Offset: 0x00004973
		private void method_1()
		{
			if (this.class11_0.String_0.Length > 0)
			{
				this.List_0.Add(this.class11_0);
			}
			this.class11_0 = new Class11(this.GClass23_0);
		}

		// Token: 0x060006CD RID: 1741 RVA: 0x000067AA File Offset: 0x000049AA
		private bool method_2(char char_0)
		{
			return char_0 == ' ' || char_0 == '\t' || char_0 == '\n';
		}

		// Token: 0x060006CE RID: 1742 RVA: 0x000067BD File Offset: 0x000049BD
		private bool method_3(char char_0)
		{
			return char_0 == '\n' || char_0 == '\a';
		}

		// Token: 0x060006CF RID: 1743 RVA: 0x000067CA File Offset: 0x000049CA
		private bool method_4(char char_0)
		{
			return char_0 == '\t';
		}

		// Token: 0x0400027B RID: 635
		private GClass23 gclass23_0;

		// Token: 0x0400027C RID: 636
		private string string_0;

		// Token: 0x0400027D RID: 637
		private List<Class11> list_0;

		// Token: 0x0400027E RID: 638
		private Class11 class11_0;
	}
}
