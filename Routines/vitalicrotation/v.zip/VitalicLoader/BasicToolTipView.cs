﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000028 RID: 40
	public partial class BasicToolTipView : GForm0, GInterface1, GInterface3
	{
		// Token: 0x0600015B RID: 347 RVA: 0x0000ADB8 File Offset: 0x00008FB8
		public BasicToolTipView()
		{
			this.int_11 = 200;
			this.timer_0 = new System.Windows.Forms.Timer();
			this.timer_0.Interval = 13;
			this.timer_0.Tick += this.timer_0_Tick;
			this.genum1_0 = BasicToolTipView.GEnum1.const_1;
			this.int_10 = 120;
			this.drawMode_0 = DrawMode.Normal;
			this.color_0 = Color.White;
			this.color_1 = Color.White;
			this.InitializeComponent();
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint, true);
			GEnum29 genum29_ = (base.GEnum29_0 == GEnum29.const_1) ? GEnum29.const_2 : GEnum29.const_1;
			this.BackColor = GClass39.GClass46.smethod_0(genum29_);
			this.ForeColor = GClass39.GClass40.GClass43.smethod_0(base.GEnum29_0);
			this.color_5 = GClass39.GClass40.GClass43.smethod_0(base.GEnum29_0);
			this.Font = GClass67.smethod_2(12f);
			BasicToolTipView.ShowWindow(base.Handle, 4);
			base.Hide();
		}

		// Token: 0x14000008 RID: 8
		// (add) Token: 0x0600015C RID: 348 RVA: 0x0000AEA4 File Offset: 0x000090A4
		// (remove) Token: 0x0600015D RID: 349 RVA: 0x0000AEDC File Offset: 0x000090DC
		public event GDelegate2 Event_0
		{
			add
			{
				GDelegate2 gdelegate = this.gdelegate2_0;
				GDelegate2 gdelegate2;
				do
				{
					gdelegate2 = gdelegate;
					GDelegate2 value2 = (GDelegate2)Delegate.Combine(gdelegate2, value);
					gdelegate = Interlocked.CompareExchange<GDelegate2>(ref this.gdelegate2_0, value2, gdelegate2);
				}
				while (gdelegate != gdelegate2);
			}
			remove
			{
				GDelegate2 gdelegate = this.gdelegate2_0;
				GDelegate2 gdelegate2;
				do
				{
					gdelegate2 = gdelegate;
					GDelegate2 value2 = (GDelegate2)Delegate.Remove(gdelegate2, value);
					gdelegate = Interlocked.CompareExchange<GDelegate2>(ref this.gdelegate2_0, value2, gdelegate2);
				}
				while (gdelegate != gdelegate2);
			}
		}

		// Token: 0x14000009 RID: 9
		// (add) Token: 0x0600015E RID: 350 RVA: 0x0000AF14 File Offset: 0x00009114
		// (remove) Token: 0x0600015F RID: 351 RVA: 0x0000AF4C File Offset: 0x0000914C
		public event GDelegate3 Event_1
		{
			add
			{
				GDelegate3 gdelegate = this.gdelegate3_0;
				GDelegate3 gdelegate2;
				do
				{
					gdelegate2 = gdelegate;
					GDelegate3 value2 = (GDelegate3)Delegate.Combine(gdelegate2, value);
					gdelegate = Interlocked.CompareExchange<GDelegate3>(ref this.gdelegate3_0, value2, gdelegate2);
				}
				while (gdelegate != gdelegate2);
			}
			remove
			{
				GDelegate3 gdelegate = this.gdelegate3_0;
				GDelegate3 gdelegate2;
				do
				{
					gdelegate2 = gdelegate;
					GDelegate3 value2 = (GDelegate3)Delegate.Remove(gdelegate2, value);
					gdelegate = Interlocked.CompareExchange<GDelegate3>(ref this.gdelegate3_0, value2, gdelegate2);
				}
				while (gdelegate != gdelegate2);
			}
		}

		// Token: 0x06000160 RID: 352
		[DllImport("user32.dll")]
		private static extern bool SetWindowPos(int int_12, int int_13, int int_14, int int_15, int int_16, int int_17, uint uint_1);

		// Token: 0x06000161 RID: 353
		[DllImport("user32.dll")]
		private static extern bool ShowWindow(IntPtr intptr_0, int int_12);

		// Token: 0x06000162 RID: 354 RVA: 0x00002B60 File Offset: 0x00000D60
		public void imethod_2(string string_0)
		{
			this.object_0 = string_0;
			this.method_17(true, string_0, this.color_4);
		}

		// Token: 0x06000163 RID: 355 RVA: 0x00002B77 File Offset: 0x00000D77
		public void imethod_3(object object_1)
		{
			this.object_0 = object_1;
			this.method_17(false, object_1.ToString(), this.ForeColor);
		}

		// Token: 0x06000164 RID: 356 RVA: 0x00002B93 File Offset: 0x00000D93
		public void imethod_4(Exception exception_0)
		{
			this.object_0 = exception_0;
			this.method_17(true, exception_0.Message, this.color_3);
		}

		// Token: 0x06000165 RID: 357 RVA: 0x0000AF84 File Offset: 0x00009184
		public void imethod_0(Point point_0, Size size_0)
		{
			BasicToolTipView.ShowWindow(base.Handle, 4);
			BasicToolTipView.SetWindowPos(base.Handle.ToInt32(), -1, base.Left, base.Top, base.Width, base.Height, 16U);
			if (this.GEnum1_0 != BasicToolTipView.GEnum1.const_0)
			{
				this.int_7 = this.int_11 / 13;
				if (this.int_7 <= 0)
				{
					return;
				}
				if (this.GEnum1_0 == BasicToolTipView.GEnum1.const_1 || this.GEnum1_0 == BasicToolTipView.GEnum1.const_3)
				{
					base.Opacity = 0.0;
					this.double_0 = 1.0 / (double)this.int_7;
				}
				if (this.GEnum1_0 == BasicToolTipView.GEnum1.const_2 || this.GEnum1_0 == BasicToolTipView.GEnum1.const_3)
				{
					this.int_8 = (base.Top + base.Height) / this.int_7;
					this.int_9 = (base.Top + base.Height) % this.int_7;
					base.Location = new Point(base.Left, -base.Height);
				}
				this.timer_0.Start();
			}
		}

		// Token: 0x06000166 RID: 358 RVA: 0x00002BAF File Offset: 0x00000DAF
		public void imethod_1()
		{
			if (this.int_7 > 0)
			{
				this.timer_0.Stop();
			}
			base.Hide();
		}

		// Token: 0x06000167 RID: 359 RVA: 0x00002BCB File Offset: 0x00000DCB
		public BasicToolTipView method_16(BasicToolTipView.GEnum1 genum1_1, int int_12)
		{
			this.Int32_2 = int_12;
			this.GEnum1_0 = genum1_1;
			return this;
		}

		// Token: 0x06000168 RID: 360 RVA: 0x0000B094 File Offset: 0x00009294
		private void timer_0_Tick(object sender, EventArgs e)
		{
			int num = base.Top;
			if (this.int_9 > 0)
			{
				num += this.int_9;
				this.int_9 = 0;
			}
			num += this.int_8;
			base.Location += new Size(0, num - base.Top);
			base.Opacity += this.double_0;
			this.int_7--;
			if (this.int_7 == 0)
			{
				this.timer_0.Stop();
			}
		}

		// Token: 0x06000169 RID: 361 RVA: 0x0000B120 File Offset: 0x00009320
		private void method_17(bool bool_3, string string_0, Color color_6)
		{
			this.Text = string_0;
			this.color_2 = color_6;
			Size sz;
			if (this.drawMode_0 == DrawMode.OwnerDrawVariable && this.gdelegate3_0 != null)
			{
				GEventArgs1 geventArgs = new GEventArgs1(this.Font, this.object_0, base.Height, base.Width);
				this.gdelegate3_0(this, geventArgs);
				sz = new Size(geventArgs.Int32_1, geventArgs.Int32_0) - base.Size;
			}
			else if (bool_3)
			{
				Size size = TextRenderer.MeasureText(string_0, this.Font);
				sz = new Size(this.bitmap_0.Width + size.Width + 12, 16 + Math.Max(size.Height, this.bitmap_0.Height)) - base.Size;
			}
			else
			{
				sz = TextRenderer.MeasureText(string_0, this.Font, new Size(this.int_10, 0), TextFormatFlags.WordBreak) + new Size(8, 8) - base.Size;
			}
			if (sz.Width != 0 || sz.Height != 0)
			{
				base.Size += sz;
				base.Location = new Point(base.Left - sz.Width / 2, base.Top - sz.Height + 20);
			}
			this.panel.Invalidate();
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x0600016A RID: 362 RVA: 0x00002BDC File Offset: 0x00000DDC
		// (set) Token: 0x0600016B RID: 363 RVA: 0x00002BE4 File Offset: 0x00000DE4
		public DrawMode DrawMode_0
		{
			get
			{
				return this.drawMode_0;
			}
			set
			{
				this.drawMode_0 = value;
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x0600016C RID: 364 RVA: 0x00002BED File Offset: 0x00000DED
		// (set) Token: 0x0600016D RID: 365 RVA: 0x00002BF5 File Offset: 0x00000DF5
		public Color Color_0
		{
			get
			{
				return this.color_0;
			}
			set
			{
				this.color_0 = value;
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x0600016E RID: 366 RVA: 0x00002BFE File Offset: 0x00000DFE
		// (set) Token: 0x0600016F RID: 367 RVA: 0x00002C06 File Offset: 0x00000E06
		public Color Color_1
		{
			get
			{
				return this.color_1;
			}
			set
			{
				this.color_1 = value;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000170 RID: 368 RVA: 0x00002C0F File Offset: 0x00000E0F
		// (set) Token: 0x06000171 RID: 369 RVA: 0x00002C17 File Offset: 0x00000E17
		public int Int32_2
		{
			get
			{
				return this.int_11;
			}
			set
			{
				this.int_11 = value;
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000172 RID: 370 RVA: 0x00002C20 File Offset: 0x00000E20
		// (set) Token: 0x06000173 RID: 371 RVA: 0x00002C28 File Offset: 0x00000E28
		public BasicToolTipView.GEnum1 GEnum1_0
		{
			get
			{
				return this.genum1_0;
			}
			set
			{
				this.genum1_0 = value;
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000174 RID: 372 RVA: 0x00002C31 File Offset: 0x00000E31
		// (set) Token: 0x06000175 RID: 373 RVA: 0x00002C39 File Offset: 0x00000E39
		public int Int32_3
		{
			get
			{
				return this.int_10;
			}
			set
			{
				this.int_10 = value;
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000176 RID: 374 RVA: 0x00002C42 File Offset: 0x00000E42
		// (set) Token: 0x06000177 RID: 375 RVA: 0x00002C4A File Offset: 0x00000E4A
		public Color Color_2
		{
			get
			{
				return this.color_4;
			}
			set
			{
				this.color_4 = value;
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x06000178 RID: 376 RVA: 0x00002C53 File Offset: 0x00000E53
		// (set) Token: 0x06000179 RID: 377 RVA: 0x00002C5B File Offset: 0x00000E5B
		public Color Color_3
		{
			get
			{
				return this.color_3;
			}
			set
			{
				this.color_3 = value;
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x0600017A RID: 378 RVA: 0x00002C64 File Offset: 0x00000E64
		// (set) Token: 0x0600017B RID: 379 RVA: 0x00002C6C File Offset: 0x00000E6C
		[Description("This image will be shown on asynchronous requests.")]
		public Bitmap Bitmap_0
		{
			get
			{
				return this.bitmap_1;
			}
			set
			{
				this.bitmap_1 = value;
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x0600017C RID: 380 RVA: 0x00002C75 File Offset: 0x00000E75
		// (set) Token: 0x0600017D RID: 381 RVA: 0x00002C7D File Offset: 0x00000E7D
		[Description("This image will be shown on errors during the execution.")]
		public Bitmap Bitmap_1
		{
			get
			{
				return this.bitmap_0;
			}
			set
			{
				this.bitmap_0 = value;
			}
		}

		// Token: 0x0600017E RID: 382 RVA: 0x0000B27C File Offset: 0x0000947C
		private void panel_Paint(object sender, PaintEventArgs e)
		{
			string text = string.Format(NumberFormatInfo.InvariantInfo, "font: {0}pt {1}", new object[]
			{
				9f,
				this.Font.FontFamily.Name
			});
			this.gclass28_0 = new GClass28(string.Concat(new string[]
			{
				"<style>p { margin-bottom:2px; }</style><table width=175 class=htmltooltipbackground cellspacing=5 cellpadding=0 style=\"",
				text,
				"\"><tr><td style=border:0px>",
				this.Text,
				"</td></tr></table>"
			}));
			this.gclass28_0.method_31(new Rectangle(0, 0, 10, 10));
			this.gclass28_0.Boolean_3 = true;
			this.gclass28_0.vmethod_0(e.Graphics);
			base.Size = Size.Round(this.gclass28_0.SizeF_1);
			if (this.gclass28_0 != null)
			{
				e.Graphics.Clear(Color.White);
				this.gclass28_0.method_24(e.Graphics);
			}
		}

		// Token: 0x04000081 RID: 129
		private const int int_4 = 4;

		// Token: 0x04000082 RID: 130
		private const int int_5 = -1;

		// Token: 0x04000083 RID: 131
		private const uint uint_0 = 16U;

		// Token: 0x04000084 RID: 132
		private const int int_6 = 13;

		// Token: 0x04000085 RID: 133
		private int int_7;

		// Token: 0x04000086 RID: 134
		private double double_0;

		// Token: 0x04000087 RID: 135
		private int int_8;

		// Token: 0x04000088 RID: 136
		private int int_9;

		// Token: 0x04000089 RID: 137
		private int int_10;

		// Token: 0x0400008A RID: 138
		private Color color_0;

		// Token: 0x0400008B RID: 139
		private Color color_1;

		// Token: 0x0400008C RID: 140
		private Color color_2;

		// Token: 0x0400008D RID: 141
		private Color color_3;

		// Token: 0x0400008E RID: 142
		private Color color_4;

		// Token: 0x0400008F RID: 143
		private Bitmap bitmap_0;

		// Token: 0x04000090 RID: 144
		private Bitmap bitmap_1;

		// Token: 0x04000091 RID: 145
		private BasicToolTipView.GEnum1 genum1_0;

		// Token: 0x04000092 RID: 146
		private System.Windows.Forms.Timer timer_0;

		// Token: 0x04000093 RID: 147
		private int int_11;

		// Token: 0x04000094 RID: 148
		private DrawMode drawMode_0;

		// Token: 0x04000095 RID: 149
		private object object_0;

		// Token: 0x04000096 RID: 150
		private Color color_5;

		// Token: 0x04000097 RID: 151
		private GDelegate2 gdelegate2_0;

		// Token: 0x04000098 RID: 152
		private GDelegate3 gdelegate3_0;

		// Token: 0x04000099 RID: 153
		private GClass28 gclass28_0;

		// Token: 0x02000029 RID: 41
		public enum GEnum1
		{
			// Token: 0x0400009D RID: 157
			const_0,
			// Token: 0x0400009E RID: 158
			const_1,
			// Token: 0x0400009F RID: 159
			const_2,
			// Token: 0x040000A0 RID: 160
			const_3
		}
	}
}
