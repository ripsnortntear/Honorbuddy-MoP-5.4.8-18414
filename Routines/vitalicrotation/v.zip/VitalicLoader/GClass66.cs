﻿using System;
using System.Drawing;

namespace ns0
{
	// Token: 0x0200008F RID: 143
	public sealed class GClass66
	{
		// Token: 0x17000236 RID: 566
		// (get) Token: 0x0600080F RID: 2063 RVA: 0x0000730E File Offset: 0x0000550E
		public static Color Color_0
		{
			get
			{
				return Color.FromArgb(0, 0, 0);
			}
		}

		// Token: 0x17000237 RID: 567
		// (get) Token: 0x06000810 RID: 2064 RVA: 0x00007318 File Offset: 0x00005518
		public static Color Color_1
		{
			get
			{
				return Color.FromArgb(255, 255, 255);
			}
		}

		// Token: 0x17000238 RID: 568
		// (get) Token: 0x06000811 RID: 2065 RVA: 0x0000732E File Offset: 0x0000552E
		public static Color Color_2
		{
			get
			{
				return Color.FromArgb(85, 85, 85);
			}
		}

		// Token: 0x17000239 RID: 569
		// (get) Token: 0x06000812 RID: 2066 RVA: 0x0000733B File Offset: 0x0000553B
		public static Color Color_3
		{
			get
			{
				return Color.FromArgb(0, 174, 219);
			}
		}

		// Token: 0x1700023A RID: 570
		// (get) Token: 0x06000813 RID: 2067 RVA: 0x0000734D File Offset: 0x0000554D
		public static Color Color_4
		{
			get
			{
				return Color.FromArgb(0, 177, 89);
			}
		}

		// Token: 0x1700023B RID: 571
		// (get) Token: 0x06000814 RID: 2068 RVA: 0x0000735C File Offset: 0x0000555C
		public static Color Color_5
		{
			get
			{
				return Color.FromArgb(142, 188, 0);
			}
		}

		// Token: 0x1700023C RID: 572
		// (get) Token: 0x06000815 RID: 2069 RVA: 0x0000736E File Offset: 0x0000556E
		public static Color Color_6
		{
			get
			{
				return Color.FromArgb(0, 170, 173);
			}
		}

		// Token: 0x1700023D RID: 573
		// (get) Token: 0x06000816 RID: 2070 RVA: 0x00007380 File Offset: 0x00005580
		public static Color Color_7
		{
			get
			{
				return Color.FromArgb(243, 119, 53);
			}
		}

		// Token: 0x1700023E RID: 574
		// (get) Token: 0x06000817 RID: 2071 RVA: 0x00007390 File Offset: 0x00005590
		public static Color Color_8
		{
			get
			{
				return Color.FromArgb(165, 81, 0);
			}
		}

		// Token: 0x1700023F RID: 575
		// (get) Token: 0x06000818 RID: 2072 RVA: 0x0000739F File Offset: 0x0000559F
		public static Color Color_9
		{
			get
			{
				return Color.FromArgb(231, 113, 189);
			}
		}

		// Token: 0x17000240 RID: 576
		// (get) Token: 0x06000819 RID: 2073 RVA: 0x000073B2 File Offset: 0x000055B2
		public static Color Color_10
		{
			get
			{
				return Color.FromArgb(255, 0, 148);
			}
		}

		// Token: 0x17000241 RID: 577
		// (get) Token: 0x0600081A RID: 2074 RVA: 0x000073C4 File Offset: 0x000055C4
		public static Color Color_11
		{
			get
			{
				return Color.FromArgb(124, 65, 153);
			}
		}

		// Token: 0x17000242 RID: 578
		// (get) Token: 0x0600081B RID: 2075 RVA: 0x000073D4 File Offset: 0x000055D4
		public static Color Color_12
		{
			get
			{
				return Color.FromArgb(209, 17, 65);
			}
		}

		// Token: 0x17000243 RID: 579
		// (get) Token: 0x0600081C RID: 2076 RVA: 0x000073E4 File Offset: 0x000055E4
		public static Color Color_13
		{
			get
			{
				return Color.FromArgb(255, 196, 37);
			}
		}
	}
}
