﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Reflection;

namespace ns0
{
	// Token: 0x02000060 RID: 96
	[CLSCompliant(false)]
	public static class GClass34
	{
		// Token: 0x06000727 RID: 1831 RVA: 0x0001ABA8 File Offset: 0x00018DA8
		public static float smethod_0(string string_0, float float_0)
		{
			if (string.IsNullOrEmpty(string_0))
			{
				return 0f;
			}
			string s = string_0;
			bool flag = string_0.EndsWith("%");
			float num = 0f;
			if (flag)
			{
				s = string_0.Substring(0, string_0.Length - 1);
			}
			if (!float.TryParse(s, NumberStyles.Number, NumberFormatInfo.InvariantInfo, out num))
			{
				return 0f;
			}
			if (flag)
			{
				num = num / 100f * float_0;
			}
			return num;
		}

		// Token: 0x06000728 RID: 1832 RVA: 0x000069F5 File Offset: 0x00004BF5
		public static float smethod_1(string string_0, float float_0, GClass23 gclass23_0)
		{
			return GClass34.smethod_2(string_0, float_0, gclass23_0, gclass23_0.method_7(), false);
		}

		// Token: 0x06000729 RID: 1833 RVA: 0x0001AC10 File Offset: 0x00018E10
		public static float smethod_2(string string_0, float float_0, GClass23 gclass23_0, float float_1, bool bool_0)
		{
			if (string.IsNullOrEmpty(string_0) || string_0 == "0")
			{
				return 0f;
			}
			if (string_0.EndsWith("%"))
			{
				return GClass34.smethod_0(string_0, float_0);
			}
			if (string_0.Length < 3)
			{
				return 0f;
			}
			string text = string_0.Substring(string_0.Length - 2, 2);
			string string_ = string_0.Substring(0, string_0.Length - 2);
			string key;
			float num2;
			switch (key = text)
			{
			case "em":
				num2 = float_1;
				goto IL_151;
			case "px":
				num2 = 1f;
				goto IL_151;
			case "mm":
				num2 = 3f;
				goto IL_151;
			case "cm":
				num2 = 37f;
				goto IL_151;
			case "in":
				num2 = 96f;
				goto IL_151;
			case "pt":
				num2 = 1.33333337f;
				if (bool_0)
				{
					return GClass34.smethod_0(string_, float_0);
				}
				goto IL_151;
			case "pc":
				num2 = 16f;
				goto IL_151;
			}
			num2 = 0f;
			IL_151:
			return num2 * GClass34.smethod_0(string_, float_0);
		}

		// Token: 0x0600072A RID: 1834 RVA: 0x0001AD80 File Offset: 0x00018F80
		public static Color smethod_3(string string_0)
		{
			Color empty = Color.Empty;
			if (string.IsNullOrEmpty(string_0))
			{
				return empty;
			}
			string_0 = string_0.ToLower().Trim();
			int red;
			int green;
			int blue;
			if (string_0.StartsWith("#"))
			{
				string text = string_0.Substring(1);
				if (text.Length == 6)
				{
					red = int.Parse(text.Substring(0, 2), NumberStyles.HexNumber);
					green = int.Parse(text.Substring(2, 2), NumberStyles.HexNumber);
					blue = int.Parse(text.Substring(4, 2), NumberStyles.HexNumber);
				}
				else
				{
					if (text.Length != 3)
					{
						return empty;
					}
					red = int.Parse(new string(text.Substring(0, 1)[0], 2), NumberStyles.HexNumber);
					green = int.Parse(new string(text.Substring(1, 1)[0], 2), NumberStyles.HexNumber);
					blue = int.Parse(new string(text.Substring(2, 1)[0], 2), NumberStyles.HexNumber);
				}
			}
			else if (string_0.StartsWith("rgb(") && string_0.EndsWith(")"))
			{
				string text2 = string_0.Substring(4, string_0.Length - 5);
				string[] array = text2.Split(new char[]
				{
					','
				});
				if (array.Length != 3)
				{
					return empty;
				}
				red = Convert.ToInt32(GClass34.smethod_0(array[0].Trim(), 255f));
				green = Convert.ToInt32(GClass34.smethod_0(array[1].Trim(), 255f));
				blue = Convert.ToInt32(GClass34.smethod_0(array[2].Trim(), 255f));
			}
			else
			{
				string text3 = string.Empty;
				string key;
				switch (key = string_0)
				{
				case "maroon":
					text3 = "#800000";
					break;
				case "red":
					text3 = "#ff0000";
					break;
				case "orange":
					text3 = "#ffA500";
					break;
				case "olive":
					text3 = "#808000";
					break;
				case "purple":
					text3 = "#800080";
					break;
				case "fuchsia":
					text3 = "#ff00ff";
					break;
				case "white":
					text3 = "#ffffff";
					break;
				case "lime":
					text3 = "#00ff00";
					break;
				case "green":
					text3 = "#008000";
					break;
				case "navy":
					text3 = "#000080";
					break;
				case "blue":
					text3 = "#0000ff";
					break;
				case "aqua":
					text3 = "#00ffff";
					break;
				case "teal":
					text3 = "#008080";
					break;
				case "black":
					text3 = "#000000";
					break;
				case "silver":
					text3 = "#c0c0c0";
					break;
				case "gray":
					text3 = "#808080";
					break;
				case "yellow":
					text3 = "#FFFF00";
					break;
				}
				if (string.IsNullOrEmpty(text3))
				{
					return empty;
				}
				Color color = GClass34.smethod_3(text3);
				red = (int)color.R;
				green = (int)color.G;
				blue = (int)color.B;
			}
			return Color.FromArgb(red, green, blue);
		}

		// Token: 0x0600072B RID: 1835 RVA: 0x0001B16C File Offset: 0x0001936C
		public static float smethod_4(string string_0, GClass23 gclass23_0)
		{
			if (string.IsNullOrEmpty(string_0))
			{
				return GClass34.smethod_4("medium", gclass23_0);
			}
			if (string_0 != null)
			{
				if (string_0 == "thin")
				{
					return 1f;
				}
				if (string_0 == "medium")
				{
					return 2f;
				}
				if (string_0 == "thick")
				{
					return 4f;
				}
			}
			return Math.Abs(GClass34.smethod_1(string_0, 1f, gclass23_0));
		}

		// Token: 0x0600072C RID: 1836 RVA: 0x00006A06 File Offset: 0x00004C06
		public static string[] smethod_5(string string_0)
		{
			return GClass34.smethod_6(string_0, ' ');
		}

		// Token: 0x0600072D RID: 1837 RVA: 0x0001B1DC File Offset: 0x000193DC
		public static string[] smethod_6(string string_0, char char_0)
		{
			if (string.IsNullOrEmpty(string_0))
			{
				return new string[0];
			}
			string[] array = string_0.Split(new char[]
			{
				char_0
			});
			List<string> list = new List<string>();
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].Trim();
				if (!string.IsNullOrEmpty(text))
				{
					list.Add(text);
				}
			}
			return list.ToArray();
		}

		// Token: 0x0600072E RID: 1838 RVA: 0x0001B244 File Offset: 0x00019444
		private static Type smethod_7(string string_0, ref string string_1)
		{
			int num = string_0.LastIndexOf('.');
			if (num < 0)
			{
				return null;
			}
			string name = string_0.Substring(0, num);
			string_1 = string_0.Substring(num + 1);
			string_1 = string_1.Replace("(", string.Empty).Replace(")", string.Empty);
			foreach (Assembly assembly in GClass36.List_0)
			{
				Type type = assembly.GetType(name, false, true);
				if (type != null)
				{
					return type;
				}
			}
			return null;
		}

		// Token: 0x0600072F RID: 1839 RVA: 0x0001B2F0 File Offset: 0x000194F0
		private static object smethod_8(string string_0)
		{
			if (string_0.StartsWith("method:", StringComparison.CurrentCultureIgnoreCase))
			{
				string empty = string.Empty;
				Type type = GClass34.smethod_7(string_0.Substring(7), ref empty);
				if (type == null)
				{
					return null;
				}
				MethodInfo method = type.GetMethod(empty);
				if (method.IsStatic && method.GetParameters().Length <= 0)
				{
					return method;
				}
				return null;
			}
			else if (string_0.StartsWith("property:", StringComparison.CurrentCultureIgnoreCase))
			{
				string empty2 = string.Empty;
				Type type2 = GClass34.smethod_7(string_0.Substring(9), ref empty2);
				if (type2 == null)
				{
					return null;
				}
				return type2.GetProperty(empty2);
			}
			else
			{
				if (Uri.IsWellFormedUriString(string_0, UriKind.RelativeOrAbsolute))
				{
					return new Uri(string_0);
				}
				return new FileInfo(string_0);
			}
		}

		// Token: 0x06000730 RID: 1840 RVA: 0x0001B394 File Offset: 0x00019594
		public static Image smethod_9(string string_0)
		{
			object obj = GClass34.smethod_8(string_0);
			FileInfo fileInfo = obj as FileInfo;
			PropertyInfo propertyInfo = obj as PropertyInfo;
			MethodInfo methodInfo = obj as MethodInfo;
			Image result;
			try
			{
				if (fileInfo != null)
				{
					if (!fileInfo.Exists)
					{
						result = null;
					}
					else
					{
						result = Image.FromFile(fileInfo.FullName);
					}
				}
				else if (propertyInfo != null)
				{
					if (!propertyInfo.PropertyType.IsSubclassOf(typeof(Image)) && !propertyInfo.PropertyType.Equals(typeof(Image)))
					{
						result = null;
					}
					else
					{
						result = (propertyInfo.GetValue(null, null) as Image);
					}
				}
				else if (methodInfo != null)
				{
					if (!methodInfo.ReturnType.IsSubclassOf(typeof(Image)))
					{
						result = null;
					}
					else
					{
						result = (methodInfo.Invoke(null, null) as Image);
					}
				}
				else
				{
					result = null;
				}
			}
			catch
			{
				result = new Bitmap(50, 50);
			}
			return result;
		}

		// Token: 0x06000731 RID: 1841 RVA: 0x0001B480 File Offset: 0x00019680
		public static string smethod_10(string string_0)
		{
			object obj = GClass34.smethod_8(string_0);
			FileInfo fileInfo = obj as FileInfo;
			PropertyInfo propertyInfo = obj as PropertyInfo;
			MethodInfo methodInfo = obj as MethodInfo;
			string result;
			try
			{
				if (fileInfo != null)
				{
					if (!fileInfo.Exists)
					{
						result = null;
					}
					else
					{
						StreamReader streamReader = new StreamReader(fileInfo.FullName);
						string text = streamReader.ReadToEnd();
						streamReader.Dispose();
						result = text;
					}
				}
				else if (propertyInfo != null)
				{
					if (!propertyInfo.PropertyType.Equals(typeof(string)))
					{
						result = null;
					}
					else
					{
						result = (propertyInfo.GetValue(null, null) as string);
					}
				}
				else if (methodInfo != null)
				{
					if (!methodInfo.ReturnType.Equals(typeof(string)))
					{
						result = null;
					}
					else
					{
						result = (methodInfo.Invoke(null, null) as string);
					}
				}
				else
				{
					result = string.Empty;
				}
			}
			catch
			{
				result = string.Empty;
			}
			return result;
		}

		// Token: 0x06000732 RID: 1842 RVA: 0x0001B564 File Offset: 0x00019764
		public static void smethod_11(string string_0)
		{
			object obj = GClass34.smethod_8(string_0);
			FileInfo fileInfo = obj as FileInfo;
			MethodInfo methodInfo = obj as MethodInfo;
			Uri uri = obj as Uri;
			try
			{
				if (fileInfo == null && !(uri != null))
				{
					if (methodInfo != null)
					{
						methodInfo.Invoke(null, null);
					}
				}
				else
				{
					Process.Start(new ProcessStartInfo(string_0)
					{
						UseShellExecute = true
					});
				}
			}
			catch
			{
				throw;
			}
		}
	}
}
