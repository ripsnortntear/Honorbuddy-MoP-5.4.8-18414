﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Security;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000043 RID: 67
	[ToolboxItem(false)]
	[Designer("MetroFramework.Design.Controls.MetroTabPageDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	public class GClass21 : TabPage, GInterface2
	{
		// Token: 0x0600041D RID: 1053 RVA: 0x000114FC File Offset: 0x0000F6FC
		public GClass21()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.Controls.Add(this.gcontrol1_0);
			base.Controls.Add(this.gcontrol1_1);
			this.gcontrol1_0.Boolean_0 = true;
			this.gcontrol1_1.Boolean_0 = true;
			this.gcontrol1_0.Event_0 += this.method_1;
			this.gcontrol1_1.Event_0 += this.method_0;
		}

		// Token: 0x1400002E RID: 46
		// (add) Token: 0x0600041E RID: 1054 RVA: 0x0001159C File Offset: 0x0000F79C
		// (remove) Token: 0x0600041F RID: 1055 RVA: 0x000115D4 File Offset: 0x0000F7D4
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000420 RID: 1056 RVA: 0x000049A8 File Offset: 0x00002BA8
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x1400002F RID: 47
		// (add) Token: 0x06000421 RID: 1057 RVA: 0x0001160C File Offset: 0x0000F80C
		// (remove) Token: 0x06000422 RID: 1058 RVA: 0x00011644 File Offset: 0x0000F844
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000423 RID: 1059 RVA: 0x000049C8 File Offset: 0x00002BC8
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000030 RID: 48
		// (add) Token: 0x06000424 RID: 1060 RVA: 0x0001167C File Offset: 0x0000F87C
		// (remove) Token: 0x06000425 RID: 1061 RVA: 0x000116B4 File Offset: 0x0000F8B4
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000426 RID: 1062 RVA: 0x000049E8 File Offset: 0x00002BE8
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x170000F5 RID: 245
		// (get) Token: 0x06000427 RID: 1063 RVA: 0x000116EC File Offset: 0x0000F8EC
		// (set) Token: 0x06000428 RID: 1064 RVA: 0x00004A08 File Offset: 0x00002C08
		[DefaultValue(GEnum10.const_0)]
		[Category("Metro Appearance")]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x170000F6 RID: 246
		// (get) Token: 0x06000429 RID: 1065 RVA: 0x00011744 File Offset: 0x0000F944
		// (set) Token: 0x0600042A RID: 1066 RVA: 0x00004A11 File Offset: 0x00002C11
		[DefaultValue(GEnum29.const_0)]
		[Category("Metro Appearance")]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x170000F7 RID: 247
		// (get) Token: 0x0600042B RID: 1067 RVA: 0x00004A1A File Offset: 0x00002C1A
		// (set) Token: 0x0600042C RID: 1068 RVA: 0x00004A22 File Offset: 0x00002C22
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x170000F8 RID: 248
		// (get) Token: 0x0600042D RID: 1069 RVA: 0x00004A2B File Offset: 0x00002C2B
		// (set) Token: 0x0600042E RID: 1070 RVA: 0x00004A33 File Offset: 0x00002C33
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x170000F9 RID: 249
		// (get) Token: 0x0600042F RID: 1071 RVA: 0x00004A3C File Offset: 0x00002C3C
		// (set) Token: 0x06000430 RID: 1072 RVA: 0x00004A44 File Offset: 0x00002C44
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x170000FA RID: 250
		// (get) Token: 0x06000431 RID: 1073 RVA: 0x00004A4D File Offset: 0x00002C4D
		// (set) Token: 0x06000432 RID: 1074 RVA: 0x00004A55 File Offset: 0x00002C55
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x170000FB RID: 251
		// (get) Token: 0x06000433 RID: 1075 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x06000434 RID: 1076 RVA: 0x00002923 File Offset: 0x00000B23
		[DefaultValue(false)]
		[Browsable(false)]
		[Category("Metro Behaviour")]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x170000FC RID: 252
		// (get) Token: 0x06000435 RID: 1077 RVA: 0x00004A5E File Offset: 0x00002C5E
		// (set) Token: 0x06000436 RID: 1078 RVA: 0x00004A66 File Offset: 0x00002C66
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x170000FD RID: 253
		// (get) Token: 0x06000437 RID: 1079 RVA: 0x00004A6F File Offset: 0x00002C6F
		// (set) Token: 0x06000438 RID: 1080 RVA: 0x00004A7C File Offset: 0x00002C7C
		[Category("Metro Appearance")]
		public int Int32_0
		{
			get
			{
				return this.gcontrol1_1.Int32_1;
			}
			set
			{
				this.gcontrol1_1.Int32_1 = value;
			}
		}

		// Token: 0x170000FE RID: 254
		// (get) Token: 0x06000439 RID: 1081 RVA: 0x00004A8A File Offset: 0x00002C8A
		// (set) Token: 0x0600043A RID: 1082 RVA: 0x00004A97 File Offset: 0x00002C97
		[Category("Metro Appearance")]
		public bool Boolean_1
		{
			get
			{
				return this.gcontrol1_1.Boolean_0;
			}
			set
			{
				this.gcontrol1_1.Boolean_0 = value;
			}
		}

		// Token: 0x170000FF RID: 255
		// (get) Token: 0x0600043B RID: 1083 RVA: 0x00004AA5 File Offset: 0x00002CA5
		// (set) Token: 0x0600043C RID: 1084 RVA: 0x00004AB2 File Offset: 0x00002CB2
		[Category("Metro Appearance")]
		public bool Boolean_2
		{
			get
			{
				return this.gcontrol1_1.Boolean_1;
			}
			set
			{
				this.gcontrol1_1.Boolean_1 = value;
			}
		}

		// Token: 0x17000100 RID: 256
		// (get) Token: 0x0600043D RID: 1085 RVA: 0x00004AC0 File Offset: 0x00002CC0
		// (set) Token: 0x0600043E RID: 1086 RVA: 0x00004AC8 File Offset: 0x00002CC8
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_3
		{
			get
			{
				return this.bool_4;
			}
			set
			{
				this.bool_4 = value;
			}
		}

		// Token: 0x17000101 RID: 257
		// (get) Token: 0x0600043F RID: 1087 RVA: 0x00004AD1 File Offset: 0x00002CD1
		// (set) Token: 0x06000440 RID: 1088 RVA: 0x00004ADE File Offset: 0x00002CDE
		[Category("Metro Appearance")]
		public int Int32_1
		{
			get
			{
				return this.gcontrol1_0.Int32_1;
			}
			set
			{
				this.gcontrol1_0.Int32_1 = value;
			}
		}

		// Token: 0x17000102 RID: 258
		// (get) Token: 0x06000441 RID: 1089 RVA: 0x00004AEC File Offset: 0x00002CEC
		// (set) Token: 0x06000442 RID: 1090 RVA: 0x00004AF9 File Offset: 0x00002CF9
		[Category("Metro Appearance")]
		public bool Boolean_4
		{
			get
			{
				return this.gcontrol1_0.Boolean_0;
			}
			set
			{
				this.gcontrol1_0.Boolean_0 = value;
			}
		}

		// Token: 0x17000103 RID: 259
		// (get) Token: 0x06000443 RID: 1091 RVA: 0x00004B07 File Offset: 0x00002D07
		// (set) Token: 0x06000444 RID: 1092 RVA: 0x00004B14 File Offset: 0x00002D14
		[Category("Metro Appearance")]
		public bool Boolean_5
		{
			get
			{
				return this.gcontrol1_0.Boolean_1;
			}
			set
			{
				this.gcontrol1_0.Boolean_1 = value;
			}
		}

		// Token: 0x17000104 RID: 260
		// (get) Token: 0x06000445 RID: 1093 RVA: 0x00003D38 File Offset: 0x00001F38
		// (set) Token: 0x06000446 RID: 1094 RVA: 0x00004B22 File Offset: 0x00002D22
		[Category("Metro Appearance")]
		public bool Boolean_6
		{
			get
			{
				return base.AutoScroll;
			}
			set
			{
				if (value)
				{
					this.bool_3 = true;
					this.bool_4 = true;
				}
				base.AutoScroll = value;
			}
		}

		// Token: 0x06000447 RID: 1095 RVA: 0x00004B3C File Offset: 0x00002D3C
		private void method_0(object sender, ScrollEventArgs e)
		{
			base.AutoScrollPosition = new Point(e.NewValue, this.gcontrol1_0.Int32_6);
			this.method_2();
		}

		// Token: 0x06000448 RID: 1096 RVA: 0x00004B60 File Offset: 0x00002D60
		private void method_1(object sender, ScrollEventArgs e)
		{
			base.AutoScrollPosition = new Point(this.gcontrol1_1.Int32_6, e.NewValue);
			this.method_2();
		}

		// Token: 0x06000449 RID: 1097 RVA: 0x0001179C File Offset: 0x0000F99C
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
				}
				if (color.A == 255 && this.BackgroundImage == null)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600044A RID: 1098 RVA: 0x00011824 File Offset: 0x0000FA24
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600044B RID: 1099 RVA: 0x0001188C File Offset: 0x0000FA8C
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			if (base.DesignMode)
			{
				this.gcontrol1_1.Visible = false;
				this.gcontrol1_0.Visible = false;
				return;
			}
			this.method_2();
			if (this.Boolean_0)
			{
				this.gcontrol1_1.Visible = base.HorizontalScroll.Visible;
			}
			if (base.HorizontalScroll.Visible)
			{
				this.gcontrol1_1.Int32_2 = base.HorizontalScroll.Minimum;
				this.gcontrol1_1.Int32_3 = base.HorizontalScroll.Maximum;
				this.gcontrol1_1.Int32_4 = base.HorizontalScroll.SmallChange;
				this.gcontrol1_1.Int32_5 = base.HorizontalScroll.LargeChange;
			}
			if (this.Boolean_3)
			{
				this.gcontrol1_0.Visible = base.VerticalScroll.Visible;
			}
			if (base.VerticalScroll.Visible)
			{
				this.gcontrol1_0.Int32_2 = base.VerticalScroll.Minimum;
				this.gcontrol1_0.Int32_3 = base.VerticalScroll.Maximum;
				this.gcontrol1_0.Int32_4 = base.VerticalScroll.SmallChange;
				this.gcontrol1_0.Int32_5 = base.VerticalScroll.LargeChange;
			}
			this.vmethod_2(new GEventArgs3(Color.Empty, Color.Empty, paintEventArgs_0.Graphics));
		}

		// Token: 0x0600044C RID: 1100 RVA: 0x00004B84 File Offset: 0x00002D84
		protected override void OnMouseWheel(MouseEventArgs e)
		{
			base.OnMouseWheel(e);
			this.gcontrol1_0.Int32_6 = base.VerticalScroll.Value;
			this.gcontrol1_1.Int32_6 = base.HorizontalScroll.Value;
		}

		// Token: 0x0600044D RID: 1101 RVA: 0x00003DDE File Offset: 0x00001FDE
		[SecuritySafeCritical]
		protected override void WndProc(ref Message m)
		{
			base.WndProc(ref m);
			if (!base.DesignMode)
			{
				Class29.ShowScrollBar(base.Handle, 3, 0);
			}
		}

		// Token: 0x0600044E RID: 1102 RVA: 0x000119E4 File Offset: 0x0000FBE4
		private void method_2()
		{
			if (base.DesignMode)
			{
				return;
			}
			if (!this.Boolean_6)
			{
				this.gcontrol1_0.Visible = false;
				this.gcontrol1_1.Visible = false;
				return;
			}
			this.gcontrol1_0.Location = new Point(base.ClientRectangle.Width - this.gcontrol1_0.Width, base.ClientRectangle.Y);
			this.gcontrol1_0.Height = base.ClientRectangle.Height;
			if (!this.Boolean_3)
			{
				this.gcontrol1_0.Visible = false;
			}
			this.gcontrol1_1.Location = new Point(base.ClientRectangle.X, base.ClientRectangle.Height - this.gcontrol1_1.Height);
			this.gcontrol1_1.Width = base.ClientRectangle.Width;
			if (!this.Boolean_0)
			{
				this.gcontrol1_1.Visible = false;
			}
		}

		// Token: 0x0400018B RID: 395
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x0400018C RID: 396
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x0400018D RID: 397
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x0400018E RID: 398
		private GEnum10 genum10_0;

		// Token: 0x0400018F RID: 399
		private GEnum29 genum29_0;

		// Token: 0x04000190 RID: 400
		private GClass8 gclass8_0;

		// Token: 0x04000191 RID: 401
		private bool bool_0;

		// Token: 0x04000192 RID: 402
		private bool bool_1;

		// Token: 0x04000193 RID: 403
		private bool bool_2;

		// Token: 0x04000194 RID: 404
		private GControl1 gcontrol1_0 = new GControl1(GEnum3.const_1);

		// Token: 0x04000195 RID: 405
		private GControl1 gcontrol1_1 = new GControl1(GEnum3.const_0);

		// Token: 0x04000196 RID: 406
		private bool bool_3;

		// Token: 0x04000197 RID: 407
		private bool bool_4;
	}
}
