﻿using System;

namespace ns0
{
	// Token: 0x02000094 RID: 148
	public enum GEnum12
	{
		// Token: 0x04000455 RID: 1109
		const_0,
		// Token: 0x04000456 RID: 1110
		const_1,
		// Token: 0x04000457 RID: 1111
		const_2
	}
}
