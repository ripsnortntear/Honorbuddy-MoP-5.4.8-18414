﻿using System;
using System.Runtime.CompilerServices;
using System.Threading;

namespace ns0
{
	// Token: 0x0200000E RID: 14
	internal class Class2<T> : Class1
	{
		// Token: 0x0600005F RID: 95 RVA: 0x000088B4 File Offset: 0x00006AB4
		public static Class2<T> smethod_10(Class2<T>.Delegate1 delegate1_2, T gparam_1, int int_0)
		{
			Class2<T> @class = new Class2<T>();
			Class1.smethod_4(@class, int_0, false);
			@class.delegate1_1 = delegate1_2;
			@class.gparam_0 = gparam_1;
			return @class;
		}

		// Token: 0x06000060 RID: 96 RVA: 0x000088E0 File Offset: 0x00006AE0
		public static Class2<T> smethod_11(Class2<T>.Delegate1 delegate1_2, T gparam_1, int int_0)
		{
			Class2<T> @class = new Class2<T>();
			Class1.smethod_4(@class, int_0, true);
			@class.delegate1_1 = delegate1_2;
			@class.gparam_0 = gparam_1;
			return @class;
		}

		// Token: 0x06000061 RID: 97 RVA: 0x0000890C File Offset: 0x00006B0C
		public static Class2<T> smethod_12(Class2<T>.Delegate1 delegate1_2, T gparam_1, int int_0)
		{
			Class2<T> @class = Class2<T>.smethod_10(delegate1_2, gparam_1, int_0);
			@class.method_3();
			return @class;
		}

		// Token: 0x06000062 RID: 98 RVA: 0x0000892C File Offset: 0x00006B2C
		public static Class2<T> smethod_13(Class2<T>.Delegate1 delegate1_2, T gparam_1, int int_0)
		{
			Class2<T> @class = Class2<T>.smethod_11(delegate1_2, gparam_1, int_0);
			@class.method_3();
			return @class;
		}

		// Token: 0x06000063 RID: 99 RVA: 0x000023EE File Offset: 0x000005EE
		protected override void vmethod_1()
		{
			this.synchronizationContext_0.Post(new SendOrPostCallback(this.method_11), null);
		}

		// Token: 0x06000064 RID: 100 RVA: 0x0000894C File Offset: 0x00006B4C
		public void method_10(T gparam_1, int int_0)
		{
			lock (this.object_0)
			{
				base.method_4();
				this.gparam_0 = gparam_1;
				base.Int32_1 = int_0;
				base.method_3();
			}
		}

		// Token: 0x06000065 RID: 101 RVA: 0x0000899C File Offset: 0x00006B9C
		[CompilerGenerated]
		private void method_11(object object_2)
		{
			lock (this.object_0)
			{
				if (this.bool_0)
				{
					return;
				}
			}
			if (this.delegate1_1 != null)
			{
				this.delegate1_1(this.gparam_0);
			}
		}

		// Token: 0x0400002A RID: 42
		private Class2<T>.Delegate1 delegate1_1;

		// Token: 0x0400002B RID: 43
		private T gparam_0;

		// Token: 0x0200000F RID: 15
		// (Invoke) Token: 0x06000067 RID: 103
		public delegate void Delegate1(T data);
	}
}
