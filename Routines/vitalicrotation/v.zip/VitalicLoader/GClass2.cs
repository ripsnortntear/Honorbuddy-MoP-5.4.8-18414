﻿using System;
using System.Globalization;
using System.IO;
using System.Management;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Media;
using Styx;
using Styx.Common;
using Styx.CommonBot;
using Styx.CommonBot.Routines;
using Styx.TreeSharp;

namespace ns0
{
	// Token: 0x02000006 RID: 6
	public class GClass2 : CombatRoutine
	{
		// Token: 0x06000013 RID: 19 RVA: 0x0000215C File Offset: 0x0000035C
		public GClass2()
		{
			this.combatRoutine_0 = new InvalidRoutineWrapper();
			if (!GClass1.smethod_0())
			{
				return;
			}
			if (!GClass1.smethod_1())
			{
				return;
			}
			BotEvents.OnBotStarted += new BotEvents.OnBotStartDelegate(this.method_0);
			this.bool_2 = true;
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002197 File Offset: 0x00000397
		private void method_0(object object_0)
		{
			if (RoutineManager.Current.Name != GClass1.string_5)
			{
				return;
			}
			if (!this.bool_0 && !this.bool_1)
			{
				this.method_1();
			}
		}

		// Token: 0x06000015 RID: 21 RVA: 0x000079E4 File Offset: 0x00005BE4
		private void method_1()
		{
			string text = "0";
			this.bool_1 = true;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select ProcessorId From Win32_processor");
				if (managementObjectSearcher != null)
				{
					ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
					using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectCollection.GetEnumerator())
					{
						if (enumerator.MoveNext())
						{
							ManagementObject managementObject = (ManagementObject)enumerator.Current;
							if (managementObject["ProcessorId"] != null)
							{
								text = managementObject["ProcessorId"].ToString();
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				Logging.Write(Colors.DarkRed, "Error occurred initialising routine: " + ex.Message);
				return;
			}
			if (!string.IsNullOrEmpty(text))
			{
				string address = "http://vitalic.azurewebsites.net/request/" + GClass1.string_1.Trim() + "/" + text;
				byte[] array = null;
				using (WebClient webClient = new WebClient())
				{
					try
					{
						array = webClient.DownloadData(address);
					}
					catch (Exception ex2)
					{
						Logging.Write(Colors.DarkRed, "Error occurred initialising routine: " + ex2.Message);
						return;
					}
				}
				if (array == null)
				{
					return;
				}
				try
				{
					Thread.CurrentThread.CurrentCulture = new CultureInfo("en-US");
					Assembly assembly = Assembly.Load(array);
					foreach (Type type in assembly.GetTypes())
					{
						if (type.IsSubclassOf(typeof(CombatRoutine)) && type.IsClass)
						{
							object obj = Activator.CreateInstance(type);
							this.combatRoutine_0 = (CombatRoutine)obj;
							this.combatRoutine_0.Initialize();
						}
					}
				}
				catch (ThreadAbortException)
				{
					return;
				}
				catch (ReflectionTypeLoadException ex3)
				{
					StringBuilder stringBuilder = new StringBuilder();
					foreach (Exception ex4 in ex3.LoaderExceptions)
					{
						stringBuilder.AppendLine(ex4.Message);
						if (ex4 is FileNotFoundException)
						{
							FileNotFoundException ex5 = ex4 as FileNotFoundException;
							if (!string.IsNullOrEmpty(ex5.FusionLog))
							{
								stringBuilder.AppendLine("Fusion Log:");
								stringBuilder.AppendLine(ex5.FusionLog);
							}
						}
						stringBuilder.AppendLine();
					}
					string text2 = stringBuilder.ToString();
					Logging.Write(text2);
				}
				catch (Exception ex6)
				{
					Logging.Write(Colors.DarkRed, "Error occurred initialising routine");
					Logging.Write(ex6.ToString());
					return;
				}
				BotEvents.OnBotStarted -= new BotEvents.OnBotStartDelegate(this.method_0);
				this.bool_0 = true;
				return;
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000016 RID: 22 RVA: 0x000021C6 File Offset: 0x000003C6
		public override string Name
		{
			get
			{
				if (!this.bool_2)
				{
					return this.combatRoutine_0.Name;
				}
				return GClass1.string_5;
			}
		}

		// Token: 0x06000017 RID: 23 RVA: 0x000021E1 File Offset: 0x000003E1
		public override void Initialize()
		{
			this.combatRoutine_0.Initialize();
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000018 RID: 24 RVA: 0x000021EE File Offset: 0x000003EE
		public override Composite CombatBehavior
		{
			get
			{
				return this.combatRoutine_0.CombatBehavior;
			}
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000019 RID: 25 RVA: 0x000021FB File Offset: 0x000003FB
		public override Composite PreCombatBuffBehavior
		{
			get
			{
				return this.combatRoutine_0.PreCombatBuffBehavior;
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600001A RID: 26 RVA: 0x00002208 File Offset: 0x00000408
		public override WoWClass Class
		{
			get
			{
				return 4;
			}
		}

		// Token: 0x0600001B RID: 27 RVA: 0x0000220B File Offset: 0x0000040B
		public override void OnButtonPress()
		{
			if (!this.bool_0 && !this.bool_1 && this.bool_2)
			{
				this.method_1();
			}
			this.combatRoutine_0.OnButtonPress();
		}

		// Token: 0x0600001C RID: 28 RVA: 0x00002236 File Offset: 0x00000436
		public override void Pulse()
		{
			this.combatRoutine_0.Pulse();
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x0600001D RID: 29 RVA: 0x00002243 File Offset: 0x00000443
		public override bool WantButton
		{
			get
			{
				return true;
			}
		}

		// Token: 0x04000010 RID: 16
		private CombatRoutine combatRoutine_0;

		// Token: 0x04000011 RID: 17
		private bool bool_0;

		// Token: 0x04000012 RID: 18
		private bool bool_1;

		// Token: 0x04000013 RID: 19
		private bool bool_2;
	}
}
