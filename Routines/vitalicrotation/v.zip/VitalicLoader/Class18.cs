﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;

namespace ns0
{
	// Token: 0x02000069 RID: 105
	internal sealed class Class18
	{
		// Token: 0x06000775 RID: 1909 RVA: 0x00006C8D File Offset: 0x00004E8D
		public Class18(Size size_0)
		{
			this.bitmap_0 = new Bitmap(size_0.Width, size_0.Height, PixelFormat.Format32bppArgb);
		}

		// Token: 0x06000776 RID: 1910 RVA: 0x0001CCB0 File Offset: 0x0001AEB0
		public Graphics method_0()
		{
			Graphics graphics = Graphics.FromImage(this.bitmap_0);
			graphics.CompositingMode = CompositingMode.SourceOver;
			graphics.CompositingQuality = CompositingQuality.HighQuality;
			graphics.InterpolationMode = InterpolationMode.High;
			graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
			graphics.SmoothingMode = SmoothingMode.AntiAlias;
			graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
			return graphics;
		}

		// Token: 0x06000777 RID: 1911 RVA: 0x00006CB3 File Offset: 0x00004EB3
		public void method_1(Graphics graphics_0)
		{
			graphics_0.DrawImageUnscaled(this.bitmap_0, Point.Empty);
		}

		// Token: 0x04000409 RID: 1033
		private Bitmap bitmap_0;
	}
}
