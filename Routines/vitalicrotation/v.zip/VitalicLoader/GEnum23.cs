﻿using System;

namespace ns0
{
	// Token: 0x0200009F RID: 159
	public enum GEnum23
	{
		// Token: 0x04000481 RID: 1153
		const_0,
		// Token: 0x04000482 RID: 1154
		const_1,
		// Token: 0x04000483 RID: 1155
		const_2
	}
}
