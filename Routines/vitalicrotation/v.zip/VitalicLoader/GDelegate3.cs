﻿using System;

namespace ns0
{
	// Token: 0x0200002F RID: 47
	// (Invoke) Token: 0x060001AE RID: 430
	public delegate void GDelegate3(object sender, GEventArgs1 e);
}
