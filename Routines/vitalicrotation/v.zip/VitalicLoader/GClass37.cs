﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace ns0
{
	// Token: 0x02000065 RID: 101
	public class GClass37
	{
		// Token: 0x0600074E RID: 1870 RVA: 0x00006B3D File Offset: 0x00004D3D
		private GClass37()
		{
			this.dictionary_0 = new Dictionary<string, string>();
		}

		// Token: 0x0600074F RID: 1871 RVA: 0x0001B994 File Offset: 0x00019B94
		public GClass37(string string_1) : this()
		{
			string_1 = string_1.Substring(1, string_1.Length - 2);
			int num = string_1.IndexOf(" ");
			if (num < 0)
			{
				this.string_0 = string_1;
			}
			else
			{
				this.string_0 = string_1.Substring(0, num);
			}
			if (this.string_0.StartsWith("/"))
			{
				this.bool_0 = true;
				this.string_0 = this.string_0.Substring(1);
			}
			this.string_0 = this.string_0.ToLower();
			MatchCollection matchCollection = Class17.smethod_0("[^\\s]*\\s*=\\s*(\"[^\"]*\"|[^\\s]*)", string_1);
			foreach (object obj in matchCollection)
			{
				Match match = (Match)obj;
				string[] array = match.Value.Split(new char[]
				{
					'='
				});
				if (array.Length == 1)
				{
					if (!this.Dictionary_0.ContainsKey(array[0]))
					{
						this.Dictionary_0.Add(array[0].ToLower(), string.Empty);
					}
				}
				else if (array.Length == 2)
				{
					string key = array[0].Trim();
					string text = array[1].Trim();
					if (text.StartsWith("\"") && text.EndsWith("\"") && text.Length > 2)
					{
						text = text.Substring(1, text.Length - 2);
					}
					if (!this.Dictionary_0.ContainsKey(key))
					{
						this.Dictionary_0.Add(key, text);
					}
				}
			}
		}

		// Token: 0x17000219 RID: 537
		// (get) Token: 0x06000750 RID: 1872 RVA: 0x00006B50 File Offset: 0x00004D50
		public Dictionary<string, string> Dictionary_0
		{
			get
			{
				return this.dictionary_0;
			}
		}

		// Token: 0x1700021A RID: 538
		// (get) Token: 0x06000751 RID: 1873 RVA: 0x00006B58 File Offset: 0x00004D58
		public string String_0
		{
			get
			{
				return this.string_0;
			}
		}

		// Token: 0x1700021B RID: 539
		// (get) Token: 0x06000752 RID: 1874 RVA: 0x00006B60 File Offset: 0x00004D60
		public bool Boolean_0
		{
			get
			{
				return this.bool_0;
			}
		}

		// Token: 0x1700021C RID: 540
		// (get) Token: 0x06000753 RID: 1875 RVA: 0x0001BB4C File Offset: 0x00019D4C
		public bool Boolean_1
		{
			get
			{
				return this.String_0.StartsWith("!") || new List<string>(new string[]
				{
					"area",
					"base",
					"basefont",
					"br",
					"col",
					"frame",
					"hr",
					"img",
					"input",
					"isindex",
					"link",
					"meta",
					"param"
				}).Contains(this.String_0);
			}
		}

		// Token: 0x06000754 RID: 1876 RVA: 0x0001BC2C File Offset: 0x00019E2C
		internal void method_0(GClass23 gclass23_0)
		{
			string a = this.String_0.ToUpper();
			foreach (string text in this.Dictionary_0.Keys)
			{
				string text2 = this.Dictionary_0[text];
				string key;
				switch (key = text)
				{
				case "align":
					if (!(text2 == "left") && !(text2 == "center") && !(text2 == "right") && !(text2 == "justify"))
					{
						gclass23_0.String_53 = text2;
					}
					else
					{
						gclass23_0.String_55 = text2;
					}
					break;
				case "background":
					gclass23_0.String_42 = text2;
					break;
				case "bgcolor":
					gclass23_0.String_41 = text2;
					break;
				case "border":
					gclass23_0.String_4 = this.method_1(text2);
					if (a == "TABLE")
					{
						this.method_2(gclass23_0, text2);
					}
					else
					{
						gclass23_0.String_8 = "solid";
					}
					break;
				case "bordercolor":
					gclass23_0.String_10 = text2;
					break;
				case "cellspacing":
					gclass23_0.String_20 = this.method_1(text2);
					break;
				case "cellpadding":
					this.method_3(gclass23_0, text2);
					break;
				case "color":
					gclass23_0.String_46 = text2;
					break;
				case "dir":
					gclass23_0.String_48 = text2;
					break;
				case "face":
					gclass23_0.String_60 = text2;
					break;
				case "height":
					gclass23_0.String_40 = this.method_1(text2);
					break;
				case "hspace":
					gclass23_0.String_30 = (gclass23_0.String_29 = this.method_1(text2));
					break;
				case "nowrap":
					gclass23_0.String_57 = "nowrap";
					break;
				case "size":
					if (a == "HR")
					{
						gclass23_0.String_40 = this.method_1(text2);
					}
					break;
				case "valign":
					gclass23_0.String_53 = text2;
					break;
				case "vspace":
					gclass23_0.String_31 = (gclass23_0.String_28 = this.method_1(text2));
					break;
				case "width":
					gclass23_0.String_39 = this.method_1(text2);
					break;
				}
			}
		}

		// Token: 0x06000755 RID: 1877 RVA: 0x0001BF74 File Offset: 0x0001A174
		private string method_1(string string_1)
		{
			GClass33 gclass = new GClass33(string_1);
			if (gclass.Boolean_0)
			{
				return string_1 + "px";
			}
			return string_1;
		}

		// Token: 0x06000756 RID: 1878 RVA: 0x0001BFA0 File Offset: 0x0001A1A0
		private void method_2(GClass23 gclass23_0, string string_1)
		{
			foreach (GClass23 gclass in gclass23_0.List_0)
			{
				foreach (GClass23 gclass2 in gclass.List_0)
				{
					gclass2.String_4 = this.method_1(string_1);
				}
			}
		}

		// Token: 0x06000757 RID: 1879 RVA: 0x0001C038 File Offset: 0x0001A238
		private void method_3(GClass23 gclass23_0, string string_1)
		{
			foreach (GClass23 gclass in gclass23_0.List_0)
			{
				foreach (GClass23 gclass2 in gclass.List_0)
				{
					gclass2.String_32 = this.method_1(string_1);
				}
			}
		}

		// Token: 0x06000758 RID: 1880 RVA: 0x00006B68 File Offset: 0x00004D68
		public bool method_4(string string_1)
		{
			return this.Dictionary_0.ContainsKey(string_1);
		}

		// Token: 0x06000759 RID: 1881 RVA: 0x00006B76 File Offset: 0x00004D76
		public override string ToString()
		{
			return string.Format("<{1}{0}>", this.String_0, this.Boolean_0 ? "/" : string.Empty);
		}

		// Token: 0x040003EA RID: 1002
		private string string_0;

		// Token: 0x040003EB RID: 1003
		private bool bool_0;

		// Token: 0x040003EC RID: 1004
		private Dictionary<string, string> dictionary_0;
	}
}
