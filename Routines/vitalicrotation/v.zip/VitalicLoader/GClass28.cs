﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text.RegularExpressions;

namespace ns0
{
	// Token: 0x02000067 RID: 103
	[CLSCompliant(false)]
	public class GClass28 : GClass23
	{
		// Token: 0x0600075D RID: 1885 RVA: 0x0001C1F0 File Offset: 0x0001A3F0
		public GClass28()
		{
			this.gclass28_0 = this;
			this.dictionary_3 = new Dictionary<string, Dictionary<string, GClass29>>();
			this.dictionary_4 = new Dictionary<GClass23, RectangleF>();
			this.Dictionary_2.Add("all", new Dictionary<string, GClass29>());
			base.String_47 = "block";
			this.method_34("\n\n        \n        html, address,\n        blockquote,\n        body, dd, div,\n        dl, dt, fieldset, form,\n        frame, frameset,\n        h1, h2, h3, h4,\n        h5, h6, noframes,\n        ol, p, ul, center,\n        dir, hr, menu, pre   { display: block }\n        li              { display: list-item }\n        head            { display: none }\n        table           { display: table }\n        tr              { display: table-row }\n        thead           { display: table-header-group }\n        tbody           { display: table-row-group }\n        tfoot           { display: table-footer-group }\n        col             { display: table-column }\n        colgroup        { display: table-column-group }\n        td, th          { display: table-cell }\n        caption         { display: table-caption }\n        th              { font-weight: bolder; text-align: center }\n        caption         { text-align: center }\n        body            { margin: 8px }\n        h1              { font-size: 2em; margin: .67em 0 }\n        h2              { font-size: 1.5em; margin: .75em 0 }\n        h3              { font-size: 1.17em; margin: .83em 0 }\n        h4, p,\n        blockquote, ul,\n        fieldset, form,\n        ol, dl, dir,\n        menu            { margin: 0 0 }\n        h5              { font-size: .83em; margin: 1.5em 0 }\n        h6              { font-size: .75em; margin: 1.67em 0 }\n        h1, h2, h3, h4,\n        h5, h6, b,\n        strong          { font-weight: bolder; }\n        blockquote      { margin-left: 40px; margin-right: 40px }\n        i, cite, em,\n        var, address    { font-style: italic }\n        pre, tt, code,\n        kbd, samp       { font-family: monospace }\n        pre             { white-space: pre }\n        button, textarea,\n        input, select   { display: inline-block }\n        big             { font-size: 1.17em }\n        small, sub, sup { font-size: .83em }\n        sub             { vertical-align: sub }\n        sup             { vertical-align: super }\n        table           { border-spacing: 2px; }\n        thead, tbody,\n        tfoot           { vertical-align: middle }\n        td, th          { vertical-align: inherit }\n        s, strike, del  { text-decoration: line-through }\n        hr              { border: 1px inset }\n        ol, ul, dir,\n        menu, dd        { margin-left: 40px }\n        ol              { list-style-type: decimal }\n        ol ul, ul ol,\n        ul ul, ol ol    { margin-top: 0; margin-bottom: 0 }\n        u, ins          { text-decoration: underline }\n        br:before       { content: \"\\A\" }\n        :before, :after { white-space: pre-line }\n        center          { text-align: center }\n        :link, :visited { text-decoration: underline }\n        :focus          { outline: thin dotted invert }\n\n        /* Begin bidirectionality settings (do not change) */\n        BDO[DIR=\"ltr\"]  { direction: ltr; unicode-bidi: bidi-override }\n        BDO[DIR=\"rtl\"]  { direction: rtl; unicode-bidi: bidi-override }\n\n        *[DIR=\"ltr\"]    { direction: ltr; unicode-bidi: embed }\n        *[DIR=\"rtl\"]    { direction: rtl; unicode-bidi: embed }\n\n        @media print {\n          h1            { page-break-before: always }\n          h1, h2, h3,\n          h4, h5, h6    { page-break-after: avoid }\n          ul, ol, dl    { page-break-before: avoid }\n        }\n\n        /* Not in the specification but necessary */\n        a               { font-weight: bold; text-decoration:underline }\n        table           { border-color:#dfdfdf; border-style:outset; }\n        td, th          { border-color:#dfdfdf; border-style:inset; }\n        style, title,\n        script, link,\n        meta, area,\n        base, param     { display:none }\n        hr              { border-color: #ccc }  \n        pre             { font-size:10pt }\n        \n        /*This is the background of the HtmlToolTip*/\n        .htmltooltipbackground {\n              border:solid 1px #767676;\n              background-color:#white;\n              background-gradient:#E4E5F0;\n              text-align:center;\n        }\n\n        ");
		}

		// Token: 0x0600075E RID: 1886 RVA: 0x00006BFA File Offset: 0x00004DFA
		public GClass28(string string_71) : this()
		{
			this.string_70 = string_71;
			this.method_36();
			this.method_38(this);
			this.method_39(this);
		}

		// Token: 0x1700021D RID: 541
		// (get) Token: 0x0600075F RID: 1887 RVA: 0x00006C1D File Offset: 0x00004E1D
		internal Dictionary<GClass23, RectangleF> Dictionary_1
		{
			get
			{
				return this.dictionary_4;
			}
		}

		// Token: 0x1700021E RID: 542
		// (get) Token: 0x06000760 RID: 1888 RVA: 0x00006C25 File Offset: 0x00004E25
		public Dictionary<string, Dictionary<string, GClass29>> Dictionary_2
		{
			get
			{
				return this.dictionary_3;
			}
		}

		// Token: 0x1700021F RID: 543
		// (get) Token: 0x06000761 RID: 1889 RVA: 0x00006C2D File Offset: 0x00004E2D
		public string String_70
		{
			get
			{
				return this.string_70;
			}
		}

		// Token: 0x17000220 RID: 544
		// (get) Token: 0x06000762 RID: 1890 RVA: 0x00006C35 File Offset: 0x00004E35
		// (set) Token: 0x06000763 RID: 1891 RVA: 0x00006C3D File Offset: 0x00004E3D
		public bool Boolean_3
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x17000221 RID: 545
		// (get) Token: 0x06000764 RID: 1892 RVA: 0x00006C46 File Offset: 0x00004E46
		// (set) Token: 0x06000765 RID: 1893 RVA: 0x00006C4E File Offset: 0x00004E4E
		public bool Boolean_4
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x17000222 RID: 546
		// (get) Token: 0x06000766 RID: 1894 RVA: 0x00006C57 File Offset: 0x00004E57
		// (set) Token: 0x06000767 RID: 1895 RVA: 0x00006C5F File Offset: 0x00004E5F
		public SizeF SizeF_1
		{
			get
			{
				return this.sizeF_1;
			}
			set
			{
				this.sizeF_1 = value;
			}
		}

		// Token: 0x17000223 RID: 547
		// (get) Token: 0x06000768 RID: 1896 RVA: 0x00006C68 File Offset: 0x00004E68
		// (set) Token: 0x06000769 RID: 1897 RVA: 0x00006C70 File Offset: 0x00004E70
		public PointF PointF_1
		{
			get
			{
				return this.pointF_1;
			}
			set
			{
				this.pointF_1 = value;
			}
		}

		// Token: 0x0600076A RID: 1898 RVA: 0x0001C24C File Offset: 0x0001A44C
		public void method_34(string string_71)
		{
			if (string.IsNullOrEmpty(string_71))
			{
				return;
			}
			string_71 = string_71.ToLower();
			MatchCollection matchCollection = Class17.smethod_0("/\\*[^*/]*\\*/", string_71);
			while (matchCollection.Count > 0)
			{
				string_71 = string_71.Remove(matchCollection[0].Index, matchCollection[0].Length);
				matchCollection = Class17.smethod_0("/\\*[^*/]*\\*/", string_71);
			}
			MatchCollection matchCollection2 = Class17.smethod_0("@.*\\{\\s*(\\s*[^\\{\\}]*\\{[^\\{\\}]*\\}\\s*)*\\s*\\}", string_71);
			while (matchCollection2.Count > 0)
			{
				Match match = matchCollection2[0];
				string value = match.Value;
				string_71 = string_71.Remove(match.Index, match.Length);
				if (value.StartsWith("@media"))
				{
					MatchCollection matchCollection3 = Class17.smethod_0("@media[^\\{\\}]*\\{", value);
					if (matchCollection3.Count == 1)
					{
						string value2 = matchCollection3[0].Value;
						if (value2.StartsWith("@media") && value2.EndsWith("{"))
						{
							string[] array = value2.Substring(6, value2.Length - 7).Split(new char[]
							{
								' '
							});
							for (int i = 0; i < array.Length; i++)
							{
								if (!string.IsNullOrEmpty(array[i].Trim()))
								{
									MatchCollection matchCollection4 = Class17.smethod_0("[^\\{\\}]*\\{[^\\{\\}]*\\}", value);
									foreach (object obj in matchCollection4)
									{
										Match match2 = (Match)obj;
										this.method_35(array[i].Trim(), match2.Value);
									}
								}
							}
						}
					}
				}
				matchCollection2 = Class17.smethod_0("@.*\\{\\s*(\\s*[^\\{\\}]*\\{[^\\{\\}]*\\}\\s*)*\\s*\\}", string_71);
			}
			MatchCollection matchCollection5 = Class17.smethod_0("[^\\{\\}]*\\{[^\\{\\}]*\\}", string_71);
			foreach (object obj2 in matchCollection5)
			{
				Match match3 = (Match)obj2;
				this.method_35("all", match3.Value);
			}
		}

		// Token: 0x0600076B RID: 1899 RVA: 0x0001C484 File Offset: 0x0001A684
		private void method_35(string string_71, string string_72)
		{
			if (string.IsNullOrEmpty(string_71))
			{
				string_71 = "all";
			}
			int num = string_72.IndexOf("{");
			string string_73 = string_72.Substring(num).Replace("{", string.Empty).Replace("}", string.Empty);
			if (num < 0)
			{
				return;
			}
			string[] array = string_72.Substring(0, num).Split(new char[]
			{
				','
			});
			for (int i = 0; i < array.Length; i++)
			{
				string text = array[i].Trim();
				if (!string.IsNullOrEmpty(text))
				{
					GClass29 gclass = new GClass29(string_73);
					if (!this.Dictionary_2.ContainsKey(string_71))
					{
						this.Dictionary_2.Add(string_71, new Dictionary<string, GClass29>());
					}
					if (!this.Dictionary_2[string_71].ContainsKey(text))
					{
						this.Dictionary_2[string_71].Add(text, gclass);
					}
					else
					{
						GClass29 gclass2 = this.Dictionary_2[string_71][text];
						foreach (string key in gclass.Dictionary_0.Keys)
						{
							if (gclass2.Dictionary_0.ContainsKey(key))
							{
								gclass2.Dictionary_0[key] = gclass.Dictionary_0[key];
							}
							else
							{
								gclass2.Dictionary_0.Add(key, gclass.Dictionary_0[key]);
							}
						}
						gclass2.method_0();
					}
				}
			}
		}

		// Token: 0x0600076C RID: 1900 RVA: 0x0001C62C File Offset: 0x0001A82C
		private void method_36()
		{
			MatchCollection matchCollection = Class17.smethod_0("<[^<>]*>", this.String_70);
			GClass23 gclass23_ = this;
			int num = -1;
			foreach (object obj in matchCollection)
			{
				Match match = (Match)obj;
				string text = (match.Index > 0) ? this.String_70.Substring(num + 1, match.Index - num - 1) : string.Empty;
				if (!string.IsNullOrEmpty(text.Trim()))
				{
					GClass26 gclass = new GClass26(gclass23_);
					gclass.String_69 = text;
				}
				else if (text != null && text.Length > 0)
				{
					GClass27 gclass2 = new GClass27(gclass23_);
					gclass2.String_69 = text;
				}
				GClass37 gclass3 = new GClass37(match.Value);
				if (gclass3.Boolean_0)
				{
					gclass23_ = this.method_37(gclass3.String_0, gclass23_);
				}
				else if (gclass3.Boolean_1)
				{
					new GClass23(gclass23_, gclass3);
				}
				else
				{
					gclass23_ = new GClass23(gclass23_, gclass3);
				}
				num = match.Index + match.Length - 1;
			}
			string text2 = this.String_70.Substring((num > 0) ? (num + 1) : 0, this.String_70.Length - num - 1 + ((num == 0) ? 1 : 0));
			if (!string.IsNullOrEmpty(text2))
			{
				GClass26 gclass4 = new GClass26(gclass23_);
				gclass4.String_69 = text2;
			}
		}

		// Token: 0x0600076D RID: 1901 RVA: 0x0001C7AC File Offset: 0x0001A9AC
		private GClass23 method_37(string string_71, GClass23 gclass23_3)
		{
			if (gclass23_3 == null)
			{
				return base.GClass28_0;
			}
			if (gclass23_3.GClass37_0 == null || !gclass23_3.GClass37_0.String_0.Equals(string_71, StringComparison.CurrentCultureIgnoreCase))
			{
				return this.method_37(string_71, gclass23_3.GClass23_2);
			}
			if (gclass23_3.GClass23_2 != null)
			{
				return gclass23_3.GClass23_2;
			}
			return base.GClass28_0;
		}

		// Token: 0x0600076E RID: 1902 RVA: 0x0001C804 File Offset: 0x0001AA04
		private void method_38(GClass23 gclass23_3)
		{
			bool flag = false;
			foreach (GClass23 gclass in gclass23_3.List_0)
			{
				gclass.method_17();
				if (gclass.GClass37_0 != null)
				{
					if (this.Dictionary_2["all"].ContainsKey(gclass.GClass37_0.String_0))
					{
						this.Dictionary_2["all"][gclass.GClass37_0.String_0].method_1(gclass);
					}
					if (gclass.GClass37_0.method_4("class") && this.Dictionary_2["all"].ContainsKey("." + gclass.GClass37_0.Dictionary_0["class"]))
					{
						this.Dictionary_2["all"]["." + gclass.GClass37_0.Dictionary_0["class"]].method_1(gclass);
					}
					gclass.GClass37_0.method_0(gclass);
					if (gclass.GClass37_0.method_4("style"))
					{
						GClass29 gclass2 = new GClass29(gclass.GClass37_0.Dictionary_0["style"]);
						gclass2.method_1(gclass);
					}
					if (gclass.GClass37_0.String_0.Equals("style", StringComparison.CurrentCultureIgnoreCase) && gclass.List_0.Count == 1)
					{
						this.method_34(gclass.List_0[0].String_69);
					}
					if (gclass.GClass37_0.String_0.Equals("link", StringComparison.CurrentCultureIgnoreCase) && gclass.method_6("rel", string.Empty).Equals("stylesheet", StringComparison.CurrentCultureIgnoreCase))
					{
						this.method_34(GClass34.smethod_10(gclass.method_6("href", string.Empty)));
					}
				}
				this.method_38(gclass);
			}
			if (flag)
			{
				foreach (GClass23 gclass3 in gclass23_3.List_0)
				{
					gclass3.String_47 = "block";
				}
			}
		}

		// Token: 0x0600076F RID: 1903 RVA: 0x0001CA70 File Offset: 0x0001AC70
		private void method_39(GClass23 gclass23_3)
		{
			if (!gclass23_3.method_1())
			{
				List<List<GClass23>> list = this.method_40(gclass23_3);
				foreach (List<GClass23> list2 in list)
				{
					if (list2.Count != 0)
					{
						if (list2.Count == 1 && list2[0] is GClass27)
						{
							GClass25 gclass23_4 = new GClass25(gclass23_3, list2[0]);
							list2[0].GClass23_2 = gclass23_4;
						}
						else
						{
							GClass24 gclass23_5 = new GClass24(gclass23_3, list2[0]);
							foreach (GClass23 gclass in list2)
							{
								gclass.GClass23_2 = gclass23_5;
							}
						}
					}
				}
			}
			foreach (GClass23 gclass23_6 in gclass23_3.List_0)
			{
				this.method_39(gclass23_6);
			}
		}

		// Token: 0x06000770 RID: 1904 RVA: 0x0001CBA4 File Offset: 0x0001ADA4
		private List<List<GClass23>> method_40(GClass23 gclass23_3)
		{
			List<List<GClass23>> list = new List<List<GClass23>>();
			List<GClass23> list2 = null;
			for (int i = 0; i < gclass23_3.List_0.Count; i++)
			{
				GClass23 gclass = gclass23_3.List_0[i];
				if (gclass.String_47 == "inline")
				{
					if (list2 == null)
					{
						list2 = new List<GClass23>();
						list.Add(list2);
					}
					list2.Add(gclass);
				}
				else
				{
					list2 = null;
				}
			}
			if (list.Count > 0 && list[list.Count - 1].Count == 0)
			{
				list.RemoveAt(list.Count - 1);
			}
			return list;
		}

		// Token: 0x06000771 RID: 1905 RVA: 0x00006C79 File Offset: 0x00004E79
		public override void vmethod_0(Graphics graphics_0)
		{
			this.Dictionary_1.Clear();
			base.vmethod_0(graphics_0);
		}

		// Token: 0x040003EE RID: 1006
		private Dictionary<string, Dictionary<string, GClass29>> dictionary_3;

		// Token: 0x040003EF RID: 1007
		private string string_70;

		// Token: 0x040003F0 RID: 1008
		private bool bool_2;

		// Token: 0x040003F1 RID: 1009
		private SizeF sizeF_1;

		// Token: 0x040003F2 RID: 1010
		private PointF pointF_1;

		// Token: 0x040003F3 RID: 1011
		private Dictionary<GClass23, RectangleF> dictionary_4;

		// Token: 0x040003F4 RID: 1012
		private bool bool_3;
	}
}
