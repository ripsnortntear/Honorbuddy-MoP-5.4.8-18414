﻿using System;

namespace ns0
{
	// Token: 0x02000099 RID: 153
	public enum GEnum17
	{
		// Token: 0x04000469 RID: 1129
		const_0,
		// Token: 0x0400046A RID: 1130
		const_1,
		// Token: 0x0400046B RID: 1131
		const_2
	}
}
