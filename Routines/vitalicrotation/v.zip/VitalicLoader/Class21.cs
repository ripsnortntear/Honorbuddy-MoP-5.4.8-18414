﻿using System;

namespace ns0
{
	// Token: 0x0200008D RID: 141
	internal static class Class21
	{
		// Token: 0x04000432 RID: 1074
		internal const string string_0 = "MetroFramework.Design";

		// Token: 0x04000433 RID: 1075
		internal const string string_1 = "MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a";

		// Token: 0x04000434 RID: 1076
		internal const string string_2 = "MetroFramework.Design, PublicKey=00240000048000009400000006020000002400005253413100040000010001004d3b6f2adab21d00d59de966f5d7f4d8325296ded578ac35bca529580b534443bb4090600ff1f057136d58f20a225e0d025119aec656e9b6ac5691e12689c0b03d55c8b8822fd84e2acbde80a2d9124009d20f5adf05d36cfa95ba164a0d6ab348a9f8e3a00f066f4d32c0b71b5be6d7f86616491f6dd0630e49ec15a0c8f9c9";

		// Token: 0x04000435 RID: 1077
		internal const string string_3 = "MetroFramework.Fonts";

		// Token: 0x04000436 RID: 1078
		internal const string string_4 = "MetroFramework.Fonts, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a";

		// Token: 0x04000437 RID: 1079
		internal const string string_5 = "MetroFramework.Fonts, PublicKey=00240000048000009400000006020000002400005253413100040000010001004d3b6f2adab21d00d59de966f5d7f4d8325296ded578ac35bca529580b534443bb4090600ff1f057136d58f20a225e0d025119aec656e9b6ac5691e12689c0b03d55c8b8822fd84e2acbde80a2d9124009d20f5adf05d36cfa95ba164a0d6ab348a9f8e3a00f066f4d32c0b71b5be6d7f86616491f6dd0630e49ec15a0c8f9c9";

		// Token: 0x04000438 RID: 1080
		internal const string string_6 = "MetroFramework.Fonts.FontResolver, MetroFramework.Fonts, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a";

		// Token: 0x04000439 RID: 1081
		internal const string string_7 = "5f91a84759bf584a";

		// Token: 0x0400043A RID: 1082
		internal const string string_8 = "00240000048000009400000006020000002400005253413100040000010001004d3b6f2adab21d00d59de966f5d7f4d8325296ded578ac35bca529580b534443bb4090600ff1f057136d58f20a225e0d025119aec656e9b6ac5691e12689c0b03d55c8b8822fd84e2acbde80a2d9124009d20f5adf05d36cfa95ba164a0d6ab348a9f8e3a00f066f4d32c0b71b5be6d7f86616491f6dd0630e49ec15a0c8f9c9";

		// Token: 0x0400043B RID: 1083
		internal const string string_9 = "5f91a84759bf584a";
	}
}
