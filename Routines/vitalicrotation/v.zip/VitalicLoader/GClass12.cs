﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000034 RID: 52
	[DefaultEvent("Click")]
	[Designer("MetroFramework.Design.Controls.MetroButtonDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	[ToolboxBitmap(typeof(Button))]
	public class GClass12 : GClass11
	{
		// Token: 0x060001F1 RID: 497 RVA: 0x0000312A File Offset: 0x0000132A
		public GClass12()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.OptimizedDoubleBuffer, true);
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x060001F2 RID: 498 RVA: 0x0000313E File Offset: 0x0000133E
		// (set) Token: 0x060001F3 RID: 499 RVA: 0x00003150 File Offset: 0x00001350
		private bool Boolean_2
		{
			get
			{
				return this.bool_10 || this.bool_11;
			}
			set
			{
				if (!this.bool_10)
				{
					this.bool_11 = value;
				}
			}
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x00003161 File Offset: 0x00001361
		public void method_0(bool bool_12)
		{
			if (bool_12)
			{
				this.Boolean_2 = true;
				this.bool_10 = true;
			}
			else
			{
				this.bool_10 = false;
				this.Boolean_2 = false;
				this.bool_8 = false;
			}
			base.Invalidate();
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x0000BF70 File Offset: 0x0000A170
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (this.bool_8 && !this.Boolean_2 && base.Enabled)
				{
					color = GClass39.GClass46.GClass47.smethod_1(base.GEnum29_0);
				}
				else if ((this.bool_8 || this.bool_10) && this.Boolean_2 && base.Enabled)
				{
					color = GClass39.GClass46.GClass47.smethod_2(base.GEnum29_0);
				}
				else if (!base.Enabled)
				{
					color = GClass39.GClass46.GClass47.smethod_3(base.GEnum29_0);
				}
				else if (!base.Boolean_8)
				{
					color = GClass39.GClass46.GClass47.smethod_0(base.GEnum29_0);
				}
				if (color.A == 255 && this.BackgroundImage == null)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x0000BCEC File Offset: 0x00009EEC
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x0000C060 File Offset: 0x0000A260
		protected override void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color color;
			Color color2;
			if (this.bool_8 && !this.Boolean_2 && base.Enabled)
			{
				color = GClass39.GClass40.GClass41.smethod_1(base.GEnum29_0);
				color2 = GClass39.GClass56.GClass57.smethod_1(base.GEnum29_0);
			}
			else if ((this.bool_8 || this.bool_10) && this.Boolean_2 && base.Enabled)
			{
				color = GClass39.GClass40.GClass41.smethod_2(base.GEnum29_0);
				color2 = GClass39.GClass56.GClass57.smethod_2(base.GEnum29_0);
			}
			else if (!base.Enabled)
			{
				color = GClass39.GClass40.GClass41.smethod_3(base.GEnum29_0);
				color2 = GClass39.GClass56.GClass57.smethod_3(base.GEnum29_0);
			}
			else
			{
				color = GClass39.GClass40.GClass41.smethod_0(base.GEnum29_0);
				if (base.Boolean_9)
				{
					color2 = this.ForeColor;
				}
				else if (base.Boolean_10)
				{
					color2 = GClass39.smethod_0(base.GEnum10_0);
				}
				else
				{
					color2 = GClass39.GClass56.GClass57.smethod_0(base.GEnum29_0);
				}
			}
			using (Pen pen = new Pen(color))
			{
				Rectangle rect = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
				paintEventArgs_0.Graphics.DrawRectangle(pen, rect);
			}
			if (base.Boolean_1 && !this.bool_8 && !this.Boolean_2 && base.Enabled)
			{
				using (Pen pen2 = GClass39.smethod_2(base.GEnum10_0))
				{
					Rectangle rect2 = new Rectangle(0, 0, base.Width - 1, base.Height - 1);
					paintEventArgs_0.Graphics.DrawRectangle(pen2, rect2);
					rect2 = new Rectangle(1, 1, base.Width - 3, base.Height - 3);
					paintEventArgs_0.Graphics.DrawRectangle(pen2, rect2);
				}
			}
			TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Text, GClass67.smethod_12(base.GEnum27_0, base.GEnum28_0), base.ClientRectangle, color2, GClass39.smethod_4(this.TextAlign));
			this.vmethod_2(new GEventArgs3(Color.Empty, color2, paintEventArgs_0.Graphics));
			if (base.Boolean_0 && this.bool_9)
			{
				ControlPaint.DrawFocusRectangle(paintEventArgs_0.Graphics, base.ClientRectangle);
			}
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x00003191 File Offset: 0x00001391
		protected override void OnGotFocus(EventArgs e)
		{
			this.bool_9 = true;
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x060001F9 RID: 505 RVA: 0x000031A7 File Offset: 0x000013A7
		protected override void OnLostFocus(EventArgs e)
		{
			this.bool_9 = false;
			this.bool_8 = false;
			this.Boolean_2 = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		// Token: 0x060001FA RID: 506 RVA: 0x000031CB File Offset: 0x000013CB
		protected override void OnEnter(EventArgs e)
		{
			this.bool_9 = true;
			base.Invalidate();
			base.OnEnter(e);
		}

		// Token: 0x060001FB RID: 507 RVA: 0x000031E1 File Offset: 0x000013E1
		protected override void OnLeave(EventArgs e)
		{
			this.bool_9 = false;
			this.bool_8 = false;
			this.Boolean_2 = false;
			base.Invalidate();
			base.OnLeave(e);
		}

		// Token: 0x060001FC RID: 508 RVA: 0x00003205 File Offset: 0x00001405
		protected override void OnKeyDown(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Space)
			{
				this.bool_8 = true;
				this.Boolean_2 = true;
				base.Invalidate();
			}
			base.OnKeyDown(e);
		}

		// Token: 0x060001FD RID: 509 RVA: 0x0000322C File Offset: 0x0000142C
		protected override void OnKeyUp(KeyEventArgs e)
		{
			this.bool_8 = false;
			this.Boolean_2 = false;
			base.Invalidate();
			base.OnKeyUp(e);
		}

		// Token: 0x060001FE RID: 510 RVA: 0x00003249 File Offset: 0x00001449
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_8 = true;
			base.Invalidate();
			base.OnMouseEnter(e);
		}

		// Token: 0x060001FF RID: 511 RVA: 0x0000325F File Offset: 0x0000145F
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.Boolean_2 = true;
				base.Invalidate();
			}
			base.OnMouseDown(e);
		}

		// Token: 0x06000200 RID: 512 RVA: 0x00003282 File Offset: 0x00001482
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this.Boolean_2 = false;
			base.Invalidate();
			base.OnMouseUp(e);
		}

		// Token: 0x06000201 RID: 513 RVA: 0x00003298 File Offset: 0x00001498
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_8 = false;
			base.Invalidate();
			base.OnMouseLeave(e);
		}

		// Token: 0x06000202 RID: 514 RVA: 0x000032AE File Offset: 0x000014AE
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x040000C7 RID: 199
		private bool bool_8;

		// Token: 0x040000C8 RID: 200
		private bool bool_9;

		// Token: 0x040000C9 RID: 201
		private bool bool_10;

		// Token: 0x040000CA RID: 202
		private bool bool_11;
	}
}
