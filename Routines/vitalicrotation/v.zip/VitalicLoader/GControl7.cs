﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Drawing.Text;
using System.Reflection;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000062 RID: 98
	[CLSCompliant(false)]
	public class GControl7 : ScrollableControl
	{
		// Token: 0x06000734 RID: 1844 RVA: 0x0001B5D4 File Offset: 0x000197D4
		public GControl7()
		{
			this.gclass28_0 = new GClass28();
			base.SetStyle(ControlStyles.ResizeRedraw, true);
			base.SetStyle(ControlStyles.Opaque, true);
			this.DoubleBuffered = true;
			this.BackColor = SystemColors.Window;
			this.AutoScroll = true;
			GClass36.smethod_0(Assembly.GetCallingAssembly());
		}

		// Token: 0x17000213 RID: 531
		// (get) Token: 0x06000735 RID: 1845 RVA: 0x00006A10 File Offset: 0x00004C10
		// (set) Token: 0x06000736 RID: 1846 RVA: 0x00006A18 File Offset: 0x00004C18
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
		public override bool AutoSize
		{
			get
			{
				return base.AutoSize;
			}
			set
			{
				base.AutoSize = value;
			}
		}

		// Token: 0x17000214 RID: 532
		// (get) Token: 0x06000737 RID: 1847 RVA: 0x00003D38 File Offset: 0x00001F38
		// (set) Token: 0x06000738 RID: 1848 RVA: 0x00006A21 File Offset: 0x00004C21
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
		public override bool AutoScroll
		{
			get
			{
				return base.AutoScroll;
			}
			set
			{
				base.AutoScroll = value;
			}
		}

		// Token: 0x17000215 RID: 533
		// (get) Token: 0x06000739 RID: 1849 RVA: 0x00006A2A File Offset: 0x00004C2A
		public GClass28 GClass28_0
		{
			get
			{
				return this.gclass28_0;
			}
		}

		// Token: 0x17000216 RID: 534
		// (get) Token: 0x0600073A RID: 1850 RVA: 0x00006A32 File Offset: 0x00004C32
		// (set) Token: 0x0600073B RID: 1851 RVA: 0x00006A3A File Offset: 0x00004C3A
		[EditorBrowsable(EditorBrowsableState.Always)]
		[Editor("System.Windows.Forms.Design.ListControlStringCollectionEditor, System.Design, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a", typeof(UITypeEditor))]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
		[Browsable(true)]
		[Localizable(true)]
		public override string Text
		{
			get
			{
				return base.Text;
			}
			set
			{
				base.Text = value;
				this.vmethod_0();
				this.vmethod_1();
				base.Invalidate();
			}
		}

		// Token: 0x0600073C RID: 1852 RVA: 0x00006A55 File Offset: 0x00004C55
		protected virtual void vmethod_0()
		{
			this.gclass28_0 = new GClass28(this.Text);
		}

		// Token: 0x0600073D RID: 1853 RVA: 0x0001B628 File Offset: 0x00019828
		public virtual void vmethod_1()
		{
			this.gclass28_0.method_31((this is GControl8) ? new Rectangle(0, 0, 10, 10) : base.ClientRectangle);
			using (Graphics graphics = base.CreateGraphics())
			{
				this.gclass28_0.vmethod_0(graphics);
			}
			base.AutoScrollMinSize = new Size((int)this.gclass28_0.SizeF_1.Width - 17, (int)this.gclass28_0.SizeF_1.Height);
		}

		// Token: 0x0600073E RID: 1854 RVA: 0x00006A68 File Offset: 0x00004C68
		protected override void OnClick(EventArgs e)
		{
			base.OnClick(e);
			base.Focus();
		}

		// Token: 0x0600073F RID: 1855 RVA: 0x00006A78 File Offset: 0x00004C78
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.vmethod_1();
		}

		// Token: 0x06000740 RID: 1856 RVA: 0x0001B6C0 File Offset: 0x000198C0
		protected override void OnPaint(PaintEventArgs e)
		{
			base.OnPaint(e);
			if (!(this is GControl8))
			{
				e.Graphics.Clear(SystemColors.Window);
			}
			this.gclass28_0.PointF_1 = base.AutoScrollPosition;
			e.Graphics.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
			this.gclass28_0.method_24(e.Graphics);
		}

		// Token: 0x06000741 RID: 1857 RVA: 0x0001B720 File Offset: 0x00019920
		protected override void OnMouseMove(MouseEventArgs e)
		{
			base.OnMouseMove(e);
			MetroForm metroForm = (MetroForm)base.FindForm();
			foreach (GClass23 key in this.gclass28_0.Dictionary_1.Keys)
			{
				RectangleF value = this.gclass28_0.Dictionary_1[key];
				if (Rectangle.Round(value).Contains(e.X, e.Y))
				{
					metroForm.method_1(GEnum9.const_1);
					return;
				}
			}
			if ((GEnum9)metroForm.Cursor.Tag == GEnum9.const_1)
			{
				metroForm.method_1(GEnum9.const_0);
			}
		}

		// Token: 0x06000742 RID: 1858 RVA: 0x0001B7DC File Offset: 0x000199DC
		protected override void OnMouseClick(MouseEventArgs e)
		{
			base.OnMouseClick(e);
			foreach (GClass23 gclass in this.gclass28_0.Dictionary_1.Keys)
			{
				RectangleF value = this.gclass28_0.Dictionary_1[gclass];
				if (Rectangle.Round(value).Contains(e.X, e.Y))
				{
					GClass34.smethod_11(gclass.method_6("href", string.Empty));
					break;
				}
			}
		}

		// Token: 0x06000743 RID: 1859 RVA: 0x0001B880 File Offset: 0x00019A80
		protected override void WndProc(ref Message m)
		{
			if (m.Msg == 32)
			{
				MetroForm metroForm = (MetroForm)base.FindForm();
				metroForm.method_1(GEnum9.const_0);
				m.Result = (IntPtr)1;
				return;
			}
			base.WndProc(ref m);
		}

		// Token: 0x040003E8 RID: 1000
		protected GClass28 gclass28_0;
	}
}
