﻿using System;

namespace ns0
{
	// Token: 0x020000AA RID: 170
	public enum GEnum29
	{
		// Token: 0x0400049B RID: 1179
		const_0,
		// Token: 0x0400049C RID: 1180
		const_1,
		// Token: 0x0400049D RID: 1181
		const_2
	}
}
