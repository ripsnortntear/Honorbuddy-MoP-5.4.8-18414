﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000047 RID: 71
	[Designer("MetroFramework.Design.Controls.MetroToggleDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	[ToolboxBitmap(typeof(CheckBox))]
	public class MetroToggle : CheckBox, GInterface2
	{
		// Token: 0x060004F6 RID: 1270 RVA: 0x000053A7 File Offset: 0x000035A7
		public MetroToggle()
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			base.Name = "MetroToggle";
		}

		// Token: 0x14000038 RID: 56
		// (add) Token: 0x060004F7 RID: 1271 RVA: 0x00012C80 File Offset: 0x00010E80
		// (remove) Token: 0x060004F8 RID: 1272 RVA: 0x00012CB8 File Offset: 0x00010EB8
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060004F9 RID: 1273 RVA: 0x000053D4 File Offset: 0x000035D4
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000039 RID: 57
		// (add) Token: 0x060004FA RID: 1274 RVA: 0x00012CF0 File Offset: 0x00010EF0
		// (remove) Token: 0x060004FB RID: 1275 RVA: 0x00012D28 File Offset: 0x00010F28
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060004FC RID: 1276 RVA: 0x000053F4 File Offset: 0x000035F4
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x1400003A RID: 58
		// (add) Token: 0x060004FD RID: 1277 RVA: 0x00012D60 File Offset: 0x00010F60
		// (remove) Token: 0x060004FE RID: 1278 RVA: 0x00012D98 File Offset: 0x00010F98
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x060004FF RID: 1279 RVA: 0x00005414 File Offset: 0x00003614
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x17000132 RID: 306
		// (get) Token: 0x06000500 RID: 1280 RVA: 0x00012DD0 File Offset: 0x00010FD0
		// (set) Token: 0x06000501 RID: 1281 RVA: 0x00005434 File Offset: 0x00003634
		[DefaultValue(GEnum10.const_0)]
		[Category("Metro Appearance")]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x17000133 RID: 307
		// (get) Token: 0x06000502 RID: 1282 RVA: 0x00012E28 File Offset: 0x00011028
		// (set) Token: 0x06000503 RID: 1283 RVA: 0x0000543D File Offset: 0x0000363D
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x17000134 RID: 308
		// (get) Token: 0x06000504 RID: 1284 RVA: 0x00005446 File Offset: 0x00003646
		// (set) Token: 0x06000505 RID: 1285 RVA: 0x0000544E File Offset: 0x0000364E
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x17000135 RID: 309
		// (get) Token: 0x06000506 RID: 1286 RVA: 0x00005457 File Offset: 0x00003657
		// (set) Token: 0x06000507 RID: 1287 RVA: 0x0000545F File Offset: 0x0000365F
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x17000136 RID: 310
		// (get) Token: 0x06000508 RID: 1288 RVA: 0x00005468 File Offset: 0x00003668
		// (set) Token: 0x06000509 RID: 1289 RVA: 0x00005470 File Offset: 0x00003670
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x17000137 RID: 311
		// (get) Token: 0x0600050A RID: 1290 RVA: 0x00005479 File Offset: 0x00003679
		// (set) Token: 0x0600050B RID: 1291 RVA: 0x00005481 File Offset: 0x00003681
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x17000138 RID: 312
		// (get) Token: 0x0600050C RID: 1292 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x0600050D RID: 1293 RVA: 0x00002923 File Offset: 0x00000B23
		[Browsable(false)]
		[Category("Metro Behaviour")]
		[DefaultValue(false)]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x17000139 RID: 313
		// (get) Token: 0x0600050E RID: 1294 RVA: 0x0000548A File Offset: 0x0000368A
		// (set) Token: 0x0600050F RID: 1295 RVA: 0x00005492 File Offset: 0x00003692
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x1700013A RID: 314
		// (get) Token: 0x06000510 RID: 1296 RVA: 0x0000549B File Offset: 0x0000369B
		// (set) Token: 0x06000511 RID: 1297 RVA: 0x000054A3 File Offset: 0x000036A3
		[DefaultValue(GEnum15.const_0)]
		[Category("Metro Appearance")]
		public GEnum15 GEnum15_0
		{
			get
			{
				return this.genum15_0;
			}
			set
			{
				this.genum15_0 = value;
			}
		}

		// Token: 0x1700013B RID: 315
		// (get) Token: 0x06000512 RID: 1298 RVA: 0x000054AC File Offset: 0x000036AC
		// (set) Token: 0x06000513 RID: 1299 RVA: 0x000054B4 File Offset: 0x000036B4
		[DefaultValue(GEnum16.const_1)]
		[Category("Metro Appearance")]
		public GEnum16 GEnum16_0
		{
			get
			{
				return this.genum16_0;
			}
			set
			{
				this.genum16_0 = value;
			}
		}

		// Token: 0x1700013C RID: 316
		// (get) Token: 0x06000514 RID: 1300 RVA: 0x000054BD File Offset: 0x000036BD
		// (set) Token: 0x06000515 RID: 1301 RVA: 0x000054C5 File Offset: 0x000036C5
		[DefaultValue(true)]
		[Category("Metro Appearance")]
		public bool Boolean_1
		{
			get
			{
				return this.bool_4;
			}
			set
			{
				this.bool_4 = value;
			}
		}

		// Token: 0x1700013D RID: 317
		// (get) Token: 0x06000516 RID: 1302 RVA: 0x000033C1 File Offset: 0x000015C1
		// (set) Token: 0x06000517 RID: 1303 RVA: 0x000033C9 File Offset: 0x000015C9
		[Browsable(false)]
		public override Font Font
		{
			get
			{
				return base.Font;
			}
			set
			{
				base.Font = value;
			}
		}

		// Token: 0x1700013E RID: 318
		// (get) Token: 0x06000518 RID: 1304 RVA: 0x000054CE File Offset: 0x000036CE
		// (set) Token: 0x06000519 RID: 1305 RVA: 0x000054D6 File Offset: 0x000036D6
		[Browsable(false)]
		public override Color ForeColor
		{
			get
			{
				return base.ForeColor;
			}
			set
			{
				base.ForeColor = value;
			}
		}

		// Token: 0x1700013F RID: 319
		// (get) Token: 0x0600051A RID: 1306 RVA: 0x000054DF File Offset: 0x000036DF
		[Browsable(false)]
		public override string Text
		{
			get
			{
				if (base.Checked)
				{
					return "On";
				}
				return "Off";
			}
		}

		// Token: 0x0600051B RID: 1307 RVA: 0x00012E80 File Offset: 0x00011080
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
				}
				if (color.A == 255)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600051C RID: 1308 RVA: 0x00012F00 File Offset: 0x00011100
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600051D RID: 1309 RVA: 0x00012F60 File Offset: 0x00011160
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color foreColor;
			Color color;
			if (this.bool_5 && !this.bool_6 && base.Enabled)
			{
				foreColor = GClass39.GClass56.GClass61.smethod_1(this.GEnum29_0);
				color = GClass39.GClass40.GClass42.smethod_1(this.GEnum29_0);
			}
			else if (this.bool_5 && this.bool_6 && base.Enabled)
			{
				foreColor = GClass39.GClass56.GClass61.smethod_2(this.GEnum29_0);
				color = GClass39.GClass40.GClass42.smethod_2(this.GEnum29_0);
			}
			else if (!base.Enabled)
			{
				foreColor = GClass39.GClass56.GClass61.smethod_3(this.GEnum29_0);
				color = GClass39.GClass40.GClass42.smethod_3(this.GEnum29_0);
			}
			else
			{
				foreColor = ((!this.bool_2) ? GClass39.GClass56.GClass61.smethod_0(this.GEnum29_0) : GClass39.smethod_0(this.GEnum10_0));
				color = GClass39.GClass40.GClass42.smethod_0(this.GEnum29_0);
			}
			using (Pen pen = new Pen(color))
			{
				Rectangle rect = new Rectangle(this.Boolean_1 ? 30 : 0, 0, base.ClientRectangle.Width - (this.Boolean_1 ? 31 : 1), base.ClientRectangle.Height - 1);
				paintEventArgs_0.Graphics.DrawRectangle(pen, rect);
			}
			Color color2 = base.Checked ? GClass39.smethod_0(this.GEnum10_0) : GClass39.GClass40.GClass42.smethod_0(this.GEnum29_0);
			using (SolidBrush solidBrush = new SolidBrush(color2))
			{
				Rectangle rect2 = new Rectangle(this.Boolean_1 ? 32 : 2, 2, base.ClientRectangle.Width - (this.Boolean_1 ? 34 : 4), base.ClientRectangle.Height - 4);
				paintEventArgs_0.Graphics.FillRectangle(solidBrush, rect2);
			}
			Color color3 = this.BackColor;
			if (!this.bool_0)
			{
				color3 = GClass39.GClass46.smethod_0(this.GEnum29_0);
			}
			using (SolidBrush solidBrush2 = new SolidBrush(color3))
			{
				int x = base.Checked ? (base.Width - 11) : (this.Boolean_1 ? 30 : 0);
				Rectangle rect3 = new Rectangle(x, 0, 11, base.ClientRectangle.Height);
				paintEventArgs_0.Graphics.FillRectangle(solidBrush2, rect3);
			}
			using (SolidBrush solidBrush3 = new SolidBrush(GClass39.GClass40.GClass42.smethod_1(this.GEnum29_0)))
			{
				int x2 = base.Checked ? (base.Width - 10) : (this.Boolean_1 ? 30 : 0);
				Rectangle rect4 = new Rectangle(x2, 0, 10, base.ClientRectangle.Height);
				paintEventArgs_0.Graphics.FillRectangle(solidBrush3, rect4);
			}
			if (this.Boolean_1)
			{
				Rectangle bounds = new Rectangle(0, 0, 30, base.ClientRectangle.Height);
				TextRenderer.DrawText(paintEventArgs_0.Graphics, this.Text, GClass67.smethod_5(this.genum15_0, this.genum16_0), bounds, foreColor, GClass39.smethod_4(this.TextAlign));
			}
			if (this.bool_3 && this.bool_7)
			{
				ControlPaint.DrawFocusRectangle(paintEventArgs_0.Graphics, base.ClientRectangle);
			}
		}

		// Token: 0x0600051E RID: 1310 RVA: 0x000054F4 File Offset: 0x000036F4
		protected override void OnGotFocus(EventArgs e)
		{
			this.bool_7 = true;
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x0600051F RID: 1311 RVA: 0x0000550A File Offset: 0x0000370A
		protected override void OnLostFocus(EventArgs e)
		{
			this.bool_7 = false;
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		// Token: 0x06000520 RID: 1312 RVA: 0x0000552E File Offset: 0x0000372E
		protected override void OnEnter(EventArgs e)
		{
			this.bool_7 = true;
			base.Invalidate();
			base.OnEnter(e);
		}

		// Token: 0x06000521 RID: 1313 RVA: 0x00005544 File Offset: 0x00003744
		protected override void OnLeave(EventArgs e)
		{
			this.bool_7 = false;
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnLeave(e);
		}

		// Token: 0x06000522 RID: 1314 RVA: 0x00005568 File Offset: 0x00003768
		protected override void OnKeyDown(KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Space)
			{
				this.bool_5 = true;
				this.bool_6 = true;
				base.Invalidate();
			}
			base.OnKeyDown(e);
		}

		// Token: 0x06000523 RID: 1315 RVA: 0x0000558F File Offset: 0x0000378F
		protected override void OnKeyUp(KeyEventArgs e)
		{
			this.bool_5 = false;
			this.bool_6 = false;
			base.Invalidate();
			base.OnKeyUp(e);
		}

		// Token: 0x06000524 RID: 1316 RVA: 0x000055AC File Offset: 0x000037AC
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_5 = true;
			base.Invalidate();
			base.OnMouseEnter(e);
		}

		// Token: 0x06000525 RID: 1317 RVA: 0x000055C2 File Offset: 0x000037C2
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.bool_6 = true;
				base.Invalidate();
			}
			base.OnMouseDown(e);
		}

		// Token: 0x06000526 RID: 1318 RVA: 0x000055E5 File Offset: 0x000037E5
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this.bool_6 = false;
			base.Invalidate();
			base.OnMouseUp(e);
		}

		// Token: 0x06000527 RID: 1319 RVA: 0x000055FB File Offset: 0x000037FB
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_5 = false;
			base.Invalidate();
			base.OnMouseLeave(e);
		}

		// Token: 0x06000528 RID: 1320 RVA: 0x0000311B File Offset: 0x0000131B
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x06000529 RID: 1321 RVA: 0x000034EF File Offset: 0x000016EF
		protected override void OnCheckedChanged(EventArgs e)
		{
			base.OnCheckedChanged(e);
			base.Invalidate();
		}

		// Token: 0x0600052A RID: 1322 RVA: 0x000132A4 File Offset: 0x000114A4
		public override Size GetPreferredSize(Size proposedSize)
		{
			Size preferredSize = base.GetPreferredSize(proposedSize);
			preferredSize.Width = (this.Boolean_1 ? 80 : 50);
			return preferredSize;
		}

		// Token: 0x040001C3 RID: 451
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x040001C4 RID: 452
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x040001C5 RID: 453
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x040001C6 RID: 454
		private GEnum10 genum10_0;

		// Token: 0x040001C7 RID: 455
		private GEnum29 genum29_0;

		// Token: 0x040001C8 RID: 456
		private GClass8 gclass8_0;

		// Token: 0x040001C9 RID: 457
		private bool bool_0;

		// Token: 0x040001CA RID: 458
		private bool bool_1;

		// Token: 0x040001CB RID: 459
		private bool bool_2;

		// Token: 0x040001CC RID: 460
		private bool bool_3;

		// Token: 0x040001CD RID: 461
		private GEnum15 genum15_0;

		// Token: 0x040001CE RID: 462
		private GEnum16 genum16_0 = GEnum16.const_1;

		// Token: 0x040001CF RID: 463
		private bool bool_4 = true;

		// Token: 0x040001D0 RID: 464
		private bool bool_5;

		// Token: 0x040001D1 RID: 465
		private bool bool_6;

		// Token: 0x040001D2 RID: 466
		private bool bool_7;
	}
}
