﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200002C RID: 44
	[ToolboxItemFilter("System.Windows.Forms")]
	[ProvideProperty("ToolTip", typeof(Control))]
	public class GClass9 : Component, IExtenderProvider
	{
		// Token: 0x0600018E RID: 398 RVA: 0x00002D1A File Offset: 0x00000F1A
		public GClass9()
		{
			this.hashtable_0 = new Hashtable();
			this.bool_0 = false;
			this.ginterface4_0 = new GClass10();
			this.ginterface3_0 = new BasicToolTipView();
			this.string_0 = string.Empty;
		}

		// Token: 0x0600018F RID: 399 RVA: 0x0000B5D4 File Offset: 0x000097D4
		public void method_0(Control control_1, string string_1)
		{
			if (string_1.Equals(string.Empty))
			{
				if (this.hashtable_0.ContainsKey(control_1))
				{
					control_1.MouseEnter -= this.method_7;
					control_1.MouseLeave -= this.method_6;
					control_1.MouseDown -= this.method_2;
					control_1.MouseMove -= this.method_5;
					control_1.LostFocus -= this.method_4;
					control_1.Click -= this.method_3;
					this.hashtable_0.Remove(control_1);
				}
				return;
			}
			if (this.hashtable_0.ContainsKey(control_1))
			{
				this.hashtable_0[control_1] = string_1;
				return;
			}
			this.hashtable_0.Add(control_1, string_1);
			control_1.MouseEnter += this.method_7;
			control_1.MouseLeave += this.method_6;
			control_1.MouseDown += this.method_2;
			control_1.MouseMove += this.method_5;
			control_1.LostFocus += this.method_4;
			control_1.Click += this.method_3;
		}

		// Token: 0x06000190 RID: 400 RVA: 0x00002D55 File Offset: 0x00000F55
		public string method_1(Control control_1)
		{
			if (this.hashtable_0.ContainsKey(control_1))
			{
				return this.hashtable_0[control_1].ToString();
			}
			return string.Empty;
		}

		// Token: 0x06000191 RID: 401 RVA: 0x00002D7C File Offset: 0x00000F7C
		private void method_2(object sender, MouseEventArgs e)
		{
			this.ginterface3_0.imethod_1();
		}

		// Token: 0x06000192 RID: 402 RVA: 0x00002D7C File Offset: 0x00000F7C
		private void method_3(object sender, EventArgs e)
		{
			this.ginterface3_0.imethod_1();
		}

		// Token: 0x06000193 RID: 403 RVA: 0x00002D7C File Offset: 0x00000F7C
		private void method_4(object sender, EventArgs e)
		{
			this.ginterface3_0.imethod_1();
		}

		// Token: 0x06000194 RID: 404 RVA: 0x0000B710 File Offset: 0x00009910
		private void method_5(object sender, MouseEventArgs e)
		{
			(this.ginterface3_0 as Form).Location = new Point(Cursor.Position.X + 10, Cursor.Position.Y + 20);
		}

		// Token: 0x06000195 RID: 405 RVA: 0x0000B754 File Offset: 0x00009954
		private void method_6(object sender, EventArgs e)
		{
			Control control = sender as Control;
			if (!(control is GControl3) || !control.Bounds.Contains(control.PointToClient(Control.MousePosition)))
			{
				this.ginterface3_0.imethod_1();
			}
			if (this.bool_1)
			{
				this.ginterface4_0.imethod_2(sender as Control);
				if ((sender as Control).Equals(this.control_0))
				{
					this.bool_1 = false;
				}
			}
		}

		// Token: 0x06000196 RID: 406 RVA: 0x0000B7CC File Offset: 0x000099CC
		private void method_7(object sender, EventArgs e)
		{
			if ((this.ginterface3_0 as Control).Visible)
			{
				return;
			}
			this.bool_1 = this.bool_0;
			Control control = sender as Control;
			this.control_0 = control;
			Point point_ = control.Parent.PointToScreen(control.Location);
			if (control is GInterface1)
			{
				this.ginterface3_0.GEnum10_0 = ((GInterface1)control).GEnum10_0;
				this.ginterface3_0.GEnum29_0 = ((GInterface1)control).GEnum29_0;
				this.ginterface3_0.GClass8_0 = ((GInterface1)control).GClass8_0;
			}
			else if (control is GInterface2)
			{
				this.ginterface3_0.GEnum10_0 = ((GInterface2)control).GEnum10_0;
				this.ginterface3_0.GEnum29_0 = ((GInterface2)control).GEnum29_0;
				this.ginterface3_0.GClass8_0 = ((GInterface2)control).GClass8_0;
			}
			this.ginterface3_0.imethod_0(point_, control.Size);
			if (this.bool_0)
			{
				this.ginterface3_0.imethod_2(this.string_0);
				this.ginterface4_0.imethod_1(this.hashtable_0[control].ToString(), control);
				return;
			}
			try
			{
				this.ginterface3_0.imethod_3(this.ginterface4_0.imethod_0(this.hashtable_0[control].ToString()));
			}
			catch (Exception exception_)
			{
				this.ginterface3_0.imethod_4(exception_);
			}
		}

		// Token: 0x06000197 RID: 407 RVA: 0x0000B940 File Offset: 0x00009B40
		private void method_8(object sender, GEventArgs2 e)
		{
			if (!e.Control_0.Equals(this.control_0))
			{
				return;
			}
			this.bool_1 = false;
			if (e.Boolean_0)
			{
				this.ginterface3_0.imethod_3(e.Object_0);
				return;
			}
			this.ginterface3_0.imethod_4(e.Exception_0);
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000198 RID: 408 RVA: 0x00002D89 File Offset: 0x00000F89
		// (set) Token: 0x06000199 RID: 409 RVA: 0x00002D91 File Offset: 0x00000F91
		[Description("Determines if the data provider is used asynchronously.")]
		[DefaultValue(true)]
		public bool Boolean_0
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x0600019A RID: 410 RVA: 0x00002D9A File Offset: 0x00000F9A
		// (set) Token: 0x0600019B RID: 411 RVA: 0x00002DAB File Offset: 0x00000FAB
		[Description("The data provider that is used for requesting tooltips.")]
		public GInterface4 GInterface4_0
		{
			get
			{
				return this.ginterface4_0 ?? new GClass10();
			}
			set
			{
				this.ginterface4_0 = value;
				this.ginterface4_0.Event_0 += this.method_8;
			}
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x0600019C RID: 412 RVA: 0x00002DCB File Offset: 0x00000FCB
		// (set) Token: 0x0600019D RID: 413 RVA: 0x00002DD3 File Offset: 0x00000FD3
		[Description("The view provider that is used for displaying tooltips.")]
		public GInterface3 GInterface3_0
		{
			get
			{
				return this.ginterface3_0;
			}
			set
			{
				this.ginterface3_0 = value;
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x0600019E RID: 414 RVA: 0x00002DDC File Offset: 0x00000FDC
		// (set) Token: 0x0600019F RID: 415 RVA: 0x00002DE4 File Offset: 0x00000FE4
		[Description("This text will be shown on asynchronous requests.")]
		public string String_0
		{
			get
			{
				return this.string_0;
			}
			set
			{
				this.string_0 = value;
			}
		}

		// Token: 0x060001A0 RID: 416 RVA: 0x00002DED File Offset: 0x00000FED
		public bool CanExtend(object extendee)
		{
			return extendee is Control && !(extendee is Form) && !(extendee is GClass9);
		}

		// Token: 0x040000A8 RID: 168
		private GInterface4 ginterface4_0;

		// Token: 0x040000A9 RID: 169
		private GInterface3 ginterface3_0;

		// Token: 0x040000AA RID: 170
		private bool bool_0;

		// Token: 0x040000AB RID: 171
		private bool bool_1;

		// Token: 0x040000AC RID: 172
		private string string_0;

		// Token: 0x040000AD RID: 173
		private Hashtable hashtable_0;

		// Token: 0x040000AE RID: 174
		private Control control_0;
	}
}
