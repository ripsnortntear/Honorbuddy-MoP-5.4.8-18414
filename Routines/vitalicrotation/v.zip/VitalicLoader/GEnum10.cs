﻿using System;

namespace ns0
{
	// Token: 0x02000090 RID: 144
	public enum GEnum10
	{
		// Token: 0x0400043E RID: 1086
		const_0,
		// Token: 0x0400043F RID: 1087
		const_1,
		// Token: 0x04000440 RID: 1088
		const_2,
		// Token: 0x04000441 RID: 1089
		const_3,
		// Token: 0x04000442 RID: 1090
		const_4,
		// Token: 0x04000443 RID: 1091
		const_5,
		// Token: 0x04000444 RID: 1092
		const_6,
		// Token: 0x04000445 RID: 1093
		const_7,
		// Token: 0x04000446 RID: 1094
		const_8,
		// Token: 0x04000447 RID: 1095
		const_9,
		// Token: 0x04000448 RID: 1096
		const_10,
		// Token: 0x04000449 RID: 1097
		const_11,
		// Token: 0x0400044A RID: 1098
		const_12,
		// Token: 0x0400044B RID: 1099
		const_13
	}
}
