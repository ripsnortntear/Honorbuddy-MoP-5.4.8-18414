﻿using System;
using System.Drawing;

namespace ns0
{
	// Token: 0x02000051 RID: 81
	public class GClass30
	{
		// Token: 0x170001E3 RID: 483
		// (get) Token: 0x060006A2 RID: 1698 RVA: 0x000064C3 File Offset: 0x000046C3
		// (set) Token: 0x060006A3 RID: 1699 RVA: 0x000064CB File Offset: 0x000046CB
		public float Single_0
		{
			get
			{
				return this.float_0;
			}
			set
			{
				this.float_0 = value;
			}
		}

		// Token: 0x170001E4 RID: 484
		// (get) Token: 0x060006A4 RID: 1700 RVA: 0x000064D4 File Offset: 0x000046D4
		// (set) Token: 0x060006A5 RID: 1701 RVA: 0x000064DC File Offset: 0x000046DC
		public float Single_1
		{
			get
			{
				return this.float_1;
			}
			set
			{
				this.float_1 = value;
			}
		}

		// Token: 0x170001E5 RID: 485
		// (get) Token: 0x060006A6 RID: 1702 RVA: 0x000064E5 File Offset: 0x000046E5
		// (set) Token: 0x060006A7 RID: 1703 RVA: 0x000064ED File Offset: 0x000046ED
		public float Single_2
		{
			get
			{
				return this.float_2;
			}
			set
			{
				this.float_2 = value;
			}
		}

		// Token: 0x170001E6 RID: 486
		// (get) Token: 0x060006A8 RID: 1704 RVA: 0x000064F6 File Offset: 0x000046F6
		// (set) Token: 0x060006A9 RID: 1705 RVA: 0x000064FE File Offset: 0x000046FE
		public float Single_3
		{
			get
			{
				return this.float_3;
			}
			set
			{
				this.float_3 = value;
			}
		}

		// Token: 0x170001E7 RID: 487
		// (get) Token: 0x060006AA RID: 1706 RVA: 0x000174D4 File Offset: 0x000156D4
		// (set) Token: 0x060006AB RID: 1707 RVA: 0x00006507 File Offset: 0x00004707
		public float Single_4
		{
			get
			{
				return this.RectangleF_0.Right;
			}
			set
			{
				this.Single_2 = value - this.Single_0;
			}
		}

		// Token: 0x170001E8 RID: 488
		// (get) Token: 0x060006AC RID: 1708 RVA: 0x000174F0 File Offset: 0x000156F0
		// (set) Token: 0x060006AD RID: 1709 RVA: 0x00006517 File Offset: 0x00004717
		public float Single_5
		{
			get
			{
				return this.RectangleF_0.Bottom;
			}
			set
			{
				this.Single_3 = value - this.Single_1;
			}
		}

		// Token: 0x170001E9 RID: 489
		// (get) Token: 0x060006AE RID: 1710 RVA: 0x00006527 File Offset: 0x00004727
		// (set) Token: 0x060006AF RID: 1711 RVA: 0x00006546 File Offset: 0x00004746
		public RectangleF RectangleF_0
		{
			get
			{
				return new RectangleF(this.Single_0, this.Single_1, this.Single_2, this.Single_3);
			}
			set
			{
				this.Single_0 = value.Left;
				this.Single_1 = value.Top;
				this.Single_2 = value.Width;
				this.Single_3 = value.Height;
			}
		}

		// Token: 0x170001EA RID: 490
		// (get) Token: 0x060006B0 RID: 1712 RVA: 0x0000657C File Offset: 0x0000477C
		// (set) Token: 0x060006B1 RID: 1713 RVA: 0x0000658F File Offset: 0x0000478F
		public PointF PointF_0
		{
			get
			{
				return new PointF(this.Single_0, this.Single_1);
			}
			set
			{
				this.Single_0 = value.X;
				this.Single_1 = value.Y;
			}
		}

		// Token: 0x170001EB RID: 491
		// (get) Token: 0x060006B2 RID: 1714 RVA: 0x000065AB File Offset: 0x000047AB
		// (set) Token: 0x060006B3 RID: 1715 RVA: 0x000065BE File Offset: 0x000047BE
		public SizeF SizeF_0
		{
			get
			{
				return new SizeF(this.Single_2, this.Single_3);
			}
			set
			{
				this.Single_2 = value.Width;
				this.Single_3 = value.Height;
			}
		}

		// Token: 0x04000273 RID: 627
		private float float_0;

		// Token: 0x04000274 RID: 628
		private float float_1;

		// Token: 0x04000275 RID: 629
		private float float_2;

		// Token: 0x04000276 RID: 630
		private float float_3;
	}
}
