﻿using System;

namespace ns0
{
	// Token: 0x02000037 RID: 55
	public enum GEnum2
	{
		// Token: 0x040000EE RID: 238
		const_0,
		// Token: 0x040000EF RID: 239
		const_1
	}
}
