﻿using System;
using System.Drawing;

namespace ns0
{
	// Token: 0x020000A8 RID: 168
	internal class Class25
	{
		// Token: 0x06000832 RID: 2098 RVA: 0x0001DB8C File Offset: 0x0001BD8C
		public static Image smethod_0(Image image_0, Rectangle rectangle_0)
		{
			int width = image_0.Width;
			int height = image_0.Height;
			float num = (float)rectangle_0.Width / (float)width;
			float num2 = (float)rectangle_0.Height / (float)height;
			float num3 = (num2 < num) ? num2 : num;
			int thumbWidth = (int)((float)width * num3);
			int thumbHeight = (int)((float)height * num3);
			return image_0.GetThumbnailImage(thumbWidth, thumbHeight, null, IntPtr.Zero);
		}
	}
}
