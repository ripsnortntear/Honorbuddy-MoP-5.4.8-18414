﻿using System;

namespace ns0
{
	// Token: 0x020000A4 RID: 164
	public enum GEnum28
	{
		// Token: 0x04000495 RID: 1173
		const_0,
		// Token: 0x04000496 RID: 1174
		const_1,
		// Token: 0x04000497 RID: 1175
		const_2
	}
}
