﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200006B RID: 107
	public sealed class GClass39
	{
		// Token: 0x06000780 RID: 1920 RVA: 0x0001CCF4 File Offset: 0x0001AEF4
		public static Color smethod_0(GEnum10 genum10_0)
		{
			switch (genum10_0)
			{
			case GEnum10.const_1:
				return GClass66.Color_0;
			case GEnum10.const_2:
				return GClass66.Color_2;
			case GEnum10.const_3:
				return GClass66.Color_3;
			case GEnum10.const_4:
				return GClass66.Color_4;
			case GEnum10.const_5:
				return GClass66.Color_5;
			case GEnum10.const_6:
				return GClass66.Color_6;
			case GEnum10.const_7:
				return GClass66.Color_7;
			case GEnum10.const_8:
				return GClass66.Color_8;
			case GEnum10.const_9:
				return GClass66.Color_9;
			case GEnum10.const_10:
				return GClass66.Color_10;
			case GEnum10.const_11:
				return GClass66.Color_11;
			case GEnum10.const_12:
				return GClass66.Color_12;
			case GEnum10.const_13:
				return GClass66.Color_13;
			default:
				return GClass66.Color_3;
			}
		}

		// Token: 0x06000781 RID: 1921 RVA: 0x0001CD94 File Offset: 0x0001AF94
		public static SolidBrush smethod_1(GEnum10 genum10_0)
		{
			switch (genum10_0)
			{
			case GEnum10.const_1:
				return GClass65.SolidBrush_0;
			case GEnum10.const_2:
				return GClass65.SolidBrush_2;
			case GEnum10.const_3:
				return GClass65.SolidBrush_3;
			case GEnum10.const_4:
				return GClass65.SolidBrush_4;
			case GEnum10.const_5:
				return GClass65.SolidBrush_5;
			case GEnum10.const_6:
				return GClass65.SolidBrush_6;
			case GEnum10.const_7:
				return GClass65.SolidBrush_7;
			case GEnum10.const_8:
				return GClass65.SolidBrush_8;
			case GEnum10.const_9:
				return GClass65.SolidBrush_9;
			case GEnum10.const_10:
				return GClass65.SolidBrush_10;
			case GEnum10.const_11:
				return GClass65.SolidBrush_11;
			case GEnum10.const_12:
				return GClass65.SolidBrush_12;
			case GEnum10.const_13:
				return GClass65.SolidBrush_13;
			default:
				return GClass65.SolidBrush_3;
			}
		}

		// Token: 0x06000782 RID: 1922 RVA: 0x0001CE34 File Offset: 0x0001B034
		public static Pen smethod_2(GEnum10 genum10_0)
		{
			switch (genum10_0)
			{
			case GEnum10.const_1:
				return GClass68.Pen_0;
			case GEnum10.const_2:
				return GClass68.Pen_2;
			case GEnum10.const_3:
				return GClass68.Pen_3;
			case GEnum10.const_4:
				return GClass68.Pen_4;
			case GEnum10.const_5:
				return GClass68.Pen_5;
			case GEnum10.const_6:
				return GClass68.Pen_6;
			case GEnum10.const_7:
				return GClass68.Pen_7;
			case GEnum10.const_8:
				return GClass68.Pen_8;
			case GEnum10.const_9:
				return GClass68.Pen_9;
			case GEnum10.const_10:
				return GClass68.Pen_10;
			case GEnum10.const_11:
				return GClass68.Pen_11;
			case GEnum10.const_12:
				return GClass68.Pen_12;
			case GEnum10.const_13:
				return GClass68.Pen_13;
			default:
				return GClass68.Pen_3;
			}
		}

		// Token: 0x06000783 RID: 1923 RVA: 0x0001CED4 File Offset: 0x0001B0D4
		public static StringFormat smethod_3(ContentAlignment contentAlignment_0)
		{
			StringFormat stringFormat = new StringFormat();
			stringFormat.Trimming = StringTrimming.EllipsisCharacter;
			if (contentAlignment_0 <= ContentAlignment.MiddleCenter)
			{
				switch (contentAlignment_0)
				{
				case ContentAlignment.TopLeft:
					stringFormat.Alignment = StringAlignment.Near;
					stringFormat.LineAlignment = StringAlignment.Near;
					break;
				case ContentAlignment.TopCenter:
					stringFormat.Alignment = StringAlignment.Center;
					stringFormat.LineAlignment = StringAlignment.Near;
					break;
				case (ContentAlignment)3:
					break;
				case ContentAlignment.TopRight:
					stringFormat.Alignment = StringAlignment.Far;
					stringFormat.LineAlignment = StringAlignment.Near;
					break;
				default:
					if (contentAlignment_0 != ContentAlignment.MiddleLeft)
					{
						if (contentAlignment_0 == ContentAlignment.MiddleCenter)
						{
							stringFormat.Alignment = StringAlignment.Center;
							stringFormat.LineAlignment = StringAlignment.Center;
						}
					}
					else
					{
						stringFormat.Alignment = StringAlignment.Center;
						stringFormat.LineAlignment = StringAlignment.Near;
					}
					break;
				}
			}
			else if (contentAlignment_0 <= ContentAlignment.BottomLeft)
			{
				if (contentAlignment_0 != ContentAlignment.MiddleRight)
				{
					if (contentAlignment_0 == ContentAlignment.BottomLeft)
					{
						stringFormat.Alignment = StringAlignment.Far;
						stringFormat.LineAlignment = StringAlignment.Near;
					}
				}
				else
				{
					stringFormat.Alignment = StringAlignment.Center;
					stringFormat.LineAlignment = StringAlignment.Far;
				}
			}
			else if (contentAlignment_0 != ContentAlignment.BottomCenter)
			{
				if (contentAlignment_0 == ContentAlignment.BottomRight)
				{
					stringFormat.Alignment = StringAlignment.Far;
					stringFormat.LineAlignment = StringAlignment.Far;
				}
			}
			else
			{
				stringFormat.Alignment = StringAlignment.Far;
				stringFormat.LineAlignment = StringAlignment.Center;
			}
			return stringFormat;
		}

		// Token: 0x06000784 RID: 1924 RVA: 0x00006D16 File Offset: 0x00004F16
		public static TextFormatFlags smethod_4(ContentAlignment contentAlignment_0)
		{
			return GClass39.smethod_5(contentAlignment_0, false);
		}

		// Token: 0x06000785 RID: 1925 RVA: 0x0001CFE0 File Offset: 0x0001B1E0
		public static TextFormatFlags smethod_5(ContentAlignment contentAlignment_0, bool bool_0)
		{
			TextFormatFlags textFormatFlags = TextFormatFlags.Default;
			switch (bool_0)
			{
			case false:
				textFormatFlags = TextFormatFlags.EndEllipsis;
				break;
			case true:
				textFormatFlags = TextFormatFlags.WordBreak;
				break;
			}
			if (contentAlignment_0 <= ContentAlignment.MiddleCenter)
			{
				switch (contentAlignment_0)
				{
				case ContentAlignment.TopLeft:
					textFormatFlags = textFormatFlags;
					break;
				case ContentAlignment.TopCenter:
					textFormatFlags |= TextFormatFlags.HorizontalCenter;
					break;
				case (ContentAlignment)3:
					break;
				case ContentAlignment.TopRight:
					textFormatFlags |= TextFormatFlags.Right;
					break;
				default:
					if (contentAlignment_0 != ContentAlignment.MiddleLeft)
					{
						if (contentAlignment_0 == ContentAlignment.MiddleCenter)
						{
							textFormatFlags |= (TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
						}
					}
					else
					{
						textFormatFlags |= TextFormatFlags.VerticalCenter;
					}
					break;
				}
			}
			else if (contentAlignment_0 <= ContentAlignment.BottomLeft)
			{
				if (contentAlignment_0 != ContentAlignment.MiddleRight)
				{
					if (contentAlignment_0 == ContentAlignment.BottomLeft)
					{
						textFormatFlags |= TextFormatFlags.Bottom;
					}
				}
				else
				{
					textFormatFlags |= (TextFormatFlags.Right | TextFormatFlags.VerticalCenter);
				}
			}
			else if (contentAlignment_0 != ContentAlignment.BottomCenter)
			{
				if (contentAlignment_0 == ContentAlignment.BottomRight)
				{
					textFormatFlags |= (TextFormatFlags.Bottom | TextFormatFlags.Right);
				}
			}
			else
			{
				textFormatFlags |= (TextFormatFlags.Bottom | TextFormatFlags.HorizontalCenter);
			}
			return textFormatFlags;
		}

		// Token: 0x0200006C RID: 108
		public sealed class GClass40
		{
			// Token: 0x06000787 RID: 1927 RVA: 0x00006D1F File Offset: 0x00004F1F
			public static Color smethod_0(GEnum29 genum29_0)
			{
				if (genum29_0 == GEnum29.const_2)
				{
					return Color.FromArgb(68, 68, 68);
				}
				return Color.FromArgb(204, 204, 204);
			}

			// Token: 0x0200006D RID: 109
			public static class GClass41
			{
				// Token: 0x06000788 RID: 1928 RVA: 0x00006D1F File Offset: 0x00004F1F
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(68, 68, 68);
					}
					return Color.FromArgb(204, 204, 204);
				}

				// Token: 0x06000789 RID: 1929 RVA: 0x00006D45 File Offset: 0x00004F45
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(170, 170, 170);
					}
					return Color.FromArgb(102, 102, 102);
				}

				// Token: 0x0600078A RID: 1930 RVA: 0x00006D6B File Offset: 0x00004F6B
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(238, 238, 238);
					}
					return Color.FromArgb(51, 51, 51);
				}

				// Token: 0x0600078B RID: 1931 RVA: 0x00006D91 File Offset: 0x00004F91
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(109, 109, 109);
					}
					return Color.FromArgb(155, 155, 155);
				}
			}

			// Token: 0x0200006E RID: 110
			public static class GClass42
			{
				// Token: 0x0600078C RID: 1932 RVA: 0x00006DB7 File Offset: 0x00004FB7
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(153, 153, 153);
					}
					return Color.FromArgb(153, 153, 153);
				}

				// Token: 0x0600078D RID: 1933 RVA: 0x00006DE6 File Offset: 0x00004FE6
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(204, 204, 204);
					}
					return Color.FromArgb(51, 51, 51);
				}

				// Token: 0x0600078E RID: 1934 RVA: 0x00006DB7 File Offset: 0x00004FB7
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(153, 153, 153);
					}
					return Color.FromArgb(153, 153, 153);
				}

				// Token: 0x0600078F RID: 1935 RVA: 0x00006E0C File Offset: 0x0000500C
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(85, 85, 85);
					}
					return Color.FromArgb(204, 204, 204);
				}
			}

			// Token: 0x0200006F RID: 111
			public static class GClass43
			{
				// Token: 0x06000790 RID: 1936 RVA: 0x00006DB7 File Offset: 0x00004FB7
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(153, 153, 153);
					}
					return Color.FromArgb(153, 153, 153);
				}

				// Token: 0x06000791 RID: 1937 RVA: 0x00006DE6 File Offset: 0x00004FE6
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(204, 204, 204);
					}
					return Color.FromArgb(51, 51, 51);
				}

				// Token: 0x06000792 RID: 1938 RVA: 0x00006DB7 File Offset: 0x00004FB7
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(153, 153, 153);
					}
					return Color.FromArgb(153, 153, 153);
				}

				// Token: 0x06000793 RID: 1939 RVA: 0x00006E0C File Offset: 0x0000500C
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(85, 85, 85);
					}
					return Color.FromArgb(204, 204, 204);
				}
			}

			// Token: 0x02000070 RID: 112
			public static class GClass44
			{
				// Token: 0x06000794 RID: 1940 RVA: 0x00006D1F File Offset: 0x00004F1F
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(68, 68, 68);
					}
					return Color.FromArgb(204, 204, 204);
				}

				// Token: 0x06000795 RID: 1941 RVA: 0x00006D1F File Offset: 0x00004F1F
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(68, 68, 68);
					}
					return Color.FromArgb(204, 204, 204);
				}

				// Token: 0x06000796 RID: 1942 RVA: 0x00006D1F File Offset: 0x00004F1F
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(68, 68, 68);
					}
					return Color.FromArgb(204, 204, 204);
				}

				// Token: 0x06000797 RID: 1943 RVA: 0x00006D91 File Offset: 0x00004F91
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(109, 109, 109);
					}
					return Color.FromArgb(155, 155, 155);
				}
			}

			// Token: 0x02000071 RID: 113
			public static class GClass45
			{
				// Token: 0x06000798 RID: 1944 RVA: 0x00006D1F File Offset: 0x00004F1F
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(68, 68, 68);
					}
					return Color.FromArgb(204, 204, 204);
				}

				// Token: 0x06000799 RID: 1945 RVA: 0x00006D1F File Offset: 0x00004F1F
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(68, 68, 68);
					}
					return Color.FromArgb(204, 204, 204);
				}

				// Token: 0x0600079A RID: 1946 RVA: 0x00006D1F File Offset: 0x00004F1F
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(68, 68, 68);
					}
					return Color.FromArgb(204, 204, 204);
				}

				// Token: 0x0600079B RID: 1947 RVA: 0x00006D91 File Offset: 0x00004F91
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(109, 109, 109);
					}
					return Color.FromArgb(155, 155, 155);
				}
			}
		}

		// Token: 0x02000072 RID: 114
		public sealed class GClass46
		{
			// Token: 0x0600079D RID: 1949 RVA: 0x00006E32 File Offset: 0x00005032
			public static Color smethod_0(GEnum29 genum29_0)
			{
				if (genum29_0 == GEnum29.const_2)
				{
					return Color.FromArgb(17, 17, 17);
				}
				return Color.FromArgb(255, 255, 255);
			}

			// Token: 0x02000073 RID: 115
			public sealed class GClass47
			{
				// Token: 0x0600079F RID: 1951 RVA: 0x00006E58 File Offset: 0x00005058
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(34, 34, 34);
					}
					return Color.FromArgb(238, 238, 238);
				}

				// Token: 0x060007A0 RID: 1952 RVA: 0x00006D45 File Offset: 0x00004F45
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(170, 170, 170);
					}
					return Color.FromArgb(102, 102, 102);
				}

				// Token: 0x060007A1 RID: 1953 RVA: 0x00006D6B File Offset: 0x00004F6B
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(238, 238, 238);
					}
					return Color.FromArgb(51, 51, 51);
				}

				// Token: 0x060007A2 RID: 1954 RVA: 0x00006E7E File Offset: 0x0000507E
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(80, 80, 80);
					}
					return Color.FromArgb(204, 204, 204);
				}
			}

			// Token: 0x02000074 RID: 116
			public sealed class GClass48
			{
				// Token: 0x02000075 RID: 117
				public sealed class GClass49
				{
					// Token: 0x060007A5 RID: 1957 RVA: 0x00006EA4 File Offset: 0x000050A4
					public static Color smethod_0(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(153, 153, 153);
						}
						return Color.FromArgb(102, 102, 102);
					}

					// Token: 0x060007A6 RID: 1958 RVA: 0x00006ECA File Offset: 0x000050CA
					public static Color smethod_1(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(204, 204, 204);
						}
						return Color.FromArgb(17, 17, 17);
					}

					// Token: 0x060007A7 RID: 1959 RVA: 0x00006ECA File Offset: 0x000050CA
					public static Color smethod_2(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(204, 204, 204);
						}
						return Color.FromArgb(17, 17, 17);
					}

					// Token: 0x060007A8 RID: 1960 RVA: 0x00006EF0 File Offset: 0x000050F0
					public static Color smethod_3(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(85, 85, 85);
						}
						return Color.FromArgb(179, 179, 179);
					}
				}

				// Token: 0x02000076 RID: 118
				public sealed class GClass50
				{
					// Token: 0x060007AA RID: 1962 RVA: 0x00006F16 File Offset: 0x00005116
					public static Color smethod_0(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(51, 51, 51);
						}
						return Color.FromArgb(204, 204, 204);
					}

					// Token: 0x060007AB RID: 1963 RVA: 0x00006F16 File Offset: 0x00005116
					public static Color smethod_1(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(51, 51, 51);
						}
						return Color.FromArgb(204, 204, 204);
					}

					// Token: 0x060007AC RID: 1964 RVA: 0x00006F16 File Offset: 0x00005116
					public static Color smethod_2(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(51, 51, 51);
						}
						return Color.FromArgb(204, 204, 204);
					}

					// Token: 0x060007AD RID: 1965 RVA: 0x00006F3C File Offset: 0x0000513C
					public static Color smethod_3(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(34, 34, 34);
						}
						return Color.FromArgb(230, 230, 230);
					}
				}
			}

			// Token: 0x02000077 RID: 119
			public sealed class GClass51
			{
				// Token: 0x02000078 RID: 120
				public sealed class GClass52
				{
					// Token: 0x060007B0 RID: 1968 RVA: 0x00006F62 File Offset: 0x00005162
					public static Color smethod_0(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(51, 51, 51);
						}
						return Color.FromArgb(221, 221, 221);
					}

					// Token: 0x060007B1 RID: 1969 RVA: 0x00006ECA File Offset: 0x000050CA
					public static Color smethod_1(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(204, 204, 204);
						}
						return Color.FromArgb(17, 17, 17);
					}

					// Token: 0x060007B2 RID: 1970 RVA: 0x00006ECA File Offset: 0x000050CA
					public static Color smethod_2(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(204, 204, 204);
						}
						return Color.FromArgb(17, 17, 17);
					}

					// Token: 0x060007B3 RID: 1971 RVA: 0x00006F62 File Offset: 0x00005162
					public static Color smethod_3(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(51, 51, 51);
						}
						return Color.FromArgb(221, 221, 221);
					}
				}

				// Token: 0x02000079 RID: 121
				public sealed class GClass53
				{
					// Token: 0x060007B5 RID: 1973 RVA: 0x00006F88 File Offset: 0x00005188
					public static Color smethod_0(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(38, 38, 38);
						}
						return Color.FromArgb(234, 234, 234);
					}

					// Token: 0x060007B6 RID: 1974 RVA: 0x00006F88 File Offset: 0x00005188
					public static Color smethod_1(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(38, 38, 38);
						}
						return Color.FromArgb(234, 234, 234);
					}

					// Token: 0x060007B7 RID: 1975 RVA: 0x00006F88 File Offset: 0x00005188
					public static Color smethod_2(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(38, 38, 38);
						}
						return Color.FromArgb(234, 234, 234);
					}

					// Token: 0x060007B8 RID: 1976 RVA: 0x00006F88 File Offset: 0x00005188
					public static Color smethod_3(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(38, 38, 38);
						}
						return Color.FromArgb(234, 234, 234);
					}
				}
			}

			// Token: 0x0200007A RID: 122
			public sealed class GClass54
			{
				// Token: 0x0200007B RID: 123
				public sealed class GClass55
				{
					// Token: 0x060007BB RID: 1979 RVA: 0x00006F88 File Offset: 0x00005188
					public static Color smethod_0(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(38, 38, 38);
						}
						return Color.FromArgb(234, 234, 234);
					}

					// Token: 0x060007BC RID: 1980 RVA: 0x00006F88 File Offset: 0x00005188
					public static Color smethod_1(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(38, 38, 38);
						}
						return Color.FromArgb(234, 234, 234);
					}

					// Token: 0x060007BD RID: 1981 RVA: 0x00006F88 File Offset: 0x00005188
					public static Color smethod_2(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(38, 38, 38);
						}
						return Color.FromArgb(234, 234, 234);
					}

					// Token: 0x060007BE RID: 1982 RVA: 0x00006F62 File Offset: 0x00005162
					public static Color smethod_3(GEnum29 genum29_0)
					{
						if (genum29_0 == GEnum29.const_2)
						{
							return Color.FromArgb(51, 51, 51);
						}
						return Color.FromArgb(221, 221, 221);
					}
				}
			}
		}

		// Token: 0x0200007C RID: 124
		public sealed class GClass56
		{
			// Token: 0x060007C0 RID: 1984 RVA: 0x00006FAE File Offset: 0x000051AE
			public static Color smethod_0(GEnum29 genum29_0)
			{
				if (genum29_0 == GEnum29.const_2)
				{
					return Color.FromArgb(255, 255, 255);
				}
				return Color.FromArgb(0, 0, 0);
			}

			// Token: 0x0200007D RID: 125
			public sealed class GClass57
			{
				// Token: 0x060007C2 RID: 1986 RVA: 0x00006FD1 File Offset: 0x000051D1
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(204, 204, 204);
					}
					return Color.FromArgb(0, 0, 0);
				}

				// Token: 0x060007C3 RID: 1987 RVA: 0x00006E32 File Offset: 0x00005032
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(17, 17, 17);
					}
					return Color.FromArgb(255, 255, 255);
				}

				// Token: 0x060007C4 RID: 1988 RVA: 0x00006E32 File Offset: 0x00005032
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(17, 17, 17);
					}
					return Color.FromArgb(255, 255, 255);
				}

				// Token: 0x060007C5 RID: 1989 RVA: 0x00006FF4 File Offset: 0x000051F4
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(109, 109, 109);
					}
					return Color.FromArgb(136, 136, 136);
				}
			}

			// Token: 0x0200007E RID: 126
			public sealed class GClass58
			{
				// Token: 0x060007C7 RID: 1991 RVA: 0x0000701A File Offset: 0x0000521A
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(255, 255, 255);
					}
					return Color.FromArgb(255, 255, 255);
				}

				// Token: 0x060007C8 RID: 1992 RVA: 0x0000701A File Offset: 0x0000521A
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(255, 255, 255);
					}
					return Color.FromArgb(255, 255, 255);
				}

				// Token: 0x060007C9 RID: 1993 RVA: 0x0000701A File Offset: 0x0000521A
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(255, 255, 255);
					}
					return Color.FromArgb(255, 255, 255);
				}

				// Token: 0x060007CA RID: 1994 RVA: 0x00007049 File Offset: 0x00005249
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(209, 209, 209);
					}
					return Color.FromArgb(209, 209, 209);
				}
			}

			// Token: 0x0200007F RID: 127
			public sealed class GClass59
			{
				// Token: 0x060007CC RID: 1996 RVA: 0x00007078 File Offset: 0x00005278
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(170, 170, 170);
					}
					return Color.FromArgb(0, 0, 0);
				}

				// Token: 0x060007CD RID: 1997 RVA: 0x0000709B File Offset: 0x0000529B
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(93, 93, 93);
					}
					return Color.FromArgb(128, 128, 128);
				}

				// Token: 0x060007CE RID: 1998 RVA: 0x0000709B File Offset: 0x0000529B
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(93, 93, 93);
					}
					return Color.FromArgb(128, 128, 128);
				}

				// Token: 0x060007CF RID: 1999 RVA: 0x000070C1 File Offset: 0x000052C1
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(51, 51, 51);
					}
					return Color.FromArgb(209, 209, 209);
				}
			}

			// Token: 0x02000080 RID: 128
			public sealed class GClass60
			{
				// Token: 0x060007D1 RID: 2001 RVA: 0x00007078 File Offset: 0x00005278
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(170, 170, 170);
					}
					return Color.FromArgb(0, 0, 0);
				}

				// Token: 0x060007D2 RID: 2002 RVA: 0x000070C1 File Offset: 0x000052C1
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(51, 51, 51);
					}
					return Color.FromArgb(209, 209, 209);
				}
			}

			// Token: 0x02000081 RID: 129
			public sealed class GClass61
			{
				// Token: 0x060007D4 RID: 2004 RVA: 0x000070E7 File Offset: 0x000052E7
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(170, 170, 170);
					}
					return Color.FromArgb(17, 17, 17);
				}

				// Token: 0x060007D5 RID: 2005 RVA: 0x00006DB7 File Offset: 0x00004FB7
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(153, 153, 153);
					}
					return Color.FromArgb(153, 153, 153);
				}

				// Token: 0x060007D6 RID: 2006 RVA: 0x00006DB7 File Offset: 0x00004FB7
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(153, 153, 153);
					}
					return Color.FromArgb(153, 153, 153);
				}

				// Token: 0x060007D7 RID: 2007 RVA: 0x0000710D File Offset: 0x0000530D
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(93, 93, 93);
					}
					return Color.FromArgb(136, 136, 136);
				}
			}

			// Token: 0x02000082 RID: 130
			public sealed class GClass62
			{
				// Token: 0x060007D9 RID: 2009 RVA: 0x00006DB7 File Offset: 0x00004FB7
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(153, 153, 153);
					}
					return Color.FromArgb(153, 153, 153);
				}

				// Token: 0x060007DA RID: 2010 RVA: 0x000070E7 File Offset: 0x000052E7
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(170, 170, 170);
					}
					return Color.FromArgb(17, 17, 17);
				}

				// Token: 0x060007DB RID: 2011 RVA: 0x00006DB7 File Offset: 0x00004FB7
				public static Color smethod_2(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(153, 153, 153);
					}
					return Color.FromArgb(153, 153, 153);
				}

				// Token: 0x060007DC RID: 2012 RVA: 0x0000710D File Offset: 0x0000530D
				public static Color smethod_3(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(93, 93, 93);
					}
					return Color.FromArgb(136, 136, 136);
				}
			}

			// Token: 0x02000083 RID: 131
			public sealed class GClass63
			{
				// Token: 0x060007DE RID: 2014 RVA: 0x00007078 File Offset: 0x00005278
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(170, 170, 170);
					}
					return Color.FromArgb(0, 0, 0);
				}

				// Token: 0x060007DF RID: 2015 RVA: 0x000070C1 File Offset: 0x000052C1
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(51, 51, 51);
					}
					return Color.FromArgb(209, 209, 209);
				}
			}

			// Token: 0x02000084 RID: 132
			public sealed class GClass64
			{
				// Token: 0x060007E1 RID: 2017 RVA: 0x00007078 File Offset: 0x00005278
				public static Color smethod_0(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(170, 170, 170);
					}
					return Color.FromArgb(0, 0, 0);
				}

				// Token: 0x060007E2 RID: 2018 RVA: 0x000070C1 File Offset: 0x000052C1
				public static Color smethod_1(GEnum29 genum29_0)
				{
					if (genum29_0 == GEnum29.const_2)
					{
						return Color.FromArgb(51, 51, 51);
					}
					return Color.FromArgb(209, 209, 209);
				}
			}
		}
	}
}
