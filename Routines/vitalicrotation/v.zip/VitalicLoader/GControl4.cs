﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000048 RID: 72
	[DefaultEvent("Scroll")]
	[ToolboxBitmap(typeof(TrackBar))]
	public class GControl4 : Control, GInterface2
	{
		// Token: 0x0600052B RID: 1323 RVA: 0x000132D0 File Offset: 0x000114D0
		public GControl4(int int_6, int int_7, int int_8)
		{
			base.SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.Selectable | ControlStyles.UserMouse | ControlStyles.SupportsTransparentBackColor | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
			this.BackColor = Color.Transparent;
			this.Int32_1 = int_6;
			this.Int32_2 = int_7;
			this.Int32_0 = int_8;
		}

		// Token: 0x0600052C RID: 1324 RVA: 0x00005611 File Offset: 0x00003811
		public GControl4() : this(0, 100, 50)
		{
		}

		// Token: 0x1400003B RID: 59
		// (add) Token: 0x0600052D RID: 1325 RVA: 0x00013338 File Offset: 0x00011538
		// (remove) Token: 0x0600052E RID: 1326 RVA: 0x00013370 File Offset: 0x00011570
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x0600052F RID: 1327 RVA: 0x0000561E File Offset: 0x0000381E
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x1400003C RID: 60
		// (add) Token: 0x06000530 RID: 1328 RVA: 0x000133A8 File Offset: 0x000115A8
		// (remove) Token: 0x06000531 RID: 1329 RVA: 0x000133E0 File Offset: 0x000115E0
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000532 RID: 1330 RVA: 0x0000563E File Offset: 0x0000383E
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x1400003D RID: 61
		// (add) Token: 0x06000533 RID: 1331 RVA: 0x00013418 File Offset: 0x00011618
		// (remove) Token: 0x06000534 RID: 1332 RVA: 0x00013450 File Offset: 0x00011650
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000535 RID: 1333 RVA: 0x0000565E File Offset: 0x0000385E
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x17000140 RID: 320
		// (get) Token: 0x06000536 RID: 1334 RVA: 0x00013488 File Offset: 0x00011688
		// (set) Token: 0x06000537 RID: 1335 RVA: 0x0000567E File Offset: 0x0000387E
		[Category("Metro Appearance")]
		[DefaultValue(GEnum10.const_0)]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x17000141 RID: 321
		// (get) Token: 0x06000538 RID: 1336 RVA: 0x000134E0 File Offset: 0x000116E0
		// (set) Token: 0x06000539 RID: 1337 RVA: 0x00005687 File Offset: 0x00003887
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x17000142 RID: 322
		// (get) Token: 0x0600053A RID: 1338 RVA: 0x00005690 File Offset: 0x00003890
		// (set) Token: 0x0600053B RID: 1339 RVA: 0x00005698 File Offset: 0x00003898
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x17000143 RID: 323
		// (get) Token: 0x0600053C RID: 1340 RVA: 0x000056A1 File Offset: 0x000038A1
		// (set) Token: 0x0600053D RID: 1341 RVA: 0x000056A9 File Offset: 0x000038A9
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x17000144 RID: 324
		// (get) Token: 0x0600053E RID: 1342 RVA: 0x000056B2 File Offset: 0x000038B2
		// (set) Token: 0x0600053F RID: 1343 RVA: 0x000056BA File Offset: 0x000038BA
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		[Browsable(false)]
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x17000145 RID: 325
		// (get) Token: 0x06000540 RID: 1344 RVA: 0x000056C3 File Offset: 0x000038C3
		// (set) Token: 0x06000541 RID: 1345 RVA: 0x000056CB File Offset: 0x000038CB
		[Browsable(false)]
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x17000146 RID: 326
		// (get) Token: 0x06000542 RID: 1346 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x06000543 RID: 1347 RVA: 0x00002923 File Offset: 0x00000B23
		[Browsable(false)]
		[DefaultValue(true)]
		[Category("Metro Behaviour")]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x1400003E RID: 62
		// (add) Token: 0x06000544 RID: 1348 RVA: 0x00013538 File Offset: 0x00011738
		// (remove) Token: 0x06000545 RID: 1349 RVA: 0x00013570 File Offset: 0x00011770
		public event EventHandler Event_0
		{
			add
			{
				EventHandler eventHandler = this.eventHandler_3;
				EventHandler eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_3, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler eventHandler = this.eventHandler_3;
				EventHandler eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_3, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000546 RID: 1350 RVA: 0x000056D4 File Offset: 0x000038D4
		private void method_0()
		{
			if (this.eventHandler_3 != null)
			{
				this.eventHandler_3(this, EventArgs.Empty);
			}
		}

		// Token: 0x1400003F RID: 63
		// (add) Token: 0x06000547 RID: 1351 RVA: 0x000135A8 File Offset: 0x000117A8
		// (remove) Token: 0x06000548 RID: 1352 RVA: 0x000135E0 File Offset: 0x000117E0
		public event ScrollEventHandler Event_1
		{
			add
			{
				ScrollEventHandler scrollEventHandler = this.scrollEventHandler_0;
				ScrollEventHandler scrollEventHandler2;
				do
				{
					scrollEventHandler2 = scrollEventHandler;
					ScrollEventHandler value2 = (ScrollEventHandler)Delegate.Combine(scrollEventHandler2, value);
					scrollEventHandler = Interlocked.CompareExchange<ScrollEventHandler>(ref this.scrollEventHandler_0, value2, scrollEventHandler2);
				}
				while (scrollEventHandler != scrollEventHandler2);
			}
			remove
			{
				ScrollEventHandler scrollEventHandler = this.scrollEventHandler_0;
				ScrollEventHandler scrollEventHandler2;
				do
				{
					scrollEventHandler2 = scrollEventHandler;
					ScrollEventHandler value2 = (ScrollEventHandler)Delegate.Remove(scrollEventHandler2, value);
					scrollEventHandler = Interlocked.CompareExchange<ScrollEventHandler>(ref this.scrollEventHandler_0, value2, scrollEventHandler2);
				}
				while (scrollEventHandler != scrollEventHandler2);
			}
		}

		// Token: 0x06000549 RID: 1353 RVA: 0x000056EF File Offset: 0x000038EF
		private void method_1(ScrollEventType scrollEventType_0, int int_6)
		{
			if (this.scrollEventHandler_0 != null)
			{
				this.scrollEventHandler_0(this, new ScrollEventArgs(scrollEventType_0, int_6));
			}
		}

		// Token: 0x17000147 RID: 327
		// (get) Token: 0x0600054A RID: 1354 RVA: 0x0000570C File Offset: 0x0000390C
		// (set) Token: 0x0600054B RID: 1355 RVA: 0x00005714 File Offset: 0x00003914
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
			}
		}

		// Token: 0x17000148 RID: 328
		// (get) Token: 0x0600054C RID: 1356 RVA: 0x0000571D File Offset: 0x0000391D
		// (set) Token: 0x0600054D RID: 1357 RVA: 0x00005725 File Offset: 0x00003925
		[DefaultValue(50)]
		public int Int32_0
		{
			get
			{
				return this.int_0;
			}
			set
			{
				if (!(value >= this.int_1 & value <= this.int_2))
				{
					throw new ArgumentOutOfRangeException("Value is outside appropriate range (min, max)");
				}
				this.int_0 = value;
				this.method_0();
				base.Invalidate();
			}
		}

		// Token: 0x17000149 RID: 329
		// (get) Token: 0x0600054E RID: 1358 RVA: 0x00005760 File Offset: 0x00003960
		// (set) Token: 0x0600054F RID: 1359 RVA: 0x00013618 File Offset: 0x00011818
		[DefaultValue(0)]
		public int Int32_1
		{
			get
			{
				return this.int_1;
			}
			set
			{
				if (value < this.int_2)
				{
					this.int_1 = value;
					if (this.int_0 < this.int_1)
					{
						this.int_0 = this.int_1;
						if (this.eventHandler_3 != null)
						{
							this.eventHandler_3(this, new EventArgs());
						}
					}
					base.Invalidate();
					return;
				}
				throw new ArgumentOutOfRangeException("Minimal value is greather than maximal one");
			}
		}

		// Token: 0x1700014A RID: 330
		// (get) Token: 0x06000550 RID: 1360 RVA: 0x00005768 File Offset: 0x00003968
		// (set) Token: 0x06000551 RID: 1361 RVA: 0x0001367C File Offset: 0x0001187C
		[DefaultValue(100)]
		public int Int32_2
		{
			get
			{
				return this.int_2;
			}
			set
			{
				if (value > this.int_1)
				{
					this.int_2 = value;
					if (this.int_0 > this.int_2)
					{
						this.int_0 = this.int_2;
						if (this.eventHandler_3 != null)
						{
							this.eventHandler_3(this, new EventArgs());
						}
					}
					base.Invalidate();
					return;
				}
				throw new ArgumentOutOfRangeException("Maximal value is lower than minimal one");
			}
		}

		// Token: 0x1700014B RID: 331
		// (get) Token: 0x06000552 RID: 1362 RVA: 0x00005770 File Offset: 0x00003970
		// (set) Token: 0x06000553 RID: 1363 RVA: 0x00005778 File Offset: 0x00003978
		[DefaultValue(1)]
		public int Int32_3
		{
			get
			{
				return this.int_3;
			}
			set
			{
				this.int_3 = value;
			}
		}

		// Token: 0x1700014C RID: 332
		// (get) Token: 0x06000554 RID: 1364 RVA: 0x00005781 File Offset: 0x00003981
		// (set) Token: 0x06000555 RID: 1365 RVA: 0x00005789 File Offset: 0x00003989
		[DefaultValue(5)]
		public int Int32_4
		{
			get
			{
				return this.int_4;
			}
			set
			{
				this.int_4 = value;
			}
		}

		// Token: 0x1700014D RID: 333
		// (get) Token: 0x06000556 RID: 1366 RVA: 0x00005792 File Offset: 0x00003992
		// (set) Token: 0x06000557 RID: 1367 RVA: 0x000057B7 File Offset: 0x000039B7
		[DefaultValue(10)]
		public int Int32_5
		{
			get
			{
				if (this.int_5 == 0)
				{
					return (this.int_2 - this.int_1) / this.int_3;
				}
				return this.int_5;
			}
			set
			{
				this.int_5 = value;
			}
		}

		// Token: 0x06000558 RID: 1368 RVA: 0x000136E0 File Offset: 0x000118E0
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.smethod_0(this.GEnum29_0);
				}
				if (color.A == 255)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x06000559 RID: 1369 RVA: 0x00013760 File Offset: 0x00011960
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x0600055A RID: 1370 RVA: 0x000137C0 File Offset: 0x000119C0
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			Color color_;
			Color color_2;
			if (this.bool_4 && !this.bool_5 && base.Enabled)
			{
				color_ = GClass39.GClass46.GClass48.GClass49.smethod_1(this.GEnum29_0);
				color_2 = GClass39.GClass46.GClass48.GClass50.smethod_1(this.GEnum29_0);
			}
			else if (this.bool_4 && this.bool_5 && base.Enabled)
			{
				color_ = GClass39.GClass46.GClass48.GClass49.smethod_2(this.GEnum29_0);
				color_2 = GClass39.GClass46.GClass48.GClass50.smethod_2(this.GEnum29_0);
			}
			else if (base.Enabled && this.Int32_0 != 0)
			{
				color_ = GClass39.GClass46.GClass48.GClass49.smethod_0(this.GEnum29_0);
				color_2 = GClass39.GClass46.GClass48.GClass50.smethod_0(this.GEnum29_0);
			}
			else
			{
				color_ = GClass39.GClass46.GClass48.GClass49.smethod_3(this.GEnum29_0);
				color_2 = GClass39.GClass46.GClass48.GClass50.smethod_3(this.GEnum29_0);
			}
			this.method_2(paintEventArgs_0.Graphics, color_, color_2);
			if (this.bool_3 && this.bool_6)
			{
				ControlPaint.DrawFocusRectangle(paintEventArgs_0.Graphics, base.ClientRectangle);
			}
		}

		// Token: 0x0600055B RID: 1371 RVA: 0x000138A4 File Offset: 0x00011AA4
		private void method_2(Graphics graphics_0, Color color_0, Color color_1)
		{
			int num = (this.int_0 - this.int_1) * (base.Width - 6) / (this.int_2 - this.int_1);
			using (SolidBrush solidBrush = new SolidBrush(color_0))
			{
				Rectangle rect = new Rectangle(0, base.Height / 2 - 2, num, 4);
				graphics_0.FillRectangle(solidBrush, rect);
				Rectangle rect2 = new Rectangle(num, base.Height / 2 - 8, 6, 16);
				graphics_0.FillRectangle(solidBrush, rect2);
			}
			using (SolidBrush solidBrush2 = new SolidBrush(color_1))
			{
				Rectangle rect3 = new Rectangle(num + 7, base.Height / 2 - 2, base.Width - num + 7, 4);
				graphics_0.FillRectangle(solidBrush2, rect3);
			}
		}

		// Token: 0x0600055C RID: 1372 RVA: 0x000057C0 File Offset: 0x000039C0
		protected override void OnGotFocus(EventArgs e)
		{
			this.bool_6 = true;
			base.Invalidate();
			base.OnGotFocus(e);
		}

		// Token: 0x0600055D RID: 1373 RVA: 0x000057D6 File Offset: 0x000039D6
		protected override void OnLostFocus(EventArgs e)
		{
			this.bool_6 = false;
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnLostFocus(e);
		}

		// Token: 0x0600055E RID: 1374 RVA: 0x000057FA File Offset: 0x000039FA
		protected override void OnEnter(EventArgs e)
		{
			this.bool_6 = true;
			base.Invalidate();
			base.OnEnter(e);
		}

		// Token: 0x0600055F RID: 1375 RVA: 0x00005810 File Offset: 0x00003A10
		protected override void OnLeave(EventArgs e)
		{
			this.bool_6 = false;
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnLeave(e);
		}

		// Token: 0x06000560 RID: 1376 RVA: 0x00005834 File Offset: 0x00003A34
		protected override void OnKeyDown(KeyEventArgs e)
		{
			this.bool_4 = true;
			this.bool_5 = true;
			base.Invalidate();
			base.OnKeyDown(e);
		}

		// Token: 0x06000561 RID: 1377 RVA: 0x00013980 File Offset: 0x00011B80
		protected override void OnKeyUp(KeyEventArgs e)
		{
			this.bool_4 = false;
			this.bool_5 = false;
			base.Invalidate();
			base.OnKeyUp(e);
			switch (e.KeyCode)
			{
			case Keys.Prior:
				this.method_3(this.Int32_0 + this.int_4);
				this.method_1(ScrollEventType.LargeIncrement, this.Int32_0);
				break;
			case Keys.Next:
				this.method_3(this.Int32_0 - this.int_4);
				this.method_1(ScrollEventType.LargeDecrement, this.Int32_0);
				break;
			case Keys.End:
				this.Int32_0 = this.int_2;
				break;
			case Keys.Home:
				this.Int32_0 = this.int_1;
				break;
			case Keys.Left:
			case Keys.Down:
				this.method_3(this.Int32_0 - this.int_3);
				this.method_1(ScrollEventType.SmallDecrement, this.Int32_0);
				break;
			case Keys.Up:
			case Keys.Right:
				this.method_3(this.Int32_0 + this.int_3);
				this.method_1(ScrollEventType.SmallIncrement, this.Int32_0);
				break;
			}
			if (this.Int32_0 == this.int_1)
			{
				this.method_1(ScrollEventType.First, this.Int32_0);
			}
			if (this.Int32_0 == this.int_2)
			{
				this.method_1(ScrollEventType.Last, this.Int32_0);
			}
			Point point = base.PointToClient(Cursor.Position);
			this.OnMouseMove(new MouseEventArgs(MouseButtons.None, 0, point.X, point.Y, 0));
		}

		// Token: 0x06000562 RID: 1378 RVA: 0x00005851 File Offset: 0x00003A51
		protected override bool ProcessDialogKey(Keys keyData)
		{
			if (keyData == Keys.Tab | Control.ModifierKeys == Keys.Shift)
			{
				return base.ProcessDialogKey(keyData);
			}
			this.OnKeyDown(new KeyEventArgs(keyData));
			return true;
		}

		// Token: 0x06000563 RID: 1379 RVA: 0x0000587C File Offset: 0x00003A7C
		protected override void OnMouseEnter(EventArgs e)
		{
			this.bool_4 = true;
			base.Invalidate();
			base.Focus();
			base.OnMouseEnter(e);
		}

		// Token: 0x06000564 RID: 1380 RVA: 0x00013AE0 File Offset: 0x00011CE0
		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				this.bool_5 = true;
				base.Invalidate();
			}
			base.OnMouseDown(e);
			if (e.Button == MouseButtons.Left)
			{
				base.Capture = true;
				this.method_1(ScrollEventType.ThumbTrack, this.int_0);
				this.method_0();
				this.OnMouseMove(e);
			}
		}

		// Token: 0x06000565 RID: 1381 RVA: 0x00013B3C File Offset: 0x00011D3C
		protected override void OnMouseMove(MouseEventArgs e)
		{
			base.OnMouseMove(e);
			if (base.Capture & e.Button == MouseButtons.Left)
			{
				ScrollEventType scrollEventType_ = ScrollEventType.ThumbPosition;
				int x = e.Location.X;
				float num = (float)(this.int_2 - this.int_1) / (float)(base.ClientSize.Width - 3);
				this.int_0 = (int)((float)x * num + (float)this.int_1);
				if (this.int_0 <= this.int_1)
				{
					this.int_0 = this.int_1;
					scrollEventType_ = ScrollEventType.First;
				}
				else if (this.int_0 >= this.int_2)
				{
					this.int_0 = this.int_2;
					scrollEventType_ = ScrollEventType.Last;
				}
				this.method_1(scrollEventType_, this.int_0);
				this.method_0();
				base.Invalidate();
			}
		}

		// Token: 0x06000566 RID: 1382 RVA: 0x00005899 File Offset: 0x00003A99
		protected override void OnMouseUp(MouseEventArgs e)
		{
			this.bool_5 = false;
			base.Invalidate();
			base.OnMouseUp(e);
		}

		// Token: 0x06000567 RID: 1383 RVA: 0x000058AF File Offset: 0x00003AAF
		protected override void OnMouseLeave(EventArgs e)
		{
			this.bool_4 = false;
			base.Invalidate();
			base.OnMouseLeave(e);
		}

		// Token: 0x06000568 RID: 1384 RVA: 0x00013C04 File Offset: 0x00011E04
		protected override void OnMouseWheel(MouseEventArgs e)
		{
			base.OnMouseWheel(e);
			int num = e.Delta / 120 * (this.int_2 - this.int_1) / this.int_5;
			this.method_3(this.Int32_0 + num);
			((HandledMouseEventArgs)e).Handled = true;
		}

		// Token: 0x06000569 RID: 1385 RVA: 0x0000472B File Offset: 0x0000292B
		protected override void OnEnabledChanged(EventArgs e)
		{
			base.OnEnabledChanged(e);
			base.Invalidate();
		}

		// Token: 0x0600056A RID: 1386 RVA: 0x000058C5 File Offset: 0x00003AC5
		private void method_3(int int_6)
		{
			if (int_6 < this.int_1)
			{
				this.Int32_0 = this.int_1;
				return;
			}
			if (int_6 > this.int_2)
			{
				this.Int32_0 = this.int_2;
				return;
			}
			this.Int32_0 = int_6;
		}

		// Token: 0x040001D3 RID: 467
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x040001D4 RID: 468
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x040001D5 RID: 469
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x040001D6 RID: 470
		private GEnum10 genum10_0;

		// Token: 0x040001D7 RID: 471
		private GEnum29 genum29_0;

		// Token: 0x040001D8 RID: 472
		private GClass8 gclass8_0;

		// Token: 0x040001D9 RID: 473
		private bool bool_0;

		// Token: 0x040001DA RID: 474
		private bool bool_1;

		// Token: 0x040001DB RID: 475
		private bool bool_2;

		// Token: 0x040001DC RID: 476
		private EventHandler eventHandler_3;

		// Token: 0x040001DD RID: 477
		private ScrollEventHandler scrollEventHandler_0;

		// Token: 0x040001DE RID: 478
		private bool bool_3;

		// Token: 0x040001DF RID: 479
		private int int_0 = 50;

		// Token: 0x040001E0 RID: 480
		private int int_1;

		// Token: 0x040001E1 RID: 481
		private int int_2 = 100;

		// Token: 0x040001E2 RID: 482
		private int int_3 = 1;

		// Token: 0x040001E3 RID: 483
		private int int_4 = 5;

		// Token: 0x040001E4 RID: 484
		private int int_5 = 10;

		// Token: 0x040001E5 RID: 485
		private bool bool_4;

		// Token: 0x040001E6 RID: 486
		private bool bool_5;

		// Token: 0x040001E7 RID: 487
		private bool bool_6;
	}
}
