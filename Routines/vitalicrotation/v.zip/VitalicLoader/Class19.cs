﻿using System;
using System.Data;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x0200008B RID: 139
	internal class Class19
	{
		// Token: 0x060007F1 RID: 2033 RVA: 0x000071D9 File Offset: 0x000053D9
		public Class19(string string_0)
		{
			this.method_2(string_0);
		}

		// Token: 0x060007F2 RID: 2034 RVA: 0x000071E8 File Offset: 0x000053E8
		public Class19(Control control_0)
		{
			this.method_2(control_0.Name);
		}

		// Token: 0x060007F3 RID: 2035 RVA: 0x000071FC File Offset: 0x000053FC
		public string method_0()
		{
			return "en";
		}

		// Token: 0x060007F4 RID: 2036 RVA: 0x0001D554 File Offset: 0x0001B754
		public string method_1()
		{
			string text = Application.CurrentCulture.TwoLetterISOLanguageName;
			if (text.Length == 0)
			{
				text = this.method_0();
			}
			return text.ToLower();
		}

		// Token: 0x060007F5 RID: 2037 RVA: 0x0001D584 File Offset: 0x0001B784
		private void method_2(string string_0)
		{
			Assembly callingAssembly = Assembly.GetCallingAssembly();
			string name = string.Concat(new string[]
			{
				callingAssembly.GetName().Name,
				".Localization.",
				this.method_1(),
				".",
				string_0,
				".xml"
			});
			Stream manifestResourceStream = callingAssembly.GetManifestResourceStream(name);
			if (manifestResourceStream == null)
			{
				name = string.Concat(new string[]
				{
					callingAssembly.GetName().Name,
					".Localization.",
					this.method_0(),
					".",
					string_0,
					".xml"
				});
				manifestResourceStream = callingAssembly.GetManifestResourceStream(name);
			}
			if (this.dataSet_0 == null)
			{
				this.dataSet_0 = new DataSet();
			}
			if (manifestResourceStream != null)
			{
				DataSet dataSet = new DataSet();
				dataSet.ReadXml(manifestResourceStream);
				this.dataSet_0.Merge(dataSet);
				manifestResourceStream.Close();
			}
		}

		// Token: 0x060007F6 RID: 2038 RVA: 0x00007203 File Offset: 0x00005403
		private string method_3(object object_0)
		{
			if (object_0 == null)
			{
				return "";
			}
			return object_0.ToString();
		}

		// Token: 0x060007F7 RID: 2039 RVA: 0x0001D6A0 File Offset: 0x0001B8A0
		public string method_4(string string_0)
		{
			if (string.IsNullOrEmpty(string_0))
			{
				return "";
			}
			if (this.dataSet_0 == null)
			{
				return "~" + string_0;
			}
			if (this.dataSet_0.Tables["Localization"] == null)
			{
				return "~" + string_0;
			}
			DataRow[] array = this.dataSet_0.Tables["Localization"].Select("Key='" + string_0 + "'");
			if (array.Length <= 0)
			{
				return "~" + string_0;
			}
			return array[0]["Value"].ToString();
		}

		// Token: 0x060007F8 RID: 2040 RVA: 0x0001D748 File Offset: 0x0001B948
		public string method_5(string string_0, object object_0)
		{
			string text = this.method_4(string_0);
			return text.Replace("#1", this.method_3(object_0));
		}

		// Token: 0x060007F9 RID: 2041 RVA: 0x0001D770 File Offset: 0x0001B970
		public string method_6(string string_0, object object_0, object object_1)
		{
			string text = this.method_4(string_0);
			text = text.Replace("#1", this.method_3(object_0));
			return text.Replace("#2", this.method_3(object_1));
		}

		// Token: 0x060007FA RID: 2042 RVA: 0x0001D7AC File Offset: 0x0001B9AC
		public string method_7(string string_0, object object_0, object object_1, object object_2)
		{
			string text = this.method_4(string_0);
			text = text.Replace("#1", this.method_3(object_0));
			text = text.Replace("#2", this.method_3(object_1));
			return text.Replace("#3", this.method_3(object_2));
		}

		// Token: 0x060007FB RID: 2043 RVA: 0x0001D7FC File Offset: 0x0001B9FC
		public string method_8(string string_0, object object_0, object object_1, object object_2, object object_3)
		{
			string text = this.method_4(string_0);
			text = text.Replace("#1", this.method_3(object_0));
			text = text.Replace("#2", this.method_3(object_1));
			text = text.Replace("#3", this.method_3(object_2));
			return text.Replace("#4", this.method_3(object_3));
		}

		// Token: 0x060007FC RID: 2044 RVA: 0x0001D860 File Offset: 0x0001BA60
		public string method_9(string string_0, object object_0, object object_1, object object_2, object object_3, object object_4)
		{
			string text = this.method_4(string_0);
			text = text.Replace("#1", this.method_3(object_0));
			text = text.Replace("#2", this.method_3(object_1));
			text = text.Replace("#3", this.method_3(object_2));
			text = text.Replace("#4", this.method_3(object_3));
			return text.Replace("#5", this.method_3(object_4));
		}

		// Token: 0x0400042B RID: 1067
		private DataSet dataSet_0;
	}
}
