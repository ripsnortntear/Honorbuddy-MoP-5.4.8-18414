﻿using System;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000014 RID: 20
	public sealed class GClass5 : GClass3
	{
		// Token: 0x06000083 RID: 131 RVA: 0x00008CC4 File Offset: 0x00006EC4
		public void method_6(Control control_1, Size size_0, GEnum0 genum0_1, int int_3)
		{
			GClass5.Class5 @class = new GClass5.Class5();
			@class.control_0 = control_1;
			@class.size_0 = size_0;
			@class.gclass5_0 = this;
			base.method_3(@class.control_0, genum0_1, int_3, new GDelegate0(@class.method_0), new GDelegate1(@class.method_1));
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00008D14 File Offset: 0x00006F14
		private int method_7(int int_3, int int_4)
		{
			float float_ = (float)this.int_0 - (float)this.int_1;
			float float_2 = (float)int_3;
			float float_3 = (float)int_4 - (float)int_3;
			float float_4 = (float)this.int_2 - (float)this.int_1;
			return base.method_5(float_, float_2, float_4, float_3);
		}

		// Token: 0x02000015 RID: 21
		[CompilerGenerated]
		private sealed class Class5
		{
			// Token: 0x06000086 RID: 134 RVA: 0x00008D54 File Offset: 0x00006F54
			public void method_0()
			{
				int width = this.gclass5_0.method_7(this.control_0.Width, this.size_0.Width);
				int height = this.gclass5_0.method_7(this.control_0.Height, this.size_0.Height);
				this.control_0.Size = new Size(width, height);
			}

			// Token: 0x06000087 RID: 135 RVA: 0x00008DB8 File Offset: 0x00006FB8
			public bool method_1()
			{
				return this.control_0.Size.Equals(this.size_0);
			}

			// Token: 0x04000033 RID: 51
			public GClass5 gclass5_0;

			// Token: 0x04000034 RID: 52
			public Control control_0;

			// Token: 0x04000035 RID: 53
			public Size size_0;
		}
	}
}
