﻿using System;
using System.Text.RegularExpressions;

namespace ns0
{
	// Token: 0x02000068 RID: 104
	internal static class Class17
	{
		// Token: 0x06000772 RID: 1906 RVA: 0x0001CC38 File Offset: 0x0001AE38
		public static MatchCollection smethod_0(string string_20, string string_21)
		{
			Regex regex = new Regex(string_20, RegexOptions.IgnoreCase | RegexOptions.Singleline);
			return regex.Matches(string_21);
		}

		// Token: 0x06000773 RID: 1907 RVA: 0x0001CC58 File Offset: 0x0001AE58
		public static string smethod_1(string string_20, string string_21)
		{
			int num;
			return Class17.smethod_2(string_20, string_21, out num);
		}

		// Token: 0x06000774 RID: 1908 RVA: 0x0001CC70 File Offset: 0x0001AE70
		public static string smethod_2(string string_20, string string_21, out int int_0)
		{
			MatchCollection matchCollection = Class17.smethod_0(string_20, string_21);
			if (matchCollection.Count > 0)
			{
				int_0 = matchCollection[0].Index;
				return matchCollection[0].Value;
			}
			int_0 = -1;
			return null;
		}

		// Token: 0x040003F5 RID: 1013
		public const string string_0 = ";?[^;\\s]*:[^\\{\\}:;]*(\\}|;)?";

		// Token: 0x040003F6 RID: 1014
		public const string string_1 = "/\\*[^*/]*\\*/";

		// Token: 0x040003F7 RID: 1015
		public const string string_2 = "@.*\\{\\s*(\\s*[^\\{\\}]*\\{[^\\{\\}]*\\}\\s*)*\\s*\\}";

		// Token: 0x040003F8 RID: 1016
		public const string string_3 = "@media[^\\{\\}]*\\{";

		// Token: 0x040003F9 RID: 1017
		public const string string_4 = "[^\\{\\}]*\\{[^\\{\\}]*\\}";

		// Token: 0x040003FA RID: 1018
		public const string string_5 = "{[0-9]+|[0-9]*\\.[0-9]+}";

		// Token: 0x040003FB RID: 1019
		public const string string_6 = "([0-9]+|[0-9]*\\.[0-9]+)\\%";

		// Token: 0x040003FC RID: 1020
		public const string string_7 = "([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)";

		// Token: 0x040003FD RID: 1021
		public const string string_8 = "(#\\S{6}|#\\S{3}|rgb\\(\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\,\\s*[0-9]{1,3}\\%?\\s*\\)|maroon|red|orange|yellow|olive|purple|fuchsia|white|lime|green|navy|blue|aqua|teal|black|silver|gray)";

		// Token: 0x040003FE RID: 1022
		public const string string_9 = "(normal|{[0-9]+|[0-9]*\\.[0-9]+}|([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|([0-9]+|[0-9]*\\.[0-9]+)\\%)";

		// Token: 0x040003FF RID: 1023
		public const string string_10 = "(none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset)";

		// Token: 0x04000400 RID: 1024
		public const string string_11 = "(([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|thin|medium|thick)";

		// Token: 0x04000401 RID: 1025
		public const string string_12 = "(\"[^\"]*\"|'[^']*'|\\S+\\s*)(\\s*\\,\\s*(\"[^\"]*\"|'[^']*'|\\S+))*";

		// Token: 0x04000402 RID: 1026
		public const string string_13 = "(normal|italic|oblique)";

		// Token: 0x04000403 RID: 1027
		public const string string_14 = "(normal|small-caps)";

		// Token: 0x04000404 RID: 1028
		public const string string_15 = "(normal|bold|bolder|lighter|100|200|300|400|500|600|700|800|900)";

		// Token: 0x04000405 RID: 1029
		public const string string_16 = "(([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|([0-9]+|[0-9]*\\.[0-9]+)\\%|xx-small|x-small|small|medium|large|x-large|xx-large|larger|smaller)";

		// Token: 0x04000406 RID: 1030
		public const string string_17 = "(([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|([0-9]+|[0-9]*\\.[0-9]+)\\%|xx-small|x-small|small|medium|large|x-large|xx-large|larger|smaller)(\\/(normal|{[0-9]+|[0-9]*\\.[0-9]+}|([0-9]+|[0-9]*\\.[0-9]+)(em|ex|px|in|cm|mm|pt|pc)|([0-9]+|[0-9]*\\.[0-9]+)\\%))?(\\s|$)";

		// Token: 0x04000407 RID: 1031
		public const string string_18 = "<[^<>]*>";

		// Token: 0x04000408 RID: 1032
		public const string string_19 = "[^\\s]*\\s*=\\s*(\"[^\"]*\"|[^\\s]*)";
	}
}
