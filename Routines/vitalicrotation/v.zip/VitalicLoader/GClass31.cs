﻿using System;

namespace ns0
{
	// Token: 0x02000054 RID: 84
	public class GClass31
	{
		// Token: 0x0400027F RID: 639
		public const string string_0 = "absolute";

		// Token: 0x04000280 RID: 640
		public const string string_1 = "auto";

		// Token: 0x04000281 RID: 641
		public const string string_2 = "baseline";

		// Token: 0x04000282 RID: 642
		public const string string_3 = "blink";

		// Token: 0x04000283 RID: 643
		public const string string_4 = "block";

		// Token: 0x04000284 RID: 644
		public const string string_5 = "bold";

		// Token: 0x04000285 RID: 645
		public const string string_6 = "bolder";

		// Token: 0x04000286 RID: 646
		public const string string_7 = "bottom";

		// Token: 0x04000287 RID: 647
		public const string string_8 = "center";

		// Token: 0x04000288 RID: 648
		public const string string_9 = "collapse";

		// Token: 0x04000289 RID: 649
		public const string string_10 = "cursive";

		// Token: 0x0400028A RID: 650
		public const string string_11 = "decimal";

		// Token: 0x0400028B RID: 651
		public const string string_12 = "fantasy";

		// Token: 0x0400028C RID: 652
		public const string string_13 = "hide";

		// Token: 0x0400028D RID: 653
		public const string string_14 = "inherit";

		// Token: 0x0400028E RID: 654
		public const string string_15 = "inline";

		// Token: 0x0400028F RID: 655
		public const string string_16 = "inline-table";

		// Token: 0x04000290 RID: 656
		public const string string_17 = "inset";

		// Token: 0x04000291 RID: 657
		public const string string_18 = "italic";

		// Token: 0x04000292 RID: 658
		public const string string_19 = "justify";

		// Token: 0x04000293 RID: 659
		public const string string_20 = "large";

		// Token: 0x04000294 RID: 660
		public const string string_21 = "larger";

		// Token: 0x04000295 RID: 661
		public const string string_22 = "left";

		// Token: 0x04000296 RID: 662
		public const string string_23 = "lighter";

		// Token: 0x04000297 RID: 663
		public const string string_24 = "line-through";

		// Token: 0x04000298 RID: 664
		public const string string_25 = "list-item";

		// Token: 0x04000299 RID: 665
		public const string string_26 = "ltr";

		// Token: 0x0400029A RID: 666
		public const string string_27 = "medium";

		// Token: 0x0400029B RID: 667
		public const string string_28 = "middle";

		// Token: 0x0400029C RID: 668
		public const string string_29 = "monospace";

		// Token: 0x0400029D RID: 669
		public const string string_30 = "none";

		// Token: 0x0400029E RID: 670
		public const string string_31 = "normal";

		// Token: 0x0400029F RID: 671
		public const string string_32 = "nowrap";

		// Token: 0x040002A0 RID: 672
		public const string string_33 = "oblique";

		// Token: 0x040002A1 RID: 673
		public const string string_34 = "outset";

		// Token: 0x040002A2 RID: 674
		public const string string_35 = "overline";

		// Token: 0x040002A3 RID: 675
		public const string string_36 = "pre";

		// Token: 0x040002A4 RID: 676
		public const string string_37 = "pre-wrap";

		// Token: 0x040002A5 RID: 677
		public const string string_38 = "pre-line";

		// Token: 0x040002A6 RID: 678
		public const string string_39 = "right";

		// Token: 0x040002A7 RID: 679
		public const string string_40 = "rtl";

		// Token: 0x040002A8 RID: 680
		public const string string_41 = "sans-serif";

		// Token: 0x040002A9 RID: 681
		public const string string_42 = "serif";

		// Token: 0x040002AA RID: 682
		public const string string_43 = "show";

		// Token: 0x040002AB RID: 683
		public const string string_44 = "small";

		// Token: 0x040002AC RID: 684
		public const string string_45 = "smaller";

		// Token: 0x040002AD RID: 685
		public const string string_46 = "solid";

		// Token: 0x040002AE RID: 686
		public const string string_47 = "sub";

		// Token: 0x040002AF RID: 687
		public const string string_48 = "super";

		// Token: 0x040002B0 RID: 688
		public const string string_49 = "table";

		// Token: 0x040002B1 RID: 689
		public const string string_50 = "table-row";

		// Token: 0x040002B2 RID: 690
		public const string string_51 = "table-row-group";

		// Token: 0x040002B3 RID: 691
		public const string string_52 = "table-header-group";

		// Token: 0x040002B4 RID: 692
		public const string string_53 = "table-footer-group";

		// Token: 0x040002B5 RID: 693
		public const string string_54 = "table-column";

		// Token: 0x040002B6 RID: 694
		public const string string_55 = "table-column-group";

		// Token: 0x040002B7 RID: 695
		public const string string_56 = "table-cell";

		// Token: 0x040002B8 RID: 696
		public const string string_57 = "table-caption";

		// Token: 0x040002B9 RID: 697
		public const string string_58 = "text-bottom";

		// Token: 0x040002BA RID: 698
		public const string string_59 = "text-top";

		// Token: 0x040002BB RID: 699
		public const string string_60 = "thin";

		// Token: 0x040002BC RID: 700
		public const string string_61 = "thick";

		// Token: 0x040002BD RID: 701
		public const string string_62 = "top";

		// Token: 0x040002BE RID: 702
		public const string string_63 = "underline";

		// Token: 0x040002BF RID: 703
		public const string string_64 = "x-large";

		// Token: 0x040002C0 RID: 704
		public const string string_65 = "x-small";

		// Token: 0x040002C1 RID: 705
		public const string string_66 = "xx-large";

		// Token: 0x040002C2 RID: 706
		public const string string_67 = "xx-small";

		// Token: 0x040002C3 RID: 707
		public const string string_68 = "cm";

		// Token: 0x040002C4 RID: 708
		public const string string_69 = "mm";

		// Token: 0x040002C5 RID: 709
		public const string string_70 = "px";

		// Token: 0x040002C6 RID: 710
		public const string string_71 = "in";

		// Token: 0x040002C7 RID: 711
		public const string string_72 = "em";

		// Token: 0x040002C8 RID: 712
		public const string string_73 = "ex";

		// Token: 0x040002C9 RID: 713
		public const string string_74 = "pt";

		// Token: 0x040002CA RID: 714
		public const string string_75 = "pc";

		// Token: 0x040002CB RID: 715
		public const string string_76 = "maroon";

		// Token: 0x040002CC RID: 716
		public const string string_77 = "red";

		// Token: 0x040002CD RID: 717
		public const string string_78 = "orange";

		// Token: 0x040002CE RID: 718
		public const string string_79 = "yellow";

		// Token: 0x040002CF RID: 719
		public const string string_80 = "olive";

		// Token: 0x040002D0 RID: 720
		public const string string_81 = "fuchsia";

		// Token: 0x040002D1 RID: 721
		public const string string_82 = "lime";

		// Token: 0x040002D2 RID: 722
		public const string string_83 = "white";

		// Token: 0x040002D3 RID: 723
		public const string string_84 = "green";

		// Token: 0x040002D4 RID: 724
		public const string string_85 = "navy";

		// Token: 0x040002D5 RID: 725
		public const string string_86 = "blue";

		// Token: 0x040002D6 RID: 726
		public const string string_87 = "aqua";

		// Token: 0x040002D7 RID: 727
		public const string string_88 = "teal";

		// Token: 0x040002D8 RID: 728
		public const string string_89 = "black";

		// Token: 0x040002D9 RID: 729
		public const string string_90 = "silver";

		// Token: 0x040002DA RID: 730
		public const string string_91 = "gray";

		// Token: 0x040002DB RID: 731
		public const string string_92 = "purple";
	}
}
