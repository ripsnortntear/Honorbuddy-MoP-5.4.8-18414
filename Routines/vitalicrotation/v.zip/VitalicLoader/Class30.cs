﻿using System;
using System.Runtime.InteropServices;
using System.Security;

namespace ns0
{
	// Token: 0x020000CE RID: 206
	[SuppressUnmanagedCodeSecurity]
	internal sealed class Class30
	{
		// Token: 0x060008A7 RID: 2215 RVA: 0x000077F1 File Offset: 0x000059F1
		public Class30(IntPtr intptr_1)
		{
			this.intptr_0 = intptr_1;
		}

		// Token: 0x060008A8 RID: 2216
		[DllImport("user32.dll")]
		private static extern bool CreateCaret(IntPtr intptr_1, int int_0, int int_1, int int_2);

		// Token: 0x060008A9 RID: 2217
		[DllImport("user32.dll")]
		private static extern bool SetCaretPos(int int_0, int int_1);

		// Token: 0x060008AA RID: 2218
		[DllImport("user32.dll")]
		private static extern bool DestroyCaret();

		// Token: 0x060008AB RID: 2219
		[DllImport("user32.dll")]
		private static extern bool ShowCaret(IntPtr intptr_1);

		// Token: 0x060008AC RID: 2220
		[DllImport("user32.dll")]
		public static extern bool HideCaret(IntPtr intptr_1);

		// Token: 0x060008AD RID: 2221 RVA: 0x00007800 File Offset: 0x00005A00
		public bool method_0(int int_0, int int_1)
		{
			return Class30.CreateCaret(this.intptr_0, 0, int_0, int_1);
		}

		// Token: 0x060008AE RID: 2222 RVA: 0x00007810 File Offset: 0x00005A10
		public void method_1()
		{
			Class30.HideCaret(this.intptr_0);
		}

		// Token: 0x060008AF RID: 2223 RVA: 0x0000781E File Offset: 0x00005A1E
		public void method_2()
		{
			Class30.ShowCaret(this.intptr_0);
		}

		// Token: 0x060008B0 RID: 2224 RVA: 0x0000782C File Offset: 0x00005A2C
		public bool method_3(int int_0, int int_1)
		{
			return Class30.SetCaretPos(int_0, int_1);
		}

		// Token: 0x060008B1 RID: 2225 RVA: 0x00007835 File Offset: 0x00005A35
		public void method_4()
		{
			Class30.DestroyCaret();
		}

		// Token: 0x04000653 RID: 1619
		private IntPtr intptr_0;
	}
}
