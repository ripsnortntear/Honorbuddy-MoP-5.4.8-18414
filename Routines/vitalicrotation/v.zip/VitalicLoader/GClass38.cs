﻿using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000066 RID: 102
	public class GClass38 : ToolTip
	{
		// Token: 0x0600075A RID: 1882 RVA: 0x00006B9C File Offset: 0x00004D9C
		public GClass38()
		{
			base.OwnerDraw = true;
			base.Popup += this.GClass38_Popup;
			base.Draw += this.GClass38_Draw;
		}

		// Token: 0x0600075B RID: 1883 RVA: 0x0001C0D0 File Offset: 0x0001A2D0
		private void GClass38_Popup(object sender, PopupEventArgs e)
		{
			string toolTip = base.GetToolTip(e.AssociatedControl);
			string text = string.Format(NumberFormatInfo.InvariantInfo, "font: {0}pt {1}", new object[]
			{
				e.AssociatedControl.Font.Size,
				e.AssociatedControl.Font.FontFamily.Name
			});
			this.gclass28_0 = new GClass28(string.Concat(new string[]
			{
				"<table class=htmltooltipbackground cellspacing=5 cellpadding=0 style=\"",
				text,
				"\"><tr><td style=border:0px>",
				toolTip,
				"</td></tr></table>"
			}));
			this.gclass28_0.method_31(new Rectangle(0, 0, 10, 10));
			this.gclass28_0.Boolean_3 = true;
			using (Graphics graphics = e.AssociatedControl.CreateGraphics())
			{
				this.gclass28_0.vmethod_0(graphics);
			}
			e.ToolTipSize = Size.Round(this.gclass28_0.SizeF_1);
		}

		// Token: 0x0600075C RID: 1884 RVA: 0x00006BCF File Offset: 0x00004DCF
		private void GClass38_Draw(object sender, DrawToolTipEventArgs e)
		{
			e.Graphics.Clear(Color.White);
			if (this.gclass28_0 != null)
			{
				this.gclass28_0.method_24(e.Graphics);
			}
		}

		// Token: 0x040003ED RID: 1005
		private GClass28 gclass28_0;
	}
}
