﻿using System;
using System.ComponentModel;
using System.Drawing.Design;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000041 RID: 65
	[ToolboxItem(false)]
	[Editor("MetroFramework.Design.MetroTabPageCollectionEditor, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a", typeof(UITypeEditor))]
	public class GClass20 : TabControl.TabPageCollection
	{
		// Token: 0x060003E3 RID: 995 RVA: 0x000047C8 File Offset: 0x000029C8
		public GClass20(GControl2 gcontrol2_0) : base(gcontrol2_0)
		{
		}
	}
}
