﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace ns0
{
	// Token: 0x020000CF RID: 207
	[CompilerGenerated]
	internal class Class31
	{
		// Token: 0x04000654 RID: 1620
		internal static Dictionary<string, int> dictionary_0;

		// Token: 0x04000655 RID: 1621 RVA: 0x000020D0 File Offset: 0x000002D0
		internal static int int_0;

		// Token: 0x04000656 RID: 1622
		internal static Dictionary<string, int> dictionary_1;

		// Token: 0x04000657 RID: 1623
		internal static Dictionary<string, int> dictionary_2;

		// Token: 0x04000658 RID: 1624
		internal static Dictionary<string, int> dictionary_3;

		// Token: 0x04000659 RID: 1625
		internal static Dictionary<string, int> dictionary_4;

		// Token: 0x0400065A RID: 1626
		internal static Dictionary<string, int> dictionary_5;

		// Token: 0x0400065B RID: 1627
		internal static Dictionary<string, int> dictionary_6;
	}
}
