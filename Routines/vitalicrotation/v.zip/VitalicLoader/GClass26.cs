﻿using System;

namespace ns0
{
	// Token: 0x0200004E RID: 78
	[CLSCompliant(false)]
	public class GClass26 : GClass23
	{
		// Token: 0x06000698 RID: 1688 RVA: 0x0000647B File Offset: 0x0000467B
		public GClass26(GClass23 gclass23_3) : base(gclass23_3)
		{
		}
	}
}
