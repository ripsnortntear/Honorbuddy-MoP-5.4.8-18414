﻿using System;

namespace ns0
{
	// Token: 0x0200004D RID: 77
	[CLSCompliant(false)]
	public class GClass25 : GClass24
	{
		// Token: 0x06000696 RID: 1686 RVA: 0x00006452 File Offset: 0x00004652
		public GClass25(GClass23 gclass23_3) : base(gclass23_3)
		{
			base.String_47 = "none";
		}

		// Token: 0x06000697 RID: 1687 RVA: 0x00006466 File Offset: 0x00004666
		public GClass25(GClass23 gclass23_3, GClass23 gclass23_4) : base(gclass23_3, gclass23_4)
		{
			base.String_47 = "none";
		}
	}
}
