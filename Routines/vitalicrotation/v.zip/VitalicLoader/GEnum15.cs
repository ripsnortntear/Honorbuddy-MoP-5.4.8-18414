﻿using System;

namespace ns0
{
	// Token: 0x02000097 RID: 151
	public enum GEnum15
	{
		// Token: 0x04000461 RID: 1121
		const_0,
		// Token: 0x04000462 RID: 1122
		const_1,
		// Token: 0x04000463 RID: 1123
		const_2
	}
}
