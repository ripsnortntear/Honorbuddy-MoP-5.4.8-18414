﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;

namespace ns0
{
	// Token: 0x02000044 RID: 68
	[Designer("MetroFramework.Design.Controls.MetroTextBoxDesigner, MetroFramework.Design, Version=1.4.0.0, Culture=neutral, PublicKeyToken=5f91a84759bf584a")]
	public class GControl3 : Control, GInterface2
	{
		// Token: 0x0600044F RID: 1103 RVA: 0x00004BB9 File Offset: 0x00002DB9
		public GControl3()
		{
			base.SetStyle(ControlStyles.DoubleBuffer | ControlStyles.OptimizedDoubleBuffer, true);
			base.TabStop = false;
			this.method_6();
			this.method_9();
			this.method_8();
		}

		// Token: 0x14000031 RID: 49
		// (add) Token: 0x06000450 RID: 1104 RVA: 0x00011AE8 File Offset: 0x0000FCE8
		// (remove) Token: 0x06000451 RID: 1105 RVA: 0x00011B20 File Offset: 0x0000FD20
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_2
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_0;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000452 RID: 1106 RVA: 0x00004BF4 File Offset: 0x00002DF4
		protected virtual void vmethod_0(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, geventArgs3_0);
			}
		}

		// Token: 0x14000032 RID: 50
		// (add) Token: 0x06000453 RID: 1107 RVA: 0x00011B58 File Offset: 0x0000FD58
		// (remove) Token: 0x06000454 RID: 1108 RVA: 0x00011B90 File Offset: 0x0000FD90
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_3
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_1;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_1, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000455 RID: 1109 RVA: 0x00004C14 File Offset: 0x00002E14
		protected virtual void vmethod_1(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_1 != null)
			{
				this.eventHandler_1(this, geventArgs3_0);
			}
		}

		// Token: 0x14000033 RID: 51
		// (add) Token: 0x06000456 RID: 1110 RVA: 0x00011BC8 File Offset: 0x0000FDC8
		// (remove) Token: 0x06000457 RID: 1111 RVA: 0x00011C00 File Offset: 0x0000FE00
		[Category("Metro Appearance")]
		public event EventHandler<GEventArgs3> Event_4
		{
			add
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler<GEventArgs3> eventHandler = this.eventHandler_2;
				EventHandler<GEventArgs3> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<GEventArgs3> value2 = (EventHandler<GEventArgs3>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<GEventArgs3>>(ref this.eventHandler_2, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000458 RID: 1112 RVA: 0x00004C34 File Offset: 0x00002E34
		protected virtual void vmethod_2(GEventArgs3 geventArgs3_0)
		{
			if (base.GetStyle(ControlStyles.UserPaint) && this.eventHandler_2 != null)
			{
				this.eventHandler_2(this, geventArgs3_0);
			}
		}

		// Token: 0x17000105 RID: 261
		// (get) Token: 0x06000459 RID: 1113 RVA: 0x00011C38 File Offset: 0x0000FE38
		// (set) Token: 0x0600045A RID: 1114 RVA: 0x00004C54 File Offset: 0x00002E54
		[DefaultValue(GEnum10.const_0)]
		[Category("Metro Appearance")]
		public GEnum10 GEnum10_0
		{
			get
			{
				if (base.DesignMode || this.genum10_0 != GEnum10.const_0)
				{
					return this.genum10_0;
				}
				if (this.GClass8_0 != null && this.genum10_0 == GEnum10.const_0)
				{
					return this.GClass8_0.GEnum10_0;
				}
				if (this.GClass8_0 == null && this.genum10_0 == GEnum10.const_0)
				{
					return GEnum10.const_3;
				}
				return this.genum10_0;
			}
			set
			{
				this.genum10_0 = value;
			}
		}

		// Token: 0x17000106 RID: 262
		// (get) Token: 0x0600045B RID: 1115 RVA: 0x00011C90 File Offset: 0x0000FE90
		// (set) Token: 0x0600045C RID: 1116 RVA: 0x00004C5D File Offset: 0x00002E5D
		[Category("Metro Appearance")]
		[DefaultValue(GEnum29.const_0)]
		public GEnum29 GEnum29_0
		{
			get
			{
				if (base.DesignMode || this.genum29_0 != GEnum29.const_0)
				{
					return this.genum29_0;
				}
				if (this.GClass8_0 != null && this.genum29_0 == GEnum29.const_0)
				{
					return this.GClass8_0.GEnum29_0;
				}
				if (this.GClass8_0 == null && this.genum29_0 == GEnum29.const_0)
				{
					return GEnum29.const_1;
				}
				return this.genum29_0;
			}
			set
			{
				this.genum29_0 = value;
			}
		}

		// Token: 0x17000107 RID: 263
		// (get) Token: 0x0600045D RID: 1117 RVA: 0x00004C66 File Offset: 0x00002E66
		// (set) Token: 0x0600045E RID: 1118 RVA: 0x00004C6E File Offset: 0x00002E6E
		[Browsable(false)]
		[DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
		public GClass8 GClass8_0
		{
			get
			{
				return this.gclass8_0;
			}
			set
			{
				this.gclass8_0 = value;
			}
		}

		// Token: 0x17000108 RID: 264
		// (get) Token: 0x0600045F RID: 1119 RVA: 0x00004C77 File Offset: 0x00002E77
		// (set) Token: 0x06000460 RID: 1120 RVA: 0x00004C7F File Offset: 0x00002E7F
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		public bool Boolean_8
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x17000109 RID: 265
		// (get) Token: 0x06000461 RID: 1121 RVA: 0x00004C88 File Offset: 0x00002E88
		// (set) Token: 0x06000462 RID: 1122 RVA: 0x00004C90 File Offset: 0x00002E90
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_9
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x1700010A RID: 266
		// (get) Token: 0x06000463 RID: 1123 RVA: 0x00004C99 File Offset: 0x00002E99
		// (set) Token: 0x06000464 RID: 1124 RVA: 0x00004CA1 File Offset: 0x00002EA1
		[Category("Metro Appearance")]
		[DefaultValue(false)]
		public bool Boolean_10
		{
			get
			{
				return this.bool_2;
			}
			set
			{
				this.bool_2 = value;
			}
		}

		// Token: 0x1700010B RID: 267
		// (get) Token: 0x06000465 RID: 1125 RVA: 0x00002916 File Offset: 0x00000B16
		// (set) Token: 0x06000466 RID: 1126 RVA: 0x00002923 File Offset: 0x00000B23
		[Browsable(false)]
		[DefaultValue(false)]
		[Category("Metro Behaviour")]
		public bool Boolean_11
		{
			get
			{
				return base.GetStyle(ControlStyles.Selectable);
			}
			set
			{
				base.SetStyle(ControlStyles.Selectable, value);
			}
		}

		// Token: 0x1700010C RID: 268
		// (get) Token: 0x06000467 RID: 1127 RVA: 0x00004CAA File Offset: 0x00002EAA
		// (set) Token: 0x06000468 RID: 1128 RVA: 0x00004CB2 File Offset: 0x00002EB2
		[Category("Metro Appearance")]
		[DefaultValue(GEnum19.const_0)]
		public GEnum19 GEnum19_0
		{
			get
			{
				return this.genum19_0;
			}
			set
			{
				this.genum19_0 = value;
				this.method_9();
			}
		}

		// Token: 0x1700010D RID: 269
		// (get) Token: 0x06000469 RID: 1129 RVA: 0x00004CC1 File Offset: 0x00002EC1
		// (set) Token: 0x0600046A RID: 1130 RVA: 0x00004CC9 File Offset: 0x00002EC9
		[Category("Metro Appearance")]
		[DefaultValue(GEnum20.const_1)]
		public GEnum20 GEnum20_0
		{
			get
			{
				return this.genum20_0;
			}
			set
			{
				this.genum20_0 = value;
				this.method_9();
			}
		}

		// Token: 0x1700010E RID: 270
		// (get) Token: 0x0600046B RID: 1131 RVA: 0x00004CD8 File Offset: 0x00002ED8
		// (set) Token: 0x0600046C RID: 1132 RVA: 0x00004CE5 File Offset: 0x00002EE5
		[DefaultValue("")]
		[Category("Metro Appearance")]
		[EditorBrowsable(EditorBrowsableState.Always)]
		[Browsable(true)]
		public string String_0
		{
			get
			{
				return this.class9_0.String_0;
			}
			set
			{
				this.class9_0.String_0 = value;
			}
		}

		// Token: 0x1700010F RID: 271
		// (get) Token: 0x0600046D RID: 1133 RVA: 0x00004CF3 File Offset: 0x00002EF3
		// (set) Token: 0x0600046E RID: 1134 RVA: 0x00004CFB File Offset: 0x00002EFB
		[Browsable(true)]
		[EditorBrowsable(EditorBrowsableState.Always)]
		[Category("Metro Appearance")]
		[DefaultValue(null)]
		public Image Image_0
		{
			get
			{
				return this.image_0;
			}
			set
			{
				this.image_0 = value;
				this.Refresh();
			}
		}

		// Token: 0x17000110 RID: 272
		// (get) Token: 0x0600046F RID: 1135 RVA: 0x00004D0A File Offset: 0x00002F0A
		// (set) Token: 0x06000470 RID: 1136 RVA: 0x00004D12 File Offset: 0x00002F12
		[Browsable(true)]
		[DefaultValue(false)]
		[Category("Metro Appearance")]
		[EditorBrowsable(EditorBrowsableState.Always)]
		public bool Boolean_0
		{
			get
			{
				return this.bool_3;
			}
			set
			{
				this.bool_3 = value;
				this.Refresh();
			}
		}

		// Token: 0x17000111 RID: 273
		// (get) Token: 0x06000471 RID: 1137 RVA: 0x00004D21 File Offset: 0x00002F21
		// (set) Token: 0x06000472 RID: 1138 RVA: 0x00004D29 File Offset: 0x00002F29
		[Category("Metro Appearance")]
		[Browsable(true)]
		[DefaultValue(true)]
		[EditorBrowsable(EditorBrowsableState.Always)]
		public bool Boolean_1
		{
			get
			{
				return this.bool_4;
			}
			set
			{
				this.bool_4 = value;
				this.Refresh();
			}
		}

		// Token: 0x17000112 RID: 274
		// (get) Token: 0x06000473 RID: 1139 RVA: 0x00011CE8 File Offset: 0x0000FEE8
		protected Size Size_0
		{
			get
			{
				if (this.bool_4 && this.image_0 != null)
				{
					Size size = this.image_0.Size;
					double num = (double)(base.ClientRectangle.Height - 2) / (double)size.Height;
					new Point(1, 1);
					return new Size((int)((double)size.Width * num), (int)((double)size.Height * num));
				}
				return new Size(-1, -1);
			}
		}

		// Token: 0x17000113 RID: 275
		// (get) Token: 0x06000474 RID: 1140 RVA: 0x00004D38 File Offset: 0x00002F38
		// (set) Token: 0x06000475 RID: 1141 RVA: 0x00004D45 File Offset: 0x00002F45
		public override ContextMenu ContextMenu
		{
			get
			{
				return this.class9_0.ContextMenu;
			}
			set
			{
				this.ContextMenu = value;
				this.class9_0.ContextMenu = value;
			}
		}

		// Token: 0x17000114 RID: 276
		// (get) Token: 0x06000476 RID: 1142 RVA: 0x00004D5A File Offset: 0x00002F5A
		// (set) Token: 0x06000477 RID: 1143 RVA: 0x00004D67 File Offset: 0x00002F67
		public override ContextMenuStrip ContextMenuStrip
		{
			get
			{
				return this.class9_0.ContextMenuStrip;
			}
			set
			{
				this.ContextMenuStrip = value;
				this.class9_0.ContextMenuStrip = value;
			}
		}

		// Token: 0x17000115 RID: 277
		// (get) Token: 0x06000478 RID: 1144 RVA: 0x00004D7C File Offset: 0x00002F7C
		// (set) Token: 0x06000479 RID: 1145 RVA: 0x00004D89 File Offset: 0x00002F89
		[DefaultValue(false)]
		public bool Boolean_2
		{
			get
			{
				return this.class9_0.Multiline;
			}
			set
			{
				this.class9_0.Multiline = value;
			}
		}

		// Token: 0x17000116 RID: 278
		// (get) Token: 0x0600047A RID: 1146 RVA: 0x00004D97 File Offset: 0x00002F97
		// (set) Token: 0x0600047B RID: 1147 RVA: 0x00004DA4 File Offset: 0x00002FA4
		public override string Text
		{
			get
			{
				return this.class9_0.Text;
			}
			set
			{
				this.class9_0.Text = value;
			}
		}

		// Token: 0x17000117 RID: 279
		// (get) Token: 0x0600047C RID: 1148 RVA: 0x00004DB2 File Offset: 0x00002FB2
		// (set) Token: 0x0600047D RID: 1149 RVA: 0x00004DBF File Offset: 0x00002FBF
		public string[] String_1
		{
			get
			{
				return this.class9_0.Lines;
			}
			set
			{
				this.class9_0.Lines = value;
			}
		}

		// Token: 0x17000118 RID: 280
		// (get) Token: 0x0600047E RID: 1150 RVA: 0x00004DCD File Offset: 0x00002FCD
		// (set) Token: 0x0600047F RID: 1151 RVA: 0x00004DA4 File Offset: 0x00002FA4
		[Browsable(false)]
		public string String_2
		{
			get
			{
				return this.class9_0.SelectedText;
			}
			set
			{
				this.class9_0.Text = value;
			}
		}

		// Token: 0x17000119 RID: 281
		// (get) Token: 0x06000480 RID: 1152 RVA: 0x00004DDA File Offset: 0x00002FDA
		// (set) Token: 0x06000481 RID: 1153 RVA: 0x00004DE7 File Offset: 0x00002FE7
		[DefaultValue(false)]
		public bool Boolean_3
		{
			get
			{
				return this.class9_0.ReadOnly;
			}
			set
			{
				this.class9_0.ReadOnly = value;
			}
		}

		// Token: 0x1700011A RID: 282
		// (get) Token: 0x06000482 RID: 1154 RVA: 0x00004DF5 File Offset: 0x00002FF5
		// (set) Token: 0x06000483 RID: 1155 RVA: 0x00004E02 File Offset: 0x00003002
		public char Char_0
		{
			get
			{
				return this.class9_0.PasswordChar;
			}
			set
			{
				this.class9_0.PasswordChar = value;
			}
		}

		// Token: 0x1700011B RID: 283
		// (get) Token: 0x06000484 RID: 1156 RVA: 0x00004E10 File Offset: 0x00003010
		// (set) Token: 0x06000485 RID: 1157 RVA: 0x00004E1D File Offset: 0x0000301D
		[DefaultValue(false)]
		public bool Boolean_4
		{
			get
			{
				return this.class9_0.UseSystemPasswordChar;
			}
			set
			{
				this.class9_0.UseSystemPasswordChar = value;
			}
		}

		// Token: 0x1700011C RID: 284
		// (get) Token: 0x06000486 RID: 1158 RVA: 0x00004E2B File Offset: 0x0000302B
		// (set) Token: 0x06000487 RID: 1159 RVA: 0x00004E38 File Offset: 0x00003038
		[DefaultValue(HorizontalAlignment.Left)]
		public HorizontalAlignment HorizontalAlignment_0
		{
			get
			{
				return this.class9_0.TextAlign;
			}
			set
			{
				this.class9_0.TextAlign = value;
			}
		}

		// Token: 0x1700011D RID: 285
		// (get) Token: 0x06000488 RID: 1160 RVA: 0x00004E46 File Offset: 0x00003046
		// (set) Token: 0x06000489 RID: 1161 RVA: 0x00004E53 File Offset: 0x00003053
		[DefaultValue(true)]
		public bool Boolean_5
		{
			get
			{
				return this.class9_0.TabStop;
			}
			set
			{
				this.class9_0.TabStop = value;
			}
		}

		// Token: 0x1700011E RID: 286
		// (get) Token: 0x0600048A RID: 1162 RVA: 0x00004E61 File Offset: 0x00003061
		// (set) Token: 0x0600048B RID: 1163 RVA: 0x00004E6E File Offset: 0x0000306E
		public int Int32_0
		{
			get
			{
				return this.class9_0.MaxLength;
			}
			set
			{
				this.class9_0.MaxLength = value;
			}
		}

		// Token: 0x1700011F RID: 287
		// (get) Token: 0x0600048C RID: 1164 RVA: 0x00004E7C File Offset: 0x0000307C
		// (set) Token: 0x0600048D RID: 1165 RVA: 0x00004E89 File Offset: 0x00003089
		public ScrollBars ScrollBars_0
		{
			get
			{
				return this.class9_0.ScrollBars;
			}
			set
			{
				this.class9_0.ScrollBars = value;
			}
		}

		// Token: 0x14000034 RID: 52
		// (add) Token: 0x0600048E RID: 1166 RVA: 0x00011D58 File Offset: 0x0000FF58
		// (remove) Token: 0x0600048F RID: 1167 RVA: 0x00011D90 File Offset: 0x0000FF90
		public event EventHandler Event_0
		{
			add
			{
				EventHandler eventHandler = this.eventHandler_3;
				EventHandler eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler value2 = (EventHandler)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_3, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			remove
			{
				EventHandler eventHandler = this.eventHandler_3;
				EventHandler eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler value2 = (EventHandler)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler>(ref this.eventHandler_3, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000490 RID: 1168 RVA: 0x00004E97 File Offset: 0x00003097
		private void class9_0_AcceptsTabChanged(object sender, EventArgs e)
		{
			if (this.eventHandler_3 != null)
			{
				this.eventHandler_3(this, e);
			}
		}

		// Token: 0x06000491 RID: 1169 RVA: 0x00004EAE File Offset: 0x000030AE
		private void class9_0_SizeChanged(object sender, EventArgs e)
		{
			base.OnSizeChanged(e);
		}

		// Token: 0x06000492 RID: 1170 RVA: 0x00004EB7 File Offset: 0x000030B7
		private void method_0(object sender, EventArgs e)
		{
			base.OnCursorChanged(e);
		}

		// Token: 0x06000493 RID: 1171 RVA: 0x00004EC0 File Offset: 0x000030C0
		private void class9_0_ContextMenuStripChanged(object sender, EventArgs e)
		{
			base.OnContextMenuStripChanged(e);
		}

		// Token: 0x06000494 RID: 1172 RVA: 0x00004EC9 File Offset: 0x000030C9
		private void class9_0_ContextMenuChanged(object sender, EventArgs e)
		{
			base.OnContextMenuChanged(e);
		}

		// Token: 0x06000495 RID: 1173 RVA: 0x00004ED2 File Offset: 0x000030D2
		private void class9_0_ClientSizeChanged(object sender, EventArgs e)
		{
			base.OnClientSizeChanged(e);
		}

		// Token: 0x06000496 RID: 1174 RVA: 0x00004EDB File Offset: 0x000030DB
		private void class9_0_Click(object sender, EventArgs e)
		{
			base.Invalidate();
			base.OnClick(e);
		}

		// Token: 0x06000497 RID: 1175 RVA: 0x00004EEA File Offset: 0x000030EA
		private void class9_0_ChangeUICues(object sender, UICuesEventArgs e)
		{
			base.OnChangeUICues(e);
		}

		// Token: 0x06000498 RID: 1176 RVA: 0x00004EF3 File Offset: 0x000030F3
		private void class9_0_CausesValidationChanged(object sender, EventArgs e)
		{
			base.OnCausesValidationChanged(e);
		}

		// Token: 0x06000499 RID: 1177 RVA: 0x00004EFC File Offset: 0x000030FC
		private void class9_0_KeyUp(object sender, KeyEventArgs e)
		{
			if (e.KeyData == Keys.Return || e.KeyData == Keys.Escape)
			{
				e.SuppressKeyPress = true;
				base.Parent.Focus();
				this.bool_5 = false;
				base.Invalidate();
			}
			base.OnKeyUp(e);
		}

		// Token: 0x0600049A RID: 1178 RVA: 0x00004F39 File Offset: 0x00003139
		private void class9_0_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == '\r' || e.KeyChar == '\u001b')
			{
				e.Handled = true;
			}
			base.OnKeyPress(e);
		}

		// Token: 0x0600049B RID: 1179 RVA: 0x00004F5D File Offset: 0x0000315D
		private void class9_0_KeyDown(object sender, KeyEventArgs e)
		{
			base.OnKeyDown(e);
		}

		// Token: 0x0600049C RID: 1180 RVA: 0x00004F66 File Offset: 0x00003166
		private void class9_0_TextChanged(object sender, EventArgs e)
		{
			base.OnTextChanged(e);
		}

		// Token: 0x0600049D RID: 1181 RVA: 0x00004F6F File Offset: 0x0000316F
		private void class9_0_MouseMove(object sender, MouseEventArgs e)
		{
			base.OnMouseMove(e);
		}

		// Token: 0x0600049E RID: 1182 RVA: 0x00004F78 File Offset: 0x00003178
		private void class9_0_MouseEnter(object sender, EventArgs e)
		{
			this.bool_5 = true;
			base.Invalidate();
			base.OnMouseEnter(e);
		}

		// Token: 0x0600049F RID: 1183 RVA: 0x00004F8E File Offset: 0x0000318E
		private void class9_0_MouseLeave(object sender, EventArgs e)
		{
			this.bool_5 = false;
			base.Invalidate();
			base.OnMouseLeave(e);
		}

		// Token: 0x060004A0 RID: 1184 RVA: 0x00004FA4 File Offset: 0x000031A4
		public void method_1(int int_0, int int_1)
		{
			this.class9_0.Select(int_0, int_1);
		}

		// Token: 0x060004A1 RID: 1185 RVA: 0x00004FB3 File Offset: 0x000031B3
		public void method_2()
		{
			this.class9_0.SelectAll();
		}

		// Token: 0x060004A2 RID: 1186 RVA: 0x00004FC0 File Offset: 0x000031C0
		public void method_3()
		{
			this.class9_0.Clear();
		}

		// Token: 0x060004A3 RID: 1187 RVA: 0x00004FCD File Offset: 0x000031CD
		public void method_4(string string_0)
		{
			this.class9_0.AppendText(string_0);
		}

		// Token: 0x060004A4 RID: 1188 RVA: 0x00011DC8 File Offset: 0x0000FFC8
		protected override void OnPaintBackground(PaintEventArgs e)
		{
			try
			{
				Color color = this.BackColor;
				this.class9_0.BackColor = this.BackColor;
				if (!this.bool_0)
				{
					color = GClass39.GClass46.GClass47.smethod_0(this.GEnum29_0);
					this.class9_0.BackColor = GClass39.GClass46.GClass47.smethod_0(this.GEnum29_0);
				}
				if (color.A == 255)
				{
					e.Graphics.Clear(color);
				}
				else
				{
					base.OnPaintBackground(e);
					this.vmethod_0(new GEventArgs3(color, Color.Empty, e.Graphics));
				}
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060004A5 RID: 1189 RVA: 0x00011E6C File Offset: 0x0001006C
		protected override void OnPaint(PaintEventArgs e)
		{
			try
			{
				if (base.GetStyle(ControlStyles.AllPaintingInWmPaint))
				{
					this.OnPaintBackground(e);
				}
				this.vmethod_1(new GEventArgs3(Color.Empty, Color.Empty, e.Graphics));
				this.vmethod_3(e);
			}
			catch
			{
				base.Invalidate();
			}
		}

		// Token: 0x060004A6 RID: 1190 RVA: 0x00011ECC File Offset: 0x000100CC
		protected virtual void vmethod_3(PaintEventArgs paintEventArgs_0)
		{
			if (this.bool_1)
			{
				this.class9_0.ForeColor = this.ForeColor;
			}
			else
			{
				this.class9_0.ForeColor = GClass39.GClass56.GClass57.smethod_0(this.GEnum29_0);
			}
			Color color = GClass39.GClass40.GClass41.smethod_0(this.GEnum29_0);
			if (this.bool_2)
			{
				color = GClass39.smethod_0(this.GEnum10_0);
			}
			if (this.bool_5 && base.Enabled && !this.bool_2)
			{
				color = GClass39.GClass40.GClass43.smethod_1(this.GEnum29_0);
			}
			using (Pen pen = new Pen(color))
			{
				paintEventArgs_0.Graphics.DrawRectangle(pen, new Rectangle(0, 0, base.Width - 1, base.Height - 1));
			}
			this.method_5(paintEventArgs_0.Graphics);
		}

		// Token: 0x060004A7 RID: 1191 RVA: 0x00011FA0 File Offset: 0x000101A0
		private void method_5(Graphics graphics_0)
		{
			if (this.bool_4 && this.image_0 != null)
			{
				Point location = new Point(1, 1);
				if (this.bool_3)
				{
					location = new Point(base.ClientRectangle.Width - this.Size_0.Width - 1, 1);
				}
				graphics_0.DrawImage(this.image_0, new Rectangle(location, this.Size_0));
				this.method_9();
			}
			this.vmethod_2(new GEventArgs3(Color.Empty, this.class9_0.ForeColor, graphics_0));
		}

		// Token: 0x060004A8 RID: 1192 RVA: 0x00004FDB File Offset: 0x000031DB
		public override void Refresh()
		{
			base.Refresh();
			this.method_9();
		}

		// Token: 0x060004A9 RID: 1193 RVA: 0x00004FE9 File Offset: 0x000031E9
		protected override void OnResize(EventArgs e)
		{
			base.OnResize(e);
			this.method_9();
		}

		// Token: 0x060004AA RID: 1194 RVA: 0x00012030 File Offset: 0x00010230
		private void method_6()
		{
			if (this.class9_0 != null)
			{
				return;
			}
			this.class9_0 = new GControl3.Class9();
			this.class9_0.BorderStyle = BorderStyle.None;
			this.class9_0.Font = GClass67.smethod_8(this.genum19_0, this.genum20_0);
			this.class9_0.Location = new Point(3, 3);
			this.class9_0.Size = new Size(base.Width - 6, base.Height - 6);
			base.Size = new Size(this.class9_0.Width + 6, this.class9_0.Height + 6);
			this.class9_0.TabStop = true;
			base.Controls.Add(this.class9_0);
		}

		// Token: 0x060004AB RID: 1195 RVA: 0x000120F0 File Offset: 0x000102F0
		public bool method_7()
		{
			return this.class9_0.ClientRectangle.Contains(base.PointToClient(Control.MousePosition));
		}

		// Token: 0x060004AC RID: 1196 RVA: 0x0001211C File Offset: 0x0001031C
		private void method_8()
		{
			this.class9_0.AcceptsTabChanged += this.class9_0_AcceptsTabChanged;
			this.class9_0.CausesValidationChanged += this.class9_0_CausesValidationChanged;
			this.class9_0.ChangeUICues += this.class9_0_ChangeUICues;
			this.class9_0.Click += this.class9_0_Click;
			this.class9_0.ClientSizeChanged += this.class9_0_ClientSizeChanged;
			this.class9_0.ContextMenuChanged += this.class9_0_ContextMenuChanged;
			this.class9_0.ContextMenuStripChanged += this.class9_0_ContextMenuStripChanged;
			this.class9_0.MouseMove += this.class9_0_MouseMove;
			this.class9_0.MouseEnter += this.class9_0_MouseEnter;
			this.class9_0.MouseLeave += this.class9_0_MouseLeave;
			this.class9_0.KeyDown += this.class9_0_KeyDown;
			this.class9_0.KeyPress += this.class9_0_KeyPress;
			this.class9_0.KeyUp += this.class9_0_KeyUp;
			this.class9_0.SizeChanged += this.class9_0_SizeChanged;
			this.class9_0.TextChanged += this.class9_0_TextChanged;
		}

		// Token: 0x060004AD RID: 1197 RVA: 0x00012284 File Offset: 0x00010484
		private void method_9()
		{
			if (this.class9_0 == null)
			{
				return;
			}
			this.class9_0.Font = GClass67.smethod_8(this.genum19_0, this.genum20_0);
			if (this.bool_4)
			{
				Point location = new Point(this.Size_0.Width + 4, 3);
				if (this.bool_3)
				{
					location = new Point(3, 3);
				}
				this.class9_0.Location = location;
				this.class9_0.Size = new Size(base.Width - 7 - this.Size_0.Width, base.Height - 6);
				return;
			}
			this.class9_0.Location = new Point(3, 3);
			this.class9_0.Size = new Size(base.Width - 6, base.Height - 6);
		}

		// Token: 0x04000198 RID: 408
		private EventHandler<GEventArgs3> eventHandler_0;

		// Token: 0x04000199 RID: 409
		private EventHandler<GEventArgs3> eventHandler_1;

		// Token: 0x0400019A RID: 410
		private EventHandler<GEventArgs3> eventHandler_2;

		// Token: 0x0400019B RID: 411
		private GEnum10 genum10_0;

		// Token: 0x0400019C RID: 412
		private GEnum29 genum29_0;

		// Token: 0x0400019D RID: 413
		private GClass8 gclass8_0;

		// Token: 0x0400019E RID: 414
		private bool bool_0;

		// Token: 0x0400019F RID: 415
		private bool bool_1;

		// Token: 0x040001A0 RID: 416
		private bool bool_2;

		// Token: 0x040001A1 RID: 417
		private GControl3.Class9 class9_0;

		// Token: 0x040001A2 RID: 418
		private GEnum19 genum19_0;

		// Token: 0x040001A3 RID: 419
		private GEnum20 genum20_0 = GEnum20.const_1;

		// Token: 0x040001A4 RID: 420
		private Image image_0;

		// Token: 0x040001A5 RID: 421
		private bool bool_3;

		// Token: 0x040001A6 RID: 422
		private bool bool_4 = true;

		// Token: 0x040001A7 RID: 423
		private bool bool_5;

		// Token: 0x040001A8 RID: 424
		private EventHandler eventHandler_3;

		// Token: 0x02000045 RID: 69
		private class Class9 : TextBox
		{
			// Token: 0x060004AE RID: 1198 RVA: 0x00004FF8 File Offset: 0x000031F8
			public Class9()
			{
				this.bool_0 = (this.Text.Trim().Length == 0);
			}

			// Token: 0x17000120 RID: 288
			// (get) Token: 0x060004AF RID: 1199 RVA: 0x00005024 File Offset: 0x00003224
			// (set) Token: 0x060004B0 RID: 1200 RVA: 0x0000502C File Offset: 0x0000322C
			[Browsable(true)]
			[EditorBrowsable(EditorBrowsableState.Always)]
			[DefaultValue("")]
			public string String_0
			{
				get
				{
					return this.string_0;
				}
				set
				{
					this.string_0 = value.Trim();
					base.Invalidate();
				}
			}

			// Token: 0x060004B1 RID: 1201 RVA: 0x00012358 File Offset: 0x00010558
			private void method_0()
			{
				using (Graphics graphics = base.CreateGraphics())
				{
					this.method_1(graphics);
				}
			}

			// Token: 0x060004B2 RID: 1202 RVA: 0x00012390 File Offset: 0x00010590
			private void method_1(Graphics graphics_0)
			{
				TextFormatFlags textFormatFlags = TextFormatFlags.EndEllipsis | TextFormatFlags.NoPadding;
				Rectangle clientRectangle = base.ClientRectangle;
				clientRectangle.Offset(3, 0);
				switch (base.TextAlign)
				{
				case HorizontalAlignment.Left:
					clientRectangle.Offset(1, 1);
					break;
				case HorizontalAlignment.Right:
					textFormatFlags |= TextFormatFlags.Right;
					clientRectangle.Offset(0, 1);
					break;
				case HorizontalAlignment.Center:
					textFormatFlags |= TextFormatFlags.HorizontalCenter;
					clientRectangle.Offset(0, 1);
					break;
				}
				TextRenderer.DrawText(graphics_0, this.string_0, this.Font, clientRectangle, SystemColors.GrayText, this.BackColor, textFormatFlags);
			}

			// Token: 0x060004B3 RID: 1203 RVA: 0x00005040 File Offset: 0x00003240
			protected override void OnPaint(PaintEventArgs e)
			{
				base.OnPaint(e);
				if (this.bool_0 && !this.Focused)
				{
					this.method_1(e.Graphics);
				}
			}

			// Token: 0x060004B4 RID: 1204 RVA: 0x00005065 File Offset: 0x00003265
			protected override void OnTextAlignChanged(EventArgs e)
			{
				base.OnTextAlignChanged(e);
				base.Invalidate();
			}

			// Token: 0x060004B5 RID: 1205 RVA: 0x00005074 File Offset: 0x00003274
			protected override void OnTextChanged(EventArgs e)
			{
				base.OnTextChanged(e);
				this.bool_0 = (this.Text.Trim().Length == 0);
			}

			// Token: 0x060004B6 RID: 1206 RVA: 0x00012414 File Offset: 0x00010614
			protected override void OnGotFocus(EventArgs e)
			{
				bool flag = false;
				if (!this.bool_1)
				{
					this.bool_1 = true;
					if (this.SelectionLength == 0 && Control.MouseButtons == MouseButtons.None)
					{
						flag = true;
					}
				}
				base.OnGotFocus(e);
				if (flag)
				{
					base.SelectionStart = this.Text.Length;
					base.DeselectAll();
				}
			}

			// Token: 0x17000121 RID: 289
			// (get) Token: 0x060004B7 RID: 1207 RVA: 0x00005096 File Offset: 0x00003296
			// (set) Token: 0x060004B8 RID: 1208 RVA: 0x0000509E File Offset: 0x0000329E
			public override string Text
			{
				get
				{
					return base.Text;
				}
				set
				{
					base.Text = value;
					this.bool_1 = false;
				}
			}

			// Token: 0x060004B9 RID: 1209
			[DllImport("user32.dll", CharSet = CharSet.Auto)]
			public static extern IntPtr SendMessage(HandleRef handleRef_0, int int_3, int int_4, int int_5);

			// Token: 0x060004BA RID: 1210 RVA: 0x000050AE File Offset: 0x000032AE
			internal IntPtr method_2(int int_3, int int_4, int int_5)
			{
				return GControl3.Class9.SendMessage(new HandleRef(this, base.Handle), int_3, int_4, int_5);
			}

			// Token: 0x060004BB RID: 1211 RVA: 0x000050C4 File Offset: 0x000032C4
			private void method_3(ref Message message_0)
			{
				base.WndProc(ref message_0);
				this.method_2(211, 1, 5);
			}

			// Token: 0x060004BC RID: 1212 RVA: 0x00012464 File Offset: 0x00010664
			protected override void WndProc(ref Message m)
			{
				if (m.Msg == 32)
				{
					m.Result = (IntPtr)1;
					return;
				}
				if (m.Msg == 48)
				{
					this.method_3(ref m);
					return;
				}
				base.WndProc(ref m);
				if ((m.Msg == 15 || m.Msg == 8465) && this.bool_0 && !this.Focused && !base.GetStyle(ControlStyles.UserPaint))
				{
					this.method_0();
				}
			}

			// Token: 0x040001A9 RID: 425
			private const int int_0 = 8465;

			// Token: 0x040001AA RID: 426
			private const int int_1 = 15;

			// Token: 0x040001AB RID: 427
			private const int int_2 = 211;

			// Token: 0x040001AC RID: 428
			private bool bool_0;

			// Token: 0x040001AD RID: 429
			private bool bool_1;

			// Token: 0x040001AE RID: 430
			private string string_0 = "";
		}
	}
}
