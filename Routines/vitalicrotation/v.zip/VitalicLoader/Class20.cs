﻿using System;

namespace ns0
{
	// Token: 0x0200008C RID: 140
	internal static class Class20
	{
		// Token: 0x0400042C RID: 1068
		internal const string string_0 = "MetroFrameworkVitalic.dll";

		// Token: 0x0400042D RID: 1069
		internal const string string_1 = "1.4.0.0";

		// Token: 0x0400042E RID: 1070
		internal const string string_2 = "Metro UI Framework for Vitalic Elite Rogue";

		// Token: 0x0400042F RID: 1071
		internal const string string_3 = "";

		// Token: 0x04000430 RID: 1072
		internal const string string_4 = "";

		// Token: 0x04000431 RID: 1073
		internal const string string_5 = "";
	}
}
